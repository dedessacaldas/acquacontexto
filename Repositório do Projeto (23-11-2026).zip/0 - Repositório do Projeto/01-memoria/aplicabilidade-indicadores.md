---
name: aplicabilidade-indicadores
description: Quais indicadores do Anexo 8 valem para cada uma das 14 travessias, alcance do expurgo 2.6 e regras 4.5/4.6 (13/11/2026)
metadata:
  type: project
---

Anexo 2: 14 travessias — Litoral (SS–Ilhabela; Santos–V. Carvalho; Santos–Guarujá; Bertioga–Guarujá; Iguape–Juréia; Cananéia–Continente; Cananéia–IC; Cananéia–Ariri), Metropolitana/EMAE (João Basso–Riacho Grande; Taquacetuba–Bororé 1; Bororé 2–Grajaú), Paraibuna (Comércio–Varginha; Capim D'Angola–Ribeirão Branco; Natividade da Serra–Bairro Alto–Pouso Alto).

Aplicabilidade (Anexo 8): IVP só litorâneas e metropolitanas (9.1.2) → Paraibuna sem IVP. IHP nos períodos de horário fixo (9.2.3), ITP nos de intervalo (9.3.2); peso 0,34 dividido por n1/n2. IDF, IOE, IAU, IRE todas (9.5.2, 9.4.2, 9.7.3); IOE fora do IQS (3.4.6). IAD só travessias da Tabela 5 (9.6.2) → só Cananéia–Ariri fica sem IAD; SS–Ilhabela tem IAD veículos e passageiros. Out/26: só Santos–Guarujá e SS têm períodos por intervalo (ITP).

Expurgo 2.6 só para IVP, IHP, ITP, IAD. No IAD a hora expurgada sai do HOC e do HPF. 4.5: indicador não aferível por culpa da concessionária = nota 0 (risco das horas NO_DATA do IAD). 4.6: redistribuição de peso só prevista p/ impossibilidade imputável ao Poder Concedente; a aplicação também redistribui p/ indicador não aplicável (validar com VI).

Ver [[auditoria-indicadores-2026-10]], [[informativo-expurgos]], [[iad-tempo-de-fila]].
