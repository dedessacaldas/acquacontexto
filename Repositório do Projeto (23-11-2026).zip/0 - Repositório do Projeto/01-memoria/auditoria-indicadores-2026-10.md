---
name: auditoria-indicadores-2026-10
description: Revisão da planilha Indicadores_2026-10 (IQS concessão 0,60) contra o Anexo 8: causas dos zeros e lacunas de dados (09/11/2026)
metadata:
  type: project
  modified: 2026-11-09T16:15:04.876Z
---

Planilha gerada pela aplicação (dados do "Drive"/SIGO), 27 abas, mês não fechado. IQS concessão out/26 = 0,60 (set 0,56; ago 0,55).

Fórmulas conferem com o Anexo 8 (limites Etapas 1–3, nota (x−LO2)/(LO1−LO2), ITP2 com mín(1;NVP/NVR), média ponderada pela tarifa, madrugada fora de IHP/ITP). Achados:
- IAD = 0 em 7 de 8 travessias: fonte ESTIMATE = espera igual ao intervalo da grade (Iguape 30 min em 884/992 h; Cananéia–Continente 60 min em 968 h). Anexo 9.6.4.1 exige medição amostral por placas p/ veículos; só Santos–Guarujá tem MEASURED (5 dias). São Sebastião: série de passageiros idêntica à de veículos (copiada).
- Cananéia–Ariri IVP 0,46: grade tem 2 viagens/dia no mesmo sentido; só 1 registrada/dia → erro de programação ou registro.
- São Sebastião IHP 0,20: regras de horário fixo "em paralelo" à janela de intervalo (868 viagens, 730 sem partida). Sem paralelo IHP=1 → IQS 0,51→0,69.
- 1.032 passagens de navio em Santos–Guarujá rejeitadas por DID_NOT_STOP; Anexo 2.6(ii) exclui também atrasos, não só paralisação.
- Etapa em branco; regra 8.3.1.2/8.4.1.3 (comparar com Indicadores Preliminares Referenciais → nota 1) não aplicada.
- Média móvel usa out+set+ago; Anexo 3.5 escreve n-1,n-2,n-3.
- IOE sem fator 1,5 (VUC/ambulância/carro-forte); lanchas com poucos dias de dado.

IAD revisto em 13/11 (explicação didática pedida pela Dedessa): o 0 é a NOTA, não o IAD1. IAD1 ~0,4 (Bertioga 0,41; Can.-IC 0,44; Iguape 0,45; Can.-Cont. 0,01; SG medido 0,69 c/ 5 dias; SS veíc. 0,21, pass. −0,29) < LO2 0,85 → nota 0. Só V. Carvalho passa (0,94 → 0,93). Causa: espera ESTIMATE = intervalo da grade por sentido (aba Viagens col. Horário programado) em Iguape 455/496 h e Can.-Cont. 484/496; parcial em V. Carvalho 327, Can.-IC 228; Bertioga só 143 (resto valores quebrados, parecem registros reais, fila acima da tolerância); SS e SG não. Espera idêntica nos lados 1 e 2 em todas as horas (exceto SG/SS) → PER_SIDE só duplica. (Iguape 30=ref → toda hora H0 → teto IAD1 0,5; Can.-Cont. 60 = 2×ref → toda hora H1). PER_SIDE não causa o zero (leitura por travessia também dá 0). Para nota>0 é preciso HPF ≤ 15% do HOC. Simulação c/ espera = ½ intervalo: Bertioga/Cananéias 1,0, Iguape 0,96 (só sensibilidade).

Exportação ExportTemposEmbarque15minReport (Cananéia–Continente, 15 min, por margem, campo Tempo) = fonte da aplicação: só valores 30/60/90/120, 60 em 948/960 h, margens idênticas → campo parece ser intervalo até a próxima balsa, não espera média (9.6.2). Recalculado IAD1 0,01, nota 0. Grade 1 partida/h por sentido + ref 30 sem tolerância = travessia no limite mesmo com medição real.
Exportação de todas as travessias (13/11): margens idênticas e 2–3 valores redondos em 6 de 8 (só SG e SS variam); Paraibuna campo vazio; Ariri 0. Recalculo c/ média simples: V. Carvalho 0,87 (nota 0,16) vs app 0,94 (0,93); demais nota 0. App não bate hora a hora c/ export (Bertioga 15%); indício de defasagem 3h no 'Data Hora' (pico 12 min de V. Carvalho às 2–5h e 13–16h no export). Pendente: perguntar ao dev a fonte/fuso.

Ver [[iad-tempo-de-fila]], [[definicao-viagem-embarque]], [[informativo-indicadores]].
