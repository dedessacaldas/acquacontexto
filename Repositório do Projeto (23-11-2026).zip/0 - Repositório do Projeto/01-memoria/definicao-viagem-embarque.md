---
name: definicao-viagem-embarque
description: Contrato não define início/fim de embarque nem de viagem; trechos mais próximos (Anexo 17, Anexo 8 IVP/IHP/IAD) (04/11/2026)
metadata:
  type: project
  modified: 2026-11-04T11:56:59.878Z
---

Busca feita em 04/11/2026 no Contrato SPI 012-2026 e Anexos 1, 3A, 3B, 8, 16, 17 (texto extraído com pdftotext). Não há definição explícita de início/fim de embarque nem de início/fim de viagem. Anexos 1, 16, 3B e corpo do contrato não tratam do tema. Revisado em 11/11/2026 com o contrato assinado e o Anexo 14 (agora na raiz de /mnt/project-files/): contrato Cl. 1ª remete as definições ao Anexo 17; Anexo 14 não define partida nem viagem, só usa PARTIDAS BASE (PMF), PARTIDAS ADICIONAIS e QUANTIDADE DE VIAGENS (QV) na Tabela 1 do item 2.1.5; nela QV = 4 × PMF em todos os anos (ex.: ano 1, 145.887 partidas e 583.548 viagens). A razão 4 não é explicada no texto.

Mais próximo:
- Anexo 17, QUANTIDADE DE VIAGENS: "deslocamento de uma embarcação operante, válidas nos termos do ANEXO 3A, entre um terminal da saída e um terminal de chegada. Para fins de controle, contabilizada como o total de chegadas e saídas de um único terminal, por TRAVESSIA."
- Anexo 8, 9.1.5 (IVP): atraso > 15 min = viagem não realizada. 9.2.6 (IHP): no horário = "partem entre 2 minutos antes e 5 minutos depois do horário programado". 9.2.2: banco registra "Horário efetivo (hora e minuto) de realização da viagem". O marco é a partida, mas "partir" não é definido.
- Anexo 8, 9.6.4 (IAD): fila vai "até o momento do embarque" (veículos) ou até "cruzarem a barreira de controle do terminal de embarque" (pedestres/ciclistas). 9.6.4.1: placa na chegada à fila e no "momento de embarque".
- Anexo 3A 2.6.9.1: partidas extras da programação excepcional só contam com ocupação mínima de 65%.

Lacuna a resolver com ARTESP/Verificador (marco de partida = desatracação? recolhimento de rampa?). Ver [[programacao-viagens-rev08]], [[iad-tempo-de-fila]].

13/11/2026: viagem vazia (reposicionar embarcação na outra margem p/ demanda) — nenhuma cláusula trata expressamente. Base indireta: Anexo 17 QUANTIDADE DE VIAGENS (deslocamento de embarcação operante, sem exigir carga); Anexo 3A Tabelas 1–13 "conforme demanda, observando intervalo máximo" (pede saída de cada margem); risco: 3A 2.6.9.1–2.6.9.2 (PDF p.13–14) só em programação EXCEPCIONAL exige ocupação ≥65% p/ contar partida; A8 9.4.11 IOE baixo indica rever frequências (fora do IQS).
