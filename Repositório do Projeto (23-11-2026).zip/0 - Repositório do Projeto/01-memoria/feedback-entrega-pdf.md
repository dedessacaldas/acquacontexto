---
name: feedback-entrega-pdf
description: Dedessa só recebe o PDF quando ele chega como anexo novo: cada versão revisada precisa de nome de arquivo novo (17/11/2026)
metadata:
  type: feedback
---
Ao revisar um PDF já anexado na thread, o anexo com o mesmo caminho não chega como arquivo novo para a Dedessa e ela pede "me dê o PDF" de novo.

**Why:** em 17/11/2026 ela pediu o PDF 4 vezes depois de revisões entregues por cima do mesmo arquivo.

**How to apply:** a cada revisão entregue, salvar uma cópia com sufixo de versão (ex.: "(v. 17-11 11h12)") e anexar essa cópia. Manter também o arquivo com o nome padrão atualizado.

Vale também para Excel: em 17/11 ela pediu o Excel da REV05 duas vezes (17h55 e 18h29), mesmo com nome novo. Se pedir de novo, perguntar o que aparece para ela ao tentar baixar.
