---
name: iad-tempo-de-fila
description: Como o Anexo 8 (item 9.6, IAD) define tempo de fila/HPF e a solução recomendada de medição com OCR/LPR (29/10/2026)
metadata:
  type: project
  modified: 2026-10-29T14:18:09.381Z
---

Anexo 8, item 9.6 (IAD): IAD1 = 1 − HPF/HOC; HOC = horas 6h–22h do mês; HPF = 0,5·H0 + 1·H1 + 2,5·H2 + 5·H3, por sentido, por hora, com base no tempo médio de fila dos usuários que ENTRARAM na fila naquela hora. Faixas: H0 = tolerância < t ≤ referência; H1 = 1–2× ref; H2 = 2–3× ref; H3 ≥ 3× ref (Tabela 5; sem tolerância → H0 = 0). Metas Tabela 6: Etapas 1–3 REF 0,980 / LO1 0,950 / LO2 0,850; Etapa 4 0,999/0,985/0,925.
Tempo de fila = do alinhamento na fila até o embarque (veículos). 9.6.4.1: amostral, placa na chegada à fila e no embarque, ou metodologia equivalente validada pelo DH. Pedestres (9.6.4.2): estimativa nº em fila × capacidade/intervalo.
Anexo 3A 2.11.3.7/2.11.3.9: IVA deve detectar filas; CFTV deve ter leitura de placas (reaproveitável como pontos LPR).

Recomendação dada à Dedessa: OCR da cabine sozinha não basta (fica no meio da fila; perde fila externa e trecho até a rampa). Mínimo: LPR no ponto de início de fila + LPR na rampa de embarque; cabine como ponto intermediário/conciliação. Ver [[programacao-viagens-rev08]].

13/11/2026: informativo PDF (2 págs., identidade Acquavias) "Tempo de fila × tempo de espera" em /mnt/project-files/informativo-fila-espera/ (gerador/corpo.html + base.css.html → informativo.html; print.js). Tempo de fila = IAD 9.6 (medido, placa chegada/embarque, hora×sentido 6–22h, Tabela 5, peso 0,30, tem expurgo). Tempo de espera para embarque = ITEE no IAU (9.7.9/9.7.17, pesquisa semestral, opinião Excelente…Péssimo, entra no FQ, sem expurgo) + informação ao usuário (3A 2.10.5.1 iv, 2.10.11.3 PMV); 3C 5.1.1.4.1 permanência na área de espera 10–30 min (projeto). 9.6.1 usa "tempo de espera" para a régua da Tabela 5 (redação solta).
13/11 ~17h40 (Dedessa): no informativo, "tempo de espera para embarque" = tempo de espera para embarque DA PRÓXIMA VIAGEM, dado lançado no DRIVE, referência para o ITEE/IAU. Não confundir com tempo de fila (IAD).
13/11 ~19h (Dedessa): informativo refeito para a OPERAÇÃO, sem citar indicadores (IAD/IAU/IQS) nem contrato. Tempo de fila na Acquavias = CRONOMETRADO do veículo entrar na fila do bolsão até alinhar na 1ª posição da fila. Pág. 2 usa a Tabela 5 como semáforo (verde ≤ tolerância, amarelo ≤ referência, vermelho acima). Versão com contrato guardada em gerador/corpo_v1_contrato.html.
