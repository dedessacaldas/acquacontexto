---
name: iau-ponderacao-amostra
description: Anexo 8 não exige peso por nº de pesquisas no IAU; só peso 2 no ICHC; consolidação entre travessias não definida (11/11/2026)
metadata:
  type: project
  modified: 2026-11-11T13:20:50.522Z
---

Pergunta da Dedessa (11/11/2026): IAU precisa de peso por quantidade de pesquisas?

Resposta pelo Anexo 8:
- 9.7.11–9.7.19: cada índice = (B1+B2+B3)/(B1..B5), B = "número total mensal de registros" por grau. É contagem: cada resposta pesa igual, então somar registros já pondera pelo volume. Não há peso adicional por nº de pesquisas.
- 9.7.10: único peso explícito é ICHC×2 (divisor 10), embora o texto diga "média aritmética dos nove índices".
- 9.7.4: IAU semestral e "discriminado para cada TRAVESSIA". O Anexo 8 NÃO diz como consolidar as travessias num IAU único (nem por amostra, demanda ou tarifa). A média ponderada pela tarifa só aparece em IVP/IHP/ITP (dias da semana).
- Tamanho de amostra não definido: fica na metodologia do instituto aprovada pela ARTESP (9.7.6) e no Manual de Medição do VI (5.3).
- Nº de pesquisas/amostra e forma de execução: NÃO definidos no Anexo 8, no Contrato nem em outros anexos (Anexo 20 só cita pesquisa com colaboradores). Anexo 8 define só: semestral por travessia (9.7.4), instituto independente escolhido pela ARTESP de lista ≥3 (9.7.5), 9 temas mínimos (9.7.9), escala 5 graus (9.7.11–19). Plano da pesquisa vai à aprovação da ARTESP (9.7.6).
- Inconsistência: B "mensal" num indicador semestral.

Manual de Medição ECR (arquivo REV.01 14/08, cabeçalho REV.00), item 4.4.2 e ficha 5.9: também NÃO define nº de entrevistas/amostra p/ IAU (95%/5% só p/ IAD). Define: coleta em dispositivo móvel c/ geolocalização+timestamp; amostra estratificada pico/vale e perfis (pedestre, ciclista, moto, leve/pesado); descarta amostra concentrada em baixa demanda; expurgo de entrevistas incompletas; metodologia homologada pelo VI. Divergências c/ Anexo 8: ignora ICHC×2 ('média aritmética dos 9'), ficha diz notas 0–10 (Anexo: 5 graus), fórmula FQ em branco.

Ver [[auditoria-indicadores-2026-10]], [[informativo-indicadores]].
13/11/2026: questionário preliminar da Mind Pesquisas (instituto do IAU, v2 nov/26) revisado: D1–D9 = 9 índices com escala de 5 graus + NS/NA (excluir do denominador), ICHC peso 2 ok, E1 avaliação geral fora do cálculo. Ajustes apontados: NS/NA explícito na metodologia aprovada pela ARTESP; exemplos de sentido só SG (fazer lista p/ todas as 14 travessias); falta seção B; Acquavias precisa informar faixas pico/vale por travessia; "urbanidade" pode ficar entre parênteses.
