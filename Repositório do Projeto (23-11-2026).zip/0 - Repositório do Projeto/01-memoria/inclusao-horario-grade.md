---
name: inclusao-horario-grade
description: como incluir horário novo na grade (ex.: 05h45 escolar Cananéia–Continente): Anexo 3A 2.5.8/2.5.9 × 2.6, indicadores, remuneração, ouvidoria (17/11/2026)
metadata:
  type: project
  modified: 2026-11-17T13:21:34.686Z
---
Pedido 17/11/2026: demanda de saída 05h45 Cananéia ⇄ Continente exclusiva p/ transporte escolar, gerando ouvidoria. Grade vigente (PDF "Grade de Horários - Cananéia - Continente"): Cananéia 05:00 e 06:15; Continente 05:30 e 06:30. Anexo 3A Tab. 8 (mínima inicial) tem esses horários como mínimo; Tab. 20 (final) também não tem 05h45 (até 5h00 de hora em hora; conforme demanda a partir de 6h00). Sentido exato e frota (1 ou 2 balsas no horário) não confirmados.

Regras achadas:
- Alteração permanente da Programação Operacional: Anexo 3A 2.5.8 (comunicar ARTESP 30 dias antes, justificada, com dados e benefícios) + 2.5.9 (divulgação regional e avisos nos terminais 30 dias antes). Programação aprovada é base da fiscalização (2.5.7). Grade mínima não pode ser reduzida (2.7.1/2.7.3), então incluir, não trocar 06h15.
- Temporária: Programação Operacional Excepcional 2.6.1–2.6.8 (10 dias antes ou menos se justificado; ARTESP 5 dias; silêncio = não objeção); partidas só contam com ocupação ≥65% (2.6.9.1/2.6.9.2).
- Indicadores: IHP só mede viagens programadas (Anexo 8 9.2.1, 9.2.5); depois de incluída, 05h45 passa a contar no IHP (janela −2/+5 min, 9.2.6). Viagem extra reduz ITP2 (9.3.7). IRE mensal conta reclamações (9.7.22).
- Remuneração: PA = partidas acima da PMF, autorizadas pela ARTESP (Anexo 14 2.1.3; Glossário "PARTIDAS ADICIONAIS"); ver [[valor-por-viagem-contrato]].
- Ouvidoria: resposta em até 20 dias úteis, 1 prorrogação (Anexo 3A 2.10.9.2 i).
- Anexo 11 item 75 (descumprir parâmetros do contrato, grupo IV/D) é o risco de operar fora do aprovado sem comunicar.
Ver [[grades-horarios-pdf]], [[template-horarios-detalhado]].

Operação assistida (pergunta 17/11): vale o mesmo rito. Anexo 8 8.3.1: 2ª etapa começa com a FASE DE OPERAÇÃO e inclui a operação assistida; Anexo 3A 2.5.1 exige programação aprovada "durante toda a FASE DE OPERAÇÃO"; Anexo 20 cap. 4 não tem rito próprio p/ grade, e 4.2.i diz que a concessionária assume riscos e recebe contraprestação conforme contrato. Diferença: IQS não afeta a CPE nessa etapa (Anexo 8 8.3.1.1), só penalidades do Anexo 11; indicador melhor que o referencial preliminar = nota 1 (8.3.1.2).
