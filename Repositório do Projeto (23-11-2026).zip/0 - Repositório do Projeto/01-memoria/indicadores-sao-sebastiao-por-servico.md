---
name: indicadores-sao-sebastiao-por-servico
description: São Sebastião–Ilhabela: indicadores do Anexo 8 são por TRAVESSIA (uma só); só o IAD é separado veículos×passageiros; lacunas de consolidação (11/11/2026)
metadata:
  type: project
  modified: 2026-11-11T15:56:26.541Z
---

Pergunta da Dedessa (11/11/2026): em São Sebastião–Ilhabela (grade de balsa + grade de lancha p/ pedestres/ciclistas) os indicadores são da travessia ou separados?

Achados:
- Anexo 2 (item 2 e Tab. 1): SS–Ilhabela é UMA travessia; 2.1.6 frota = 8 FB + 2 lanchas. (Santos–Guarujá e Santos–V. Carvalho são travessias distintas.)
- Anexo 8: IVP 9.1.3, IHP 9.2.4, ITP 9.3.3, IOE 9.4.3, IDF 9.5.3, IAD 9.6.1, IAU 9.7.4 → "discriminada para cada TRAVESSIA". Nada manda separar por serviço.
- Única exceção: IAD 9.6.2 "discriminados os serviços de veículos e passageiros"; Tabela 5: SS–Ilhabela Veículos tol 15/ref 60; Passageiros tol 15/ref 30. Anexo 8 não diz como juntar os dois IAD no IQS (fórmula 3.4 tem um IAD só).
- Anexo 3A tem grades separadas: Tab. 1/13 (ferry) e 2/14 (embarcação de passageiros).
- ITP mede headway entre partidas consecutivas (9.3.1): misturar balsa e lancha distorce; n1/n2 (3.4.1–3.4.2) por travessia sem regra p/ serviços simultâneos.
- IOE 9.4.6 já trata: pedestre peso 0 em balsa, 1 em lancha. IRE 9.7.22: Tt "pessoas ou veículos (dependendo da travessia)" — indefinido p/ SS.
- Manual de Medição ECR: também "segregada para cada travessia", sem separação por serviço.

Recomendação dada: apurar por serviço internamente, consolidar por travessia (somar NVR/NVP em IVP/IHP; ITP por grade e consolidar), IAD obrigatoriamente com 2 séries; formalizar critério de consolidação com VI/ARTESP.

Ver [[auditoria-indicadores-2026-10]], [[iau-ponderacao-amostra]], [[definicao-viagem-embarque]].
