---
name: informativo-expurgos
description: Informativo PDF (2 págs) de ocorrências excludentes do Anexo 8 item 2.6 (incisos i–vi) e classificação das categorias do DRIVE (12/11/2026)
metadata:
  type: project
  modified: 2026-11-12T14:10:15.693Z
---

12/11/2026: gerado /mnt/project-files/informativo-expurgos/Informativo - Ocorrências Excludentes.pdf a partir da tabela de expurgos da Dedessa. Gerador: informativo-expurgos/gerador/informativo.html + print.js (mesma identidade de [[informativo-indicadores]]).

Base contratual conferida: Anexo 8 item 2.6 (expurgo só para IVP, IHP, ITP, IAD; não IDF) e 2.6.1 (provar que não dava para mitigar/evitar e nexo causal). iv e v exigem comunicação prévia + justificativa técnica; vi é "a critério da ARTESP e do Poder Concedente"; ii fala só em "atrasos". Evento previsível (ex.: evento esportivo) deve ir para Programação Operacional Excepcional (Anexo 3A 2.6).

Divergências apontadas na tabela da Dedessa (proposta, não validada): Queda ao Mar e Derramamento de Combustível não são inciso iii (criar categoria "Avaria por detrito/lixo"); "embarques prioritários" não é norma de navegação; "variação extrema de maré" não está no texto; "Problemas com Atracadouro" não é manutenção programada (v); Ocorrência Genérica, Imprensa, Falha de comunicação = não é expurgo.

12/11/2026 (revisão): a Dedessa pediu para MANTER as categorias do DRIVE como estão (são tipificações) e instruir a detalhar no campo Comentário. Removidas as sugestões de categorias/campos novos. Lista real do DRIVE (4 abas): Ocorrência = Acidente de Trabalho, Derramamento de Combustível, Embarque Indevido, Evento Esportivo, Falta de Energia, Fiscalização, Imprensa no Local, Infraestrutura, Investigação, Mal Súbito de Usuário, Ocorrência com Embarcação, Falha nos meios de comunicação, Passagem de Navio, Problema com Atracadouro, Segurança Patrimonial, Queda ao Mar; Embarcação = Colisão de Veículos, Ocorrência com Usuários, Ocorrência Devido a Desnivelamento, Queda de Motocicleta; Estrada = Acidente de Tráfego, Congestionamento de Tráfego, Obstrução, Trabalhos; Climática = Chuva Intensa, Maré, Neblina, Vento. Avaria por detrito (iii) = Ocorrência com Embarcação + comentário. Ela também pediu para tirar a frase "no inciso vi nada é automático" do quadro de atenção da pág. 1.

13/11/2026: 2º informativo "Registro de ocorrências" (2 págs.) em /mnt/project-files/informativo-ocorrencias/ (gerador/corpo.html + base.css.html; print.js): cruzamento horário ocorrência × viagem, diagnóstico 09–11/11 (231 ocorr.: 91% sem Tipo, 27% sem Tipo e Comentário, 68% sem Emb., 98% sem Margem, Para.=Sim só 1, 20 durações suspeitas), campo a campo, exemplo errado × certo, comentário bom por tipo, checklist.
13/11 ~17h40: Dedessa pediu no informativo de ocorrências "exatamente os incisos e classificações do DRIVE que mandei" → pág. 3 com a tabela de correlação dela (= dTipoOcorrencia do Bases BI: i Climática; ii Passagem de Navio; iii Derramamento de Combustível, Queda ao Mar; iv Infraestrutura, Trabalhos; v Problema com Atracadouro; vi demais + Ocorrência Genérica; Acidente de Trabalho sem inciso) e nomes das abas pelos prints do DRIVE (12/11).
13/11 ~19h15: informativo de ocorrências refeito p/ Operação (2 págs.): SEM falar de expurgo e SEM diagnóstico dos registros (pedido da Dedessa). Pág. 1 = 3 passos no DRIVE + campos da tela "Criação de Ocorrência" (Estado, Data Início, Data Fim, Gravidade, Paralisar Travessia, Travessia, Embarcação, Comentário, Localização) + horário × viagens; pág. 2 = tabela de incisos (sem "Ocorrência Genérica", que não está no DRIVE), exemplo incompleto × correto, checklist. Versão anterior em gerador/corpo_v1.html.
