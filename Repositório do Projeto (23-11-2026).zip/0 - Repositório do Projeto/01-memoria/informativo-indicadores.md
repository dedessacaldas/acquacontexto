---
name: informativo-indicadores
description: Informativo PDF de 4 páginas sobre os indicadores do Anexo 8 para divulgação interna na Acquavias, com fluxograma de responsáveis (06/11/2026)
metadata:
  type: project
  modified: 2026-11-06T19:41:11.669Z
---

Em 06/11/2026 foi gerado /mnt/project-files/informativo-indicadores/Informativo - Indicadores de Desempenho.pdf (4 págs. A4), para divulgação geral na Acquavias. Gerador em informativo-indicadores/gerador/ (informativo.html + print.js via Playwright, fontes Lato e logos recortados do ID VISUAL).

Identidade visual Acquavias (ID VISUAL ACQUAVIAS.pdf): fonte Lato; Azul #005B7F (Pantone 3025 C); Esmeralda #00B5AD (Pantone 3395 C); padrão de linhas onduladas.

Fluxo de responsáveis pedido pela Dedessa: Operação opera conforme o contrato → Analista de Performance analisa indicadores e cálculos e cobra os responsáveis (gerentes e coordenadores de Operação e de Manutenção). Distribuição adotada (proposta, não validada): Operação = IVP, IHP, ITP, IAD, IAU, IRE, IOE; Manutenção = IDF, IAU, apoio em IVP e IAD.

Achado: a ficha FQ.md do Obsidian diz 1,3 para FQ1 ≥ 0,90; o Anexo 8 diz 1,13. Pesos do IQS somam 0,99 (só com FQ chega a 1). Ver [[iad-tempo-de-fila]], [[grades-horarios-pdf]].

07/11/2026: versão em slides 16:9 (13 slides, PDF) para reunião da Dedessa com os encarregados do Litoral Sul: informativo-indicadores/Apresentação - Indicadores - Encarregados Litoral Sul.pdf (gerador/slides_sul.html). Sul pelo Anexo 2: Cananéia–Ilha Comprida (FB-05, FB-12), Cananéia–Continente (FB-Cananéia, FB-Ribeira), Iguape–Juréia (FB-13, FB-16), Cananéia–Ariri (lancha Canéu, 37,6 km; fora do IAD). IAD Tabela 5: Cananéia–IC e Cananéia–Continente sem tolerância, ref 30 min; Iguape–Juréia tol 20, ref 30.
