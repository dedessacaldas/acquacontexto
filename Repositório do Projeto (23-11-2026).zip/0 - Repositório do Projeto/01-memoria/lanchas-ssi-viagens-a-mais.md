---
name: lanchas-ssi-viagens-a-mais
description: viagens a mais das lanchas LS-03/LS-04 em São Sebastião–Ilhabela 09–16/11: critério 65% de 370 pax (Anexo 3A 2.6.9.1) e resultado (17/11/2026)
metadata:
  type: project
---
Pedido 17/11/2026 (Dedessa): capacidade LS-03 e LS-04 = 370 passageiros (informado por ela). Viagem a mais só conta com ocupação ≥65% (Anexo 3A 2.6.9.1; abaixo disso, 2.6.9.2: conta só a programação) → corte 241 pax. Passageiros = Ped. + Bic. (leitura minha).
Grade lancha: SS 06:30–19:30 e IB 07:00–20:00 de hora em hora. Casamento: saída mais próxima entre −10/+15 min (mesma regra do relatório diário).
Resultado 09–16/11 (export Viagens_NOV_26 enviado 17/11): 435 viagens, 212 de grade (12 horários sem viagem), 223 a mais (~28/dia, LS-04 faz 180 delas: serviço de meia em meia hora). Só 7 a mais atingem 65% (SS 05:30–06:05 e IB 17:30). Ocupação média 21% (76 pax), igual às de grade. Em 194 de 204 horas com extra, grade + extra ≤ 370 (cabia numa lancha). Picos reais: SS 05:30–07:00, IB 16:30–18:30.
Arquivo: relatorios-viagens/lanchas-ssi/"Viagens a mais - Lanchas São Sebastião-Ilhabela - 09 a 16-11-2026.xlsx" (script scratchpad ls/a.py). Ver [[template-horarios-detalhado]], [[inclusao-horario-grade]].
