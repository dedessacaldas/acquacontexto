---
name: pesagem-veiculos-contrato
description: onde o Contrato SPI 012/2026 e anexos tratam de peso/pesagem de veículos nas travessias, e relação com SIGO/indicadores (verificado 28/10 e 09/11/2026)
metadata:
  type: project
  modified: 2026-11-09T21:49:02.384Z
---

- Corpo do Contrato SPI 012/2026: nenhuma menção a peso/pesagem/balança.
- Anexo 6, item 1.9.iv: dado obrigatório ao MIA/ARTESP = "pesagem estimada do grupo global de veículos transportados em cada viagem", por TRAVESSIA (digital, automatizado, editável). Item 1.10: coleta deve vir de sensores/equipamentos.
- Anexo 11, itens 31 (não implantar sistema de pesagem, IV/D), 44 e 45 (suporte à fiscalização incl. pesagem, IV/D e V/F), 46 (não verificar peso de veículos sujeitos por lei, IV/D).
- Anexo 3C, item 4.1.3: Sistema de Pesagem em Movimento + sinalização semafórica no Novo Terminal São Sebastião (cronograma de investimentos).
- Anexo 5: categorias tarifárias por tipo/nº de eixos, não por peso.
- Indicadores (Anexo 8): NENHUM usa peso. IOE (9.4.6/9.4.8) usa contagem de veículos por tipo × fator de equivalência e capacidade legal do CSN. SIGO (Anexo 8 item 6.1; Anexo 3A 2.11.2) é o sistema exigido pelo contrato para coletar dados dos indicadores — não é alternativa ao contrato.
- Contrato não lista campos técnicos de balança (peso por eixo, PBT, tolerância, nº de série etc.); qualquer lista assim é proposta, não exigência.
Relacionado: thread anterior sobre balança INMETRO (nenhuma exigência INMETRO para balança).
