---
name: power-bi-travessias
description: Power BI de viagens (receita Anexo 14 e operacional): bases, grade corrigida, Power Query/DAX e decisões pendentes (11/11/2026)
metadata:
  type: project
---

Pedido da Dedessa (11/11/2026): Power BI a partir de nov/2026 com dois relatórios: receita (A obrigatórias/projetadas, B suplementares, A+B, dia e acumulado de todos os meses) e operacional (grade cumprida, faltas, fixas, sob demanda, expurgos, não cumpridas).

Entregas em /mnt/project-files/power-bi-travessias/: "Bases BI - Travessias.xlsx" (dTravessia, dCalendario 09/11/2026–08/11/2027 com feriados e MesContratual, dParametros, dParametrosAno, dGrade 9.880 slots, fProjecao, CorrecoesGrade), "Power Query - consultas.txt", "DAX - medidas.txt", gerador-bases/ (norm.py, build_bases.py regeram as bases a partir da grade REV00). Doc "Power BI de Viagens – Bases, Correções e Passo a Passo": https://claude.ai/artifact/2u5MGxVxnNQyHu3hhWRkiU

Regras: casamento viagem×grade com janela FIX −10/+15 min e DEM até o próximo slot; viagem DESCONSIDERADA = Tipo preenchido (INF/LIXO/VAL) ou duplicata <3 min mesma embarcação/sentido. EXPURGO (versão final 11/11/2026): só para o relatório de OPERAÇÃO (indicador); não altera A/B nem receita. Horário programado dentro da janela [Início, Fim] de ocorrência aceita (tipo listado, com fim; sem exigir Para.=Sim) E não realizado ou atrasado (>+5) = viagem expurgada (MODO_EXPURGO=2; 1 = como o Drive, tudo na janela). 09/11: 8, 10/11: 1. (A)/(B) por tipo de projeção (aba REV09_DETPROJ da BD_QT, FIX e DEM por travessia/dia; escolha da Dedessa): viagem FIX = cumpriu horário fixo ou travessia só com projeção FIX; A = min(real FIX, proj FIX) + min(real DEM, proj DEM); B = excedente. RECEITA (regra da Dedessa): A ÷ 4 × 2.314,05 × FO; B ÷ 4 × 2.314,05 × 0,6 × FO; sem DD (DIVISOR_PARTIDAS=4). 09/11 R$ 608 mil, 10/11 R$ 637 mil. DETPROJ difere da BASE_DADOS_QT em 35 dias (Cananéia–Ilha Comprida, jun/2027). FO ano 1 = 0,75 (relatórios diários antigos não aplicavam FO). JB, TAQ, BOR com EmOperacao=Não.

Grade corrigida: SVC dias úteis pela grade nova; sábado Santos completado 09:00–22:40 a cada 20 min (premissa); Bertioga SAB/DOM/FER 2 embarcações 06:40–18:20 (54/margem, premissa); CC 04:00/04:30.

Pendente de decisão da Dedessa: A pela projeção × Anexo 14 literal (só PMF a 100%); PMF da Tabela 1 tratado como anual (÷12); significado INF/LIXO/VAL; fins de semana BG e SVC (validar antes de 14/11); mês calendário × contratual; PUP 2.314,05 sem fonte documental.

Publicação (11/11/2026): Dedessa quer usar no Power BI Service. Pastas no SharePoint/OneDrive "Gestão de Performance - Documentos/10 - Informativos e Análises/3 - Relatórios Viagens" com subpastas Viagens (2026_BD_Viagens.xlsx) e Ocorrências, e os arquivos Bases BI - Travessias.xlsx e Quantitativo de Viagens - BD_QT.xlsx soltos. Versão das consultas que lê do SharePoint: "Power Query - consultas (SharePoint).txt" (parâmetros pSite e pPastaRelatorios; consulta ArquivosSP filtra pela subpasta). Montagem no Desktop: .pbix "Gestão de Performance - Análises Integradas" salvo em OneDrive Gestão de Performance - Documentos (13/11/2026). Conferido com pbixray: regras e viagens 09–10/11 batem com o Python (2.939 viagens, 23 desconsideradas, grade 846/118/8 expurgos em 09/11); faltavam fProjecao (código antigo, vazia), medidas DAX, relacionamentos (autodetectados errados), desmarcar carga das intermediárias e Data/hora automática. fProjecao no SharePoint lê a aba fProjecao do Bases BI (a leitura direta da REV09_DETPROJ via Power Query voltou vazia; causa não identificada) → nova revisão da BD_QT exige regerar a aba com build_bases.py. Tem licença Power BI Pro (confirmado 11/11/2026).

Ver [[relatorio-diario-viagens]], [[valor-por-viagem-contrato]], [[programacao-viagens-rev08]].
