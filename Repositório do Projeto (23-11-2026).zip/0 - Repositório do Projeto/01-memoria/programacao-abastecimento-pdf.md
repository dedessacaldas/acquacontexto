---
name: programacao-abastecimento-pdf
description: PDF Acquavias da programação de abastecimento de combustível e aditivo (09 a 13/11/2026), formato e gerador (09/11/2026)
metadata:
  type: project
  modified: 2026-11-09T19:25:12.597Z
---

09/11/2026: a Dedessa mandou por texto a programação de abastecimento de combustível e aditivo (09 a 13/11/2026) e pediu "layout Acquavias". Entregue em /mnt/project-files/programacao-abastecimento/ (PDF de 2 págs. A4). Gerador: gerador/gen.py (dados no próprio script) → programacao.html → print.js (Playwright). Visual igual ao de [[informativo-indicadores]].

Formato: por região (Litoral Norte, Litoral Centro, Litoral Sul, Paraibuna e Natividade da Serra), tabela Data | Hora | Travessia | Litros | Endereço, as Obs. como enviadas e o aditivo em chips por embarcação. Dados mantidos como enviados; onde falta hora/data/endereço, aparece "ver obs." ou "não informado". Só se ordenou por data e hora dentro da região.

Inconsistências apontadas (sem corrigir nada): a Obs. de Cananéia–Ilha Comprida dá Av. Washington Luiz, mas a linha dá Praça Martim Afonso; no Sul, as linhas não têm hora; em Paraibuna, as linhas não têm data e Paraitinga/Natividade não têm endereço; o aditivo não tem data nem local (no Centro e no Sul).
