---
name: programacao-viagens-rev08
description: Como a planilha "Quantitativo de Viagens - Acquavias_REV08.xlsx" calcula a programação de viagens 2026-2027 e os problemas achados na auditoria de 27/10/2026
metadata:
  type: project
  modified: 2026-10-27T20:25:27.393Z
---

Planilha: /mnt/project-files/Quantitativo de Viagens - Acquavias_REV08.xlsx (75 MB; openpyxl read_only leva ~20 s por passada).
Memória de cálculo: "Memória de Cálculo - Programação de Viagens_REV00.pdf" (out/2026, 64 p.). Período 09/11/2026–08/11/2027.

Estrutura: fórmula LET em REV08_PROJ_2026-2027 (1 célula por travessia/dia) -> BASE_DADOS_QT (Tb_Viagens) -> REV08_DETPROJ separa FIX/DEM (FIX de Tb_AN_VIAG_FIX; DEM = total - FIX). Regime do dia em Tb_DiasClassif (aba ÍNDICE), mínimos em Tb_VIAG_MIN_GR, histórico em AN_HIST_2025-2026 (blocos mensais de 17 linhas desde ago/2025; 204 linhas = 12 meses).

Achados da auditoria (27/10/2026), relevantes para o Verificador Independente:
- "Taquecetuba" (typo) na lista sem fator: Taquacetuba recebe 1,05 (a memória, item 7.13, concorda; o Passo 3 da memória discorda).
- João Basso e Bororé sem ARRED: valores decimais.
- Mistas em Operação Verão sem piso do mínimo: 5 dias de Santos/Guarujá abaixo da grade.
- Feriados só nacionais (faltam 9 de julho, municipais).
- 66 células de set/2027 com cálculo desatualizado no arquivo salvo (+549 viagens ao recalcular).
Total salvo REV08: 688.552 viagens (208.704 FIX, 479.848 DEM).

Documento entregue: Claude Doc "Metodologia da Programação de Viagens – REV08 (2026-2027)" https://claude.ai/artifact/AzL5eT2yUy3K5XUZtadsvB

Cananéia/Ilha Comprida (28/10/2026): mínimo contratual = 64 viagens/dia (Anexo 3A, item 2.7 e Tabela 6: 32 + 32 por sentido) = 1.920 em 30 dias; a planilha (Tb_VIAG_MIN_GR) usa 64. O Verificador apontou 2.040 = 68 × 30, e 68 é a média histórica de "dias comuns" citada na memória de cálculo (item 4, "de 68 para 93 viagens"), não um mínimo. A grade final (Tabela 18, após a substituição das embarcações) daria cerca de 79/dia.
