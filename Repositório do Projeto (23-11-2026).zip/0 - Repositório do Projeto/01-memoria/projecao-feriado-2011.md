---
name: projecao-feriado-2011
description: projeção de viagens e demanda para 20/11/2026 (feriado sexta) — método, números e falta do dado diário de 20/11/2025 (16/11/2026)
metadata:
  type: project
---
Pedido da Dedessa (16/11/2026 16h40): projeção para 20/11/2026 considerando 20/11/2025, viagens realizadas até agora e demanda crescente. Gerador: /mnt/project-files/relatorios-viagens/projecao-2011/gerador/calc.py → res.pkl.
Histórico enviado ("Volume Transportado - AGO.25 a OUT.26.xlsx") é MENSAL por travessia (veículos+bicicletas; sem pedestres, sem viagens) → 20/11/2025 não dá para isolar; pedido o dado diário/horário de 20/11/2025.
Método provisório: viagens = quantitativo REV10 de 20/11 × (realizado ÷ quantitativo em 14–15/11, teto 1,15) → 1.646 (quantitativo 1.641). Demanda (veículos+bic.) = média de 14–15/11 × crescimento semana a semana de SG (16/11 × 09/11 até 16h: viagens +2,9%, volume +15,9%) → ~40,8 mil (base 35,2 mil). Nov/2025 média diária SG 27.471 × dias úteis 2026 28.898. Ver [[relatorio-financeiro-viagens]].
16/11 ~16h50: recebido export diário de 20/11/2025 (1.435 viagens = quantitativo REV10 de 20/11/2026 nas mesmas travessias; o quantitativo foi feito a partir dele). PDF 1 pág.: projecao-2011/Projeção de Viagens e Demanda - 20-11-2026.pdf (calc2.py, gen.py). Base = veículos+bic. de 20/11/2025 × (média/dia 09–15/11/26 ÷ média/dia nov/25) por travessia → 37.360 (2025: 37.682); alta ×1,159 (SG 16/11×09/11 até 16h) → 43.307; viagens 1.646; picos 07h, 14h, 16h, 18h.
16/11 ~17h: pedido "considere os regimes das grades": calc3.py (grade de feriado = DOM do grades.py). Conforme demanda: viagens/hora = viagens de 20/11/2025 na hora × fator de demanda (mantém ocupação), mín. da grade. Horário fixo: grade + adicionais quando demanda/hora > p90 veíc.+bic./viagem de 09–15/11/26. Total base 1.566 / alta 1.732 (mín. grade 935; adicionais 92/126: Ilha Comprida 35–44, Iguape 28–38, Continente 9–12, SG madrugada 13–18). PDF virou 2 págs.
