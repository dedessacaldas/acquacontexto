---
name: quantitativo-vale-paraiba
description: revisão da planilha "Quantitivo de Viagens - Travessias Vale do Paraiba.xlsx" (aba REV06_PROJ_2026-2027): lógica grade×2×1,05 e erros achados (19/11/2026)
metadata:
  type: project
  modified: 2026-11-19T12:39:20.024Z
---
Planilha enviada pela Dedessa em 19/11/2026 (abas REV06_PROJ_2026-2027, GRADE, Varginha, Paraitinga, Natividade). Período 09/11/2026–08/11/2027. Valores diários DIGITADOS (sem fórmula), só totais =SUM e AI87 =AGGREGATE(9,6,AI2:AI85).

Lógica deduzida: viagens/dia = saídas da aba GRADE × 2 sentidos (↔ mesmos horários) × 1,05, arredondado; em OV (15/12–14/02) × 1,07. GRADE: Varginha 30 saídas → 60 → 63/64; Paraitinga 33 → 66 → 69/71; Natividade DU 50 → 100 → 105/107, SAB/DOM/FER 40 → 80 → 84/86. Regras DU×FDS/FER e dias da semana conferem 100%.

Achados (19/11): (1) bloco set/2027 tem linhas "Praticado Este Mês" (VEIC/PED) e "Análise Novo Contrato" (52/58/147-99) que entram no AGGREGATE: total mostra 96.683, correto 84.463 (Varginha 23.057, Paraitinga 25.309, Natividade 36.097). (2) fator 5%/7% não documentado e aplicado também às 12 viagens fixas da madrugada; OV não existe no Anexo 3A. (3) feriados faltando: Carnaval 09/02/2027, Corpus Christi 27/05/2027, 9 de julho 2027, municipais (Natividade: −21 viagens/dia útil virado feriado). (4) abas Varginha/Paraitinga/Natividade desatualizadas (espaçamento 40 min onde o máximo é 20; não batem com GRADE). Contrato: Anexo 3A 2.7.5/2.8.5 diz que Paraibuna não tem programação mínima, mas Tabelas 25–27 trazem a mínima final; a GRADE segue as Tabelas 25–27. Ver [[programacao-viagens-rev08]], [[template-horarios-detalhado]].
