---
name: registro-ocorrencias
description: classificação das ocorrências do DRIVE por inciso (Anexo 8 2.6 i–v) via tipo+comentário, desvios de registro e relatório 09–18/11 (19/11/2026)
metadata:
  type: project
  modified: 2026-11-19T14:57:33.044Z
---

Pedido da Dedessa (19/11/2026): no operacional, usar só as ocorrências dos incisos que permitem expurgo, lendo também o comentário. As de outras finalidades não contam. Depois, fazer um relatório de registro com os desvios, as ocorrências fora do expurgo e os problemas do DRIVE.

**Gerador:** /mnt/project-files/relatorios-viagens/registro-ocorrencias/gerador/
- classif.py: lê entradas/Ocorrencias_NOV26_09a18.xlsx e gera ocorr_class.pkl, com as colunas cl (EL/NC/DRIVE), inc, mot e desv.
- gen_reg.py: monta o PDF (header_reg.html) e o Excel "Ocorrências classificadas".
- O operacional usa ocorr_class.pkl em gen_op21.py, com filtro cl == 'EL'. Ver [[relatorio-operacao-3dias]].

**Regras, nesta ordem:**
1. DRIVE: tablet, drive, login.
2. Outra finalidade (NC): demanda, saída antecipada, troca de margem, emergência, viagem especial, pedágio, PMV, abastecimento, acidente de trabalho, falha mecânica, falha corretiva de doca e derramamento por veículo de usuário.
3. Inciso pelo comentário: navio, draga ou batelão = ii; maré, vento ou neblina = i; rede de pesca ou detrito = iii; reparo de doca = v.
4. Sem comentário, vale o tipo.
5. O inciso vi fica fora (depende de aceite da ARTESP).

**Resultado 09–18/11:**
- 913 registros: EL 529 (i 60, ii 462, iii 1, v 6), NC 382, DRIVE 2.
- Desvios: 98% sem margem; 164 sem comentário; 55 com tipo diferente do comentário; 61 possíveis duplicadas.
- Operacional 09–18/11: viagens fixas 91,7% (era 92,2% com todas as ocorrências).

**Pontos abertos para a Dedessa:**
- 159 "Passagem de Navio" sem comentário foram contadas como inciso ii, mas o nexo causal é frágil (item 2.6.1).
- Os 6 registros de inciso v só valem se a manutenção foi comunicada antes.

Ver [[informativo-expurgos]] e [[aplicabilidade-indicadores]].
