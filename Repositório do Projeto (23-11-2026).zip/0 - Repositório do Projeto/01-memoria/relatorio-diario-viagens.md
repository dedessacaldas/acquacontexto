---
name: relatorio-diario-viagens
description: Relatório diário de viagens em 2 versões (Diretoria com receita / Operação), obrigatórias (A) × adicionais (B) por margem e intervalo — regras e gerador (10/11/2026)
metadata:
  type: project
  modified: 2026-11-10T22:20:47.914Z
---

Pedido da Dedessa (10/11/2026): todo dia, um relatório completo em PDF (identidade Acquavias) em duas versões, uma para a Diretoria geral e outra só para a Operação dela. Página 1 das duas: viagens (A) obrigatórias e (B) adicionais por travessia e faixa horária (00–05, 05–07, 07–09, 09–12, 12–16, 16–19, 19–24).

Diretoria (3 págs.): no topo, os multiplicadores de receita, R$ 2.314,05 por viagem obrigatória e 60% (R$ 1.388,43) por adicional. Análise com quantidade em cima e receita embaixo, por margem 1 / margem 2 e depois total, com subtotal por região. Desde 10/11/2026 o resumo da receita fica na pág. 1, na linha de cards ((A), (B) e total), e a última página traz só os critérios, sem pontos de atenção (pedido da Dedessa). Em 10/11/2026 a Dedessa pediu para TIRAR da versão Diretoria as obrigatórias não realizadas: saíram o card, a coluna, a receita não auferida e os destaques em vermelho. Continuam as previstas e o % de cumprimento. A versão Operação mantém tudo (flag show_nr em build.py).
Operação (9 págs.): mesma pág. 1, quantitativo por margem com % de cumprimento, viagens A/B por hora, volume por classificação e por faixa/hora, frota, gantt, pontualidade dos horários fixos e intervalos.

Regras adotadas (leitura minha, não validada): obrigatória = da grade. No horário fixo, conta a saída mais próxima entre −10 e +15 min. Na faixa conforme demanda, a faixa é dividida em janelas do intervalo máximo e a 1ª saída de cada janela é a obrigatória (janela vazia = não realizada). Todo o resto é adicional. Horário fixo igual ao início de uma faixa conta só na faixa, para bater com os totais das grades em PDF (SG 95/margem). A BD_QT (projeção) entra como referência (SG 570 × grade 190). Desde 10/11/2026, a pedido da Dedessa, as duas versões mostram o "% cumprido da projeção" = viagens realizadas (A+B) ÷ BD_QT do dia, por travessia, subtotal e total, além de um card na pág. 1. 09/11: 1.444 de 1.487 = 97,1%. Também em 10/11/2026, a Dedessa pediu para NÃO citar fontes externas no relatório (nem BD_QT, nem BSM, nem nome de arquivo); a coluna se chama só "Projeção". A pág. 1 ganhou o bloco "Acumulado do mês": realizado acumulado ÷ projeção do mês inteiro (% do fechamento) e o ritmo (÷ projeção até o dia). O realizado de cada dia vai para gerador/acumulado.csv (rodar os dias em ordem e não apagar). O mês é o calendário: nov/2026 = 09–30/11, 34.084 projetadas; em 09/11, 4,2%. O multiplicador é por perna (partida), conforme o Anexo 17. O valor de 2.314,05 e a regra dos 60% viriam do Anexo 14, que não está na pasta.

Gerador: /mnt/project-files/relatorios-viagens/relatorio-diario/gerador/ (LEIAME.txt). Para rodar: ./gerar.sh "<export BSM>.xlsx" AAAA-MM-DD "<BD_QT>.xlsx" <saída>. A grade por tipo de dia (DU/SAB/DOM+feriados) está em grades.py e precisa ser editada quando a grade mudar.

Pendências das grades: Bertioga só tem grade DU (usada todo dia). O PDF de sábado de Santos–VC mostra Santos sem saídas das 16h às 22h. Natividade dá 51 pelo cálculo de janelas contra 50 no PDF. No BSM, Natividade junta Pouso Alto e Bairro Alto num sentido só.

09/11/2026: 1.444 viagens, 852 (A) de 973 previstas (87,6%), 592 (B), receita R$ 2,79 mi, 121 obrigatórias não realizadas (R$ 280 mil). Concentradas em Paraitinga (sem BSM até 15:33), Natividade, Bertioga (defasada) e Varginha.

Ver [[relatorio-viagens-santos-guaruja]], [[grades-horarios-pdf]], [[informativo-indicadores]].

12/11/2026: rodado 11/11 (export "ExportDadosVolumeTransportadoReport.xlsx" salvo em entradas/1 - 1111_Completo.xlsx): 1.536 viagens, 928 (A) de 974, 608 (B). Acumulado.csv tem 09/11 e 11/11; 10/11 falta (só havia export parcial até 10:23). A Dedessa pediu que a versão Operação traga como observação cada horário fixo fora da tolerância (−2/+5) com o atraso em min: nova seção "Observações para a Operação" logo após a seção 1 (obs_operacao() em build.py), com resumo por travessia e a lista uma a uma; em não realizada, mostra a saída tardia até +60 min, possível sentido trocado ou o vão sem saída.
