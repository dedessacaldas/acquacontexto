---
name: relatorio-tempo-escoamento
description: Relatório PDF tempo de escoamento da demanda (volume BSM × capacidade das embarcações) SG + todas as travessias, 09–17/11/2026: definição, gerador e números (18/11/2026)
metadata:
  type: project
  modified: 2026-11-18T20:01:13.354Z
---
Pedido da Dedessa (18/11/2026 16h53): "tempo médio de atendimento à demanda" em Santos–Guarujá, por volume transportado / acúmulo de demanda, média de tempo que uma embarcação leva para escoar a demanda; relatório de todas as travessias, modelo Acquavias. Bases NOV26 até 17/11 23h58 (13.748 viagens).
Entregue: /mnt/project-files/relatorios-viagens/tempo-escoamento/Relatório - Tempo de Escoamento da Demanda - 09 a 17-11-2026 (v. 18-11 17h01).pdf (4 págs.). Gerador em tempo-escoamento/gerador/: base.py → calc.py → hora.py → fila.py → res.py → gen.py → pagina.html; print.js + header.html (Playwright).

Definição adotada (não validada pela Dedessa): tempo de escoamento (min) = demanda da hora na margem (veq embarcados, Feq Anexo 8 9.4.6) ÷ lotação média (ficha Apêndice 02) × ciclo (mediana entre saídas da mesma embarcação na mesma margem) ÷ embarcações que saíram na hora. ≤45 folga, 45–60 limite, >60 demanda acumula. "1 embarcação sozinha" = sem dividir pelas embarcações. SG FB-14/16/21 = serviço de ciclistas (pass.).
Números: SG balsas 35,3 min/h (Santos 35,4, Guarujá 35,3), pico DU Guarujá 08h 57,9; Guarujá 05h 55 com 2 balsas; 1 balsa sozinha 181 min; ritmo ~108 veq/h por balsa (44 veq/24,5 min); >60 só 2% das horas. SSI balsas 42,9 min, 24% das horas >60 (12–18h). Demais com folga (Cananéia–Continente 28, Bertioga 21). Conferência com fila registrada (+3 h): fila alta SG 12% → 36% (≤45 → >60), SSI 5% → 34%. Fila alta SG com folga = quase toda 09–12/11.
Ver [[relatorio-fila-navios]], [[informativo-indicadores]], [[feedback-entrega-pdf]].
18/11 17h07 (Dedessa): "tempo médio de intervalo de atendimento" = intervalo entre saídas da mesma margem (qualquer embarcação), não disponibilidade de frota. Pediu 2 análises: intervalo simples e intervalo considerando o volume (cada intervalo com média por margem/hora e demanda acumulada = carga da saída que fecha o intervalo; média ponderada pela demanda). gerador/intervalo.py → I.pkl (exclui intervalos > 3 h); gen_int.py → pagina_int.html + header_int.html → "Relatório - Intervalo de Atendimento da Demanda - 09 a 17-11-2026 (v. 18-11 17h09).pdf" (5 págs.). SG balsas 5,8 min (c/ volume 5,6), DU 06–22h 4,5; 31,4 veq por intervalo; madrugada 20 min. SSI balsa 18,6 (17,7).
