---
name: relatorio-viagens-santos-guaruja
description: Relatório Excel (layout Acquavias) de viagens cumpridas × grade em Santos–Guarujá a partir do export de volume transportado (BSM) — critérios e gerador (09/11/2026)
metadata:
  type: project
  modified: 2026-11-09T19:03:30.112Z
---

09/11/2026: a Dedessa pediu, a partir do "ExportDadosVolumeTransportadoReport.xlsx" (BSM) + PDF da grade Santos–Guarujá, um Excel com viagens por margem, embarcações operando e viagens cumpridas × grade. Entregue em /mnt/project-files/relatorios-viagens/ (gerador/calc.py → res.pkl; gerador/build.py → xlsx; abas Resumo, Viagens por hora, Embarcações, Horários fixos, Intervalos, Inconsistências, Base de dados, Critérios).

Critérios adotados: margem = sentido (1 = saída Santos, 2 = saída Guarujá); saída = "Término Embarque/Início Travessia" em hora:minuto. Faixa fixa: −2/+5 min no horário (Anexo 8 9.2.6), +5 a +15 atraso, fora disso não realizada (9.1.5). Conforme demanda: nenhum intervalo entre saídas seguidas da mesma margem acima do máximo; previstas = duração ÷ intervalo (dá 95/dia útil).

Resultado 09/11 (00h00–15h49): 382 viagens (Santos 188, Guarujá 194), 9 embarcações; fixos 21/22 (Guarujá 02h00: saiu 01h56); 4 intervalos > 12 min. Export tem registros com sentido repetido e travessias < 1 min (erro de apontamento?).

Ver [[grades-horarios-pdf]], [[informativo-indicadores]], [[definicao-viagem-embarque]].

09/11/2026 (2): relatório PDF de TODAS as travessias (export 00:00–17:56, 1.059 viagens) em relatorios-viagens/Relatório de Viagens - Todas as travessias - 09-11-2026.pdf; gerador em relatorios-viagens/gerador-geral/ (calc.py export→res.pkl com grades de dia útil codificadas; build.py → HTML com OBS escritas à mão; print.js com cabeçalho Acquavias). Achados: Bertioga 13–16h defasada (saiu de operação o FB-MF25 em Bertioga em vez do que fica em Guarujá); Paraitinga e Varginha sem BSM até 15:33/09:01; Natividade 3 pontas mas export só 2 sentidos, ciclo ~40 min x máx 20; VC: lancha sai de Santos entre os horários na madrugada.

10/11/2026: comparativo PDF Santos–Guarujá 05h–10h, 09/11 × 10/11 (exports "1 - 0911_Completo" e "1 - 1011_Completo", BSM) em relatorios-viagens/comparativo-sg-0911-1011/ (gerador/calc.py → res.pkl; gen.py → HTML; print.js). Quantitativo da faixa = grade DU (REV09 aba GRADE): 05:00 fixo + 05:20–06:20 + 06:30–09:54 = 23/margem (46). Referência REV09_PROJ: 570 (09/11) e 627 (10/11) viagens/dia, rateado pela parcela 05–10h de 09/11 (24,1%). Resultado: 147 → 151 viagens; intervalos ok 99,3% → 98,0% (1 e 3 excessos de 1–3 min); veículos 6.585 → 6.631. BSM quase sem pedestres (20/43). 10/11: saídas repetidas de Guarujá FB-14 05:52/05:58 e FB-20 08:20/08:23.

10/11/2026 (2): relatório geral PDF (9 págs.) de TODAS as travessias, 09/11 dia inteiro (1.444 viagens, 32 embarcações) em relatorios-viagens/relatorio-geral-0911/ (gerador/calc.py → res.pkl; build.py + template.html → HTML; print.js com header.html). Seções pedidas pela Dedessa: volume geral por classificação, volume por faixas horárias e por hora, viagens em horário fixo, viagens nos intervalos (conforme demanda), quantidade de viagens por hora, frota por horário (contagem e escala por embarcação). Grade Santos–Vicente de Carvalho nova (horários diferentes por margem: Santos 75, VC 76) já codificada no calc.py. Achados: Bertioga defasada também 18:40–21:40 (19 não realizados); Varginha madrugada com 1 balsa alternando, grade pede as duas margens a cada hora; Paraitinga sem BSM até 15:33.

13/11/2026: mesmo comparativo para 09–12/11 (4 dias) em relatorios-viagens/comparativo-sg-0911-1211/ (4 págs.; calc.py lê Viagens_091011.xlsx = export completo 4.506 e Export_1211.xlsx; gen.py com 4 dias, pontos de atenção gerados dos dados). Com o export completo 10/11 virou 154 (antes 151). 147/154/154/156; 6 intervalos acima do máx. (todos Santos, faixa 12 min; maior 19 min em 12/11 09:08–09:27); fixo 05:00 no horário em todos. Projeção SG 570/627/622/595, parcela da faixa = média dos 4 dias (24,7%).
13/11/2026 (2): + 13/11 (export parcial até 16h, Export_1311.xlsx) → comparativo 09–13/11 em relatorios-viagens/comparativo-sg-0911-1311/ (5 dias; 13/11 fora do rateio da projeção; proj. 13/11 = 635). 13/11: 151 viagens, 1 intervalo acima (Guarujá 05:00→05:22, faixa 20 min); muitos registros com sentido repetido (FB-14, FB-11).
16/11/2026: comparativo SG 05–10h 09–13/11 + 16/11 (dias úteis; 14–15 fora por grade de fim de semana) em relatorios-viagens/comparativo-sg-0911-1611/ (gerador copiado do 0911-1311; 09–13 do export completo 09–15, 16/11 de Export_1611.xlsx até 16h). 16/11: 177 viagens na faixa (recorde), 2 intervalos acima do máx.; FB-20 com 16 saídas seguidas no mesmo sentido (19 Santos × 7 Guarujá) → provável sentido errado no registro.
16/11 (2): comparativo refeito com 14 (sáb) e 15/11 (dom), 8 dias, 5 págs.; calc.py tem CFG por tipo de dia na faixa (DU: 05:00 fixo + ≤20 05–06:30 + ≤12; SAB: 05:00/05:30/06:00 fixos + ≤15 06:30–09 + ≤12; DOM: 05:00 fixo + ≤20 05:30–09 + ≤12); mín. por margem 23/18/17. Versão só dias úteis em calc_du.py/gen_du.py.
