---
name: valor-por-viagem-contrato
description: valor por viagem: Anexo 14 item 2.1.3 confirma 60% p/ partidas adicionais e fator FO; R$ 2.314,05 não consta de nenhum documento (11/11/2026)
metadata:
  type: project
  modified: 2026-11-10T22:58:14.919Z
---

Busca em 10/11/2026 no contrato SPI 012/2026 e Anexos (pasta "1 - Contrato e Anexos"): nenhum documento traz R$ 2.314,05 nem a regra "60% para viagens adicionais" usados no relatório diário ([[relatorio-diario-viagens]]).

O que existe: remuneração por partida via PREÇO UNITÁRIO POR PARTIDA (preço da proposta vencedora = desconto sobre o PREÇO UNITÁRIO POR PARTIDA MÁXIMO do Edital, item 6.1) — Glossário (Anexo 17) p.22; reajuste anual IPCA na Cl. 12.1 (p.10/81). Contraprestação = PARCELA FIXA (partidas-piso, "PARTIDAS BASE") + PARCELA VARIÁVEL (partidas acima do piso), "nos termos do item 2.3 do ANEXO 14" — Glossário p.19-20; Cl. 8.1 e 10.1–10.2 do contrato (p.7-8/81). Anexo 3A item 2.6.9.1–2.6.9.3 (p.14): partidas de programação excepcional só contam com ocupação ≥65%; parcela variável só é devida se TOTAL DE PARTIDAS REALIZADAS > PARTIDAS BASE.

**Atualização 11/11/2026:** usuária enviou Anexo 14 (/mnt/project-files/ANEXO 14 - MECANISMO DE PAGAMENTO...pdf). Item 2.1.3: PF = PUP × PMF × FO; PV = PUP × 0,6 × PA × FO (60% confirmado), PA = max(0, PR − PMF) mensal, partidas adicionais autorizadas pela ARTESP. CPE = (PF+PV)×(1−DD), DD = 1−(0,8+0,2×IQS) (2.2.1); CP = CPE − RT − OF (2.1.1). Tabela 1 (2.1.5): ano 1 PMF 145.887 (tabela por ano contratual, não explicita se é total mensal ou anual), FO 0,75; ano 2 FO 0,80 ... ano 6+ FO 1,00. R$ 2.314,05 NÃO aparece em nenhum documento (é o PUP da proposta; contrato/anexos não trazem o número).

**How to apply:** ao citar o valor por viagem, indicar como fonte o usuário/Anexo 14, não o contrato; o PUP de R$ 2.314,05 deve ser confirmado pela proposta comercial/reajuste.

Fichas Obsidian do Anexo 14 (CP, CPE, PF, PV, DD, PUP, OF) em /mnt/project-files/contraprestacao-obsidian/ (11/11/2026). OF = 3% da CPE (Cl. 42.1, p.62). Anexo 14 está na raiz de /mnt/project-files/, não na pasta "1 - Contrato e Anexos".

**11/11/2026 (2):** na Tabela 1, QV = 4 × PMF exatamente (583.548 = 4 × 145.887) → 1 partida base = 4 viagens; explica a regra da Dedessa "viagens ÷ 4 × PUP × FO". PF usa a PMF da Tabela 1 (não o BD_QT); PMF ano 1 tratada como anual → 12.157/mês → PF ≈ R$ 21,1 mi/mês (com FO 0,75), a confirmar se é anual. Ver [[power-bi-travessias]].

**11/11/2026 (3), consenso proposto à Dedessa:** Glossário (Anexo 17) tem erros: PARTIDAS BASE definida como "partidas realizadas" (no Anexo 14 é piso fixo da Tabela 1); PARCELA VARIÁVEL mistura partida/viagem; Tabela 1 escreve PMFm "mês 1 ao 12" mas os valores só fazem sentido anuais (QV 583.548/ano ≈ operação real ~1.500 viagens/dia; mensal daria 19.452/dia e PF R$ 253 mi/mês). Ela calculava 4.862,9/dia = 145.887÷30 (leitura mensal) — errado. Não há piso diário; apuração mensal. PF fixa ≈ R$ 21,1 mi/mês; PV só acima de 12.157 partidas (48.629 viagens) no mês; com ~1.450–1.480 viagens/dia fica abaixo do piso → PV 0. Card de decisão: receita no BI pelo Anexo 14 (PF rateada + PV) × manter A/B por viagem.
Decisão da Dedessa (11/11/2026): MANTER receita (A)/(B) por viagem no BI (viagens ÷ 4 × PUP × FO; B a 60%); Anexo 14 (PF/PV, PF rateada, % do piso) fica só como conferência no DAX.
