---
name: volume-medio-hora-barco
description: PDF de volume médio por hora e por embarcação, todas as travessias 09–19/11 (até 15h18): regra da média e gerador (19/11/2026)
metadata:
  type: project
---
O pedido foi "Média de volume transportado por hora e por barco", feito em 19/11/2026 depois de [[volume-ssi-dia]]. O export tinha todas as travessias, de 09/11 a 19/11 15:18, com 16.480 registros.

O gerador é `/mnt/project-files/relatorios-viagens/volume-medio/gerador/gen.py`, que gera pagina.html. Depois rode `node ../../relatorio-financeiro/gerador/print.js $PWD/pagina.html OUT $PWD/header.html`. Os caminhos precisam ser absolutos.

O PDF tem 4 páginas, na pasta volume-medio:
- resumo por travessia;
- mapas de calor por hora (veículos, pedestres e viagens);
- tabela por embarcação;
- critérios.

**Regras da média:**
- A hora é a do início da travessia.
- A média de uma hora do dia é o volume dividido pelo nº de dias com aquela hora completa. A última hora incompleta do último dia fica fora.
- Média por hora da travessia = total ÷ horas do período.
- Por embarcação: volume ÷ viagens, e volume ÷ horas em que a embarcação fez ao menos uma saída.
- Veículos são contados em unidades, sem veículo equivalente.

**Resultados:**

| Travessia | Veículos/h | Pedestres e cicl./h | Veículos/viagem | Pico |
|---|---|---|---|---|
| Santos–Guarujá | 950 | 256 | 36,2 | 07h |
| SSI balsa | 226 | 103 | 34,7 | 17h |
| SSI lancha | – | 182 | – | – |
| Vicente de Carvalho | – | 445 | – | – |

A SSI lancha leva 79,5 pedestres por viagem.

**Versão executiva (19/11 15h32).** Ela pediu destaque por embarcação: hoje de 00h até agora na pág. 1, e o período todo na pág. 2. O gerador é `gen2.py`, que gera `pagina2.html`. O PDF tem 2 páginas: "Volume Médio por Embarcação - Executivo - 19-11-2026 (até 15h18).pdf".
- Pág. 1: média de hoje = volume ÷ horas decorridas, que foram 15,3, incluindo a hora incompleta.
- Pág. 2: o período, mais o comparativo "hoje × período". Esse comparativo pega hoje de 00h a 14h59 contra a média dos 10 dias anteriores nas mesmas horas.
- Números do comparativo: veículos +21%, pedestres +11%.

**Versão 3 (19/11 15h37).** Ela pediu "simplifique, faça a média por hora em operação, não resuma os títulos, mais visual e informativo".
- O gerador é `gen3.py`, que gera `pagina3.html`. O PDF tem 2 págs.: "Média por Hora em Operação por Embarcação - 19-11-2026 (até 15h18).pdf".
- A métrica única é a média por hora em operação: volume ÷ horas com pelo menos uma viagem. Vale para embarcação e para travessia.
- Cada linha tem barras de veículos (azul) e de pedestres e ciclistas (verde).
- Saiu a média por viagem.
- Nomes e títulos vão por extenso, sem "Veíc." e sem "SS–".

**Versão 4 (19/11 15h42).** Ela achou a anterior confusa e pediu para simplificar e organizar os números.
- O gerador é `gen4.py`, que gera `pagina4.html`. O PDF: "Média por Hora em Operação - Balsas e Lanchas - 19-11-2026 (até 15h18).pdf".
- Pág. 1 é hoje e pág. 2 é o período, com a mesma estrutura nas duas:
  - 3 cards: viagens, veículos e pedestres;
  - tabela de Balsas (veículos por hora em operação, com barra, mais pedestres por hora);
  - tabela de Lanchas (pedestres por hora em operação).
- Em cada tabela, a linha da travessia em destaque traz o total, e as embarcações vêm abaixo em ordem decrescente.
- Saíram os destaques em texto e o comparativo hoje × período.

**Versão 5, a definitiva (19/11 15h48).** Ela definiu: "volume transportado por barco por hora, média entre 00h e agora".
- O divisor é o total de horas do período (hoje: 00h até o último registro, 15,3 h). Entram as horas em que o barco não operou. NÃO é por hora em operação.
- Com isso, a soma dos barcos dá o total da travessia.
- O gerador é `gen5.py` (com header5.html), que gera `pagina5.html`. O PDF: "Volume Transportado por Embarcação por Hora - 19-11-2026 (até 15h18).pdf".
- O layout é o da v4, sem a coluna de horas em operação.
- Títulos e colunas dizem "Média de veículos por hora" e "Média por hora de cada embarcação", nunca "volume por hora" (pedido de 19/11 15h50). O PDF atual: "Média por Hora de Cada Embarcação - 19-11-2026 (até 15h18).pdf".
- Ela estranhou "290 veículos/h no FB-CL (Cláudio Leite)". As motos pesam muito: o FB-CL levou 1.321 motos e 1.523 automóveis no dia.

**Versão 6 (19/11 15h57).** O gerador é `gen6.py` (header5.html), que gera `pagina6.html`. O PDF: "Média por Hora de Cada Embarcação - Hora a Hora - 19-11-2026 (até 15h18).pdf", 4 páginas: pág. 1–2 hoje e pág. 3–4 o período.
- Seção 1, média por hora: tabelas de Balsas e de Lanchas. A coluna Viagens fica afastada da média, e há uma coluna nova de média por viagem.
- Seção 2, média de hora em hora por embarcação: grade colorida com uma coluna por hora.
  - Hoje: o volume de cada hora.
  - Período: cada hora dividida pelo nº de dias em que ela aconteceu.
  - A última coluna é a média por hora da seção 1.

**Versão 7 (19/11 16h01), pedido de layout "mais bonito e intuitivo".** O gerador é `gen7.py` (header5.html), que gera `pagina7.html`. O PDF tem 5 páginas e sufixo "- v7".
- Destaques no topo: os 3 barcos com maior média de veículos por hora, o de maior carga por viagem e a lancha líder.
- Seção 1: um cartão por travessia, com cabeçalho colorido e os totais em chips, em 2 colunas. As lanchas vêm em 3 colunas.
- Seção 2: grade de hora em hora com células arredondadas e legenda de cor.
