---
name: volume-ssi-dia
description: Relatório PDF de volume transportado de São Sebastião ⇄ Ilhabela do dia (export BSM parcial), gerador e números de 19/11/2026
metadata:
  type: project
---
Pedido da Dedessa (19/11/2026 13h08): "relatório de volume transportado para São Sebastião hoje até agora". Entregue: /mnt/project-files/relatorios-viagens/volume-ssi/Volume Transportado - São Sebastião-Ilhabela - 19-11-2026 (até 12h40).pdf (2 págs.). Gerador volume-ssi/gerador/gen.py (lê export_1911.xlsx; usa base.css/fontes/print.js de relatorio-financeiro/gerador; header.html próprio).
Conteúdo: 6 cards; (1) por serviço (balsa FB / lancha LS) × margem com pedestres, bicicletas, motos, automóveis, micro/ônibus, caminhões; composição dos veículos; obs automáticas; (2) por hora (gráfico veículos da balsa por margem + linha pedestres; tabela); (3) por embarcação. Veículos em unidades (sem veq). Todos os registros entram (3 "inf" — pandas lê "inf" como float infinito na coluna Tipo).
19/11 até 12h40: 107 viagens (78 balsa, 29 lancha), 2.831 veículos, 3.257 pedestres+cicl., 224 caminhões; pico veículos 11h (452); 63% dos veículos no sentido Ilhabela. Ver [[relatorio-tempo-escoamento]], [[feedback-entrega-pdf]].
