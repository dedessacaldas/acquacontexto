# Chat do projeto (respostas dadas direto pelo coordenador, fora das threads)
- **Período:** 26/10 a 23/11/2026. A maioria dos pedidos virou thread (ver demais arquivos desta pasta). Abaixo, o que foi resolvido no próprio chat.

## Fórmulas de Excel (29/10/2026)
- Extrair só a hora de data/hora: `=MOD(G2;1)` (formato hh:mm:ss); se for texto, `=VALOR(DIREITA(G2;8))`.
- Dia da semana: `=TEXTO([@Data];"ddd")` (não usar TEXTO sobre DIA.DA.SEMANA). Célula formatada como Texto não calcula: trocar para Geral.
- Feriados nacionais/SP de 01/01 a 26/10/2026 listados; fórmula de feriado: `=SE(OU([@Data]=DATA(2026;{…};{…}));"FER";TEXTO([@Data];"ddd"))`.
- Regime: `=SE(OU([@[DIA DA SEMANA]]="dom";[@[DIA DA SEMANA]]="FER");"DOM/FER";SE([@[DIA DA SEMANA]]="sáb";"SAB";"DU"))` (OU envolve cada comparação).
- Análise de horários praticados com janela −2/+5 min: `CONT.SES` sobre a base por data, sentido e hora de início da travessia; 0 = horário não cumprido.

## Anexos enviados (11/11/2026)
- Dedessa enviou o **contrato assinado (SPI 012/2026)** e os Anexos 11, 13, **14**, 15, 15A, 16, 17, 18, 19, 20 e 21, que estão na raiz de `/mnt/project-files/`.

## E-mail ao financeiro (19/11/2026)
- Rascunho explicando o Relatório Financeiro (09–18/11): (A) obrigatórias = dentro do quantitativo da grade, valor integral; (B) adicionais = acima da grade, 60% (Anexo 14, 2.1.3); cálculo ÷4 × R$ 2.314,05 × 0,75; números R$ 6,58 mi realizados e projeção R$ 15,06 mi (+1,9% sobre orçamento).

## API e integrações (19/11/2026)
- "API" não aparece no contrato nem nas propostas; estão previstas integrações (arrecadação → DRIVE; manutenção → DRIVE; DRIVE → gestão contratual com indicadores/IQS; site e app com dados do DRIVE em até 90 dias após a transferência), sem detalhe técnico.
- **Peso de veículos no SIGO:** não previsto na proposta da Innovia; o peso viria da pesagem em movimento do Novo Terminal de São Sebastião (Anexo 3C 4.1.3). Seria preciso pedir integração com contagem por categoria + tabela de peso médio (ou balança).
- **E-mail do Verificador (ECR, "ES009 - Lista API projetada")**: rascunho de resposta: API solicitada ao fornecedor em 19/11/2026, prazo após avaliação; enquanto isso, **extrações semanais toda segunda-feira** (dados de segunda a domingo da semana anterior), em planilha/CSV, abertas a outra periodicidade se a ECR pedir.

## Volume médio por hora e por barco (19/11/2026)
- Ver thread 20 (relatório em `relatorios-viagens/volume-medio/`).
