# Verificar exigência de balança registrada no INMETRO
- **Data:** 26/10/2026 · **Estado:** resolvida
- **Pergunta:** algum documento exige balança registrada no INMETRO?

## Achados
- **Não.** Nenhum anexo/apêndice exige registro, aferição ou homologação de balança pelo INMETRO/IPEM. "Balança", "metrologia" e "IPEM" não aparecem.
- Única menção ao INMETRO: **Anexo 3C, item 7.1.10 (p. 77)**, certificado de qualidade de projetos funcionais/executivos por organismo acreditado pelo INMETRO (Portaria 367/2017).
- Pesagem: Anexo 3C 4.1.3 (sistema de pesagem em movimento no Novo Terminal de São Sebastião); Anexo 6 item 1.9.iv (pesagem estimada por viagem); Anexo 11 infrações 31, 44 e 45; Anexo 21 (linha de custo "Pesagem em Movimento").

## Ressalvas
- Na época o corpo do contrato não estava na pasta. A metrologia legal pode valer por lei se a pesagem servir para fiscalizar/cobrar (análise jurídica à parte).
- Ver também [[pesagem-veiculos-contrato]] e a thread 06.
