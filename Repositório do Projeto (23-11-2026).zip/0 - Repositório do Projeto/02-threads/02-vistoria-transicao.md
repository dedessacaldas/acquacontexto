# Localizar serviços de vistoria na fase de transição
- **Data:** 27/10/2026 · **Estado:** resolvida
- **Pergunta:** qual item manda contratar vistoria, regularização e documentação de embarcações na transição?

## Achados
- **Anexo 20, item 4.2.iv (p. 5):** na **Etapa de Operação Assistida** (3 meses após a Fase de Transição), apresentar comprovação de contratação de **Sociedade Classificadora**.
- **Anexo 17, verbete "Sociedade Classificadora" (p. 29):** regularização, controle e certificação de embarcações (NORMAM 331/DPC).
- **Anexo 3A, 3.3.3.5 a 3.3.3.10 (p. 60):** vistorias anuais (NORMAM-202), CSN a cada 5 anos, contratar Sociedade Classificadora; comprovação junto com o PSC (até 120 dias após o Termo de Transferência, item 3.2.3).
- **Anexo 20, 3.4.ii.c:** avaliar contratos vigentes da SEMIL. **3.4.i.b:** acompanhar manutenções nos primeiros 10 dias.
- **Anexo 3B, 1.4:** nenhuma embarcação entra na frota sem regularização na Autoridade Marítima.
