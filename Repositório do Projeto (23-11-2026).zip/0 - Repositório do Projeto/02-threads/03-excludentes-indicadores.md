# Explicar cláusula de excludentes nos indicadores
- **Data:** 27/10/2026 · **Estado:** resolvida
- **Pergunta:** o que significa o parágrafo "a CONCESSIONÁRIA deverá comprovar que tais eventos não poderiam ter sido mitigados..."?

## Achados
- É o **Anexo 8, item 2.6.1**. O item 2.6 exclui do IHP, ITP, IVP e IAD viagens atrasadas/não realizadas por: (i) clima; (ii) regras de navegação; (iii) avaria por lixo/detritos; (iv) obras comunicadas e justificadas; (v) manutenção programada de pontes/flutuantes comunicada; (vi) outros casos fortuitos, a critério da ARTESP/PC.
- **A exclusão não é automática.** A concessionária prova: (1) que o evento era inevitável e não mitigável; (2) o nexo causal com aquela viagem específica.
- Sem prova, a viagem entra no cálculo e reduz o IQS (pesos 0,20 / 0,34 / 0,30, item 3.4).
- Recomendação: registro por viagem (horário, causa, evidência, mitigação tentada).
- Desdobramentos: [[informativo-expurgos]], [[registro-ocorrencias]], [[aplicabilidade-indicadores]].
