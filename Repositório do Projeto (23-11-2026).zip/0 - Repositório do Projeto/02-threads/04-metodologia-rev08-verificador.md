# Preparar explicação da metodologia de viagens ao verificador (REV08)
- **Data:** 27/10/2026 · **Estado:** resolvida
- **Pedido:** passo a passo e resumo da fórmula LET da planilha "Quantitativo de Viagens - Acquavias_REV08" para reunião com o Verificador Independente.

## Entregável
- Artefato **"Metodologia da Programação de Viagens – REV08 (2026-2027)"**: https://claude.ai/artifact/AzL5eT2yUy3K5XUZtadsvB (resumo de 1 página, 12 passos, exemplo SS/Ilhabela 26/12/2026 = 248 viagens, mais 9 casos reais).

## Achados
- Fórmula reproduzida nas 5.316 células: bate em todas menos 66.
- 66 células de set/2027 sem recálculo (≈ +549 viagens).
- Santos/Guarujá abaixo do mínimo em 5 dias de verão (ex.: 24/12/2026, 505 × 570).
- Grafia "Taquecetuba" na fórmula faz Taquacetuba receber fator 1,05 indevidamente.
- João Basso e Bororé com viagens fracionadas.
- Detalhes: [[programacao-viagens-rev08]].
