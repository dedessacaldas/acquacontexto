# Conferir mínimo mensal de Cananéia/Ilha Comprida
- **Data:** 28/10/2026 · **Estado:** resolvida
- **Pergunta:** o Verificador disse 2.040 viagens/mês; não são 1.920?

## Resposta
- **1.920 está correto.** Anexo 3A, item 2.7, **Tabela 6** (Programação Operacional Mínima Inicial): 32 + 32 = **64 viagens/dia** × 30 = 1.920 (REV08, Tb_VIAG_MIN_GR, TODOS_OS_DIAS = 64).
- 2.040 = 68 × 30; 68 é a **média histórica** dos dias comuns (63 DU, 79 SAB, 86 DOM/FER), citada na memória de cálculo (Operação Verão 68 → 93). Não é mínimo.
- Tabela 18 (grade final, ≈79/dia) só vale após substituição das embarcações (2.8.3).
- Sugestão: deixar claro na memória de cálculo que 68 é média histórica.
