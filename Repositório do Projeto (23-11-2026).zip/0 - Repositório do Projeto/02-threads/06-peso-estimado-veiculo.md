# Verificar exigência de peso estimado por veículo
- **Data:** 28/10/2026 · **Estado:** resolvida

## Achados
- Exigência no **Anexo 6, item 1.9.iv**: "pesagem estimada do grupo global de veículos transportados em cada viagem" (peso total por viagem, não por veículo); item 1.10: coleta por sensores/equipamentos. O corpo do contrato não fala em peso.
- Anexo 3C 4.1.3 (pesagem em movimento, São Sebastião). Anexo 11: infrações 31, 44, 45, 46.
- Nenhum anexo traz peso por categoria; tarifa do Anexo 5 é por tipo/eixos.

## Metodologia sugerida
- Peso da viagem = Σ (veículos por categoria do Anexo 5 × peso médio da categoria).
- Fontes: fichas técnicas/CRLV (leves); Resolução CONTRAN 882/2021 (PBT, teto para pesados); pesagem própria (campanha amostral e depois pesagem em movimento).
- Links enviados: CONTRAN 882/2021 (estradafacil, LegisWeb), DNIT/LabTrans BR-101/SC, UFSC BR-381/MG, ANTT HS-WIM, DNIT PNCT. Não existe tabela oficial de peso médio por veículo.
- Ver [[pesagem-veiculos-contrato]].
