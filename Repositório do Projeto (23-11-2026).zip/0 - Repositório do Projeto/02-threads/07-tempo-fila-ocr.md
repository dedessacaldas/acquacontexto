# Medir tempo de fila com OCR das cabines
- **Data:** 29/10/2026 · **Estado:** resolvida

## Achados
- **Anexo 8, item 9.6:** tempo de fila = entrada na fila → embarque (9.6.4); amostra por leitura de placa ou metodologia equivalente validada pelo DH (9.6.4.1). Hora a hora (6h–22h), por sentido. Pesos da Tabela 5: 0,5 / 1 / 2,5 / 5. HPF = 0,5·H0 + H1 + 2,5·H2 + 5·H3; IAD1 = 1 − HPF/HOC.
- Anexo 3A 2.11.3.7 e 2.11.3.9: IVA detecta fila e CFTV lê placas.

## Recomendação
- OCR da cabine sozinha mede menos que o real (perde fila de rua e pátio).
- Leitura de placa na entrada da fila (com tempo de percurso livre descontado) + na rampa de embarque; cabine como ponto intermediário. Pedestres pelo método 9.6.4.2.
- Plano de medição validado pelo DH/ARTESP, dados brutos auditáveis, NTP, taxa de pareamento, calibração manual (Anexo 16, 5.2), acesso remoto ARTESP (9.6.5), LGPD.
- Definir com o Verificador como contar filas preferenciais e agendados.
- Ver [[iad-tempo-de-fila]].
