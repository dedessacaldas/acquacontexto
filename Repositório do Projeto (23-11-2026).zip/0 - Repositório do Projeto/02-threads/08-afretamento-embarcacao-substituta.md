# Justificar cláusula de embarcação substituta no afretamento
- **Data:** 28/10/2026 · **Estado:** resolvida
- **Contexto:** contratos de afretamento a casco nu com a Internacional Marítima (Natividade e São Sebastião, REV05). Cláusula 2.2.2: aviso de 30 dias e embarcação substituta equivalente em paradas por documentação/vistoria/regularização sob responsabilidade da contratada.

## Entregas (texto na thread)
- Justificativa técnica em 7 pontos, depois versão **diplomática** baseada na rotina de embarcação afretada (aviso de 30 dias; substituição **temporária**; capacidade equivalente; parada **programada em conjunto**; escopo restrito às causas da contratada; manutenção de uso normal segue com a Acquavias, item 5.4).
- Redação sugerida para o 2.2.2 ("sem prejuízo das demais disposições deste Contrato").
- Divisão de manutenção: Acquavias = uso normal (5.4) e certificados do operador (5.1); contratada = vícios ocultos, estrutura, documentação (5.4.1, 5.4.2, 2.2, 2.2.1).
- Resposta ao Eric: (1) sem substituta, **frete suspenso proporcionalmente**; (2) **DPEM**: Acquavias contrata e gere, contratada paga; (3) início dos contratos: Natividade 09/11/2026, **São Sebastião 25/10/2026** (orçamento passa a considerar 25/10).

## Achados
- Não havia cláusula de suspensão do frete durante a vigência (só no parágrafo único do 2.2, na entrega). Sugerida frase para o fim do 2.2.2.
- DPEM contraditório (6.8 × 5.5 × 2.2 "f" em São Sebastião).
- 5.4.2 não exige substituta em defeito estrutural; docagem/vistoria de classe sem dono definido.
