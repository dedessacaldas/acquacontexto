# Criar fichas markdown dos indicadores (Obsidian) e da contraprestação
- **Datas:** 27/10/2026 e 11/11/2026 · **Estado:** resolvida

## Entregáveis
- Indicadores (Anexo 8), no modelo da ficha IVP da Dedessa: `indicadores-obsidian/IAU.md`, `IRE.md`, `ISS.md`, `IOE.md`.
- Contraprestação (Anexo 14 + Cláusulas 10 e 42.1): `contraprestacao-obsidian/CP.md`, `CPE.md`, `PF.md`, `PV.md`, `DD.md`, `PUP.md`, `OF.md`. Ano contratual 1 destacado com 🟠.

## Achados
- **ISS** não tem meta: é o fator FQ = 0,8·IAU + 0,2·IRE, bônus sobre o IQS (1,05 a 1,15); FQ₁ < 0,80 lido como sem bônus (FQ = 1).
- **IRE:** Tr = reclamações × 10.000 → 1 − reclamações por 10 mil transportados.
- **IOE** sem LO₁/LO₂ e fora do IQS (ficha traz fatores de equivalência veicular).
- Ônus de fiscalização = 3% da CPE (Cláusula 42.1).
- Pendências: **PMF** mensal ou anual (tratado como anual); **PUP R$ 2.314,05** não consta do contrato/anexos (ver [[valor-por-viagem-contrato]]).
