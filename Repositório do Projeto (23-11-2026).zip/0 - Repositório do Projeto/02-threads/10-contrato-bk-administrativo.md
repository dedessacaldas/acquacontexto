# Encaminhar contrato BK para o administrativo
- **Data:** 03/11/2026 · **Estado:** resolvida
- **Contexto:** contrato de afretamento com a BK (REV00); parte operacional já conferida pela Dedessa.

## Entregáveis
- `contratos-afretamento/BK_REV00_encaminhamento_administrativo.md`: e-mail ao administrativo, cláusula a cláusula.
- `contratos-afretamento/BK_resposta_Giselle_REV00.md`: resposta à Giselle (BK) com as 8 alterações entre a minuta dela e a REV00, pedindo assinantes e data de assinatura.
- Redação corrigida da multa (cláusula 7): 2% do valor mensal do item 3.1 (R$ 6.800 por infração); alternativa sobre o valor global de 36 parcelas (R$ 244.800); 7.2 exclui a cláusula 12 (LGPD).

## Achados
- Sem cláusula de seguro (DPEM, casco, P&I, RC); sugerido replicar o acordo da Internacional.
- 7.1 remetia à cláusula errada; 12.8 ("20 vezes o valor principal") sem base.
- 9.1 rescisão livre com 30 dias sem multa (risco); 9.2 cita "Consórcio".
- Faltam conta bancária, assinante e CPF da BK, "R$", Termo de Entrega.
- 2.3 não suspende frete se a embarcação para. 5.4 diz "AFRETANTE" em vez de FRETADORA.
- REV00 da Dedessa removeu proteções da minuta (documentos em 24h, substituta no 2.2.2, Termo de Entrega no 2.4). Assinantes do bloco Acquavias podem ser da BK. Minuta da Giselle partiu do contrato da Marfort.
