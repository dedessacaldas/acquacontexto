# Criar PDFs de grade de horários por travessia
- **Datas:** 03/11 a 10/11/2026 · **Estado:** resolvida
- **Base:** "Quantitativo de Viagens - Acquavias_REV09.xlsx" (aba GRADE) e depois REV09 2; timbrado Acquavias.

## Entregáveis
- 14 PDFs (um por travessia) + zip em `grades-horarios-rev09/`; gerador `grades-horarios-rev09/gerador/gen.py` (+ backups de 16 e 18/11, `print.js`, `manifest.json`).
- Artefato **"Justificativa – Grade Bertioga–Guarujá com horários alternados por margem"**: https://claude.ai/artifact/X7yM7W7VrUL7MK1VZ6zsgW (inclui pontos de atenção da REV05 e pauta).

## Decisões de layout (pedidas pela Dedessa)
- Só a página de grade, para tripulação; "saídas previstas"; **sem citar fonte/Anexo 3A/revisão**; rodapé "Horários sujeitos a alteração por maré, clima ou determinação da autoridade marítima".
- Itinerário só origem → destino (sem tempo de travessia nem chegada).
- Horários fixos listados um a um; períodos conforme demanda em **faixas cheias** do Anexo 3A com "a cada até X min"; usar **00h00**, nunca 24h00; coluna lateral alinhada às faixas.
- Cananéia–Marujá–Ariri: uma linha por viagem (saída, Marujá, chegada), seg–sex.

## Bertioga–Guarujá
- Tabela 5 do Anexo 3A exige só intervalo máximo por sentido (20 min 07h–13h e 16h30–18h; 40 min no resto), **não saída simultânea**. Item 2.5.10 permite programação por intervalo; ITP (9.3) × IHP (9.2.6).
- 1 embarcação alternando margens nas faixas de 40 min; 2ª embarcação nas de 20 min. Falta de tripulação **não** é justificativa (2.5.13).
- Versão final dias úteis: 2ª entra 06h40 (de Bertioga), sai após 13h00, volta 16h40; retiradas 13h40 Bertioga e 13h20 Guarujá; 49 saídas/margem; ressalva: Bertioga 40 min sem saída 16h00–16h40.
- Mudança sobre a REV05 enviada à ARTESP/Verificador: comunicar 30 dias (2.5.8/2.5.9) se já aprovada; grade de fim de semana na programação regular (excepcional exige 65% de ocupação, 2.6.9.1).

## Outros ajustes
- Cananéia–Continente: saída das 04:00 (planilha REV09 2 mudou a do Continente; ficou pendente confirmar a margem).
- Bororé: última faixa 19h00–01h00. Taquacetuba pela Tabela 11. Natividade sáb/dom última faixa assumida 40 min.
- Santos–Vicente de Carvalho (10/11): horários próprios por margem (DU 75/76, SAB 48/69, DOM 62/62); pendente confirmar lacuna de Santos no sábado 16h–22h.
- Detalhes e regeração: [[grades-horarios-pdf]].
