# Localizar definição de embarque e viagem nos indicadores
- **Datas:** 04/11 e 11/11/2026 · **Estado:** resolvida

## Resposta
- **Não há definição operacional** de início/fim de embarque nem de viagem (contrato SPI 012/2026, Anexos 1, 3A, 3B, 8, 14, 16, 17).
- Contrato, Cláusula Primeira: remete ao Anexo 17; o corpo do contrato só fala em "PREÇO UNITÁRIO POR PARTIDA".
- **Anexo 17, "QUANTIDADE DE VIAGENS":** deslocamento entre terminal de saída e de chegada; contabilizada como chegadas + saídas de um único terminal, por travessia.
- **Anexo 8:** 9.2.6 (IHP, partida de −2 a +5 min); 9.1.5 (IVP, atraso > 15 min = não realizada); 9.2.2 (horário efetivo); 9.6.4/9.6.4.1 (IAD, embarque como fim da fila).
- **Anexo 3A 2.6.9.1:** partidas excepcionais só contam com ocupação ≥ 65%.
- **Anexo 14, 2.1.3/2.1.5:** PMF (partidas base), PA = partidas realizadas − PMF; **QV = 4 × PMF** em todos os anos (ano 1: 145.887 partidas, 583.548 viagens), fator não explicado.

## Recomendação
- Propor à ARTESP/Verificador marcos objetivos (desatracação/atracação via CCO ou AIS).
- Ver [[definicao-viagem-embarque]].
