# Criar informativo sobre os indicadores de desempenho
- **Datas:** 06–07/11/2026 · **Estado:** resolvida

## Entregáveis
- `informativo-indicadores/Informativo - Indicadores de Desempenho.pdf`: 4 páginas A4 (capa/conceito "sem registro, sem nota"; formação do IQS; 8 indicadores em cartões; fluxograma de responsáveis Operação → dados → Analista de Performance → gerentes/coordenadores de Operação e Manutenção → plano de ação).
- `informativo-indicadores/Apresentação - Indicadores - Encarregados Litoral Sul.pdf`: 13 slides 16:9 (travessias do sul pelo Anexo 2).
- **Pitch** de liderança para encarregados do sul (texto na thread, ~3 min), na versão final voltado à **função do encarregado**: abrir turno → IVP; controlar saídas → pontualidade (34%); fila → IAD (30%; Iguape 20 min, Cananéia 30 min); avisar manutenção → IDF; registrar → nota existe; equipe e usuário → bônus de satisfação (até 15%).

## Pontos
- Responsáveis propostos: IVP, IHP, ITP, IAD, IRE, IOE → Operação; IDF → Manutenção; IAU → ambas; Manutenção apoia IVP e IAD (a confirmar pela Dedessa).
- Erro na ficha FQ do Obsidian: 1,3 → correto **1,13** para FQ ≥ 0,90.
- A Dedessa preferiu texto tipo pitch a apresentação.
- Identidade visual: [[informativo-indicadores]].
