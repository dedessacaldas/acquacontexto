# Relatório de viagens cumpridas Santos–Guarujá (09/11)
- **Data:** 09/11/2026 · **Estado:** resolvida
- **Entrada:** export de volume transportado (BSM) de 09/11 até 15h49 + grade de dias úteis.

## Entregável
- `relatorios-viagens/Relatório de Viagens - Santos-Guarujá - 09-11-2026.xlsx` (layout Acquavias), com abas de resumo, **Volume transportado** (por categoria, hora e embarcação), embarcação × hora e **Inconsistências**.

## Números (00h00–15h49)
- 382 viagens (188 Santos, 194 Guarujá); grade previa ~62 por margem até 15h49 (95 no dia).
- 9 ferries; até 8 simultâneos das 07h às 13h.
- Horários fixos 00h–05h: 21 de 22 (Guarujá 02h00 saiu 01h56, fora da janela −2/+5).
- Demanda: 4 intervalos > 12 min após 06h30.
- Volume: 16.983 no total (14.052 veículos; 7.564 automóveis; 6.208 motos; 2.892 bicicletas; 39 pedestres).

## Alertas
- Registros suspeitos no BSM (mesma embarcação saindo duas vezes da mesma margem, travessias < 1 min).
- Só 39 pedestres no BSM: pedestres provavelmente contados em outro controle.
- Ver [[relatorio-viagens-santos-guaruja]].
