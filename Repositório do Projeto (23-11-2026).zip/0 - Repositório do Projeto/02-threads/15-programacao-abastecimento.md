# Formatar programação de abastecimento de combustível
- **Data:** 09/11/2026 · **Estado:** resolvida

## Entregáveis
- `programacao-abastecimento/Programação de Abastecimento - 09 a 13-11-2026.pdf` (2 páginas A4 por região: Litoral Norte, Centro, Sul, Paraibuna/Natividade; totais 128.000 L de combustível e 157 L de aditivo).
- `programacao-abastecimento/Programação de Abastecimento - 09 a 13-11-2026.jpg` (1588 × 3196 px, para corpo de e-mail).
- Lista campo a campo (55 itens) do formulário de abastecimento para o coordenador (cabeçalho, contratada, caminhão, quadro por embarcação MCP1–MCP4, 26 itens de segurança, fechamento). Itens 1.1, 3.2 e 5.1 esperam "Não"; demais "Sim".
- Gerador: `programacao-abastecimento/gerador/gen.py` (+ `print.js`, `shot.js`, `shot_email.js`).

## Inconsistências apontadas no texto original
- Endereço de Cananéia–Ilha Comprida × Obs. (Av. Washington Luiz é do Continente).
- Litoral Sul sem horário por linha; Paraibuna/Natividade sem data nas linhas e sem endereço para Paraitinga e Natividade.
- Aditivo sem dia/local; datas em formatos mistos.
- Ver [[programacao-abastecimento-pdf]].
