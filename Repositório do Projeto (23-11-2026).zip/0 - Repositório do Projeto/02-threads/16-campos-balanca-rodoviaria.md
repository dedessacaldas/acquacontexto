# Levantar campos exigidos para balança rodoviária
- **Data:** 09/11/2026 · **Estado:** resolvida

## Resposta
- Não é "SIGO ou contrato": o SIGO é o sistema que o contrato manda implantar (Anexo 8 item 6.1; Anexo 3A 2.11.2.5).
- **Nenhum indicador do Anexo 8 usa peso.** O IOE (9.4.6, 9.4.8) usa veículos × fator de equivalência (carro 1; moto 0,33; VUC 1,5; ônibus/caminhão 2,5) e a capacidade do CSN.
- Campos exigidos (Anexo 6): 1.9.iv peso estimado do conjunto de veículos por viagem e travessia; 1.9.i data/hora e local; 1.9.ii embarcação e travessia; 1.9 caput formato digital, automatizado e editável; 1.10 coleta direta de sensores.
- Relacionados: Anexo 3C 4.1.3; Anexo 11 infrações 31, 44, 45, 46.
- Não exige peso por eixo, PBT/PBTC, tolerância, placa, série ou certificado de balança, nem INMETRO.
- Ver [[pesagem-veiculos-contrato]] e threads 01 e 06.
