# Revisar cálculo dos indicadores de outubro (e pontualidade Cananéia–Continente 09/11)
- **Data:** 09/11/2026 · **Estado:** resolvida

## Achados da revisão (planilha de indicadores de out/2026)
- Contas batem com o Anexo 8; **os zeros vêm dos dados de entrada e de regras de configuração**. IQS da concessão em outubro: **0,60**.
- Fontes: Drive/SIGO (viagens, partidas, estados de embarcação, espera, contagens, ocorrências). IAU, IRE e FQ vazios (sem pesquisa/reclamações; FQ = 1).
- **IAD** zero em 7 de 8 travessias: fonte "ESTIMATE" registra o intervalo da grade como espera; só Santos–Guarujá tem medição real (5 dias); SS passageiros é cópia de veículos. Dados insuficientes.
- **Cananéia–Ariri** (IVP 0,46): grade com 2 viagens/dia no mesmo sentido; corrigido, IQS ≈ 0,99.
- **São Sebastião** (IHP 0,20): 868 viagens fixas "em paralelo" à janela de intervalo (730 sem partida).
- **Bertioga** (IHP 0,53): resultado real.
- **Santos–Guarujá** (IHP 0,70): 1.032 passagens de navio rejeitadas; 2.6(ii) permite excluir se comprovado.
- Regras faltando: coluna Etapa em branco (regra do Indicador Preliminar Referencial, 8.3.1.2 e 8.4.1.3); média móvel deve usar n−1, n−2, n−3 (3.5); IOE sem fator 1,5 para VUC.

## Pontualidade Cananéia–Continente 09/11 (00h–14h)
- 27 horários, todos realizados: 25 no horário, 2 atrasados (FB-CA do Continente: 06:30 → 06:40; 11:30 → 11:35).
- Artefato **"Pontualidade Cananéia–Continente – 09/11/2026"**: https://claude.ai/artifact/LKtYuor1G9ifWMdupw41HZ + texto de WhatsApp.
- Grade **não pode ser ajustada** (Dedessa): sugestão operacional de o FB-RI seguir até a saída das 06:15.
- FB-RI com 6 viagens extras e travessias de 27–54 min (fechamento tardio no sistema).

## Relatório de todas as travessias 09/11 (até 17:56)
- `relatorios-viagens/Relatório de Viagens - Todas as travessias - 09-11-2026.pdf` (9 págs.): 1.059 viagens, 32 embarcações; 350 de 424 fixos no horário (83%).
- Pedido de "planilha de controle de expurgos por inciso" ficou para a thread de expurgos/ocorrências.
- Ver [[auditoria-indicadores-2026-10]].
