# Comparar viagens Santos–Guarujá das 5h às 10h (e relatórios gerais)
- **Datas:** 10/11 a 12/11/2026 · **Estado:** resolvida

## Entregáveis
- `relatorios-viagens/Comparativo de Viagens - Santos-Guarujá - 05h às 10h - 09-11 x 10-11-2026.pdf` (3 págs.): 147 × 151 viagens; 320% / 328% sobre o mínimo de 46 saídas da grade; 99,3% / 98,0% dentro do intervalo; veículos 6.585 → 6.631. Referência REV09 estimada: 107% / 100%.
- Versões seguintes do comparativo em `relatorios-viagens/comparativo-sg-0911-1211/`, `-1311/`, `-1611/` (com geradores `calc.py`/`gen.py`; em 16/11 há `gen_du.py` para só dias úteis).
- `Relatório Geral de Viagens - Todas as travessias - 09-11-2026.pdf` (9 págs.): 1.444 viagens, 32 embarcações; fixos 85,8% (458/534); 93,6% dentro do intervalo. Seções: volume geral, por faixa, hora a hora, frota por horário, fixos, faixas de demanda. Gerador `relatorios-viagens/gerador-geral/`.
- Relatório da Operação 11/11 com **observações de atraso** (tolerância −2/+5 min): 29 atrasos, 6 adiantadas, 17 não feitas; e versão Diretoria (acumulado sem 10/11, export parcial até 10:23).

## Alertas
- Pedestres sub-registrados no BSM; possíveis duplicidades (mesma balsa saindo 2× seguidas).
- Bertioga com balsa na margem errada 18:40–21:40; Varginha não cumpre madrugada com 1 balsa; Paraitinga sem BSM até 15:33.
- Ver [[relatorio-viagens-santos-guaruja]].
