# Criar relatórios diários de viagens para diretoria e operação (thread principal de relatórios)
- **Datas:** 10/11 a 19/11/2026 · **Estado:** concluída (não marcada como resolvida)
- É a thread mais longa do projeto. Concentra: relatórios Diretoria (financeiro) e Operação, Power BI, informativos de fila e ocorrências, template de horários, projeção do feriado, relatório de fila × navios, viagens a mais das lanchas SSI, classificação de ocorrências.

## 1. Relatórios diários Diretoria × Operação (a partir de 10/11)
- Página 1 comum: **(A) obrigatórias** (grade) e **(B) adicionais** por travessia e faixa.
- Diretoria: multiplicador no cabeçalho, quantidade em cima e receita embaixo, margem 1/2/total, subtotal por região. Sem "obrigatórias não realizadas", sem pontos de atenção, resumo da receita na página 1.
- Multiplicador **por perna** (cada saída = 1 viagem), confirmado por "PREÇO UNITÁRIO POR PARTIDA" (Cl. 12.1) e Anexo 17.
- % cumprido da projeção (realizado ÷ quantitativo do dia) e **acumulado do mês** (novembro = 09 a 30/11). **Não citar fontes** (BD_QT, BSM, nomes de arquivo).
- 09/11 (1ª versão): 1.444 viagens, 852 (A) de 973, 592 (B), R$ 2,79 mi (antes do ÷4 e FO).
- **Regra final da receita (11/11):** viagens ÷ 4 × R$ 2.314,05 × 0,75 (FO) = **R$ 433,88 por (A)**; (B) com 60% = **R$ 260,33**. (B) = só o que passa da projeção FIX/DEM (aba REV09_DETPROJ).
- Gerador: `relatorios-viagens/relatorio-diario/gerador/` (`gerar.sh`, `build.py`, `calc.py`, `grades.py`, `LEIAME.txt`). Ver [[relatorio-diario-viagens]].

## 2. Power BI (11–13/11)
- Pacote em `power-bi-travessias/` (`Bases BI - Travessias.xlsx`, `Power Query - consultas.txt`, versão SharePoint, `DAX - medidas.txt`, `gerador-bases/build_bases.py`).
- Artefato **"Power BI de Viagens – Bases, Correções e Passo a Passo"**: https://claude.ai/artifact/2u5MGxVxnNQyHu3hhWRkiU
- Expurgo só para a Operação: horário programado dentro da janela da ocorrência da mesma travessia + viagem não feita ou atrasada (> 5 min). Expurgadas continuam contando para receita.
- PF = PUP × PMF × FO (PMF Tabela 1 do Anexo 14 = 145.887 no ano 1, tratada como anual); **QV = 4 × PMF**, origem do ÷4. Não há piso diário. BI segue receita (A)/(B) por viagem; PF/PV só como conferência.
- Publicação no Service com licença Pro; consultas lendo do SharePoint ("3 - Relatórios Viagens", subpastas Viagens e Ocorrencias); 9 relacionamentos 1:*; .pbix salvo como "Gestão de Performance - Análises Integradas". Ver [[power-bi-travessias]].

## 3. Informativos (13/11)
- `informativo-fila-espera/Informativo - Tempo de Fila x Tempo de Espera.pdf`: linguagem de operação, sem contrato; fila = cronometrada no bolsão até a 1ª posição; tempo de espera para embarque = espera da próxima viagem (dado inputado no DRIVE).
- `informativo-ocorrencias/Informativo - Registro de Ocorrências.pdf`: 2 págs., só classificação por inciso e como registrar no DRIVE (sem expurgo nem diagnóstico).
- Questionário do IAU atende ao Anexo 8 (9.7.9 a 9.7.19), D1–D9, ICHC peso 2.

## 4. Relatório financeiro mensal (16–19/11)
- 1 página, receita nos cards, realizado + projetado; comparativo com orçamento em 3 cartões ("Orçamento previsto do mês", "Sem perdas"...).
- 09–16/11: projeção do mês R$ 14,99 mi; orçamento R$ 14.788.515.
- 09–17/11: 13.748 viagens (13.229 A + 519 B), R$ 5.874.968; projeção R$ 15,02 mi.
- **09–18/11:** 15.396 viagens (14.818 A + 578 B), **R$ 6.579.770** (43,7% do mês); projeção **R$ 15,06 mi** (+1,9% sobre orçamento); ritmo 99,1%.
- Base de 19/11 veio com 17/11 duplicado; pedida nova exportação.
- Gerador: `relatorios-viagens/relatorio-financeiro/gerador/` (projecao/gen_1pag18.py é a versão mais recente). Ver [[relatorio-financeiro-viagens]].
- **Prompt de sistema** com todas as regras: `prompts/Prompt de Sistema - Relatórios de Viagens (Diretoria e Operação).md`.

## 5. Relatórios da Operação (16–19/11)
- Diários e acumulados em `relatorios-viagens/relatorio-operacao/`. Gerador `relatorio-financeiro/gerador/operacao/gen_op21.py` (mais recente).
- Cruzamento com ocorrências, passagens de navio, paralisações e movimentações (frota parada por vento/maré); "frota reduzida" só explica.
- **Filtro final (19/11):** só ocorrências dos **incisos i a v** do item 2.6, tipo conferido pelo comentário (vi fica fora). 913 ocorrências → 529 elegíveis. 09–18/11: fixos no horário 91,7%.
- Acumulado 09–18/11: 15.396 viagens (102,9% do quantitativo); 153 fixos não realizados e 567 intervalos acima do máximo sem justificativa.
- Pendência: defasagem da madrugada em Paraibuna (30 min REV08 × ~10 min praticado) gera falso atraso em Natividade, Paraitinga e Varginha.

## 6. Registro de ocorrências (19/11)
- `relatorios-viagens/registro-ocorrencias/` : PDF "Relatório - Registro de Ocorrências - 09 a 18-11-2026" + `Ocorrências classificadas - 09 a 18-11-2026.xlsx`; geradores `classif.py`, `gen_reg.py`.
- 382 com outra finalidade (ajuste por demanda 219, emergência 65, viagem especial 27); 2 falhas do DRIVE; 98% sem margem; 164 sem comentário; 55 com tipo divergente; 61 possíveis duplicadas; 39 com horário inválido. Ver [[registro-ocorrencias]].

## 7. Outros entregáveis desta thread
- Comparativos Santos–Guarujá 05–10h (09 a 16/11, com sáb/dom pela grade do dia).
- Projeção do feriado de 20/11/2026: `relatorios-viagens/projecao-2011/` (1.566 base / 1.732 alta; 20/11/2025 teve 1.435). Ver [[projecao-feriado-2011]].
- Template de horários REV04 → REV08 em `template-horarios/` (abas Horário Fixo e Conforme Demanda; rota no padrão BSM "1-Origem/Destino"; Paraibuna intercalada). Ver [[template-horarios-detalhado]].
- Grade Santos–Vicente de Carvalho corrigida pelo Excel (19h DU; fim de semana Tabela 4: 12 min intercalado, 20 min simultâneo); grades de Varginha, Paraitinga e Natividade (v. 18-11 15h40).
- Média FB-CL (Claudio Leite) 20h–05h: 150 viagens, 39,4 veículos/viagem.
- Relatório executivo **Passagens de Navio × Tempo de Fila** (09–16/11) em `relatorios-viagens/relatorio-fila-navios/` (várias versões v. 17-11). Ver [[relatorio-fila-navios]].
- **Viagens a mais das lanchas SSI** (LS-03/LS-04, 370 pax, corte 65% = 241): 223 a mais, só 7 ≥ 65%; `relatorios-viagens/lanchas-ssi/`. Ver [[lanchas-ssi-viagens-a-mais]].

## Preferência registrada
- Cada revisão de PDF/Excel deve sair com **nome de arquivo novo** (sufixo "(v. dd-mm hhhmm)") para chegar como anexo. Ver [[feedback-entrega-pdf]].
