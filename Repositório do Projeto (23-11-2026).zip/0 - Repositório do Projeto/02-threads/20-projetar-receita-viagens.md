# Projetar receita das viagens (e volume SSI / volume médio por barco)
- **Datas:** 10/11 a 19/11/2026 · **Estado:** concluída (não marcada como resolvida)

## Valor por viagem
- R$ 2.314,05 **não consta** do contrato, anexos ou EVTEA. Regra dos 60% para adicionais está no **Anexo 14, item 2.1.3**: PF = PUP × PMF × FO; PV para partidas acima da PMF. Ver [[valor-por-viagem-contrato]].

## Receita projetada do ano 1 (09/11/2026 a 08/11/2027)
- `relatorios-viagens/relatorio-financeiro/Relatório Financeiro de Viagens - Ano 1.xlsx` e `.pdf` (4 págs.): **R$ 255,0 mi** (R$ 189,3 mi obrigatórias + R$ 65,7 mi adicionais), com viagens ÷ 4 × 2.314,05 × 0,75. Ver [[relatorio-financeiro-viagens]].

## Análise dos 3 primeiros dias (09–11/11) — sequência de regras
- Várias versões em `relatorio-financeiro/`: "(adicionais 00h-05h)", "(Anexo 14)", "(contrato)".
- **Regra final da Dedessa:** obrigatórias = realizadas segundo o contrato; adicionais (B) = fora da grade **só no período de horário fixo**; viagens sob demanda contam como realizadas normais (estão no Anexo 3A); **atraso não exclui da receita**; sem simulação de IQS.
- Total das 4.506 viagens (incluindo INF/LIXO/VAL e repetidas): 09/11 1.463, 10/11 1.507, 11/11 1.536.

## Projeção de novembro (12/11)
- `Relatório Financeiro de Viagens - Novembro 2026 (realizado e projeção).pdf` (1 página, cards, barra, cores Acquavias sem rosa).
- **Orçamento** = soma de novembro na BD QT (34.084 viagens, 09–30/11) ÷ 4 × 2.314,05 × 0,75 = **R$ 14.788.515**.
- Projeção "sem perdas" (100% do quantitativo 12–30/11 + adicionais na taxa dos 3 dias): **R$ 15.024.842** (+1,6%).
- Diferença 28.007 × 29.555: linhas ocultas no Excel (Cananéia/Ilha Comprida 1.533 + Cananéia/Ariri 15).
- Gerador: `relatorio-financeiro/gerador/` (gerar.py, gen_pdf.py, gen_3dias.py, projecao/…).

## Relatório da Operação no mesmo modelo
- 09–11/11 (8 págs.), 10/11 e 11/11 individuais, com semáforo por travessia; cruzamento com ocorrências explica pouco (12 de 185 fixos fora do horário; 26 de 218 intervalos). Ver [[relatorio-operacao-3dias]].

## Volume transportado SSI e volume médio (19/11)
- `relatorios-viagens/volume-ssi/` : SS–Ilhabela do dia até 12:40 (107 viagens, 2.831 veículos). Ver [[volume-ssi-dia]].
- `relatorios-viagens/volume-medio/` : média por hora e por embarcação, todas as travessias, 09–19/11. **Regra final:** média por hora = volume do barco ÷ horas desde 00h até o horário do export (horas paradas = zero); coluna "média de veículos por viagem"; grade hora a hora por embarcação; destaques no topo. Ex.: FB-CL 190 veículos/h e 60,5/viagem. Ver [[volume-medio-hora-barco]].
- Áudios enviados pela Dedessa não puderam ser transcritos.
