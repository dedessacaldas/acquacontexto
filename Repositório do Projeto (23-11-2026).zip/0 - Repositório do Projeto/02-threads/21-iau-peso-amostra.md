# Verificar peso na amostragem do IAU
- **Data:** 11/11/2026 · **Estado:** resolvida

## Respostas
- **Não há peso por quantidade de pesquisas.** Índices 9.7.11–9.7.19 contam respostas (B1..B5); somar registros entre rodadas, não fazer média de porcentagens.
- Único peso: **ICHC × 2** (9.7.10, divisor 10).
- Consolidação entre travessias: não definida (9.7.4: semestral, discriminado por travessia).
- O Anexo 8 **não define quantidade de pesquisas nem metodologia detalhada**: instituto independente (9.7.5, ARTESP escolhe de lista tríplice), 9 temas (9.7.9), escala de 5 graus, plano aprovado pela ARTESP (9.7.6).
- **Manual de Medição da ECR (Verificador):** coleta por dispositivos móveis com geolocalização e timestamp; amostra estratificada por pico/vale e perfil de usuário; descarta entrevistas incompletas (4.4.2, ficha 5.9); 95%/5% só para o IAD.
- Divergências do Manual × Anexo 8: falta peso 2 do ICHC; escala "0 a 10" × 5 graus; fórmula do FQ em branco (p. 57); REV.01 × cabeçalho REV.00.
- "Total mensal" no Anexo 8 × IAU semestral: deixar claro no plano. Ver [[iau-ponderacao-amostra]].
