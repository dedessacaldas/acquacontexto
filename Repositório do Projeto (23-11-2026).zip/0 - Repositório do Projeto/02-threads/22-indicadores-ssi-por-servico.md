# Separar indicadores de São Sebastião/Ilhabela por serviço
- **Data:** 11/11/2026 · **Estado:** resolvida

## Resposta
- Indicadores apurados **por travessia** (Anexo 2: SS–Ilhabela é uma travessia, 8 ferries + 2 lanchas, item 2.1.6). Fichas do Anexo 8: IVP 9.1.3, IHP 9.2.4, ITP 9.3.3, IOE 9.4.3, IDF 9.5.3, IAD 9.6.1, IAU 9.7.4.
- **Exceção: IAD** separado em veículos (15/60 min) e passageiros (15/30 min) (9.6.2, Tabela 5); o item 3.4 não diz como juntar no IQS.
- IVP/IHP: somar as duas programações (Tabelas 1 e 13; 2 e 14). ITP: misturar balsa e lancha distorce. IOE trata os dois (pedestre 0 na balsa, 1 na lancha, 9.4.6). IRE: Tt não definido para travessia mista (9.7.22).
- **Recomendação:** calcular separado internamente e reportar consolidado; formalizar critério de IAD, ITP e IRE com Verificador/ARTESP. Ver [[indicadores-sao-sebastiao-por-servico]].
