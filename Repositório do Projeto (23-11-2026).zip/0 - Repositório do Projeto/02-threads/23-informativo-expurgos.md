# Criar informativo de classificação de expurgos
- **Data:** 12/11/2026 · **Estado:** resolvida
- **Entrada:** tabela de incisos × classificações do DRIVE × evidências.

## Entregável
- `informativo-expurgos/Informativo - Ocorrências Excludentes.pdf` (2 págs. A4). Gerador em `informativo-expurgos/gerador/`.
- Pág. 1: regra do Anexo 8 item 2.6 (só IVP, IHP, ITP e IAD; não há expurgo para IDF), as 3 perguntas do 2.6.1, os 6 incisos com aba/categoria do DRIVE e o que escrever no Comentário.
- Pág. 2: categorias reais do DRIVE (4 abas) em "pode ser expurgo / depende da causa / não é expurgo"; modelo de Comentário (Inciso, Causa, Início/Fim, Viagens, Mitigação, Evidências, Comunicação) com exemplo fictício de neblina.

## Decisões
- Manter as classificações do DRIVE como estão (são tipificações) e **detalhar no Comentário**.
- Removido o texto sobre inciso vi do quadro de atenção.
- Divergências apontadas na tabela da Dedessa: iii só cobre detrito/lixo (Queda ao Mar e Derramamento não entram); ii "embarques prioritários" não é norma de navegação; i "variação extrema de maré" não está no texto; v "Problemas com Atracadouro" não é manutenção programada; vi depende da ARTESP.
- Ver [[informativo-expurgos]] e [[registro-ocorrencias]].
