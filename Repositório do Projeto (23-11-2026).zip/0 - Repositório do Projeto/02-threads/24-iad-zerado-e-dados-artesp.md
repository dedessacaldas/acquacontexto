# Explicar e corrigir IAD zerado de outubro (+ dados à ARTESP e SIGO)
- **Data:** 13/11/2026 · **Estado:** resolvida

## IAD de outubro
- A conta está certa; o zero é a **nota** (IAD1 ≈ 0,4 < 0,85 → nota 0). Causa: a "espera" registrada é, na maioria das travessias, o intervalo da grade (valores redondos e iguais nas duas margens).
- **HOC** = 16 h (6h–22h) × 2 sentidos × dias = **992 h em outubro**, igual para todas; só sai a hora de paralisação aceita (item 2.6), e o que sai do HOC sai do HPF.
- **Espera 0 = hora boa**: entra no HOC e não soma no HPF; diferenciar de hora sem registro.
- Recalculado com a exportação nova (1–30/10): Cananéia–Continente IAD1 0,01; **só Santos–Vicente de Carvalho com nota > 0**.
- Expurgos valem para IVP, IHP, ITP e IAD (não IDF, IOE, IAU, IRE). Aplicabilidade de indicadores por travessia: ver [[aplicabilidade-indicadores]] e [[iad-tempo-de-fila]].

## Dados que a ARTESP deve ter
- Regra geral: acesso em tempo real e a qualquer tempo aos dados operacionais (**Anexo 3A 2.11.10.3**; Cl. 43.1). Relatório de desempenho é do **Verificador Independente**; a Acquavias fornece os dados (Anexo 8; Anexo 16 3.1).
- O contrato **não usa "exportar/exportação/extração"**; não diz que exportação está excluída. Mais próximo: Cl. 24.1 lii e liii; Anexo 6 8.3; Anexo 8 6.2 e 6.5; **Anexo 3A 2.10.4.3 iii** (CCO alimentar sistema da ARTESP com banco de dados, formato a definir).
- Cl. 24.1 xvi (p. 26): fornecer à ARTESP, **quando solicitada**, em até 10 dias úteis, informações pertinentes. Conclusão: não é preciso entregar extrações à ARTESP sem solicitação; ao VI, sim.

## Entregáveis
- Artefato **"Plano de Acesso ao SIGO – ARTESP e Verificador Independente"** (virou relação de módulos liberados × cláusulas): https://claude.ai/artifact/UdFsSxkvnxw2N8fP14dk5A
- `modulos-sigo-artesp/Módulos do SIGO liberados à ARTESP.pdf` (2 págs., inclui módulo Indicadores — visualização mensal, Anexo 3A 2.11.10.1/2.11.10.2). Gerador em `modulos-sigo-artesp/gerador/`.
- Artefato **"Fornecimento e exportação de dados à ARTESP"**: https://claude.ai/artifact/379mUd2uMWKr7AxCQfxw3L
- Textos para diretoria de planejamento e WhatsApp (versão curta).
- Ver [[dados-artesp-contrato]].

## Viagem vazia para a outra margem
- Nenhuma cláusula fala expressamente; a grade é **mínimo**, não teto (Anexo 3A 2.5.2 e 2.7.1). Embarcação extra em período de horário fixo é permitida.
