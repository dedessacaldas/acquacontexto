# Incluir horário escolar das 5h45 em Cananéia
- **Data:** 17/11/2026 · **Estado:** concluída
- **Contexto:** transporte escolar precisa de saída às 05h45 em Cananéia–Continente; grade não contempla (Cananéia 05:00 → 06:15; Continente 05:30 → 06:30), gerando ouvidoria.

## Resposta
- Contrato **não proíbe** saída acima do mínimo; não trocar a 06:15 (grade mínima, 2.7.1 e 2.7.3). Tabela 20 (programação final) também não tem 05h45.
- **Definitivo:** alteração pontual por ofício (Anexo 3A **2.5.8**, 30 dias, justificada) + divulgação nos terminais (**2.5.9**, 30 dias). Depois de aceita, conta normalmente (sem a regra dos 65%).
- **Imediato:** Programação Operacional Excepcional "enxuta" (**2.6.1–2.6.8**): 10 dias ou menos se justificado; ARTESP tem 5 dias, silêncio = não objeção; partidas só contam com ocupação ≥ 65% (2.6.9.1/2.6.9.2). Recomendado mandar os dois no mesmo ofício.
- Indicadores: extra não pesa no IHP (9.2.1, 9.2.5); depois de entrar na grade, tolerância −2/+5 (9.2.6); ITP minorado (9.3.7); ajuda o IRE (9.7.22).
- Receita: adicional só paga se autorizada e acima das Partidas Base (Anexo 14, 2.1.3).
- Ouvidoria: resposta em até 20 dias úteis (Anexo 3A 2.10.9.2 i).
- **Vale na operação assistida**: Anexo 8 8.3.1 (fase de operação), Anexo 3A 2.5.1; IQS não reduz contraprestação nessa etapa (8.3.1.1); nota 1 se melhor que o referencial (8.3.1.2); penalidades valem (Anexo 11, item 75). Avisar a SEMIL (Anexo 20, 4.3).
- Operar sem comunicar: sem receita e risco de infração (2.5.9; Anexo 11 item 75).
- Passos: ofício da Prefeitura/Educação; checar com a Operação se a balsa faz 05h45 sem atrasar 06:15/06:30; protocolar ARTESP + Verificador; responder ouvidoria; atualizar PDF da grade e template.
- Ver [[inclusao-horario-grade]].
