# Medir tempo de escoamento da demanda por travessia
- **Data:** 18/11/2026 · **Estado:** concluída

## Entregáveis (em `relatorios-viagens/tempo-escoamento/`)
- `Relatório - Tempo de Escoamento da Demanda - 09 a 17-11-2026 (v. 18-11 17h01).pdf` (4 págs.): minutos de cada hora que a frota precisa para embarcar a demanda da hora = veq/h ÷ lotação × ciclo ÷ embarcações. Faixas: até 45 min folga; 45–60 limite; > 60 acumula fila.
  - Santos–Guarujá: média 35 min/h; pico Guarujá 08h (58 min); 1 balsa ≈ 108 veq/h.
  - SS–Ilhabela a mais apertada: média 43 min, 24% das horas > 60 min (12h–18h).
- `Relatório - Intervalo de Atendimento da Demanda - 09 a 17-11-2026 (v. 18-11 17h09).pdf` (5 págs.): duas análises por margem e hora.
  - **Intervalo médio** = média simples entre saídas consecutivas da mesma margem (qualquer embarcação; balsa, lancha e ciclistas separados).
  - **Intervalo considerando o volume** = média ponderada pela demanda acumulada (o que a saída seguinte levou), em veq (auto 1, moto 0,33, van 1,5, ônibus/caminhão 2,5) ou pedestres+bicicletas.
  - Santos–Guarujá: 5,8 min (DU 06–22h: 4,5); ponderado 5,6; 31 veq por intervalo; pico Guarujá 07h (39 veq em 4 min). SS–Ilhabela balsa 18,6 (17,7 ponderado).
  - Excluídos intervalos > 3 h e Cananéia–Ariri (8 viagens). Natividade junta Pouso Alto e Bairro Alto.
- Geradores em `tempo-escoamento/gerador/` (`gen.py`, `gen_int.py`, `base.py`, `calc.py`, `fila.py`, `intervalo.py`...).
- Ver [[relatorio-tempo-escoamento]].
