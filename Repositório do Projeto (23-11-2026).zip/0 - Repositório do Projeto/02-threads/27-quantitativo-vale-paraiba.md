# Revisar quantitativo de viagens do Vale do Paraíba
- **Data:** 19/11/2026 · **Estado:** concluída (nada alterado no arquivo)

## Veredito
- Lógica faz sentido: saídas da aba GRADE × 2 sentidos × **1,05** (Operação Verão 15/12–14/02: **1,07**). Varginha 63 (64), Paraitinga 69 (71), Natividade DU 105 (107), sáb/dom/fer 84 (86). GRADE respeita as Tabelas 25–27 do Anexo 3A.

## Correções sugeridas
1. **Total inflado**: AGGREGATE de AI87 soma linhas extras de set/2027 ("Praticado Este Mês", "Análise Novo Contrato"): mostra 96.683, correto **84.463** (Varginha 23.057, Paraitinga 25.309, Natividade 36.097).
2. Fatores 5%/7% não documentados e incidem também nas 12 fixas da madrugada; "Operação Verão" não existe no Anexo 3A (premissa).
3. Faltam feriados (Carnaval 09/02/2027, Corpus Christi 27/05/2027, 9 de julho, municipais).
4. Abas Varginha/Paraitinga/Natividade desatualizadas (Natividade com 40 min onde o máximo é 20).
- Anexo 3A 2.7.5 e 2.8.5: Paraibuna opera conforme demanda, sem programação mínima; usar as Tabelas 25–27 é o caminho mais seguro.
- Ver [[quantitativo-vale-paraiba]].
