### Contraprestação Pecuniária a pagar (CP)

Periodicidade: mensal, para o sistema todo (mês contratual)
**Cálculo:** $$CP_m = CPE_m - RT_m - OF_m $$
==**CPE:** Contraprestação Pecuniária Efetiva do mês - ([[CPE]])==
==**RT:** Receita Tarifária recebida no mês - (Conta da Receita Tarifária)==
	Informar à ARTESP até o **3º dia útil** do mês seguinte
==**OF:** Ônus de Fiscalização descontado no mês - ([[OF]])==

Além disso, podem ser somados ou subtraídos da CP:
	reequilíbrios econômico-financeiros reconhecidos
	valores devidos após decisão final de divergência
	valores devidos pela concessionária (ex.: compartilhamento de receitas acessórias)
	multas e indenizações, limitadas a **5% da CP do mês** (o saldo passa para os meses seguintes)

| Prazo | O quê |
| ----- | ----- |
| ==🟠Até o 3º dia útil do mês seguinte== | ==🟠Concessionária informa à ARTESP a RT depositada== |
| Até o 5º dia do mês seguinte | Concessionária envia documento de cobrança + memória de cálculo de cada componente |
| Até 10 dias do recebimento | ARTESP valida, aplica multas (se houver) e encaminha ao Poder Concedente |
| Até 30 dias do recebimento pela ARTESP | Poder Concedente paga |
Só é devida após o **Termo de Transferência** (início da Fase de Operação)
Atraso no pagamento além dos 30 dias = inadimplemento do Poder Concedente (aciona a Garantia CPP)

> Fonte: Anexo 14 – Mecanismo de Pagamento, itens 1.1, 1.3 e 2.1.1 (p. 1); Contrato SPI nº 012/2026, Cláusula 10 (pp. 8–9).
