### Contraprestação Pecuniária Efetiva (CPE)

Periodicidade: mensal
**Cálculo:** $$CPE_m = (PF_m + PV_m) \times (1 - DD_m) $$
==**PF:** Parcela Fixa do mês - ([[PF]])==
==**PV:** Parcela Variável do mês - ([[PV]])==
==**DD:** Desconto por Desempenho vigente no mês - ([[DD]])==

Juntando tudo:
$$CPE_m = PUP \times FO \times (PMF_m + 0,6 \times PA_m) \times (0,8 + 0,2 \times IQS)$$

O DD reduz a CPE em **no máximo 20%** (IQS = 0) e em 0% com IQS = 1
É a base de cálculo do [[OF]] (3% sobre a CPE)

> Fonte: Anexo 14 – Mecanismo de Pagamento, item 2.1.2 (p. 2).
