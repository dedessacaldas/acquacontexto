### Desconto por Desempenho (DD)

Periodicidade: mensal
**Cálculo:** $$DD_m = 1 - (0,8 + 0,2 \times IQS) $$
==**IQS:** Indicador de Qualidade do Serviço vigente no mês, de 0 a 1 - (Relatório de Apuração do IQS – Verificador Independente)==
	$$IQS_n = \frac {IQS_{n-1} + IQS_{n-2} + IQS_{n-3}} {3}$$ (média móvel dos 3 últimos meses)
	$$IQS = \left[ IVP \cdot 0,20 + (IHP \cdot n_1 + ITP \cdot n_2) \cdot 0,34 + IDF \cdot 0,15 + IAD \cdot 0,30 \right] \cdot FQ$$ → ver [[ISS]]

| IQS | DD | Recebe da (PF + PV) |
| --- | -- | ------------------- |
| 1,00 | 0% | 100% |
| 0,90 | 2% | 98% |
| 0,75 | 5% | 95% |
| 0,50 | 10% | 90% |
| 0,00 | 20% | 80% |
O DD vai de **0% a 20%**: cada 0,1 de IQS perdido = 2% de desconto
Se $$IQS \cdot FQ > 1$$ considerar $$IQS = 1$$

> Fonte: Anexo 14 – Mecanismo de Pagamento, item 2.2.1 (p. 4); Anexo 8 – Indicadores de Desempenho, itens 3.4 e 3.5 (pp. 5–7) e 9.7.25.4 (p. 39).
