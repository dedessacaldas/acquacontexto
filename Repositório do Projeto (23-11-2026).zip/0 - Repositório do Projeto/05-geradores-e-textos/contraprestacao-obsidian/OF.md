### Ônus de Fiscalização (OF)

Periodicidade: mensal
**Cálculo:** $$OF_m = 0,03 \times CPE_m $$
==**CPE:** Contraprestação Pecuniária Efetiva do mês - ([[CPE]])==

Também incide 3% sobre as **Receitas Acessórias**, recolhido à parte em conta indicada pela ARTESP
O Poder Concedente paga o OF descontado da CP **diretamente à ARTESP**
Descontado em [[CP]]

> Fonte: Contrato SPI nº 012/2026, Cláusulas 10.9 (p. 9), 14.13 (p. 16) e 42.1 (p. 62); Anexo 14 – Mecanismo de Pagamento, item 2.1.1 (p. 1).
