### Parcela Fixa (PF)

Periodicidade: mensal
**Cálculo:** $$PF_m = PUP \times PMF_m \times FO $$
==**PUP:** Preço Unitário por Partida da proposta vencedora, reajustado - ([[PUP]] / Proposta comercial)==
==**PMF:** Número de Partidas Base do ano contratual - (Tabela 1 do Anexo 14)==
==**FO:** Fator de Operação do ano contratual - (Tabela 1 do Anexo 14)==

| Ano | Meses | $$PMF_m$$ | $$FO_m$$ | $$QV_m$$ |
| --- | ----- | --------- | -------- | -------- |
| ==🟠1== | ==🟠1 a 12== | ==🟠145.887== | ==🟠0,75== | ==🟠583.548== |
| 2 | 13 a 24 | 185.110 | 0,80 | 740.440 |
| 3 | 25 a 36 | 185.265 | 0,85 | 741.060 |
| 4 | 37 a 48 | 185.430 | 0,90 | 741.720 |
| 5 | 49 a 60 | 185.610 | 0,95 | 742.440 |
| 6 | 61 a 72 | 185.848 | 1,00 | 743.392 |
| 7 | 73 a 84 | 174.852 | 1,00 | 699.408 |
| 8 | 85 a 96 | 175.427 | 1,00 | 701.708 |
| 9 | 97 a 108 | 176.191 | 1,00 | 704.764 |
| 10 | 109 a 120 | 176.995 | 1,00 | 707.980 |
| 11 | 121 a 132 | 177.891 | 1,00 | 711.564 |
| 12 | 133 a 144 | 178.887 | 1,00 | 715.548 |
| 13 | 145 a 156 | 179.992 | 1,00 | 719.968 |
| 14 | 157 a 168 | 181.173 | 1,00 | 724.692 |
| 15 | 169 a 180 | 182.417 | 1,00 | 729.668 |
| 16 | 181 a 192 | 183.745 | 1,00 | 734.980 |
| 17 | 193 a 204 | 185.171 | 1,00 | 740.684 |
| 18 | 205 a 216 | 186.887 | 1,00 | 747.548 |
| 19 | 217 a 228 | 188.921 | 1,00 | 755.684 |
| 20 | 229 a 240 | 191.083 | 1,00 | 764.332 |
**Atenção:** a tabela não diz se o PMF é mensal ou o total do ano. Pelo tamanho dos números, a leitura usada no Power BI é **anual (÷ 12 por mês)** → confirmar com a ARTESP
	O QV (Quantidade de Viagens) aparece na tabela mas não é usado em nenhuma fórmula do anexo ($$QV = 4 \times PMF$$)
O anexo **não reduz a PF** quando as partidas realizadas ficam abaixo do PMF; viagens não feitas pesam pelo [[IVP]] no IQS → [[DD]]
O FO é o mesmo para [[PF]] e [[PV]]

> Fonte: Anexo 14 – Mecanismo de Pagamento, itens 2.1.3 e 2.1.5, Tabela 1 (pp. 2–4).
