### Preço Unitário por Partida (PUP)

Periodicidade: reajuste anual, no aniversário do contrato
**Cálculo:** $$PUP_{n} = PUP_{db} \times \frac {IPCA_n} {IPCA_{db}} $$
==**PUPdb:** PUP da proposta comercial vencedora na Data Base - (Proposta comercial)==
==**IPCAn:** Número-índice do IPCA do mês anterior ao mês anterior ao reajuste - (IBGE)==
==**IPCAdb:** Número-índice do IPCA da Data Base - (IBGE)==

Cálculo com **4 casas decimais**, desprezando a partir da 5ª
	Centavos ≤ 5 → vira 0
	Centavos > 5 → vira 0 e soma 1 na casa das dezenas de centavos
O valor do PUP **não está escrito** no contrato nem nos anexos (vem da proposta comercial) → confirmar o valor usado (R$ 2.314,05?)
Primeiro reajuste **1 ano após a assinatura**, com IPCA desde a Data Base; os seguintes a cada 12 meses do primeiro
Usado em [[PF]] e [[PV]]

> Fonte: Anexo 14 – Mecanismo de Pagamento, itens 2.1.3 (p. 2) e 3.1.1 a 3.1.2 (pp. 4–5); Contrato SPI nº 012/2026, Cláusula 12.1 (p. 10).
