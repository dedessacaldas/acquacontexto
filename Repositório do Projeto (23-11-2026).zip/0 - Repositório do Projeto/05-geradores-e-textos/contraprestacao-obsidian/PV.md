### Parcela Variável (PV)

Periodicidade: mensal
**Cálculo:** $$PV_m = PUP \times 0,6 \times PA_m \times FO $$
==**PUP:** Preço Unitário por Partida reajustado - ([[PUP]] / Proposta comercial)==
==**PA:** Partidas Adicionais realizadas no mês, autorizadas pela ARTESP - (Relatório de viagens)==
	$$PA_m = \max(0;\ PR_m - PMF_m)$$
==**PR:** Total de Partidas Realizadas no mês - (Relatório de viagens)==
==**PMF:** Partidas Base do ano contratual - ([[PF]] / Tabela 1)==
==**FO:** Fator de Operação do ano contratual - ([[PF]] / Tabela 1)==

| Ano contratual | FO | Valor de cada partida adicional |
| -------------- | -- | ------------------------------- |
| ==🟠1== | ==🟠0,75== | ==🟠PUP × 0,45== |
| 2 | 0,80 | PUP × 0,48 |
| 3 | 0,85 | PUP × 0,51 |
| 4 | 0,90 | PUP × 0,54 |
| 5 | 0,95 | PUP × 0,57 |
| 6 em diante | 1,00 | PUP × 0,60 |
Se $$PR_m \le PMF_m$$ considerar $$PA_m = 0$$ (nunca negativo)
Só contam partidas adicionais **autorizadas pela ARTESP**
Partidas de programação excepcional só contam com ocupação ≥ 65% (Anexo 3A, item 2.6.9)

> Fonte: Anexo 14 – Mecanismo de Pagamento, itens 2.1.3 e 2.1.4 (pp. 2–3).
