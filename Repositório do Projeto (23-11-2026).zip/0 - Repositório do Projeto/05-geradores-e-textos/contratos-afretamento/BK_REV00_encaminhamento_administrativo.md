**Assunto:** Contrato de Afretamento BK (Luana I + Matteo I) – REV00 – validação administrativa/jurídica

Olá, pessoal,

Segue em anexo a minuta do Contrato de Afretamento a Casco Nu com a BK Consultoria e Serviços Ltda. (balsa Luana I + rebocador Matteo I, Travessia São Sebastião–Ilhabela). A parte operacional já está validada por mim. Peço que confirmem os pontos abaixo, que são de responsabilidade de vocês:

**1. Qualificação das partes e assinaturas**
- Preâmbulo: corrigir "e, lado BK" para "e, de outro lado, BK" e "inscrito" para "inscrita".
- AcquaVias é S.A.: a representação deve ser "na forma do seu Estatuto Social" (está "contrato social"). Confirmar se Lucas Leozzi Cabeça e Rodolfo Gonçalves Furtado Lima têm poderes para assinar em conjunto.
- BK: não há nome nem CPF do representante no bloco de assinatura. Solicitar contrato social e documento que comprove poderes.
- Solicitar à BK a comprovação de propriedade das embarcações (TIE/registro), já que o 1.1 afirma que são de propriedade dela e o "Considerando" fala em "proprietária, armadora ou detentora de direitos". Vale também conferir se o CNAE da BK comporta afretamento.
- Nome do rebocador está grafado de dois jeitos: "MATEO I" (1.1) e "Matteo I" (1.1.2). Uniformizar conforme o registro.

**2. Valor, pagamento e faturamento (cláusula 3)**
- 3.1: incluir "R$" antes de 340.000,00 e confirmar o valor mensal por conjunto.
- 3.2: a redação "dia 25 do mês subsequente ao fechamento do mês anterior" está ambígua. Definir com clareza (ex.: pagamento no dia 25 do mês seguinte ao mês de disponibilidade).
- 3.3: a conta bancária não está indicada. Pedir os dados da BK em papel timbrado.
- 3.4: NF "até o dia 30 de cada mês" precisa casar com a data de pagamento do 3.2. Confirmar também o documento fiscal correto: afretamento a casco nu é locação de bem móvel (sem ISS, Súmula Vinculante 31), então avaliar se é fatura de locação ou NFS-e e quais retenções se aplicam.
- Não há regra de pro rata para o primeiro e o último mês. Sugiro incluir.
- 3.6 e 14.19 pedem folha, FGTS e INSS de "funcionários alocados", mas no casco nu a tripulação é nossa (5.2). Avaliar se mantemos como exigência para liberar pagamento, para não gerar retenção indevida e discussão com a BK. As duas cláusulas também se repetem.

**3. Vigência e início (cláusula 4)**
- 4.1: 36 meses "a contar da data da assinatura", e a data no fecho é 09/11/2026. Confirmar a data e avaliar se o frete deve contar a partir da assinatura ou do recebimento efetivo das embarcações (não há Termo de Entrega previsto).

**4. Reajuste (cláusulas 3.2 e 8)**
- 8.1: definir a data-base e esclarecer "média do IGPM+IPCA" (média simples dos dois índices acumulados em 12 meses?). Hoje o reajuste depende de aditivo com concordância das partes, ou seja, não é automático. Confirmar se é essa a intenção.

**5. Seguros e garantias (não há cláusula)**
- O contrato não trata de nenhum seguro: DPEM, casco, P&I ou RC. Precisamos definir quem contrata e quem paga cada um, e o beneficiário. Nos contratos da Internacional Marítima definimos que o DPEM é contratado pela AcquaVias e pago pela contratada. Confirmar se replicamos aqui.
- Não há garantia contratual de nenhuma das partes. Avaliar se é necessária.

**6. Multas e penalidades (cláusulas 7 e 12.8)**
- 7.1: a multa de 2% remete à "cláusula quarta", que é a de Vigência. O valor está na cláusula 3. Definir também se a base é o valor mensal ou o valor global do contrato.
- 7.2: remete a "item 11. DA PROTEÇÃO DE DADOS", mas Proteção de Dados é a cláusula 12 (a 11 é Confidencialidade).
- 12.8: multa de "20 vezes o valor principal" sem definir o que é "valor principal". Se for o mensal, são R$ 6,8 milhões. Avaliar proporcionalidade e a chance de a BK recusar.
- 2.3: quando a embarcação para por renovação documental ou vistoria da BK, não há suspensão do frete nem obrigação de substituta. Nos contratos da Internacional incluímos que, sem substituta, o frete fica suspenso proporcionalmente aos dias parados. Sugiro a mesma redação aqui.

**7. Responsabilidades (cláusulas 5 e 6)**
- 5.4: onde está "AFRETANTE" deveria ser "FRETADORA" (as intervenções estruturais e os vícios ocultos são dela). Do jeito que está, a ressalva perde o sentido.
- 2.2 e 2.3 usam "CONTRATADA/CONTRATANTE" em vez de "FRETADORA/AFRETADORA". Uniformizar.
- 6.4: a BK responde "integral e ilimitadamente" pelos danos na execução, mas quem opera somos nós. Conferir se a redação se sustenta ou se a BK vai pedir para limitar aos vícios e defeitos do 6.2.

**8. Extinção (cláusula 9)**
- 9.1: qualquer parte pode rescindir a qualquer tempo com 30 dias de aviso e sem multa. Para uma travessia sem embarcação reserva, isso é um risco relevante. Avaliar aviso maior e/ou multa rescisória para a BK.
- 9.2: fala em rescisão "entre o Governo do Estado e o Consórcio". O correto é a extinção do Contrato de Concessão nº 012/2026 entre o Poder Concedente e a AFRETADORA (SPE).

**9. Concessão (ARTESP)**
- Incluir este contrato na lista semestral de contratos com terceiros que enviamos à ARTESP (cláusula 36.3 do Contrato de Concessão).
- O 1.4 diz que não é leasing, então a regra de interveniência da ARTESP para arrendamento mercantil (15.18 da Concessão) não deveria se aplicar. Peço que o jurídico confirme.

**10. Anexos e ajustes de forma**
- O fecho cita "seus anexos", mas nenhum anexo está listado. O 2.5 prevê Termo de Devolução e Laudo de Vistoria Final, sem o equivalente na entrega. Sugiro anexar Termo de Entrega com Laudo de Vistoria Inicial e a relação de documentos das embarcações.
- Numeração: há dois itens 2.4, e os itens 2.5, 3.6, 3.7, 5.3, 5.4, 6.7 e 6.8 estão fora da numeração automática. O título da cláusula 2 fala em "Entrega dos Serviços" (são embarcações).
- 13.5: "4ª Turma do STF" num processo do TST (o correto é TST).
- 14.23: "Cidade do São Paulo, Estado do São Paulo" deve ser "Cidade de São Paulo, Estado de São Paulo".
- Há um parágrafo solto repetindo o 10.2 depois das notas de rodapé, no fim do documento. Excluir.
- Foro (15.1): Foro Central de São Paulo. Ok, só confirmar.

Qualquer dúvida operacional, fico à disposição.

Obrigada!
