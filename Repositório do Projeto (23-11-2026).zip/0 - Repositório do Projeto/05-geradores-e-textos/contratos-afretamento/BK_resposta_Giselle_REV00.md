**Assunto:** RE: CONTRATO - AFRETAMENTO BK ACQUAVIAS

Giselle, boa tarde!

Segue em anexo a REV00 do contrato de afretamento, com as informações operacionais já revisadas por nós. As alterações em relação à minuta enviada foram:

1. **Partes:** a FRETADORA passa a ser a BK CONSULTORIA E SERVIÇOS LTDA., CNPJ 03.022.122/0001-77, no preâmbulo e na qualificação. A minuta ainda trazia a Marfort Serviços Marítimos Ltda.
2. **Item 1.2 (destinação):** a travessia foi corrigida de Bertioga–Guarujá para São Sebastião–Ilhabela.
3. **Item 2.2 (entrega e documentação):** retiramos a lista de documentos exigidos na entrega e o prazo de 24 horas para regularização. O item agora trata apenas do acompanhamento e da renovação da documentação das embarcações pela BK.
4. **Item 2.3 (afastamento para regularização):** mantivemos o aviso prévio de 30 dias e retiramos o parágrafo que exigia embarcação substituta.
5. **Item 2.4 (posse operacional):** retiramos a referência ao Termo de Entrega como marco da transferência da posse.
6. **Item 7.1 (multa):** a base de cálculo passou a ser o valor do item 3.1. Antes a cláusula remetia à "cláusula quarta", que é a de Vigência.
7. **Item 7.2:** a referência foi corrigida para a cláusula "12. DA PROTEÇÃO DE DADOS". Antes estava 11, que é a de Confidencialidade.
8. **Data e assinatura:** a data foi alterada para 09/11/2026, e o bloco de assinatura da FRETADORA passou para BK Consultoria e Serviços Ltda.

Para fecharmos a versão final, pedimos que nos confirmem:

- **Assinantes pela BK:** nome completo, cargo e CPF de quem assinará pela FRETADORA, com o contrato social ou a procuração que comprove os poderes. O campo está em branco na REV00.
- **Data de assinatura:** se 09/11/2026 está de acordo. A vigência de 36 meses conta a partir dessa data (item 4.1).

Ficamos no aguardo.

Atenciosamente,
