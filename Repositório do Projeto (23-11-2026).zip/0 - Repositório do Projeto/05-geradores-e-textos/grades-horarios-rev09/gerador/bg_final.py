import json
def hm(s): h,m=s.split(':'); return int(h)*60+int(m)
def r(a,b,s): return list(range(hm(a),hm(b)+1,s))
B = r('00:20','06:20',40)+[hm('06:40')]+r('07:00','13:00',20)+[hm('13:30')]+r('14:10','16:10',40)+r('16:30','17:50',20)+[hm('18:20')]+r('19:00','23:40',40)
G = r('00:00','06:40',40)+r('07:00','13:00',20)+[hm('13:30')]+r('13:50','15:50',40)+r('16:30','17:50',20)+[hm('18:20')]+r('18:40','23:20',40)
# contract check (Anexo 3A Tab.5): max gap per margin 20 in [07:00,13:00] and [16:30,18:00], else 40
def check(L,name):
    L=sorted(L); bad=[]
    for i in range(len(L)):
        a=L[i]; b=L[(i+1)%len(L)]+(1440 if i==len(L)-1 else 0)
        g=b-a
        # strict windows: any departure due in window
        lim=40
        for ws,we in [(420,780),(990,1080)]:
            if a>=ws and a<we: lim=20
        if g>lim: bad.append(('%02d:%02d'%(a//60,a%60),g,lim))
    print(name,len(L),'violações:',bad)
check(B,'Bertioga'); check(G,'Guarujá')
# vessel sim from 07:00, cross 20
ev=sorted([((t if t>=420 else t+1440),m) for m,L in (('B',B),('G',G)) for t in L])
cnt={'B':1,'G':1};arr=[]
for T,m in ev:
    for a in arr:
        if a[0]<=T: cnt[a[1]]+=1
    arr=[a for a in arr if a[0]>T]
    assert cnt[m]>0,(T,m)
    cnt[m]-=1; arr.append((T+20,'G' if m=='B' else 'B'))
for a in arr: cnt[a[1]]+=1
print('posição 07:00 dia seguinte',cnt)
json.dump({'Bertioga':B,'Guarujá':G},open('bertioga_grade.json','w'))
