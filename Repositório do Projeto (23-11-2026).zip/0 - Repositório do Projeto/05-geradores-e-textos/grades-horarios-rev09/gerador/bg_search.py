import itertools, json
def hm(s): h,m=s.split(':'); return int(h)*60+int(m)
def fm(t): return '%02d:%02d'%(t//60%24,t%60)
O={'B':'G','G':'B'}
def build(phases):
    """phases: list of (kind, start, end, first_margin) ; times inclusive, step 20"""
    dep={'B':set(),'G':set()}
    for k,a,b,fmg in phases:
        ts=list(range(a,b+1,20))
        if k=='D':
            for t in ts: dep['B'].add(t%1440); dep['G'].add(t%1440)
        else:
            m=fmg
            for t in ts: dep[m].add(t%1440); m=O[m]
    return dep
def feasible(dep,cross=20):
    for init in [(2,0),(1,1),(0,2)]:
        cnt={'B':init[0],'G':init[1]};arr=[];ok=True;st=[]
        for day in range(3):
            st.append(tuple(cnt.values()))
            for t in range(1440):
                T=day*1440+t
                for a in [x for x in arr if x[0]==T]: cnt[a[1]]+=1
                arr=[x for x in arr if x[0]!=T]
                for mg in 'BG':
                    if t in dep[mg]:
                        if cnt[mg]==0: ok=False;break
                        cnt[mg]-=1; arr.append((T+cross,O[mg]))
                if not ok:break
            if not ok:break
        if ok and st[1]==st[2]: return init
    return None
def contract(dep):
    bad=[]
    for mg in 'BG':
        L=sorted(dep[mg])
        for i,a in enumerate(L):
            b=L[(i+1)%len(L)]+(1440 if i==len(L)-1 else 0)
            lim=20 if (420<=a<780 or 990<=a<1080) else 40
            # also window start: must have departure at/before window start within 20
            if b-a>lim: bad.append((mg,fm(a),b-a))
        for ws in (420,990):  # first departure in window must be <= start+? ensure some departure in [ws-20, ws]
            if not any(ws-20< t<=ws for t in L): bad.append((mg,'inicio janela',fm(ws)))
    return bad
res={}
for name,mid_double in [('util',False),('fds',True)]:
    sols=[]
    for Tm in (hm('06:40'),hm('07:00')):
        for Te in (hm('16:20'),hm('16:40')):
          for o in itertools.product('BG',repeat=3):
            ph=[('S',hm('18:20'),Tm-20+1440,o[0]),('D',Tm,hm('13:00'),None)]
            if mid_double:
                ph=[('S',hm('18:20'),Tm-20+1440,o[0]),('D',Tm,hm('18:00'),None)]
            else:
                ph+= [('S',hm('13:20'),Te-20,o[1]),('D',Te,hm('18:00'),None)]
            dep=build(ph)
            c=contract(dep); f=feasible(dep)
            if not c and f: sols.append((fm(Tm),fm(Te),o,len(dep['B']),len(dep['G'])))
    print(name, sols[:20])
print('--- util ampliado')
sols=[]
for Tm in map(hm,['06:20','06:40','07:00']):
  for E1 in map(hm,['13:00','13:20']):
    for Te in map(hm,['16:00','16:20']):
      for E2 in map(hm,['18:00','18:20']):
        for o in itertools.product('BG',repeat=2):
          ph=[('S',E2+20,Tm-20+1440,o[0]),('D',Tm,E1,None),('S',E1+20,Te-20,o[1]),('D',Te,E2,None)]
          dep=build(ph)
          if not contract(dep) and feasible(dep):
              # double-vessel minutes
              dm=(E1-Tm)+(E2-Te)
              sols.append((dm,fm(Tm),fm(E1),fm(Te),fm(E2),o,len(dep['B'])))
sols.sort()
for s in sols[:12]: print(s)
