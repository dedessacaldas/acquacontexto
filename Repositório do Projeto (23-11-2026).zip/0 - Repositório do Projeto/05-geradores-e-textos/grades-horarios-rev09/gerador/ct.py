import openpyxl,datetime,statistics,json
wb=openpyxl.load_workbook('rev09.xlsx',read_only=True,data_only=True)
def p(s):
    if isinstance(s,datetime.datetime): return s
    try: return datetime.datetime.strptime(str(s),'%d/%m/%Y %H:%M:%S')
    except: return None
out={}
for t in ['SS_IB','BER_GUA','SAN_GUA','SAN_VICCAR','IG_JUR','CA_CON','CA_ILH','CA_ARI']:
    ws=wb[t+'_2025-2026']; it=ws.iter_rows(values_only=True); h=list(next(it))
    i_dp=h.index('De/Para'); i_a=h.index('Término Embarque\nInício Travessia'); i_b=h.index('Término Travessia\nInício Desembarque')
    d={}
    for r in it:
        a,b=p(r[i_a]),p(r[i_b])
        if not a or not b: continue
        m=(b-a).total_seconds()/60
        if 0<m<400: d.setdefault(r[i_dp],[]).append(m)
    for k,v in d.items():
        v.sort(); out[t+'|'+str(k)]=(len(v),round(statistics.median(v),1),round(v[len(v)//4],1),round(v[3*len(v)//4],1))
        print(t,k,out[t+'|'+str(k)])
json.dump(out,open('ct.json','w'),ensure_ascii=False,indent=1)
