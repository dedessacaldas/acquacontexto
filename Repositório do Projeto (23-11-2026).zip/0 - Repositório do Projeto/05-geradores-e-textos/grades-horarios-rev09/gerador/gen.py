import pickle, itertools, base64, html, re, os, json
from collections import OrderedDict

SP = os.path.dirname(os.path.abspath(__file__))
rows = [r for r in pickle.load(open(os.path.join(SP, 'grade_b.pkl'), 'rb'))[1:] if r and r[1] and r[6] is not None]
BG = base64.b64encode(open(os.path.join(SP, 'letterhead.jpg'), 'rb').read()).decode()
OUT = os.path.join(SP, 'html')
os.makedirs(OUT, exist_ok=True)

FIX_NAMES = {
    'Cananeia': 'Cananéia', 'Taquecetuba': 'Taquacetuba', 'Jureia': 'Juréia',
}
def fixname(s):
    s = s.strip()
    for a, b in FIX_NAMES.items():
        s = re.sub(r'\b%s\b' % a, b, s)
    return s

TITLES = OrderedDict([
    ('São Sebastião/Ilhabela', ('São Sebastião ⇄ Ilhabela', 'SaoSebastiao-Ilhabela')),
    ('Santos/Guarujá', ('Santos ⇄ Guarujá', 'Santos-Guaruja')),
    ('Santos/Vicente de Carvalho', ('Santos ⇄ Vicente de Carvalho', 'Santos-VicenteDeCarvalho')),
    ('Bertioga/Guarujá', ('Bertioga ⇄ Guarujá', 'Bertioga-Guaruja')),
    ('Iguape/Jureia', ('Iguape ⇄ Juréia', 'Iguape-Jureia')),
    ('Cananeia/Ilha Comprida', ('Cananéia ⇄ Ilha Comprida', 'Cananeia-IlhaComprida')),
    ('Cananeia/Continente', ('Cananéia ⇄ Continente', 'Cananeia-Continente')),
    ('Cananeia/Ariri', ('Cananéia ⇄ Marujá ⇄ Ariri', 'Cananeia-Ariri')),
    ('Varginha', ('Travessia Varginha', 'Varginha')),
    ('Paraitinga', ('Travessia Paraitinga', 'Paraitinga')),
    ('Natividade', ('Travessia Natividade', 'Natividade')),
    ('Taquacetuba', ('Travessia Taquacetuba', 'Taquacetuba')),
    ('Bororé', ('Travessia Bororé', 'Borore')),
    ('João Basso', ('Travessia João Basso', 'JoaoBasso')),
])
REGIAO = {'Litoral Norte': 'Sistema Litorâneo · Litoral Norte', 'Litoral Centro': 'Sistema Litorâneo · Baixada Santista',
          'Litoral Sul': 'Sistema Litorâneo · Litoral Sul', 'Paraibuna': 'Sistema de Travessias de Paraibuna',
          'Metropolitana': 'Sistema Metropolitano · Represa Billings'}
SERV = {'Veículos e Pedestres': 'Ferry boat · veículos e pedestres', 'Pedestres e Ciclistas': 'Lancha · pedestres e ciclistas'}
REG_ORDER = ['Todos os dias', 'Dias Úteis', 'Segunda a Sexta', 'Sábados', 'Domingos e Feriados', 'Sábados, Domingos e Feriados']
REG_LABEL = {'Dias Úteis': 'Dias úteis', 'Segunda a Sexta': 'Segunda a sexta', 'Sábados': 'Sábados',
             'Domingos e Feriados': 'Domingos e feriados', 'Sábados, Domingos e Feriados': 'Sábados, domingos e feriados',
             'Todos os dias': 'Todos os dias'}

def tmin(t):
    return t.hour * 60 + t.minute
def fmt(m):
    m %= 1440
    return '%02dh%02d' % (m // 60, m % 60)
def fmtc(m):
    m %= 1440
    return '%02d:%02d' % (m // 60, m % 60)

def parse_route(rota):
    if '↔' in rota:
        return [fixname(p) for p in rota.split('↔')], 'both'
    if '→' in rota:
        a, b = rota.split('→'); return (fixname(a), fixname(b)), 'fwd'
    if '←' in rota:
        a, b = rota.split('←'); return (fixname(a), fixname(b)), 'back'
    raise ValueError(rota)

# ---------- build structure ----------
# trav -> {meta, services: {serv: {regime: {ponta: [(min, tipo)]}}}, pontas order}
data = OrderedDict()
for r in rows:
    reg, trav, rota, regime, _, emb, hora, freq, imax, tipo, embarc, prog = r
    d = data.setdefault(trav, {'regiao': reg, 'services': OrderedDict(), 'pontas': [], 'shared': False, 'routes': []})
    pts, mode = parse_route(rota)
    if mode == 'both':
        d['shared'] = True
        for p in pts:
            if p not in d['pontas']: d['pontas'].append(p)
        origins = ['__ALL__']
    else:
        a, b = pts
        for p in (a, b):
            if p not in d['pontas']: d['pontas'].append(p)
        origins = [a if mode == 'fwd' else b]
        dest = b if mode == 'fwd' else a
    if fixname(rota) not in d['routes']: d['routes'].append(fixname(rota))
    s = d['services'].setdefault(emb, OrderedDict())
    rg = s.setdefault(regime, OrderedDict())
    for o in origins:
        lst = rg.setdefault(o, [])
        _iv = imax if isinstance(imax, (int, float)) else (freq if isinstance(freq, (int, float)) else None)
        entry = {'m': tmin(hora), 'tipo': tipo, 'iv': _iv, 'last': isinstance(imax, str) and imax.startswith('Última')}
        if trav == 'Cananeia/Ariri':
            entry['dest'] = dest
        lst.append(entry)


# ---------- Santos/Vicente de Carvalho: tabela enviada pela Dedessa (10/11/2026) ----------
def _hm(t):
    h, m = t.split(':'); return int(h) * 60 + int(m)
def _seq(*parts):
    out = []
    for p in parts:
        if len(p) == 3:
            a, b, iv = p; out += list(range(_hm(a), _hm(b) + 1, iv))
        else:
            out.append(_hm(p[0]))
    return [{'m': m, 'tipo': 'FIX', 'iv': None, 'last': False} for m in sorted(set(out))]
SVC_TAB = {
    'Dias Úteis': {
        'Santos': _seq(('00:00', '01:20', 40), ('02:00', '04:00', 60), ('04:40',), ('05:18', '08:42', 12), ('09:00', '15:40', 20), ('16:06', '19:06', 12), ('19:15', '20:00', 15), ('20:20', '22:40', 20), ('22:54',), ('23:25',)),
        'Vicente de Carvalho': _seq(('00:20', '01:40', 40), ('02:30',), ('03:30',), ('04:20',), ('05:00', '08:24', 12), ('08:40', '16:00', 20), ('16:12', '19:00', 12), ('19:15', '20:00', 15), ('20:20', '22:40', 20), ('23:10',), ('23:40',)),
    },
    'Sábados': {  # 16/11/2026: manhã 12 min intercalado (como dia útil); 20 min simultâneo nas duas margens
        'Santos': _seq(('00:00', '01:20', 40), ('02:00', '04:00', 60), ('04:40',), ('05:18', '08:42', 12), ('09:00', '22:40', 20), ('22:54',), ('23:25',)),
        'Vicente de Carvalho': _seq(('00:20', '01:40', 40), ('02:30',), ('03:30',), ('04:20',), ('05:00', '08:24', 12), ('08:40', '22:40', 20), ('23:10',), ('23:40',)),
    },
    'Domingos e Feriados': {  # 16/11/2026: dia todo 20 min simultâneo nas duas margens
        'Santos': _seq(('00:00', '01:20', 40), ('02:00', '04:00', 60), ('04:40',), ('05:20', '22:40', 20), ('22:54',), ('23:25',)),
        'Vicente de Carvalho': _seq(('00:20', '01:40', 40), ('02:30',), ('03:30',), ('04:20',), ('05:00', '22:40', 20), ('23:10',), ('23:40',)),
    },
}
_svc = data['Santos/Vicente de Carvalho']
for _srv in _svc['services'].values():
    for _reg in list(_srv.keys()):
        if _reg in SVC_TAB:
            _srv[_reg] = OrderedDict(SVC_TAB[_reg])

# ---------- override: Bertioga/Guarujá conforme Anexo 3A Tab. 5 + escala de embarcações (03/11/2026) ----------
BGJ = os.path.join(SP, 'bertioga_grade.json')
if os.path.exists(BGJ):
    g = json.load(open(BGJ))
    regs = OrderedDict()
    for reg, mm in g['regimes'].items():
        regs[reg] = OrderedDict((k, [{'m': m, 'tipo': 'FIX'} for m in sorted(v)]) for k, v in mm.items())
    data['Bertioga/Guarujá']['services']['Veículos e Pedestres'] = regs
    data['Bertioga/Guarujá']['janelas'] = g['janelas']
    # data['Bertioga/Guarujá']['fonte'] = 'Anexo 3A, Tabela 5 (intervalo máximo por margem: 20 min das 07h às 13h e das 16h30 às 18h; 40 min nos demais horários)'

# ---------- helpers ----------
def bands(seq):
    """seq in operational (sheet) order. returns list of (start,end,kind,gap,count)"""
    out = []; i = 0; n = len(seq); covered = -1
    while i < n:
        j = i
        if i < n - 1:
            g = (seq[i + 1]['m'] - seq[i]['m']) % 1440
            tp = seq[i + 1]['tipo']
            while j + 1 < n and (seq[j + 1]['m'] - seq[j]['m']) % 1440 == g and seq[j + 1]['tipo'] == tp:
                j += 1
        if j - i + 1 >= 3:
            st = seq[i]['m'] if seq[i]['tipo'] == tp else seq[i + 1]['m']
            out.append(('run', st, seq[j]['m'], g, tp))
            covered = j
            i = j  # boundary shared with next band
            if i == n - 1: break
            continue
        if i > covered:
            out.append(('single', [seq[i]['m']], seq[i]['tipo']))
        i += 1
    # merge consecutive singles
    merged = []
    for b in out:
        if b[0] == 'single' and merged and merged[-1][0] == 'single':
            merged[-1] = ('single', merged[-1][1] + b[1], merged[-1][2] if merged[-1][2] == b[2] else 'MIX')
        else:
            merged.append(b)
    return merged

def band_html(b):
    if b[0] == 'run':
        _, s, e, g, tipo = b
        if tipo == 'DEM':
            txt = f'conforme demanda · intervalo máx. {g} min'
            cls = 'dem'
        else:
            txt = f'saídas a cada {g} min'; cls = 'fix'
        return f'<div class="band {cls}"><span class="bt">{fmt(s)} – {fmt(e)}</span><span class="bd">{txt}</span></div>'
    times = ', '.join(fmt(m) for m in b[1])
    lab = 'saída' if len(b[1]) == 1 else 'saídas'
    return f'<div class="band fix"><span class="bt">{times}</span><span class="bd">{lab} em horário fixo</span></div>'

def span_info(seq):
    ms = sorted(set(e['m'] for e in seq))
    if len(ms) == 1:
        return fmt(ms[0]), fmt(ms[0]), False
    gaps = [((ms[(k + 1) % len(ms)] - ms[k]) % 1440, k) for k in range(len(ms))]
    gmax, k = max(gaps)
    if gmax < 180:
        return None, None, True
    first = ms[(k + 1) % len(ms)]; last = ms[k]
    return fmt(first), fmt(last), False

def timeline_svg(seq, w=480, h=26):
    pad = 4
    sx = lambda m: pad + (w - 2 * pad) * (m % 1440) / 1440
    parts = [f'<svg class="tl" viewBox="0 0 {w} {h + 12}" width="100%" preserveAspectRatio="none">']
    parts.append(f'<rect x="{pad}" y="4" width="{w-2*pad}" height="{h-8}" rx="3" fill="#EEF5F7"/>')
    for hh in range(0, 25, 3):
        x = sx(hh * 60) if hh < 24 else w - pad
        parts.append(f'<line x1="{x:.1f}" y1="2" x2="{x:.1f}" y2="{h-2}" stroke="#C9D9DF" stroke-width="0.6"/>')
        parts.append(f'<text x="{x:.1f}" y="{h+9}" font-size="7.5" text-anchor="middle" fill="#7A8C94">{hh:02d}h</text>')
    for e in seq:
        x = sx(e['m'])
        col = '#00A9A1' if e['tipo'] == 'DEM' else '#005A7C'
        parts.append(f'<line x1="{x:.1f}" y1="6" x2="{x:.1f}" y2="{h-6}" stroke="{col}" stroke-width="1.3"/>')
    parts.append('</svg>')
    return ''.join(parts)

def regimes_sorted(rg):
    return sorted(rg.keys(), key=lambda k: REG_ORDER.index(k) if k in REG_ORDER else 99)

def origin_label(d, o):
    if o == '__ALL__':
        p = d['pontas']
        if len(p) == 2:
            return f'Saídas de {p[0]} e de {p[1]}'
        return 'Saídas de ' + ', '.join(p[:-1]) + ' e de ' + p[-1]
    return f'Saídas de {o}'

def columns_for(d, rg_map):
    """returns list of (label, seq, note) columns for grid"""
    cols = []
    if '__ALL__' in rg_map:
        seq = rg_map['__ALL__']
        if len(d['pontas']) == 2:
            for p in d['pontas']:
                cols.append((f'Saídas de {p}', seq, 'mesmos horários nas duas margens'))
        else:
            cols.append((origin_label(d, '__ALL__'), seq, 'mesmos horários em todas as pontas'))
    else:
        for p in d['pontas']:
            if p in rg_map:
                cols.append((f'Saídas de {p}', rg_map[p], ''))
    return cols

def dem_blocks(seq):
    """agrupa saídas conforme demanda consecutivas com o mesmo intervalo máximo"""
    items = []  # ('fix', m) | ('dem', start, end, iv, n)
    for e in sorted(seq, key=lambda e: e['m']):
        if e['tipo'] == 'DEM':
            iv = e.get('iv')
            prev = items[-1] if items and items[-1][0] == 'dem' else None
            if prev and e.get('last') and e['m'] - prev[2] <= (prev[3] or 60) + 1:
                k, st, en, iv0, n = prev
                items[-1] = ('dem', st, e['m'], iv0, n + 1)
            elif prev and (prev[3] == iv or iv is None or prev[3] is None) and e['m'] - prev[2] <= max(iv or 0, prev[3] or 0, 1) + 1:
                k, st, en, iv0, n = items[-1]
                items[-1] = ('dem', st, e['m'], iv0 or iv, n + 1)
            else:
                items.append(('dem', e['m'], e['m'], iv, 1))
        else:
            items.append(('fix', e['m']))
    return items

def grid_html(cols, heads=None):
    out = ['<div class="grid cols%d">' % len(cols)]
    for ci, (label, seq, note) in enumerate(cols):
        items = dem_blocks(seq)
        # faixas conforme demanda pelo intervalo real até a saída seguinte (como no Anexo 3A):
        # o bloco começa na 1ª saída conforme demanda e vai até a saída que inicia o bloco seguinte
        dl = sorted(seq, key=lambda e: e['m'])
        nd = len(dl)
        gaps = [((dl[(i + 1) % nd]['m'] - dl[i]['m']) % 1440) or 1440 for i in range(nd)]
        ng = list(gaps)
        for i in range(nd):
            gp, gn = ng[i - 1], gaps[(i + 1) % nd]
            if gaps[i] < gp and gaps[i] != gn and dl[i]['tipo'] == 'DEM':
                ng[i] = gp  # ajuste da última partida do intervalo
        dems = []
        i = 0
        while i < nd:
            if dl[i]['tipo'] == 'DEM':
                j = i
                while j + 1 < nd and dl[j + 1]['tipo'] == 'DEM' and ng[j + 1] == ng[i]:
                    j += 1
                if j > i:
                    st = dl[i]['m']; en = dl[j]['m'] + gaps[j]
                    dems.append(('dem', st, en, ng[i], j - i + 1))
                    i = j + 1
                    continue
            i += 1
        indem = set()
        for _, st, en, iv, n in dems:
            for e in dl:
                if e['tipo'] == 'DEM' and st <= e['m'] < en: indem.add(id(e))
        items = [('fix', e['m']) for e in dl if id(e) not in indem]
        fixes = [x[1] for x in items]
        out.append('<div class="gcol">')
        if heads and len(heads) == len(cols):
            out.append(heads[ci])
        else:
            out.append(f'<div class="ghead"><div class="gl">{html.escape(label)}</div>' + (f'<div class="gn">{note}</div>' if note else '') + '</div>')
        f, l, h24 = span_info(seq)
        func = 'Operação 24 horas' if h24 else f'1ª saída <b>{f.replace("h", ":")}</b> · última <b>{l.replace("h", ":")}</b>'
        out.append(f'<div class="gstat"><span>{func}</span><span><b>{len(seq)}</b> saídas previstas</span></div>')
        out.append('<table class="gt">')
        byh = {}
        for m in fixes:
            byh.setdefault((m // 60) % 24, []).append(m)
        def covered(hh):
            return any((st <= hh * 60 + 59 and en > hh * 60) or (en > 1440 and hh * 60 < en - 1440) for _, st, en, iv, n in dems)
        rowsx = []  # (sortkey, html)
        for hh in range(24):
            ms = sorted(byh.get(hh, []))
            if ms:
                chips = ''.join(f'<span class="c fix">{fmtc(m)}</span>' for m in ms)
                rowsx.append((ms[0], f'<tr><th>{hh:02d}h</th><td>{chips}</td></tr>'))
            elif not covered(hh):
                rowsx.append((hh * 60, f'<tr class="empty"><th>{hh:02d}h</th><td><span class="none">sem saídas</span></td></tr>'))
        for _, st, en, iv, n in dems:
            h1, h2 = st // 60, (en - 1) // 60
            hl = f'{fmt(st)}<span>a</span>{fmt(en)}'
            ivt = f'<span class="dpb">a cada até <b>{iv} min</b></span>' if iv else ''
            rowsx.append((st + 0.5, f'<tr class="demr"><th>{hl}</th><td><div class="dp"><div class="dpl"><span class="dpt">{fmt(st)} às {fmt(en)}</span><span class="dpi">saídas conforme demanda</span></div>{ivt}</div></td></tr>'))
        if CUR['bands']:
            bl = CUR['bands']
            if CUR['off']:
                o = CUR['off'][ci]
                bl = [(st + o, en + o, iv, k) if k == 'fix' else (st, en, iv, k) for st, en, iv, k in bl]
            rowsx = [(i, r) for i, r in enumerate(band_rows(bl))]
        if len(rowsx) <= 6:
            out[-1] = out[-1].replace('<table class="gt">', '<table class="gt roomy few">')
        elif len(rowsx) <= 16:
            out[-1] = out[-1].replace('<table class="gt">', '<table class="gt roomy">')
        for _, h in sorted(rowsx, key=lambda x: x[0]):
            out.append(h)
        out.append('</table></div>')
    out.append('</div>')
    return ''.join(out)

# ---------- faixas cheias do Anexo 3A (pedido da Dedessa, 09/11/2026) ----------
def _h(t):
    h, m = t.split(':'); return int(h) * 60 + int(m)
def _b(*xs):
    return [(_h(a), _h(b), iv, k) for a, b, iv, k in xs]
BANDS = {
    'Santos/Guarujá': {
        'Dias Úteis': _b(('00:00', '05:00', 30, 'fix'), ('05:00', '06:30', 20, 'dem'), ('06:30', '20:00', 12, 'dem'), ('20:00', '24:00', 20, 'dem')),
        'Sábados': _b(('00:00', '06:30', 30, 'fix'), ('06:30', '09:00', 15, 'dem'), ('09:00', '20:30', 12, 'dem'), ('20:30', '24:00', 15, 'dem')),
        'Domingos e Feriados': _b(('00:00', '05:30', 30, 'fix'), ('05:30', '09:00', 20, 'dem'), ('09:00', '21:00', 12, 'dem'), ('21:00', '24:00', 20, 'dem')),
    },
    'Taquacetuba': {
        'Dias Úteis': _b(('05:00', '22:00', 40, 'dem'), ('22:00', '29:00', 60, 'dem')),
        'Sábados, Domingos e Feriados': _b(('01:00', '06:00', 60, 'dem'), ('06:00', '25:00', 40, 'dem')),
    },
    'João Basso': {
        'Dias Úteis': _b(('00:00', '01:00', 40, 'dem'), ('01:00', '05:00', 60, 'dem'), ('05:00', '07:00', 40, 'dem'), ('07:00', '19:00', 20, 'dem'), ('19:00', '24:00', 40, 'dem')),
        'Sábados, Domingos e Feriados': _b(('00:00', '01:00', 30, 'dem'), ('01:00', '06:00', 60, 'dem'), ('06:00', '09:00', 30, 'dem'), ('09:00', '19:00', 20, 'dem'), ('19:00', '24:00', 30, 'dem')),
    },
    'Natividade': {
        'Dias Úteis': _b(('00:00', '05:00', 60, 'fix'), ('06:00', '07:30', 40, 'dem'), ('08:00', '19:30', 20, 'dem'), ('20:00', '23:30', 40, 'dem')),
        'Sábados, Domingos e Feriados': _b(('00:00', '05:00', 60, 'fix'), ('06:00', '09:30', 40, 'dem'), ('10:00', '11:30', 20, 'dem'), ('12:00', '15:30', 40, 'dem'), ('16:00', '19:30', 20, 'dem'), ('20:00', '23:30', 40, 'dem')),
    },
    'Bororé': {
        'Dias Úteis': _b(('01:00', '05:00', 60, 'dem'), ('05:00', '07:00', 40, 'dem'), ('07:00', '19:00', 20, 'dem'), ('19:00', '25:00', 40, 'dem')),
        'Sábados, Domingos e Feriados': _b(('01:00', '06:00', 60, 'dem'), ('06:00', '09:00', 30, 'dem'), ('09:00', '19:00', 20, 'dem'), ('19:00', '25:00', 30, 'dem')),
    },
    'Paraitinga': {'Todos os dias': _b(('00:00', '05:00', 60, 'fix'), ('06:00', '23:30', 40, 'dem'))},
    'Varginha': {'Todos os dias': _b(('00:00', '05:00', 60, 'fix'), ('06:00', '23:30', 45, 'dem'))},
}
CUR = {'bands': None, 'off': None}
# madrugada intercalada entre as pontas (pedido da Dedessa, 18/11/2026): minutos somados às faixas fixas, por coluna
INTER = {'Varginha': [30, 0], 'Paraitinga': [30, 0], 'Natividade': [0, 30]}

def band_rows(bl):
    rows = []
    for st, en, iv, k in bl:
        h1, h2 = st // 60, (en - 1) // 60
        hl = f'{fmt(st)}<span>a</span>{fmt(en)}'
        ent = fmt(en)
        if k == 'fix':
            ms = list(range(st, en + 1, iv))
            byh = {}
            for m in ms:
                byh.setdefault(m // 60, []).append(m)
            for hh in sorted(byh):
                chips = ''.join(f'<span class="c fix">{fmtc(m)}</span>' for m in byh[hh])
                rows.append(f'<tr><th>{hh:02d}h</th><td>{chips}</td></tr>')
            continue
            rows.append(f'<tr class="demr fixr"><th>{hl}</th><td><div class="dp fx"><div class="dpl"><span class="dpt">{fmt(st)} às {ent}</span><span class="dpi">saídas em horário fixo</span></div><span class="dpb">a cada <b>{iv} min</b></span></div></td></tr>')
        else:
            rows.append(f'<tr class="demr"><th>{hl}</th><td><div class="dp"><div class="dpl"><span class="dpt">{fmt(st)} às {ent}</span><span class="dpi">saídas conforme demanda</span></div><span class="dpb">a cada até <b>{iv} min</b></span></div></td></tr>')
    return rows

LEGEND = '''<div class="legend">
 <div class="li"><span class="c fix">00</span><div><b>Horário fixo</b><br>Saída programada no minuto indicado.</div></div>
 <div class="li"><span class="c dem">00</span><div><b>Operação conforme demanda</b><br>A embarcação sai ao completar a lotação, sem ultrapassar o intervalo máximo. O horário indicado é a saída garantida; pode haver saídas extras entre eles.</div></div>
</div>'''

CSS = open(os.path.join(SP, 'style.css')).read()

def page(inner, cls=''):
    return f'<section class="page {cls}"><div class="content">{inner}</div></section>'

def header(d, title, sub=None):
    reg = REGIAO.get(d['regiao'], d['regiao'])
    return (f'<div class="eyebrow">Grade de horários · {html.escape(reg)}</div>'
            f'<h1>{html.escape(title)}</h1>' + (f'<div class="sub">{sub}</div>' if sub else ''))

def mini_header(title, chip, serv, d=None):
    reg = REGIAO.get(d['regiao'], d['regiao']) if d else ''
    return (f'<div class="eyebrow">Grade de horários · {html.escape(reg)}</div>'
            f'<div class="mh"><div><div class="mht">{html.escape(title)}</div><div class="serv">{html.escape(serv)}</div></div>'
            f'<div class="mhs"><div class="chiplbl">Válida para</div><span class="chip">{html.escape(chip)}</span></div></div>')

OPLEG = ('<div class="opleg"><div class="ol"><span class="c fix">07:20</span> <b>Horário fixo</b>: sair exatamente no horário.</div>'
         '<div class="ol"><span class="dpk">12 min</span> <b>Conforme demanda</b>: sair ao lotar, sem deixar passar o intervalo máximo entre uma saída e outra.</div>'
         '<div class="src">Horários sujeitos a alteração por maré, clima ou determinação da autoridade marítima.</div></div>')

def janelas_html(js):
    rows = ''.join(f'<tr><td class="jt">{t}</td><td class="jn"><span class="nb{1 if n.startswith("1") else 2}">{n}</span></td><td>{x}</td></tr>' for t, n, x in js)
    return f'<div class="bandlbl">Janelas de operação e escala de embarcações</div><table class="jan">{rows}</table>'

def oplegfor(d, cols):
    t = OPLEG.replace('Quantitativo de Viagens Acquavias – REV09 (aba GRADE)', d['fonte']) if d.get('fonte') else OPLEG
    if not any(e['tipo'] == 'DEM' for c in cols for e in c[1]):
        t = re.sub(r'<div class="ol"><span class="dpk">.*?</div>', '', t, flags=re.S)
    return t


# tempo de navegação (mediana, fim do embarque -> início do desembarque), históricos REV09 ago/2025-out/2026
TRAV_MIN = {
    ('São Sebastião', 'Ilhabela'): 20, ('Ilhabela', 'São Sebastião'): 21,
    ('Santos', 'Guarujá'): 6, ('Guarujá', 'Santos'): 6,
    ('Santos', 'Vicente de Carvalho'): 12, ('Vicente de Carvalho', 'Santos'): 14,
    ('Bertioga', 'Guarujá'): 9, ('Guarujá', 'Bertioga'): 9,
    ('Iguape', 'Juréia'): 5, ('Juréia', 'Iguape'): 6,
    ('Cananéia', 'Continente'): 8, ('Continente', 'Cananéia'): 8,
    ('Cananéia', 'Ilha Comprida'): 8, ('Ilha Comprida', 'Cananéia'): 9,
}

def itin_html(d, cols):
    pts = d['pontas']
    cards = []
    if len(pts) == 2:
        for i, (label, seq, note) in enumerate(cols):
            o = label.replace('Saídas de ', '')
            dst = pts[1] if o == pts[0] else pts[0]
            kind = 'ida' if i == 0 else 'volta'
            foot = '<div class="itf">Mesmos horários nas duas margens</div>' if note else ''
            cards.append(f'<div class="itc"><div class="it {kind} cmp nm"><div class="itl">'
                         f'<div class="st first"><div class="sl">Saída</div><div class="stn">{html.escape(o)}</div><div class="dot"></div></div>'
                         f'<div class="seg"></div>'
                         f'<div class="st last"><div class="sl">Destino</div><div class="stn">{html.escape(dst)}</div><div class="dot"></div></div>'
                         f'</div></div>{foot}</div>')
    elif len(cols) == 2:
        for i, (label, seq, note) in enumerate(cols):
            o = label.replace('Saídas de ', '')
            dst = ' e '.join(pts[1:]) if i == 0 else pts[0]
            kind = 'ida' if i == 0 else 'volta'
            cards.append(f'<div class="itc"><div class="it {kind} cmp nm"><div class="itl">'
                         f'<div class="st first"><div class="sl">Saída</div><div class="stn">{html.escape(o)}</div><div class="dot"></div></div>'
                         f'<div class="seg"></div>'
                         f'<div class="st last"><div class="sl">Destino</div><div class="stn">{html.escape(dst)}</div><div class="dot"></div></div>'
                         f'</div></div></div>')
    else:
        st = []
        for k, p in enumerate(pts):
            if k: st.append('<div class="seg nodir"></div>')
            st.append(f'<div class="st mid"><div class="sl">{"Ponta" }</div><div class="stn">{html.escape(p)}</div><div class="dot"></div></div>')
        cards.append('<div class="itc"><div class="it ida cmp nm"><div class="itl">' + ''.join(st) + '</div></div><div class="itf">Mesmos horários de saída em todas as pontas</div></div>')
    return cards

def itin_full(d, cols):
    c = itin_html(d, cols)
    return '<div class="itrow cols1">' + ''.join(c) + '</div>' + grid_html(cols)

FONTE = '<div class="fonte">Fonte: Quantitativo de Viagens Acquavias – REV09 (aba GRADE). Referência contratual: Anexo 3A – Caderno de Encargos, item 2.7 (Programação Operacional Mínima Inicial).</div>'

def build_standard(trav, d):
    title, slug = TITLES[trav]
    pages = []
    servs = list(d['services'].keys())
    sub = ' · '.join(SERV[s] for s in servs)
    # overview
    ov = [header(d, title, sub)]
    if trav in ('Varginha', 'Paraitinga', 'Natividade'):
        rota = d['routes'][0]
        ov.append(f'<div class="route">Rota: {html.escape(rota)}</div>')
    ov.append('<h2>Resumo da operação</h2>')
    for s in servs:
        rg = d['services'][s]
        if len(servs) > 1:
            ov.append(f'<h3>{SERV[s]}</h3>')
        ov.append('<table class="sum"><thead><tr><th>Dia</th><th>Ponta de saída</th><th>Funcionamento</th><th>Saídas/dia</th><th class="tlh">Distribuição ao longo do dia</th></tr></thead><tbody>')
        for regime in regimes_sorted(rg):
            rmap = rg[regime]
            keys = list(rmap.keys())
            for i, o in enumerate(keys):
                seq = rmap[o]
                f, l, h24 = span_info(seq)
                func = '24 horas' if h24 else f'{f} às {l}'
                lab = ('Todas as pontas' if len(d['pontas']) > 2 else 'Ambas as margens') if o == '__ALL__' else o
                regcell = f'<td rowspan="{len(keys)}" class="rg">{REG_LABEL.get(regime, regime)}</td>' if i == 0 else ''
                ov.append(f'<tr>{regcell}<td>{html.escape(lab)}</td><td class="nw">{func}</td><td class="num">{len(seq)}</td><td class="tlc">{timeline_svg(seq)}</td></tr>')
        ov.append('</tbody></table>')
    ov.append('<h2>Como ler esta grade</h2>')
    ov.append(LEGEND)
    ov.append('<ul class="notes">'
              '<li>Cada página seguinte traz a grade de um tipo de dia. Na coluna da esquerda está a hora; ao lado, os minutos de cada saída. Exemplo: <b>07h</b> com <span class="c fix">20</span> <span class="c fix">40</span> significa saídas às 07:20 e às 07:40.</li>'
              '<li>Feriados seguem a grade de domingos e feriados, quando houver.</li>'
              '<li>Horários sujeitos a alteração por condições de maré, clima, segurança da navegação ou determinação da autoridade marítima.</li>'
              '</ul>')
    ov.append(FONTE)
    # grids
    for s in servs:
        rg = d['services'][s]
        for regime in regimes_sorted(rg):
            rmap = rg[regime]
            CUR['bands'] = BANDS.get(trav, {}).get(regime)
            cols = columns_for(d, rmap)
            CUR['off'] = INTER.get(trav)
            if trav in INTER:
                cols = [(c[0], c[1], '') for c in cols]
                if len(cols) == 1:
                    oth = ' e '.join(d['pontas'][1:])
                    cols = [(f'Saídas de {d["pontas"][0]}', cols[0][1], ''), (f'Saídas de {oth}', cols[0][1], '')]
            # bands
            uniq = cols[:1] if all(c[1] is cols[0][1] for c in cols) else cols
            bh = ['<div class="bands cols%d%s">' % (len(uniq), ' merged' if len(uniq) < len(cols) or len(cols) == 1 else '')]
            for label, seq, note in uniq:
                bh.append('<div class="bcol">' + ''.join(band_html(b) for b in bands(seq)) + '</div>')
            bh.append('</div>')
            inner = (mini_header(title, REG_LABEL.get(regime, regime), SERV[s], d) + (janelas_html(d['janelas'][regime] if isinstance(d['janelas'], dict) else d['janelas']) if d.get('janelas') else ('' if any(e['tipo'] == 'DEM' for c in cols for e in c[1]) else '<div class="bandlbl">Faixas de operação</div>' + ''.join(bh))) + (grid_html(cols, itin_html(d, cols)) if len(itin_html(d, cols)) == len(cols) else itin_full(d, cols)) + oplegfor(d, cols))
            nb = max(len(bands(c[1])) for c in uniq)
            pages.append(page(inner, 'gridpage' + (' dense' if (nb > 4 and len(uniq) > 1) or d.get('janelas') else '')))
    return slug, title, pages

DIAS = ['Segunda-feira', 'Terça-feira', 'Quarta-feira', 'Quinta-feira', 'Sexta-feira']
# chegadas por trecho (Programação Operacional REV05, item 3.8.3): (dia, origem, destino) -> chegada
ARIRI_CHEG = {
    ('Segunda-feira', 'Cananéia', 'Marujá'): '16:00', ('Segunda-feira', 'Marujá', 'Ariri'): '16:30',
    ('Terça-feira', 'Ariri', 'Marujá'): '08:00', ('Terça-feira', 'Marujá', 'Cananéia'): '11:30',
    ('Quarta-feira', 'Cananéia', 'Marujá'): '11:00', ('Quarta-feira', 'Marujá', 'Ariri'): '12:00',
    ('Quarta-feira', 'Ariri', 'Marujá'): '13:30', ('Quarta-feira', 'Marujá', 'Cananéia'): '16:30',
    ('Quinta-feira', 'Cananéia', 'Marujá'): '11:00', ('Quinta-feira', 'Marujá', 'Ariri'): '12:45',
    ('Sexta-feira', 'Ariri', 'Marujá'): '08:30', ('Sexta-feira', 'Marujá', 'Cananéia'): '11:30',
}

def build_ariri(trav, d):
    title, slug = TITLES[trav]
    rg = d['services']['Pedestres e Ciclistas']
    legs = {k: [] for k in DIAS}
    for day, rmap in rg.items():
        for o, seq in rmap.items():
            for e in seq:
                legs[day].append((e['m'], o, e['dest'], ARIRI_CHEG.get((day, o, e['dest']), '—')))
    for k in legs: legs[k].sort()
    # montar viagens completas (ida e volta)
    ida, volta = [], []
    for day in DIAS:
        L = legs[day]
        for i, (m, o, dd, ch) in enumerate(L):
            if o == 'Cananéia':
                nxt = next((x for x in L[i+1:] if x[1] == 'Marujá' and x[2] == 'Ariri'), None)
                ida.append((day, fmtc(m), ch, nxt and fmtc(nxt[0]), nxt and nxt[3]))
            if o == 'Ariri':
                nxt = next((x for x in L[i+1:] if x[1] == 'Marujá' and x[2] == 'Cananéia'), None)
                volta.append((day, fmtc(m), ch, nxt and fmtc(nxt[0]), nxt and nxt[3]))
    def dn(x): return x.replace('-feira', '')
    ov = [header(d, title, 'Lancha · pedestres e ciclistas · linha semanal')]
    ov.append('<div class="route">Linha semanal que liga Cananéia ao Ariri com parada no Marujá. Opera de segunda a sexta; não há viagens aos sábados e domingos.</div>')
    def trip_table(t, cols, rows):
        h = ''.join(f'<th>{c}</th>' for c in cols)
        body = ''.join(f'<tr><td class="dn">{dn(r[0])}</td><td class="t out">{r[1]}</td><td class="t">{r[2]}</td><td class="t in">{r[4] or "—"}</td></tr>' for r in rows)
        return f'<h2>{t}</h2><table class="trip"><thead><tr>{h}</tr></thead><tbody>{body}</tbody></table>'
    def mins(t): h, m = t.split(':'); return int(h) * 60 + int(m)
    def dur(a, b):
        x = mins(b) - mins(a); return f'{x // 60}h{x % 60:02d}' if x >= 60 else f'{x} min'
    trips = [(DIAS.index(r[0]), r[1], 'ida', r) for r in ida] + [(DIAS.index(r[0]), r[1], 'volta', r) for r in volta]
    trips.sort()
    rows = []
    for di, _, kind, r in trips:
        day, t0, t1, _, t2 = r
        stops = (['Cananéia', 'Marujá', 'Ariri'] if kind == 'ida' else ['Ariri', 'Marujá', 'Cananéia'])
        lab = ('Ida', 'para o Ariri') if kind == 'ida' else ('Volta', 'para Cananéia')
        rows.append(f"""<div class="it {kind}">
  <div class="itd"><div class="itday">{dn(day)}</div><div class="itk">{lab[0]} · {lab[1]}</div></div>
  <div class="itl">
    <div class="st first"><div class="sl">Saída</div><div class="stt">{t0}</div><div class="dot"></div><div class="sn">{stops[0]}</div></div>
    <div class="seg"><span>{dur(t0, t1)}</span></div>
    <div class="st mid"><div class="sl">Parada</div><div class="stt">{t1}</div><div class="dot"></div><div class="sn">{stops[1]}</div></div>
    <div class="seg"><span>{dur(t1, t2)}</span></div>
    <div class="st last"><div class="sl">Chegada</div><div class="stt">{t2}</div><div class="dot"></div><div class="sn">{stops[2]}</div></div>
  </div></div>""")
    ov.append('<h2>Viagens da semana</h2><div class="its">' + ''.join(rows) + '<div class="it off"><div class="itd"><div class="itday">Sábado e domingo</div></div><div class="itoff">sem viagens</div></div></div>')
    ov.append('<ul class="notes"><li>Cada linha é uma viagem, lida da esquerda para a direita: saída, parada no Marujá e chegada. <b>Azul</b> = ida (Cananéia → Ariri); <b>verde</b> = volta (Ariri → Cananéia).</li>'
              '<li>No Marujá a lancha chega e segue no mesmo horário. Saídas são fixas; chegadas são previstas e podem variar com a maré e as condições de navegação.</li></ul>')
    ov.append('<div class="fonte">Horários sujeitos a alteração por maré, clima ou determinação da autoridade marítima.</div>')
    return slug, title, [page(''.join(ov), 'cover')]

manifest = []
for trav, d in data.items():
    if trav == 'Cananeia/Ariri':
        slug, title, pages = build_ariri(trav, d)
    else:
        slug, title, pages = build_standard(trav, d)
    doc = f'<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><title>Grade de Horários – {html.escape(title)}</title><style>{CSS}\n.page{{background-image:url(data:image/jpeg;base64,{BG});}}</style></head><body>{"".join(pages)}</body></html>'
    fn = os.path.join(OUT, slug + '.html')
    open(fn, 'w').write(doc)
    manifest.append({'html': fn, 'slug': slug, 'title': title, 'pages': len(pages)})
json.dump(manifest, open(os.path.join(SP, 'manifest.json'), 'w'), ensure_ascii=False, indent=1)
print(len(manifest), [m['slug'] + ':' + str(m['pages']) for m in manifest])
