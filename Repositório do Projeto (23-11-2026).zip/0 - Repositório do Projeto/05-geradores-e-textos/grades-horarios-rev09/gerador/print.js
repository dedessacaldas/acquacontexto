const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');
(async () => {
  const sp = __dirname;
  const man = JSON.parse(fs.readFileSync(path.join(sp, 'manifest.json')));
  const outDir = process.argv[2];
  fs.mkdirSync(outDir, { recursive: true });
  const b = await chromium.launch();
  const p = await b.newPage();
  for (const m of man) {
    await p.goto('file://' + m.html);
    await p.evaluate(() => document.fonts.ready);
    // overflow check
    const of = await p.evaluate(() => [...document.querySelectorAll('.content')].map((c, i) => c.scrollHeight - c.clientHeight).map((d, i) => d > 1 ? i + ':' + d : null).filter(Boolean));
    if (of.length) console.log('OVERFLOW', m.slug, of);
    await p.pdf({ path: path.join(outDir, 'Grade de Horários - ' + m.title.replace(/[⇄]/g, '-').replace(/\s+/g, ' ') + '.pdf'), format: 'A4', printBackground: true, preferCSSPageSize: true });
  }
  await b.close();
})();
