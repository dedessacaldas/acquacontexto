### Avaliação do Usuário (IAU)

Periodicidade: semestral, um por travessia (pesquisa de satisfação)
**Cálculo:** $$IAU_1 = \frac {ICHC \cdot 2 + ICSI + IPSI + IUFU + ICCG + IOED + ITEE + ICHP + IEGM} {10} $$
==**ICHC:** Índice das condições de higiene e conforto (peso 2) - (Pesquisa de satisfação)==
==**ICSI:** Índice das condições de segurança e iluminação - (Pesquisa de satisfação)==
==**IPSI:** Índice de sinalização e disponibilização de informações - (Pesquisa de satisfação)==
==**IUFU:** Índice de urbanidade dos funcionários no trato com os usuários - (Pesquisa de satisfação)==
==**ICCG:** Índice de cumprimento de gratuidades e tratamento prioritário - (Pesquisa de satisfação)==
==**IOED:** Índice de organização do embarque e desembarque - (Pesquisa de satisfação)==
==**ITEE:** Índice do tempo de espera para embarque - (Pesquisa de satisfação)==
==**ICHP:** Índice de cumprimento dos horários/intervalos programados - (Pesquisa de satisfação)==
==**IEGM:** Índice do estado geral de manutenção das embarcações e terminais - (Pesquisa de satisfação)==

Cada índice (0 a 1) é calculado da mesma forma:
$$I_x = \frac {B_1 + B_2 + B_3} {B_1 + B_2 + B_3 + B_4 + B_5}$$
	**B1** Excelente · **B2** Bom · **B3** Regular · **B4** Ruim · **B5** Péssimo (nº de registros de cada grau)

$$IAU = \frac {IAU_1- LO_2} {LO_1 - LO_2}$$

| Período de apuração | REF - Meta para o indicador | $$LO_1$$ | $$LO_2$$ |
| ------------------- | --------------------------- | -------- | -------- |
| ==🟠Etapas 1, 2 e 3==     | ==🟠0,80==                        | ==🟠0,70==     | ==🟠0,40==     |
| Etapa 4             | 0,90                        | 0,80     | 0,60     |
Resultado limitado a $$0 \le IAU \le 1$$ (se $$IAU_1 \ge LO_1$$ considerar $$IAU = 1$$; se $$IAU_1 \le LO_2$$ considerar $$IAU = 0$$)
Pontuações calculadas com **2 casas decimais**
Não entra direto no IQS: compõe o **FQ** com peso 0,8 → ver [[ISS]]
Pesquisa feita por **instituto independente** contratado pela concessionária e designado pela ARTESP (lista tríplice); metodologia aprovada previamente pela ARTESP

> Fonte: Anexo 8 – Indicadores de Desempenho, itens 3.4.4 (p. 7) e 9.7.4 a 9.7.21 (pp. 32–38), Tabela 6.
