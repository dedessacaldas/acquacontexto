### Ocupação das Embarcações (IOE)

Periodicidade: mensal, um por travessia (dados diários, por viagem)
**Cálculo:** $$IOE = \frac {QT_d} {CT_d} \cdot 100 $$
==**QTd:** Quantidade de veículos equivalentes ou pedestres transportados por dia - (Registro de viagens / bilhetagem)==
	$$QT_d = \sum_i QT_{d,i} = \sum_i \sum_v Q_{v,i} \cdot F_{eq,v}$$
==**CTd:** Capacidade de transporte ofertada por dia, em veículos equivalentes - (CSN das embarcações × viagens realizadas)==
	$$CT_d = \sum C_i$$ (capacidade legal de cada embarcação, conforme o CSN)

| Tipo de veículo                  | $$F_{eq}$$                  |
| -------------------------------- | --------------------------- |
| Automóvel                        | 1                           |
| Moto                             | 0,33                        |
| VUC, ambulância, carro-forte     | 1,5                         |
| Ônibus e caminhão                | 2,5                         |
| Bicicleta                        | 1 em lancha / 0,17 em balsa |
| Pedestre                         | 1 em lancha / 0 em balsa    |
Sem normalização, sem $$LO_1$$/$$LO_2$$ e **sem meta**: varia de 0% a 100%, quanto maior melhor, sem ultrapassar a capacidade legal (CSN)
**Não entra no IQS**: serve para análise de desempenho e revisão das frequências programadas (ocupação no limite ou muito baixa = rever frequência); pode ser usado para outros fins do contrato, como a **parcela variável da contraprestação**
Consolidação mensal por **média ponderada pela tarifa**: dias com fator tarifário de 150% (fins de semana) têm peso 1,5
Disponibilizar também o cálculo diário e a consolidação semanal, separando dias úteis e fins de semana
Viagens com veículos que por lei vão sozinhos (valores, inflamáveis, lixo) **não entram** no cálculo

> Fonte: Anexo 8 – Indicadores de Desempenho, itens 3.4.6 (p. 7) e 9.4.1 a 9.4.11 (pp. 24–26).
