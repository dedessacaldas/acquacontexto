### Reclamações dos Usuários (IRE)

Periodicidade: mensal
**Cálculo:** $$IRE_1 = \frac {T_t - T_r} {T_t} $$
==**Tt:** Total de pessoas ou veículos transportados, conforme a travessia - (Bilhetagem / passageiros transportados)==
==**Tr:** Quantidade de registros de reclamações × 10.000 - (Canal de reclamações / SAC)==
	Ou seja: $$IRE_1 = 1 - \frac {N_{reclamações} \cdot 10.000} {T_t}$$

$$IRE = \frac {IRE_1- LO_2} {LO_1 - LO_2}$$

| Período de apuração | REF - Meta para o indicador | $$LO_1$$ | $$LO_2$$ |
| ------------------- | --------------------------- | -------- | -------- |
| ==🟠Etapas 1, 2 e 3==     | ==🟠0,75==                        | ==🟠0,65==     | ==🟠0,45==     |
| Etapa 4             | 0,85                        | 0,70     | 0,50     |
Resultado limitado a $$0 \le IRE \le 1$$ (se $$IRE_1 \ge LO_1$$ considerar $$IRE = 1$$; se $$IRE_1 \le LO_2$$ considerar $$IRE = 0$$)
Não entra direto no IQS: compõe o **FQ** com peso 0,2 → ver [[ISS]]
A concessionária deve manter um **canal direto e permanente** para os usuários registrarem reclamações e sugestões

> Fonte: Anexo 8 – Indicadores de Desempenho, itens 3.4.5 (p. 7), 9.7.2, 9.7.4 e 9.7.22 a 9.7.24 (pp. 32 e 38), Tabela 7.
