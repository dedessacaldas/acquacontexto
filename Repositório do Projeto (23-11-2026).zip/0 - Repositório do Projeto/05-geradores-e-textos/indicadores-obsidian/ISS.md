### Satisfação do Serviço (ISS) → Fator de Qualidade (FQ)

Periodicidade: a cada nova pesquisa do [[IAU]] (semestral); o [[IRE]] é apurado mensalmente
**Cálculo:** $$FQ_1 = 0,8 \cdot IAU + 0,2 \cdot IRE $$
==**IAU:** Indicador de Avaliação do Usuário, já normalizado - ([[IAU]] / Pesquisa de satisfação)==
==**IRE:** Indicador de Reclamações dos Usuários, já normalizado - ([[IRE]] / Canal de reclamações)==

$$IQS = \left[ IVP \cdot 0,20 + (IHP \cdot n_1 + ITP \cdot n_2) \cdot 0,34 + IDF \cdot 0,15 + IAD \cdot 0,30 \right] \cdot FQ$$

| $$FQ_1$$ (igual ou maior que) | FQ - Bônus sobre o IQS (não cumulativo) |
| ----------------------------- | --------------------------------------- |
| 0,80                          | 1,05                                    |
| 0,85                          | 1,10                                    |
| 0,90                          | 1,13                                    |
| 0,95 até 1                    | 1,15                                    |
FQ funciona só como **bônus**: multiplica o valor final do IQS
Se $$IQS \cdot FQ > 1$$ considerar $$IQS = 1$$
O FQ passa a valer na **Notificação de Pagamento seguinte** ao Relatório de Pesquisa final do Verificador Independente e vale **até a próxima pesquisa**
	Se $$FQ_1 < 0,80$$ a tabela não traz valor → leitura: sem bônus, $$FQ = 1$$ (o anexo não diz expressamente)

> Fonte: Anexo 8 – Indicadores de Desempenho, itens 3.4 (p. 5), 3.4.4–3.4.5 (p. 7), 9.7.1 e 9.7.25 (pp. 32 e 39), Tabela "Valor do Fator Multiplicador – FQ".
