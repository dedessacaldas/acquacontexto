const { chromium } = require('playwright');
(async () => {
  const [,, src, out, png] = process.argv;
  const b = await chromium.launch(); const p = await b.newPage({deviceScaleFactor:1});
  await p.goto('file://' + src); await p.evaluate(() => document.fonts.ready);
  await p.pdf({ path: out, format: 'A4', printBackground: true, preferCSSPageSize: true });
  await b.close();
})();
