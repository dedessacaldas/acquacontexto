# Gera as bases tratadas para o Power BI (referência da lógica que o Power Query reproduz)
import sys, pandas as pd, numpy as np, datetime as dt
sys.path.insert(0, '.')
from norm import load_rev00
IN = '../in/'; OUT = sys.argv[1]
TOL_ANTES, TOL_DEPOIS = 10, 15        # janela de casamento para horário fixo (min)

# ---------------- dTravessia / de-para ----------------
dT = pd.DataFrame([
 # id, nome padrão, região, embarque, margem sentido1, margem sentido2, nome BD_QT, nome BSM, modo BSM
 ('SG','Santos ⇄ Guarujá','Baixada Santista','Veículos e pedestres','Santos','Guarujá','Santos/Guarujá','Santos/Guarujá','Ferry boat',1),
 ('SVC','Santos ⇄ Vicente de Carvalho','Baixada Santista','Pedestres e ciclistas','Santos','Vicente de Carvalho','Santos/Vicente de Carvalho','Santos/Vicente de Carvalho','Lancha',2),
 ('BG','Bertioga ⇄ Guarujá','Baixada Santista','Veículos e pedestres','Bertioga','Guarujá','Bertioga/Guarujá','Bertioga/Guarujá','Ferry boat',3),
 ('SSI_FB','São Sebastião ⇄ Ilhabela · balsa','Litoral Norte','Veículos e pedestres','São Sebastião','Ilhabela','São Sebastião/Ilhabela - Veículos e Pedestres','São Sebastião/Ilhabela','Ferry boat',4),
 ('SSI_LS','São Sebastião ⇄ Ilhabela · lancha','Litoral Norte','Pedestres e ciclistas','São Sebastião','Ilhabela','São Sebastião/Ilhabela - Pedestres e Ciclistas','São Sebastião/Ilhabela','Lancha',5),
 ('CC','Cananéia ⇄ Continente','Litoral Sul','Veículos e pedestres','Cananéia','Continente','Cananeia/Continente','Cananéia/Continente','Ferry boat',6),
 ('CIC','Cananéia ⇄ Ilha Comprida','Litoral Sul','Veículos e pedestres','Cananéia','Ilha Comprida','Cananeia/Ilha Comprida','Cananéia/Ilha Comprida','Ferry boat',7),
 ('IJ','Iguape ⇄ Juréia','Litoral Sul','Veículos e pedestres','Iguape','Juréia','Iguape/Jureia','Iguape/Juréia','Ferry boat',8),
 ('CA','Cananéia ⇄ Marujá ⇄ Ariri','Litoral Sul','Pedestres e ciclistas','Cananéia','Ariri','Cananeia/Ariri','Cananéia/Ariri','Lancha',9),
 ('NAT','Natividade','Paraibuna','Veículos e pedestres','Natividade','Pouso Alto / Bairro Alto','Natividade','Natividade da Serra/B. Natividade da Serra','Ferry boat',10),
 ('PAR','Paraitinga','Paraibuna','Veículos e pedestres','Ribeirão Branco',"Capim D'Angola",'Paraitinga','Ribeirão Branco/Capim DAngola','Ferry boat',11),
 ('VAR','Varginha','Paraibuna','Veículos e pedestres','Comércio','Varginha','Varginha','Comércio/Varginha','Ferry boat',12),
 ('JB','João Basso','Metropolitana','Veículos e pedestres','João Basso','Riacho Grande','João Basso','','Ferry boat',13),
 ('TAQ','Taquacetuba','Metropolitana','Veículos e pedestres','Taquacetuba','Bororé','Taquacetuba','','Ferry boat',14),
 ('BOR','Bororé','Metropolitana','Veículos e pedestres','Bororé','Grajaú','Bororé','','Ferry boat',15),
], columns=['TravessiaID','Travessia','Regiao','TipoEmbarque','Margem1','Margem2','NomeQuantitativo','NomeExportViagens','ModoExport','Ordem'])
dT['EmOperacao'] = np.where(dT.NomeExportViagens != '', 'Sim', 'Não')

# ---------------- dCalendario ----------------
FER = pd.to_datetime(['2026-11-15','2026-11-20','2026-12-25','2027-01-01','2027-02-08','2027-02-09','2027-03-26','2027-04-21','2027-05-01','2027-05-27','2027-07-09','2027-09-07','2027-10-12','2027-11-02'])
INI = pd.Timestamp('2026-11-09')
cal = pd.DataFrame({'Data': pd.date_range(INI, '2027-11-08')})
dsem = ['SEG','TER','QUA','QUI','SEX','SAB','DOM']
cal['DiaSemana'] = cal.Data.dt.weekday.map(lambda i: dsem[i])
cal['Feriado'] = cal.Data.isin(FER)
cal['CodDiaGrade'] = np.where(cal.Feriado, 'FER', cal.DiaSemana)
cal['TipoDia'] = np.where(cal.Feriado | (cal.DiaSemana == 'DOM'), 'Domingo/feriado', np.where(cal.DiaSemana == 'SAB', 'Sábado', 'Dia útil'))
cal['Ano'] = cal.Data.dt.year; cal['Mes'] = cal.Data.dt.month
cal['AnoMes'] = cal.Data.dt.strftime('%Y-%m')
MES = ['jan','fev','mar','abr','mai','jun','jul','ago','set','out','nov','dez']
cal['MesNome'] = cal.Data.dt.month.map(lambda m: MES[m-1]) + '/' + cal.Data.dt.strftime('%y')
# mês contratual: 1 = 09/11/2026 a 08/12/2026 (início da operação em 09/11)
mc = (cal.Data.dt.year - 2026) * 12 + cal.Data.dt.month - 11 + np.where(cal.Data.dt.day >= 9, 1, 0)
cal['MesContratual'] = mc; cal['AnoContratual'] = (mc - 1) // 12 + 1

# ---------------- dParametros ----------------
par = pd.DataFrame([
 ('PUP','Preço unitário por partida (R$) – proposta comercial',2314.05,'Informado pela Acquavias; reajuste anual IPCA (Anexo 14, 3.1)'),
 ('PCT_ADIC','Fator das partidas adicionais',0.60,'Anexo 14, 2.1.3 (PV = PUP × 0,6 × PA × FO)'),
 ('FO_ANO1','Fator de operação – ano contratual 1',0.75,'Anexo 14, Tabela 1'),
 ('PMF_ANO1','Partidas base – ano contratual 1 (valor da Tabela 1)',145887,'Anexo 14, Tabela 1 – confirmar se é anual ou mensal'),
 ('QV_ANO1','Quantidade de viagens – ano contratual 1',583548,'Anexo 14, Tabela 1'),
 ('EXIGE_PARALISOU','Expurgo só com ocorrência marcada "Para. = Sim" (1 = sim; 0 = vale qualquer ocorrência de tipo listado)',0,'Acquavias (11/11/2026): o filtro não depende de a travessia ter parado'),
 ('MODO_EXPURGO','1 = todo horário programado dentro da janela da ocorrência; 2 = só o horário não realizado ou atrasado na janela',2,'Acquavias (11/11/2026): expurgo só para indicador (relatório de operação)'),
 ('DIVISOR_PARTIDAS','Divisor da quantidade de viagens no cálculo da receita',4,'Acquavias (11/11/2026): receita = viagens ÷ 4 × PUP × FO'),
 ('IQS','Indicador de qualidade do serviço (0 a 1)',1.0,'Anexo 8 – usar o IQS do mês; DD = 1 − (0,8 + 0,2 × IQS)'),
], columns=['Parametro','Descricao','Valor','Fonte'])
fo = pd.DataFrame({'AnoContratual': range(1, 21), 'FO': [0.75,0.80,0.85,0.90,0.95]+[1.0]*15,
   'PMF': [145887,185110,185265,185430,185610,185848,174852,175427,176191,176995,177891,178887,179992,181173,182417,183745,185171,186887,188921,191083],
   'QV': [583548,740440,741060,741720,742440,743392,699408,701708,704764,707980,711564,715548,719968,724692,729668,734980,740684,747548,755684,764332]})

# ---------------- dGrade (corrigida) ----------------
G = load_rev00(IN + 'grade_rev00.xlsx')
REGMAP = {'DU':['SEG','TER','QUA','QUI','SEX'],'TODOS_OS_DIAS':dsem+['FER'],'SAB_DOM_FER':['SAB','DOM','FER'],'SAB':['SAB'],'DOM/FER':['DOM','FER'],
          'SEG':['SEG'],'TER':['TER'],'QUA':['QUA'],'QUI':['QUI'],'SEX':['SEX']}
rows = []
for r in G.itertuples(index=False):
    for c in REGMAP[r.Regime]: rows.append(dict(r._asdict(), CodDiaGrade=c, Fonte='Grade REV00'))
dG = pd.DataFrame(rows)
def mins(s): return [int(x[:2])*60+int(x[3:]) for x in s.split()]
def step(a,b,st): a,b=mins(a)[0],mins(b)[0]; return list(range(a,b+1,st))
def fixrows(tid, sent, cods, lst, fonte):
    return [dict(TravessiaID=tid,Sentido=sent,Regime='',Minuto=m,Tipo='FIX',Freq=None,IntMax=None,Obs='',CodDiaGrade=c,Fonte=fonte) for c in cods for m in lst]
DUc = ['SEG','TER','QUA','QUI','SEX']; FDS = ['SAB','DOM','FER']
# 1) Santos ⇄ Vicente de Carvalho: REV00 repetia os horários de VC nas duas margens
sv = pd.read_excel(IN + 'grade_svc.xlsx'); sv['m'] = sv.iloc[:,0].map(lambda t: t.hour*60+t.minute); sv['s'] = sv.Sentido.str.strip().map(lambda x: '1' if x.startswith('Santos') else '2')
sv.loc[(sv.m == 0) & (sv.index > 10), 'm'] = 1440      # 00:00 do fim da lista = 24:00 (vira 00:00 do dia seguinte)
fixes = []
for s in '12': fixes += fixrows('SVC', s, DUc, sorted(sv[sv.s == s].m.tolist()), 'Grade SVC (tabela nova, dias úteis)')
S0 = '00:00 00:40 01:20 02:00 03:00 04:00 04:40'; V0 = '00:20 01:00 01:40 02:30 03:30 04:20'
fixes += fixrows('SVC','1',['SAB'], mins(S0)+step('05:18','08:42',12)+step('09:00','22:40',20)+mins('22:54 23:25'), 'PDF sábado (Santos 16h–22h corrigido)')
fixes += fixrows('SVC','2',['SAB'], mins(V0)+step('05:00','08:24',12)+mins('08:40')+step('09:00','22:40',20)+mins('23:10 23:40'), 'PDF sábado')
fixes += fixrows('SVC','1',['DOM','FER'], mins(S0)+step('05:20','22:40',20)+mins('22:54 23:25'), 'PDF domingo/feriado')
fixes += fixrows('SVC','2',['DOM','FER'], mins(V0)+step('05:00','22:40',20)+mins('23:10 23:40'), 'PDF domingo/feriado')
# 2) Bertioga ⇄ Guarujá: REV00 tinha a grade antiga; dias úteis = PDF ajustado; fds/feriado = 2 embarcações 06h40–18h20
BB = mins('00:20 01:00 01:40 02:20 03:00 03:40 04:20 05:00 05:40 06:20 06:40')+step('07:00','12:40',20)+mins('13:00 13:20 14:00 14:40 15:20 16:00 16:40 17:00 17:20 17:40 18:00 18:20 19:00 19:40 20:20 21:00 21:40 22:20 23:00 23:40')
BGu = mins('00:00 00:40 01:20 02:00 02:40 03:20 04:00 04:40 05:20 06:00 06:40')+step('07:00','12:40',20)+mins('13:00 13:40 14:20 15:00 15:40 16:20 16:40 17:00 17:20 17:40 18:00 18:20 18:40 19:20 20:00 20:40 21:20 22:00 22:40 23:20')
fixes += fixrows('BG','1',DUc,BB,'PDF Bertioga–Guarujá (dias úteis)') + fixrows('BG','2',DUc,BGu,'PDF Bertioga–Guarujá (dias úteis)')
BBf = mins('00:20 01:00 01:40 02:20 03:00 03:40 04:20 05:00 05:40 06:20 06:40')+step('07:00','18:20',20)+mins('19:00 19:40 20:20 21:00 21:40 22:20 23:00 23:40')
BGf = mins('00:00 00:40 01:20 02:00 02:40 03:20 04:00 04:40 05:20 06:00 06:40')+step('07:00','18:20',20)+mins('18:40 19:20 20:00 20:40 21:20 22:00 22:40 23:20')
fixes += fixrows('BG','1',FDS,BBf,'Proposta fds/feriado: 2 embarcações 06h40–18h20') + fixrows('BG','2',FDS,BGf,'Proposta fds/feriado: 2 embarcações 06h40–18h20')
dG = dG[~dG.TravessiaID.isin(['SVC','BG'])]
# 3) Cananéia ⇄ Continente: 04h00/04h30 invertidos na REV00 (o PDF e as viagens realizadas confirmam Cananéia 04:00, Continente 04:30)
dG.loc[(dG.TravessiaID=='CC')&(dG.Sentido=='1')&(dG.Minuto==270),['Minuto','Fonte']] = [240,'REV00 corrigida (04:00)']
dG.loc[(dG.TravessiaID=='CC')&(dG.Sentido=='2')&(dG.Minuto==240),['Minuto','Fonte']] = [270,'REV00 corrigida (04:30)']
dG = pd.concat([dG, pd.DataFrame(fixes)], ignore_index=True)
dG = dG.sort_values(['TravessiaID','Sentido','CodDiaGrade','Minuto']).reset_index(drop=True)
# janelas
nxt = dG.groupby(['TravessiaID','Sentido','CodDiaGrade']).Minuto.shift(-1)
dG['JanelaIni'] = np.where(dG.Tipo=='FIX', dG.Minuto - TOL_ANTES, dG.Minuto)
dG['JanelaFim'] = np.where(dG.Tipo=='FIX', dG.Minuto + TOL_DEPOIS, np.minimum(nxt.fillna(1440), dG.Minuto + dG.IntMax.fillna(60).where(dG.Obs=='', 60)))
dG.loc[(dG.Tipo=='DEM'), 'JanelaFim'] = nxt.fillna(1440)[dG.Tipo=='DEM']
dG['JanelaFim'] = dG.JanelaFim.astype(int); dG['JanelaIni'] = dG.JanelaIni.astype(int)
dG['Hora'] = dG.Minuto.map(lambda m: f'{(m//60)%24:02d}:{m%60:02d}')
dG['TipoGrade'] = dG.Tipo.map({'FIX':'Horário fixo','DEM':'Conforme demanda'})
mg = dT.set_index('TravessiaID')
dG['MargemSaida'] = [mg.loc[t,'Margem1' if s=='1' else 'Margem2'] for t,s in zip(dG.TravessiaID,dG.Sentido)]
dG['SlotID'] = dG.TravessiaID+'|'+dG.Sentido+'|'+dG.CodDiaGrade+'|'+dG.Minuto.astype(str).str.zfill(4)
dG['IntervaloMax'] = dG.IntMax
dGrade = dG[['SlotID','TravessiaID','Sentido','MargemSaida','CodDiaGrade','Hora','Minuto','TipoGrade','IntervaloMax','JanelaIni','JanelaFim','Fonte']]

# ---------------- fProjecao ----------------
# aba REV09_DETPROJ do arquivo BD_QT: um bloco por mês, datas na linha do mês, linhas FIX/DEM por travessia
import datetime as _dt
_r = pd.read_excel(IN + 'bdqt_det.xlsx', 'REV09_DETPROJ_2026-2027', header=None)
_isd = lambda x: isinstance(x, (pd.Timestamp, _dt.datetime)) and not pd.isna(x)
_rows = []; _hdr = None
for _, row in _r.iterrows():
    if _isd(row[1]): _hdr = row; continue
    if row[5] in ('FIX', 'DEM') and _hdr is not None:
        nome = f'{row[1]} - {row[2]}' if str(row[1]).startswith('São Sebastião') else str(row[1])
        for c in range(6, len(row)):
            if _isd(_hdr[c]) and pd.notna(row[c]): _rows.append((pd.Timestamp(_hdr[c]).normalize(), nome, row[5], float(row[c])))
fP = pd.DataFrame(_rows, columns=['Data','NomeQuantitativo','TipoProjecao','ViagensProjetadas'])
fP = fP.merge(dT[['NomeQuantitativo','TravessiaID']], on='NomeQuantitativo')
fP['ViagensProjetadas'] = fP.ViagensProjetadas.round().astype(int)
fP = fP[['Data','TravessiaID','TipoProjecao','ViagensProjetadas']]
# travessia com projeção por demanda (as demais só têm FIX)
_dem = set(fP[(fP.TipoProjecao == 'DEM') & (fP.ViagensProjetadas > 0)].TravessiaID)
dT['TemDemanda'] = np.where(dT.TravessiaID.isin(_dem), 'Sim', 'Não')

# ---------------- fViagens ----------------
v = pd.read_excel(IN + 'bdviagens.xlsx')
v.columns = ['TravessiaExport','AberturaBSM','Embarcacao','NumBSM','DePara','InicioEmbarque','Saida','Ped','Bic','Moto','Aut','Micro','Onibus','Cam2','Cam3','Cam4','TipoBSM','Chegada','FimDesembarque']
for c in ['InicioEmbarque','Saida','Chegada','FimDesembarque']: v[c] = pd.to_datetime(v[c], dayfirst=True)
v['ModoExport'] = np.where(v.Embarcacao.astype(str).str.startswith('LS'), 'Lancha', 'Ferry boat')
v = v.merge(dT[['NomeExportViagens','ModoExport','TravessiaID']], left_on=['TravessiaExport','ModoExport'], right_on=['NomeExportViagens','ModoExport'], how='left').drop(columns='NomeExportViagens')
v['Sentido'] = v.DePara.astype(str).str[0]
v['Data'] = v.Saida.dt.normalize(); v['SaidaMin'] = v.Saida.dt.floor('min')
v = v.sort_values(['Embarcacao','Saida']).reset_index(drop=True)
v['ViagemID'] = v.NumBSM.astype(str)+'-'+v.Saida.dt.strftime('%Y%m%d%H%M%S')+'-'+v.Sentido
v['DuracaoTravessiaMin'] = ((v.Chegada - v.Saida).dt.total_seconds()/60).round(1)
v['Veiculos'] = v[['Moto','Aut','Micro','Onibus','Cam2','Cam3','Cam4']].sum(axis=1)
# expurgos
prev = v.groupby(['Embarcacao','Sentido']).Saida.shift(1)
dup = (v.Saida - prev).dt.total_seconds().div(60).lt(3)
v['MotivoDesconsiderada'] = np.select([v.TipoBSM.notna(), dup], ['Viagem de serviço (' + v.TipoBSM.fillna('') + ')', 'Registro duplicado (< 3 min do anterior)'], '')
v['Desconsiderada'] = v.MotivoDesconsiderada.ne('')
v['AlertaApontamento'] = np.where(v.DuracaoTravessiaMin < 1, 'Travessia < 1 min', '')

# ---------------- casamento viagem × grade (igual ao Power Query) ----------------
cal_i = cal.set_index('Data')
datas = sorted(v.Data.unique())
ex = []   # slot do dia com janela absoluta
for d in pd.to_datetime(datas):
    cod = cal_i.loc[d,'CodDiaGrade']
    s = dGrade[(dGrade.CodDiaGrade == cod) & dGrade.TravessiaID.isin(dT[dT.EmOperacao == 'Sim'].TravessiaID)].copy(); s['Data'] = d
    ex.append(s)
GD = pd.concat(ex, ignore_index=True)
GD['IniAbs'] = GD.Data + pd.to_timedelta(GD.JanelaIni, unit='min'); GD['FimAbs'] = GD.Data + pd.to_timedelta(GD.JanelaFim, unit='min')
GD['ProgAbs'] = GD.Data + pd.to_timedelta(GD.Minuto, unit='min')
GD['SlotDiaID'] = GD.Data.dt.strftime('%Y%m%d') + '|' + GD.SlotID
# expande em minutos (FIX: [ini, fim] inclusive; DEM: [ini, fim))
mk = []
for r in GD.itertuples(index=False):
    last = r.JanelaFim if r.TipoGrade == 'Horário fixo' else r.JanelaFim - 1
    for m in range(r.JanelaIni, last + 1):
        mk.append((r.SlotDiaID, r.TravessiaID, r.Sentido, r.Data + pd.Timedelta(minutes=m), r.TipoGrade, r.ProgAbs))
MK = pd.DataFrame(mk, columns=['SlotDiaID','TravessiaID','Sentido','SaidaMin','TipoGrade','ProgAbs'])
val = v[~v.Desconsiderada]
C = val[['ViagemID','TravessiaID','Sentido','SaidaMin','Saida']].merge(MK, on=['TravessiaID','Sentido','SaidaMin'])
C['Desvio'] = (C.SaidaMin - C.ProgAbs).dt.total_seconds()/60
C['Prior'] = np.where(C.TipoGrade == 'Horário fixo', 0, 1)
C['AbsDev'] = C.Desvio.abs()
# 1º passo: cada viagem fica com o melhor slot (fixo mais próximo; senão a janela de demanda)
C = C.sort_values(['ViagemID','Prior','AbsDev']).drop_duplicates('ViagemID')
# 2º passo: cada slot fica com a melhor viagem (fixo: menor desvio; demanda: a primeira)
C['Ord'] = np.where(C.TipoGrade == 'Horário fixo', C.AbsDev, (C.Saida - C.ProgAbs).dt.total_seconds())
C = C.sort_values(['SlotDiaID','Ord']).drop_duplicates('SlotDiaID')
v = v.merge(C[['ViagemID','SlotDiaID','Desvio','TipoGrade']], on='ViagemID', how='left')
def st(r):
    if r.Desconsiderada: return 'Desconsiderada'
    if pd.isna(r.SlotDiaID): return 'Excedente da grade'
    if r.TipoGrade == 'Conforme demanda': return 'Grade – conforme demanda'
    return 'Grade – horário fixo'
v['ClasseGrade'] = v.apply(st, axis=1)
# tipo de projeção da viagem: FIX = horário fixo da grade ou travessia só com projeção FIX; DEM = o resto
_td = dT.set_index('TravessiaID').TemDemanda
v['TipoProjecao'] = np.where(v.ClasseGrade.eq('Grade – horário fixo') | v.TravessiaID.map(_td).ne('Sim'), 'FIX', 'DEM')
v['Pontualidade'] = np.select([v.TipoGrade.ne('Horário fixo'), v.Desvio.between(-2,5), v.Desvio > 5], ['', 'No horário', 'Atrasada'], 'Adiantada')
v['Margem'] = [mg.loc[t,'Margem1' if s=='1' else 'Margem2'] if isinstance(t,str) else '' for t,s in zip(v.TravessiaID, v.Sentido)]

# ---------------- fGradeDia ----------------
# ---------------- ocorrências e paralisações ----------------
# Tabela de correlação (tipos do sistema × incisos da exclusão do Anexo 8): só os tipos listados podem expurgar
dTipo = pd.DataFrame([
 ('WeatherWind','Vento','i','WEATHER'),('WeatherRain','Chuva Intensa','i','WEATHER'),('WeatherFog','Neblina','i','WEATHER'),('WeatherTide','Maré','i','WEATHER'),
 ('VesselPassage','Passagem de Navio','ii','MARITIME_RULES'),
 ('FuelSpill','Derramamento de Combustível','iii','DEBRIS'),('Fall','Queda ao Mar','iii','DEBRIS'),
 ('Works','Travessias (Trabalhos)','iv','WORKS'),('CCOInfrastructure','Infraestrutura CCO','iv','WORKS'),
 ('DockingProblem','Problemas com Atracadouro','v','MAINTENANCE'),
 ('Accident','Acidente de Tráfego','vi','FORTUITOUS'),('EnergyFail','Falta de Energia','vi','FORTUITOUS'),('Fiscalization','Fiscalização','vi','FORTUITOUS'),
 ('GenericIncident','Ocorrência Genérica','vi','FORTUITOUS'),('Investigation','Investigação','vi','FORTUITOUS'),('News','Imprensa no Local','vi','FORTUITOUS'),
 ('Obstruction','Obstrução','vi','FORTUITOUS'),('PatrimonialSafety','Segurança Patrimonial','vi','FORTUITOUS'),('PublicInfo','Falha nos Meios de Comunicação','vi','FORTUITOUS'),
 ('SuddenUserBad','Mal Súbito de Usuário','vi','FORTUITOUS'),('Vessel','Ocorrência com Embarcação','vi','FORTUITOUS'),
 ('VesselLevelOccurrence','Ocorrência Devido a Desnivelamento','vi','FORTUITOUS'),('VesselMotorcyclistFall','Queda de Motocicleta','vi','FORTUITOUS'),
 ('VesselPeopleOccurrence','Ocorrência com Usuários','vi','FORTUITOUS'),('VesselVehicleCollision','Colisão de Veículos','vi','FORTUITOUS'),
 ('WorkAccident','Acidente de Trabalho','',''),
], columns=['CodigoTipo','TipoOcorrencia','Inciso','MotivoExclusao'])
dTipo['ExpurgaGrade'] = np.where(dTipo.Inciso != '', 'Sim', 'Não')
# palavras do comentário usadas quando o Tipo vem vazio (a ordem importa)
KW = [('navio','Passagem de Navio'),('draga','Passagem de Navio'),('maré','Maré'),('mare ','Maré'),('vento','Vento'),('neblina','Neblina'),('chuva','Chuva Intensa'),('atracadouro','Problemas com Atracadouro'),('gaveta','Problemas com Atracadouro')]
o = pd.read_excel(IN + 'ocorrencias.xlsx')
o.columns = ['TravessiaExport','OcorrenciaID','TipoInformado','Comentario','Para','Inicio','Fim','Embarcacao','MargemOcorrencia','Usuario']
o['Inicio'] = pd.to_datetime(o.Inicio, dayfirst=True); o['Fim'] = pd.to_datetime(o.Fim, dayfirst=True)
def tipo(r):
    if isinstance(r.TipoInformado, str) and r.TipoInformado.strip(): return r.TipoInformado.strip(), 'Informado'
    c = str(r.Comentario).lower() if isinstance(r.Comentario, str) else ''
    for k, t in KW:
        if k in c: return t, 'Inferido do comentário'
    return 'Não classificada', 'Sem tipo'
o[['TipoOcorrencia','OrigemTipo']] = o.apply(lambda r: pd.Series(tipo(r)), axis=1)
o['Paralisou'] = o.Para.astype(str).str.strip().str.lower().isin(['sim','s','true','1'])
# travessia: São Sebastião/Ilhabela vira balsa e lancha, salvo se a embarcação indicar qual
tx = dT[['NomeExportViagens','ModoExport','TravessiaID']]
o = o.merge(tx, left_on='TravessiaExport', right_on='NomeExportViagens', how='left').drop(columns='NomeExportViagens')
emb = o.Embarcacao.astype(str)
o = o[~((emb.str.startswith('LS') & o.ModoExport.eq('Ferry boat')) | (emb.str.startswith('FB') & o.ModoExport.eq('Lancha') & o.TravessiaExport.duplicated(keep=False)))]
o = o.merge(dTipo[['TipoOcorrencia','Inciso','ExpurgaGrade']], on='TipoOcorrencia', how='left')
o['ExpurgaGrade'] = o.ExpurgaGrade.fillna('Não')
EXIGE = bool(par.set_index('Parametro').Valor['EXIGE_PARALISOU'])
o['ParalisacaoAceita'] = (o.Paralisou | (not EXIGE)) & o.ExpurgaGrade.eq('Sim') & o.Fim.notna()
o['MotivoNaoAceita'] = np.select([~o.Paralisou, o.ExpurgaGrade.ne('Sim'), o.Fim.isna()], ['Não parou a travessia','Tipo fora da tabela de correlação','Ocorrência sem fim'], '')
o['DuracaoMin'] = ((o.Fim - o.Inicio).dt.total_seconds()/60).round(0)
fOc = o[['OcorrenciaID','TravessiaID','TravessiaExport','TipoOcorrencia','OrigemTipo','Inciso','Comentario','Paralisou','ExpurgaGrade','ParalisacaoAceita','MotivoNaoAceita','Inicio','Fim','DuracaoMin','Embarcacao','MargemOcorrencia','Usuario']].copy()
fOc['Data'] = fOc.Inicio.dt.normalize()

def marca_paralisacao(GD, oc):
    """Para cada horário programado, a paralisação aceita da mesma travessia (e margem, se a ocorrência indicar) que o cobre."""
    p = oc[oc.ParalisacaoAceita][['OcorrenciaID','TravessiaID','Inicio','Fim','MargemOcorrencia']]
    m = GD[['SlotDiaID','TravessiaID','MargemSaida','ProgAbs']].merge(p, on='TravessiaID')
    m = m[(m.ProgAbs >= m.Inicio) & (m.ProgAbs <= m.Fim)]
    mo = m.MargemOcorrencia.astype(str)
    ok = m.MargemOcorrencia.isna().to_numpy() | np.array([a in b or b in a for a, b in zip(map(str, m.MargemSaida), map(str, m.MargemOcorrencia))], dtype=bool)
    m = m[ok].sort_values('Inicio').drop_duplicates('SlotDiaID')
    return m.set_index('SlotDiaID').OcorrenciaID

MODO = int(par.set_index('Parametro').Valor['MODO_EXPURGO'])
def status(GD, modo=None):
    modo = MODO if modo is None else modo
    atraso = GD.TipoGrade.eq('Horário fixo') & (GD.Desvio > 5)
    par = GD.OcorrenciaParalisacao.notna()
    ok = GD.ViagemID.notna()
    return np.select([~ok & par, ok & atraso & par, ok & par & (modo == 1), ok],
                     ['Expurgada – não realizada', 'Expurgada – atrasada', 'Expurgada – realizada na janela', 'Cumprida'], 'Não cumprida')

GD = GD.merge(C[['SlotDiaID','ViagemID','Saida','Desvio']], on='SlotDiaID', how='left')
GD['OcorrenciaParalisacao'] = GD.SlotDiaID.map(marca_paralisacao(GD, fOc))
GD['Status'] = status(GD)
GD['ExpurgoParalisacao'] = GD.Status.str.startswith('Expurgada')
fGradeDia = GD[['SlotDiaID','Data','SlotID','TravessiaID','Sentido','MargemSaida','Hora','TipoGrade','Status','ExpurgoParalisacao','OcorrenciaParalisacao','ViagemID','Saida','Desvio']]
# simulação (só conferência): 4 combinações de parâmetros
_sims = []
for _ex in (1, 0):
    _o = fOc.copy(); _o['ParalisacaoAceita'] = (_o.Paralisou | (not _ex)) & _o.ExpurgaGrade.eq('Sim') & _o.Fim.notna()
    _g = GD.copy(); _g['OcorrenciaParalisacao'] = _g.SlotDiaID.map(marca_paralisacao(_g, _o))
    for _m in (1, 2):
        _g['Status'] = status(_g, _m); _t = _g.groupby(['Data','TravessiaID','Status']).size().rename('n').reset_index(); _t['EXIGE'] = _ex; _t['MODO'] = _m; _sims.append(_t)
SIM = pd.concat(_sims).pivot_table(index=['EXIGE','MODO','Data','TravessiaID'], columns='Status', values='n', fill_value=0)


v = v.merge(fGradeDia[['ViagemID','ExpurgoParalisacao']].dropna(subset=['ViagemID']), on='ViagemID', how='left')
v['ExpurgoParalisacao'] = v.ExpurgoParalisacao.fillna(False).astype(bool)
fViagens = v[['ViagemID','Data','Saida','TravessiaID','Sentido','Margem','Embarcacao','NumBSM','TipoBSM','Ped','Bic','Moto','Aut','Micro','Onibus','Cam2','Cam3','Cam4','Veiculos','DuracaoTravessiaMin','Desconsiderada','MotivoDesconsiderada','AlertaApontamento','ClasseGrade','TipoProjecao','SlotDiaID','Desvio','Pontualidade','ExpurgoParalisacao']].sort_values(['TravessiaID','Saida'])

corr = pd.DataFrame([
 ('Todas','Rotas "↔" (mesmos horários nas duas margens) viraram uma linha por sentido (1 = 1ª margem do nome, 2 = 2ª).'),
 ('Todas','Horários gravados como data (1900-01-01 hh:mm) convertidos para hora; "Frequência"/"Intervalo Máximo" com texto viraram número.'),
 ('Todas','Regimes (DU, SAB_DOM_FER, TODOS_OS_DIAS…) abertos por dia (SEG…DOM e FER) para ligar direto ao calendário.'),
 ('Santos ⇄ Vicente de Carvalho','REV00 repetia os horários de Vicente de Carvalho nas duas margens. Dias úteis: tabela nova "grade_Santos_Vicente_de_Carvalho" (76 por margem; o 00:00 do fim = saída de 24:00). Sábado e domingo/feriado: horários por margem do PDF.'),
 ('Santos ⇄ Vicente de Carvalho','Sábado: o PDF deixava Santos sem saídas das 16h às 22h (48). Completado com saídas a cada 20 min, como Vicente de Carvalho (69 por margem). Conferir.'),
 ('Bertioga ⇄ Guarujá','REV00 tinha a grade antiga (margens trocadas na madrugada e tarde diferente). Dias úteis: grade ajustada do PDF (49 por margem).'),
 ('Bertioga ⇄ Guarujá','Sábado, domingo e feriado: 2 embarcações das 06h40 às 18h20, saídas simultâneas a cada 20 min (54 por margem). Proposta a validar.'),
 ('Cananéia ⇄ Continente','REV00 trocava 04:00 e 04:30 entre as margens. Corrigido: Cananéia 04:00 e Continente 04:30 (PDF e viagens realizadas).'),
 ('Cananéia ⇄ Marujá ⇄ Ariri','Cada viagem semanal ficou só com a saída (Cananéia → Ariri = sentido 1; Ariri → Cananéia = sentido 2). A parada no Marujá não conta como nova viagem.'),
 ('Natividade','O export junta Pouso Alto e Bairro Alto no sentido 2; a grade de uma ponta foi aplicada aos dois sentidos.'),
 ('João Basso, Taquacetuba, Bororé','Mantidas na grade, mas fora da apuração (EmOperacao = Não) enquanto não houver viagens no export.'),
], columns=['Travessia','Correcao'])
with pd.ExcelWriter(OUT) as w:
    corr.to_excel(w, sheet_name='CorrecoesGrade', index=False)
    for n, d in [('dTravessia',dT),('dCalendario',cal),('dParametros',par),('dParametrosAno',fo),('dGrade',dGrade),('fProjecao',fP),('fViagens',fViagens),('fGradeDia',fGradeDia),('dTipoOcorrencia',dTipo),('fOcorrencias',fOc)]:
        d.to_excel(w, sheet_name=n, index=False)
# conferências
print(dGrade.groupby(['TravessiaID','Sentido','CodDiaGrade']).size().unstack().to_string())
print(fViagens.groupby(['TravessiaID','ClasseGrade']).size().unstack(fill_value=0).to_string())
print(fGradeDia.groupby(['Data','Status']).size())
print(fOc.groupby(['TravessiaID','TipoOcorrencia','OrigemTipo','ParalisacaoAceita','MotivoNaoAceita']).size().to_string())
print('sem travessia:', v.TravessiaID.isna().sum(), 'desconsideradas:', v.Desconsiderada.sum(), v.MotivoDesconsiderada.value_counts().to_dict())
print('SIMULACAO sem exigir Para.=Sim'); print(SIM.to_string())

# ---------------- conferência (A), (B) e receita ----------------
pp = par.set_index('Parametro').Valor
val2 = fViagens[~fViagens.Desconsiderada].groupby(['Data','TravessiaID','TipoProjecao']).size().rename('Real')
pj = fP.set_index(['Data','TravessiaID','TipoProjecao']).ViagensProjetadas
X = pd.concat([val2, pj], axis=1).fillna(0)
X = X[X.index.get_level_values(0).isin(fViagens.Data.unique())]
X['A'] = np.minimum(X.Real, X.ViagensProjetadas); X['B'] = X.Real - X.A
R = X.groupby(level=0)[['Real','ViagensProjetadas','A','B']].sum()
R['ReceitaA'] = R.A / pp.DIVISOR_PARTIDAS * pp.PUP * pp.FO_ANO1
R['ReceitaB'] = R.B / pp.DIVISOR_PARTIDAS * pp.PUP * pp.PCT_ADIC * pp.FO_ANO1
R['Total'] = R.ReceitaA + R.ReceitaB
print(R.to_string())
print(X.groupby(level=[0,1]).sum().to_string())
