import pandas as pd, datetime as dt, re
TR = {  # nome REV00 / BD_QT -> id
 ('São Sebastião/Ilhabela','Veículos e Pedestres'):'SSI_FB', ('São Sebastião/Ilhabela','Pedestres e Ciclistas'):'SSI_LS',
 'Bertioga/Guarujá':'BG','Santos/Guarujá':'SG','Santos/Vicente de Carvalho':'SVC','Iguape/Jureia':'IJ','Cananeia/Continente':'CC',
 'Cananeia/Ilha Comprida':'CIC','Cananeia/Ariri':'CA','Varginha':'VAR','Paraitinga':'PAR','Natividade':'NAT','João Basso':'JB','Taquacetuba':'TAQ','Bororé':'BOR'}
def tid(t,emb):
    return TR.get((t,emb)) or TR.get(t)
def hhmm(x):
    if isinstance(x,dt.datetime): return x.hour*60+x.minute
    if isinstance(x,dt.time): return x.hour*60+x.minute
    raise ValueError(x)
def num(x):
    try: return int(x)
    except: return None
def load_rev00(path):
    g=pd.read_excel(path); g.columns=[c.strip() for c in g.columns]
    out=[]
    for r in g.itertuples(index=False):
        t=tid(r.Travessia,r[5]); m=hhmm(r[6]); rota=r.Rota
        if '↔' in rota: sents=['1','2']
        elif '←' in rota: sents=['2']
        else: sents=['1']
        if t=='CA':   # linha semanal: guarda só a saída de cada viagem
            if rota.startswith('Marujá → Ariri') or rota.startswith('Cananéia ← Marujá'): continue
        for s in sents:
            out.append(dict(TravessiaID=t,Sentido=s,Regime=r[4],Minuto=m,Tipo=r.Tipo,Freq=num(r[7]),IntMax=num(r[8]),Obs=('Última partida do intervalo' if 'ltima' in f'{r[7]}{r[8]}' else '')))
    return pd.DataFrame(out)
