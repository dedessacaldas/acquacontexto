# Gera programacao.html (layout Acquavias) a partir dos dados exatamente como enviados.
import html
E = html.escape

ADDR_SSB = "Av. Antonio Januário do Nascimento s/n - São Sebastião"
ADDR_SG = "Av. Adhemar de Barros, 3.300 Vila Ligya"
ADDR_VC = "Largo Tiago Ferreira, s/n - Vicente de Carvalho"
ADDR_BG = "Avenida Henrique Costabile s/n - Bertioga"
ADDR_WL = "Av. Washington Luiz, s/nº - Cananeia"
ADDR_PM = "Praça Martim Afonso de Souza s/n - Cananeia"
ADDR_IG = "Estrada Turística Vereador Manoel Alves da Silva - Antiga estrada da Barra - Iguape-SP"

# (data, hora, travessia, litros, endereço)
regioes = [
  dict(nome="Litoral Norte", sub="São Sebastião", blocos=[
    dict(linhas=[
      ("09/11/2026", "19:00", "São Sebastião-Ilhabela", 15000, ADDR_SSB),
      ("11/11/2026", "19:00", "São Sebastião-Ilhabela", 15000, ADDR_SSB),
      ("13/11/2026", "19:00", "São Sebastião-Ilhabela", 15000, ADDR_SSB),
    ], obs=None)],
    aditivo=[("FB 30", 27), ("LS 03", 13), ("LS 04", 13)],
    aditivo_end=ADDR_SSB),
  dict(nome="Litoral Centro", sub="Guarujá, Vicente de Carvalho e Bertioga", blocos=[
    dict(linhas=[
      ("09/11/2026", "19:00", "Santos - Guarujá", 15000, ADDR_SG),
      ("10/11/2026", "15:30", "Guarujá - Bertioga", 2000, ADDR_BG),
      ("10/11/2026", "19:30", "Vicente de Carvalho", 10000, ADDR_VC),
      ("12/11/2026", "19:00", "Santos - Guarujá", 30000, ADDR_SG),
      ("13/11/2026", "01:00", "Vicente de Carvalho", 6000, ADDR_VC),
      ("13/11/2026", "15:00", "Vicente de Carvalho", 2000, ADDR_VC),
    ], obs=None)],
    aditivo=[("FB 20", 30), ("LS 05", 24), ("LS 02", 12), ("FB 18", 30)]),
  dict(nome="Litoral Sul", sub="Iguape e Cananéia", blocos=[
    dict(linhas=[
      ("10/11/2026", None, "Iguape - Juréia", 5000, ADDR_IG),
      ("10/11/2026", None, "Cananéia - Continente", 5000, ADDR_WL),
      ("10/11/2026", None, "Cananeia - Ilha Comprida", 1000, ADDR_PM),
      ("10/11/2026", None, "Cananéia - Ariri", 1000, ADDR_PM),
    ], obs="Iniciar às 15:00 na Cananéia Ilha Comprida (End: Av. Washington Luiz, s/nº - Cananeia) depois seguir para as demais conforme orientação do fiscal das Travessias"),
    dict(linhas=[
      ("13/11/2026", None, "Cananéia - Continente", 2000, ADDR_WL),
      ("13/11/2026", None, "Cananeia - Ilha Comprida", 2000, ADDR_PM),
    ], obs="Iniciar às 12:30 na Cananéia Ilha Comprida (End: Av. Washington Luiz, s/nº - Cananeia) depois seguir para as demais conforme orientação do fiscal das Travessias"),
  ], aditivo=[("FB 12", 8)]),
  dict(nome="Paraibuna e Natividade da Serra", sub="", blocos=[
    dict(linhas=[
      (None, None, "Paraitinga", 1000, None),
      (None, None, "Varginha", 500, "Porto Varginha, Paraibuna - SP"),
      (None, None, "Natividade Serra", 500, None),
    ], obs="Iniciar às 06:30 na travessia de Varginha no dia 11/11/26 (End: Porto Varginha, Paraibuna - SP) depois seguir para as demais conforme orientação do fiscal das Travessia"),
  ], aditivo=[]),
]

def n(v): return f"{v:,}".replace(",", ".")
NI = '<span class="ni">ver obs.</span>'
NA = '<span class="ni">não informado</span>'

def region_html(r, idx):
    tot = sum(l[3] for b in r["blocos"] for l in b["linhas"])
    adt = sum(a[1] for a in r["aditivo"])
    out = [f'<section class="reg"><div class="reghead"><div><span class="num">{idx}</span>'
           f'<h2>{E(r["nome"])}</h2>' + (f'<span class="sub">{E(r["sub"])}</span>' if r["sub"] else '') +
           f'</div><div class="tots"><span><b>{n(tot)}</b> L combustível</span>' +
           (f'<span class="a"><b>{n(adt)}</b> L aditivo</span>' if adt else '') + '</div></div>']
    for b in r["blocos"]:
        out.append('<table><thead><tr><th class="d">Data</th><th class="h">Hora</th><th>Travessia</th>'
                   '<th class="l">Litros</th><th>Endereço</th></tr></thead><tbody>')
        for d, h, t, l, a in b["linhas"]:
            out.append(f'<tr><td class="d">{E(d) if d else NI}</td><td class="h">{E(h) if h else NI}</td>'
                       f'<td class="t">{E(t)}</td><td class="l">{n(l)}</td><td class="e">{E(a) if a else NA}</td></tr>')
        out.append('</tbody></table>')
        if b["obs"]:
            out.append(f'<div class="obs"><b>Obs.</b> {E(b["obs"])}</div>')
    if r["aditivo"]:
        chips = "".join(f'<span class="chip"><b>{E(e)}</b>{n(l)} L</span>' for e, l in r["aditivo"])
        extra = f'<span class="aend">Endereço: {E(r["aditivo_end"])}</span>' if r.get("aditivo_end") else ''
        out.append(f'<div class="adt"><span class="lbl">Aditivo · aplicar na embarcação</span>{chips}{extra}</div>')
    out.append('</section>')
    return "".join(out)

tot = sum(l[3] for r in regioes for b in r["blocos"] for l in b["linhas"])
adt = sum(a[1] for r in regioes for a in r["aditivo"])

head = '<div class="pghead"><img src="horiz_c_white.png" alt="Acquavias"><span class="tag">Programação de Abastecimento</span></div>'
foot = lambda p: f'<div class="foot"><span><b>Acquavias</b> · Programação de abastecimento de combustível e aditivo · 09 a 13/11/2026</span><span>{p}/2</span></div>'

hero = f'''<div class="hero"><div class="pat"></div><img class="logo" src="horiz_c_white.png" alt="Acquavias">
<div class="htxt"><div class="eyebrow">Programação de abastecimento</div><h1>Combustível e aditivo</h1>
<div class="per">09 a 13 de novembro de 2026</div></div>
<div class="kpis"><div><b>{n(tot)}</b><span>litros de combustível</span></div><div><b>{n(adt)}</b><span>litros de aditivo</span></div><div><b>4</b><span>regiões</span></div></div>
<div class="wave"></div></div>'''

css = open(__file__.replace("gen.py", "style.css")).read()
p1 = f'<div class="page">{hero}<div class="inner i1">{region_html(regioes[0],1)}{region_html(regioes[1],2)}</div>{foot(1)}</div>'
p2 = f'<div class="page">{head}<div class="inner">{region_html(regioes[2],3)}{region_html(regioes[3],4)}</div>{foot(2)}</div>'
doc = f'<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><title>Programação de Abastecimento</title><style>{css}</style></head><body>{p1}{p2}</body></html>'
open(__file__.replace("gen.py", "programacao.html"), "w").write(doc)
print(tot, adt)

# Versão e-mail: página única contínua (JPG)
emcss = css + """
.page.em { height:auto; overflow:visible; }
.page.em .hero { position:relative; }
.page.em .inner { position:static; padding:9mm 14mm 4mm; }
.page.em .foot { position:static; margin:0 14mm; padding-bottom:6mm; }
"""
foot_em = '<div class="foot"><span><b>Acquavias</b> · Programação de abastecimento de combustível e aditivo · 09 a 13/11/2026</span><span></span></div>'
body = "".join(region_html(r, i + 1) for i, r in enumerate(regioes))
em = f'<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><title>Programação de Abastecimento</title><style>{emcss}</style></head><body><div class="page em">{hero}<div class="inner">{body}</div>{foot_em}</div></body></html>'
open(__file__.replace("gen.py", "email.html"), "w").write(em)
