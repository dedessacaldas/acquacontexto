const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 794, height: 1123 } });
  await p.goto('file://' + process.argv[2]); await p.evaluate(() => document.fonts.ready);
  const pages = await p.$$('.page');
  for (let i = 0; i < pages.length; i++) await pages[i].screenshot({ path: process.argv[3] + '/p' + (i + 1) + '.png' });
  const ov = await p.evaluate(() => [...document.querySelectorAll('.inner')].map(e => e.scrollHeight - e.clientHeight));
  console.log('overflow', ov); await b.close();
})();
