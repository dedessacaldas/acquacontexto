const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 794, height: 1000 }, deviceScaleFactor: 2 });
  await p.goto('file://' + process.argv[2]); await p.evaluate(() => document.fonts.ready);
  await (await p.$('.page')).screenshot({ path: process.argv[3], type: 'jpeg', quality: 92 }); await b.close();
})();
