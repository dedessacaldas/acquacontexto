# Gera comparativo.html (layout Acquavias) a partir de res.pkl
import pickle, pandas as pd
from datetime import timedelta
R=pickle.load(open('res.pkl','rb')); DAYS=['09/11','10/11']
DOW={'09/11':'segunda-feira','10/11':'terça-feira'}
C1,C2='#005B7F','#00B5AD'; COL={'09/11':C1,'10/11':C2}
PREV=23  # grade dias úteis 05:00–09:59 por margem: 05:00 fixo + 05:20–06:20 (4) + 06:30–09:54 a cada 12 (18)
PROJ={'09/11':570,'10/11':627}  # REV09_PROJ, Santos/Guarujá, viagens/dia (2 margens)
FULL0911=611
def n(v): return f"{int(round(v)):,}".replace(",",".")
def p(v,d=0): return (f"{v:.{d}f}%").replace('.',',')
def var(a,b):
    if a==0: return '–'
    x=100*(b-a)/a; s='+' if x>0 else ''
    cls='up' if x>0 else ('dn' if x<0 else '')
    return f'<span class="var {cls}">{s}{x:.1f}%</span>'.replace('.',',')
def hm(t): return pd.Timestamp(t).strftime('%H:%M')
VE=['moto','aut','micro','onib','c2','c3','c4']
CLS=[('ped','Pedestres'),('bic','Bicicletas'),('moto','Motos'),('aut','Automóveis'),('micro','Micro-ônibus e vans'),('onib','Ônibus'),('c2','Caminhões 2 eixos'),('c3','Caminhões 3 eixos'),('c4','Caminhões 4+ eixos')]
S={}
for d in DAYS:
    r=R[d]; W=r['W']; s={}
    s['viag']=len(W); s['mg']={mg:r['margens'][mg]['n'] for mg in ['Santos','Guarujá']}
    s['cls']=W[[c for c,_ in CLS]].sum(); s['clsm']=r['classes']
    s['veic']=int(W[VE].sum().sum()); s['pedbic']=int(W.ped.sum()+W.bic.sum())
    g=pd.concat([r['margens'][mg]['gaps'].assign(margem=mg) for mg in ['Santos','Guarujá']])
    s['gaps']=g; s['int_n']=len(g); s['int_ok']=int((~g.exc).sum())
    s['fx']={mg:r['margens'][mg]['fx'] for mg in ['Santos','Guarujá']}
    s['emb']=r['emb']; s['hora']=r['hora']; s['W']=W
    s['cump']=100*s['viag']/(2*PREV)
    s['ocup_v']=s['veic']/s['viag']
    S[d]=s
share=S['09/11']['viag']/FULL0911
for d in DAYS: S[d]['proj_w']=PROJ[d]*share

# ---------- gráficos SVG ----------
def bars_hour():
    Wd,H=520,125; L,B=26,16; hrs=[5,6,7,8,9]; mx=45
    gw=(Wd-L-10)/len(hrs); bw=gw*0.28
    o=[f'<svg viewBox="0 0 {Wd} {H}" class=chart>']
    for y in range(0,mx+1,10):
        yy=H-B-(H-B-12)*y/mx; o.append(f'<line x1={L} x2={Wd-6} y1={yy:.1f} y2={yy:.1f} class=grid /><text x={L-5} y={yy+3:.1f} class=ax text-anchor=end>{y}</text>')
    for i,h in enumerate(hrs):
        x0=L+gw*i+gw*0.2
        for j,d in enumerate(DAYS):
            v=int(S[d]['hora'].loc[h].sum()) if h in S[d]['hora'].index else 0
            hh=(H-B-12)*v/mx; x=x0+j*(bw+3)
            o.append(f'<rect x={x:.1f} y={H-B-hh:.1f} width={bw:.1f} height={hh:.1f} rx=1.5 fill="{COL[d]}"/><text x={x+bw/2:.1f} y={H-B-hh-3:.1f} class=vl text-anchor=middle>{v}</text>')
        o.append(f'<text x={x0+bw+1.5:.1f} y={H-3} class=ax text-anchor=middle>{h:02d}h</text>')
    o.append('</svg>'); return ''.join(o)

def bars_cls():
    keys=[('bic','Bicicletas'),('moto','Motos'),('aut','Automóveis'),('pes','Pesados*')]
    def val(d,k):
        c=S[d]['cls']
        return int(c.micro+c.onib+c.c2+c.c3+c.c4) if k=='pes' else int(c[k])
    mx=max(val(d,k) for d in DAYS for k,_ in keys)*1.12
    Wd,H=520,150; L=78; rh=14
    o=[f'<svg viewBox="0 0 {Wd} {H}" class=chart>']
    for i,(k,lab) in enumerate(keys):
        y0=8+i*36
        o.append(f'<text x={L-6} y={y0+rh+3} class=lb text-anchor=end>{lab}</text>')
        for j,d in enumerate(DAYS):
            v=val(d,k); w=(Wd-L-60)*v/mx; y=y0+j*(rh+2)
            o.append(f'<rect x={L} y={y} width={w:.1f} height={rh} rx=1.5 fill="{COL[d]}"/><text x={L+w+4:.1f} y={y+rh-3.5} class=vl>{n(v)}</text>')
    o.append('</svg>'); return ''.join(o)

def timeline(d):
    # faixa 05:00–10:00, uma linha por margem; marca saídas e intervalos acima do máximo
    s=S[d]; D=R[d]['D']; t0=D+timedelta(hours=4,minutes=58); t1=D+timedelta(hours=10,minutes=2)
    Wd=520; L=58; Rr=8; span=(t1-t0).total_seconds()
    X=lambda t:L+(Wd-L-Rr)*(pd.Timestamp(t)-t0).total_seconds()/span
    o=[f'<svg viewBox="0 0 {Wd} 78" class=chart>']
    # faixas
    b1=D+timedelta(hours=5); b2=D+timedelta(hours=6,minutes=30); b3=D+timedelta(hours=10)
    o.append(f'<rect x={X(b1):.1f} y=2 width={X(b2)-X(b1):.1f} height=56 fill="#E5EEF3"/><rect x={X(b2):.1f} y=2 width={X(b3)-X(b2):.1f} height=56 fill="#F2F8F9"/>')
    o.append(f'<text x={(X(b1)+X(b2))/2:.1f} y=10 class=bd text-anchor=middle>até 20 min</text><text x={(X(b2)+X(b3))/2:.1f} y=10 class=bd text-anchor=middle>até 12 min</text>')
    for i,mg in enumerate(['Santos','Guarujá']):
        y=24+i*22; W=s['W'][s['W'].margem==mg]
        o.append(f'<text x={L-6} y={y+3} class=lb text-anchor=end>{mg}</text><line x1={X(b1):.1f} x2={X(b3):.1f} y1={y} y2={y} stroke="#C9D8DF" stroke-width=0.6 />')
        g=s['gaps']; g=g[(g.margem==mg)&g.exc]
        for r in g.itertuples():
            o.append(f'<rect x={X(r.ant):.1f} y={y-6} width={X(r.prox)-X(r.ant):.1f} height=12 fill="#F7D9D4" stroke="#C0392B" stroke-width=.6 rx=1.5 />')
        for t in W.saida: o.append(f'<line x1={X(t):.1f} x2={X(t):.1f} y1={y-5} y2={y+5} stroke="{COL[d]}" stroke-width=1.1 />')
        fx=s['fx'][mg]
        if fx['real'] is not None: o.append(f'<circle cx={X(fx["real"].floor("min")):.1f} cy={y} r=2.6 fill="#F2B632" stroke="#fff" stroke-width=.6 />')
    for h in range(5,11):
        x=X(D+timedelta(hours=h)); o.append(f'<line x1={x:.1f} x2={x:.1f} y1=58 y2=62 stroke="#9FB3BC" stroke-width=.6 /><text x={x:.1f} y=72 class=ax text-anchor=middle>{h:02d}:00</text>')
    o.append('</svg>'); return ''.join(o)

# ---------- tabelas ----------
def kpi(lbl,a,b,fmt=n,sub='',vr=True):
    return f'''<div class=kc><div class=kl>{lbl}</div><div class=kv><span style="color:{C1}">{fmt(a)}</span><span class=ks>→</span><span style="color:{C2}">{fmt(b)}</span></div><div class=kf>{var(a,b) if vr else ''} {sub}</div></div>'''
a,b=S['09/11'],S['10/11']
kpis=''.join([
 kpi('Viagens realizadas',a['viag'],b['viag'],sub='ambas as margens'),
 kpi('Cumprimento do quantitativo da grade',a['cump'],b['cump'],fmt=lambda v:p(v),sub=f'mínimo de {2*PREV} saídas',vr=False),
 kpi('Intervalos dentro do máximo',100*a['int_ok']/a['int_n'],100*b['int_ok']/b['int_n'],fmt=lambda v:p(v,1),sub=f"{a['int_n']-a['int_ok']} e {b['int_n']-b['int_ok']} acima do máximo",vr=False),
 kpi('Veículos transportados',a['veic'],b['veic'],sub='motos, autos e pesados'),
])
# resumo por margem
rows=''
for mg in ['Santos','Guarujá']:
    va,vb=a['mg'][mg],b['mg'][mg]
    ga=a['gaps'][a['gaps'].margem==mg]; gb=b['gaps'][b['gaps'].margem==mg]
    fa,fb=a['fx'][mg],b['fx'][mg]
    rows+=f'''<tr><td class=m>Saídas de {mg}</td><td class=r>{PREV}</td><td class=r><b>{va}</b></td><td class=r>{p(100*va/PREV)}</td><td class=r><b>{vb}</b></td><td class=r>{p(100*vb/PREV)}</td><td class=r>{var(va,vb)}</td></tr>'''
rows+=f'''<tr class=tot><td class=m>Total</td><td class=r>{2*PREV}</td><td class=r><b>{a['viag']}</b></td><td class=r>{p(a['cump'])}</td><td class=r><b>{b['viag']}</b></td><td class=r>{p(b['cump'])}</td><td class=r>{var(a['viag'],b['viag'])}</td></tr>'''
rows+=f'''<tr class=ref><td class=m>Referência: quantitativo projetado (REV09)**</td><td class=r>–</td><td class=r>{n(a['proj_w'])}</td><td class=r>{p(100*a['viag']/a['proj_w'])}</td><td class=r>{n(b['proj_w'])}</td><td class=r>{p(100*b['viag']/b['proj_w'])}</td><td class=r></td></tr>'''

# horários / grade
def fxcell(f):
    if f['real'] is None: return '<span class="st nr">Não realizada</span>'
    cls='ok' if f['status']=='No horário' else 'at'
    return f'{hm(f["real"])} · {f["emb"]} <span class="st {cls}">{f["status"]} ({f["desvio"]:+.0f} min)</span>'
def gstat(s,mg,fx):
    g=s['gaps']; g=g[(g.margem==mg)&(g.faixa==fx)]
    ex=int(g.exc.sum())
    return f'<td class=r>{len(g)-ex}/{len(g)}</td><td class=r>{g.gap.max():.0f} min</td><td class=r>{"<b class=red>"+str(ex)+"</b>" if ex else "0"}</td>'
hrows=''
for mg in ['Santos','Guarujá']:
    hrows+=f'<tr><td class=m rowspan=3>{mg}</td><td>05:00 · horário fixo</td><td colspan=3>{fxcell(a["fx"][mg])}</td><td colspan=3>{fxcell(b["fx"][mg])}</td></tr>'
    hrows+=f'<tr><td>05:00–06:30 · até 20 min</td>{gstat(a,mg,"05h00–06h30")}{gstat(b,mg,"05h00–06h30")}</tr>'
    hrows+=f'<tr><td>06:30–10:00 · até 12 min</td>{gstat(a,mg,"06h30–10h00")}{gstat(b,mg,"06h30–10h00")}</tr>'
exc=''
for d in DAYS:
    g=S[d]['gaps']; g=g[g.exc].sort_values('ant')
    for r in g.itertuples():
        exc+=f'<tr><td><span class=dot style="background:{COL[d]}"></span>{d}</td><td>{r.margem}</td><td>{hm(r.ant)} ({r.emb_ant})</td><td>{hm(r.prox)} ({r.emb_prox})</td><td class=r><b class=red>{r.gap:.0f} min</b></td><td class=r>+{r.excesso:.0f} min</td></tr>'
# hora x margem
hr=''
for h in [5,6,7,8,9]:
    cells=''
    for d in DAYS:
        t=S[d]['hora']
        for mg in ['Santos','Guarujá']: cells+=f'<td class=r>{int(t.loc[h,mg])}</td>'
    ta=int(a['hora'].loc[h].sum()); tb=int(b['hora'].loc[h].sum())
    gr=1 if h==5 else (3 if h==6 else 5)  # saídas da grade por margem na hora
    hr+=f'<tr><td class=m>{h:02d}h</td><td class=r>{gr}</td>{cells}<td class=r><b>{ta}</b> → <b>{tb}</b></td><td class=r>{var(ta,tb)}</td></tr>'
# classes
cr=''
for k,lab in CLS:
    va=int(a['cls'][k]); vb=int(b['cls'][k])
    sa=int(a['clsm'].loc['Santos',k]); ga=int(a['clsm'].loc['Guarujá',k]); sb=int(b['clsm'].loc['Santos',k]); gb=int(b['clsm'].loc['Guarujá',k])
    cr+=f'<tr><td class=m>{lab}</td><td class=r>{n(sa)}</td><td class=r>{n(ga)}</td><td class=r><b>{n(va)}</b></td><td class=r>{n(sb)}</td><td class=r>{n(gb)}</td><td class=r><b>{n(vb)}</b></td><td class=r>{var(va,vb)}</td></tr>'
def tline(lab,fa,fb,bold=True):
    va,vb=fa(a),fb(b)
    return f'<tr class=tot><td class=m>{lab}</td><td class=r>{n(fa(a,"Santos"))}</td><td class=r>{n(fa(a,"Guarujá"))}</td><td class=r><b>{n(va)}</b></td><td class=r>{n(fb(b,"Santos"))}</td><td class=r>{n(fb(b,"Guarujá"))}</td><td class=r><b>{n(vb)}</b></td><td class=r>{var(va,vb)}</td></tr>'
fv=lambda s,mg=None: (s['clsm'].loc[mg,VE].sum() if mg else s['veic'])
cr+=tline('Total de veículos',fv,fv)
# embarcações
embs=sorted(set(a['emb'].index)|set(b['emb'].index))
er=''.join(f'<tr><td class=m>{e}</td>'+''.join(f'<td class=r>{int(S[d]["emb"].loc[e].sum()) if e in S[d]["emb"].index else "<span class=ni>–</span>"}</td>' for d in DAYS)+'</tr>' for e in embs)
er+=f'<tr class=tot><td class=m>Embarcações em operação</td><td class=r>{len(a["emb"])}</td><td class=r>{len(b["emb"])}</td></tr>'

LEG=f'<span class=lg><i style="background:{C1}"></i>09/11 · segunda</span><span class=lg><i style="background:{C2}"></i>10/11 · terça</span>'
html=f'''<!doctype html><html lang=pt-BR><head><meta charset=utf-8><title>Comparativo Santos–Guarujá</title><link rel=stylesheet href=style.css></head><body>
<div class=page>
 <div class=hero><div class=pat></div><img class=logo src=horiz_c_white.png>
  <div class=htxt><div class=eyebrow>Relatório de viagens · Comparativo</div><h1>Santos ⇄ Guarujá</h1><div class=per>Faixa das 05:00 às 10:00 · 09/11/2026 (segunda) × 10/11/2026 (terça) · grade de dias úteis</div></div>
  <div class=wave></div></div>
 <div class="inner i1">
  <div class=kpis>{kpis}</div>
  <div class=sec><h2>Quantidade de viagens e cumprimento</h2>{LEG}</div>
  <table><thead><tr><th>Margem</th><th class=r>Grade (mín.)</th><th class=r>09/11</th><th class=r>% cumpr.</th><th class=r>10/11</th><th class=r>% cumpr.</th><th class=r>Variação</th></tr></thead><tbody>{rows}</tbody></table>
  <p class=note>Grade de dias úteis na faixa: saída fixa às 05:00, saídas conforme demanda a cada até 20 min das 05:00 às 06:30 (05:20, 05:40, 06:00, 06:20) e a cada até 12 min das 06:30 às 10:00 (06:30 a 09:54). São {PREV} saídas mínimas por margem e {2*PREV} no total. Cumprimento = viagens realizadas ÷ saídas mínimas da grade.<br>** A REV09 projeta {PROJ['09/11']} viagens para 09/11 e {PROJ['10/11']} para 10/11 (dia inteiro, 2 margens). A projeção não é horária: a parcela da faixa foi estimada com o perfil de 09/11, quando {a['viag']} das {FULL0911} viagens do dia ({p(100*share,1)}) saíram entre 05:00 e 10:00. É só referência.</p>
  <div class=sec><h2>Viagens por hora</h2>{LEG}</div>
  <div class=cbox>{bars_hour()}</div>
  <table class=sm><thead><tr><th>Hora</th><th class=r>Grade mín. por margem</th><th class=r>09/11 Santos</th><th class=r>09/11 Guarujá</th><th class=r>10/11 Santos</th><th class=r>10/11 Guarujá</th><th class=r>Total (09 → 10)</th><th class=r>Var.</th></tr></thead><tbody>{hr}</tbody></table>
 </div>
 <div class=foot><span><b>Acquavias</b> · Análise de Performance</span><span>Fonte: exportação do BSM (volume transportado) de 09/11 e 10/11/2026 · Página 1 de 3</span></div>
</div>
<div class=page>
 <div class=pghead><img src=horiz_c_white.png><span class=tag>Santos ⇄ Guarujá · 05:00–10:00 · 09/11 × 10/11</span></div>
 <div class=inner>
  <div class=sec><h2>Viagens nos horários</h2>{LEG}</div>
  <p class=lead>Até 05:00 a grade é de horário fixo (tolerância de −2 a +5 min). Depois, as saídas são conforme demanda: cumpre-se a grade quando nenhum intervalo entre saídas seguidas da mesma margem passa do máximo da faixa.</p>
  <table class=sm><thead><tr><th rowspan=2>Margem</th><th rowspan=2>Faixa da grade</th><th colspan=3 class="c d1">09/11</th><th colspan=3 class="c d2">10/11</th></tr>
  <tr><th class=r>Dentro do máx.</th><th class=r>Maior</th><th class=r>Acima</th><th class=r>Dentro do máx.</th><th class=r>Maior</th><th class=r>Acima</th></tr></thead><tbody>{hrows}</tbody></table>
  <h3>Saídas ao longo da faixa</h3>
  <div class=tl><div class=tlh><span class=dot style="background:{C1}"></span>09/11 · segunda</div>{timeline('09/11')}<div class=tlh><span class=dot style="background:{C2}"></span>10/11 · terça</div>{timeline('10/11')}
  <div class=tlleg><span><i class=tk></i>cada traço é uma saída</span><span><i class=fxd></i>saída das 05:00 (horário fixo)</span><span><i class=exb></i>intervalo acima do máximo</span></div></div>
  <h3>Intervalos acima do máximo</h3>
  <table class=sm><thead><tr><th>Dia</th><th>Saídas de</th><th>Saída anterior</th><th>Saída seguinte</th><th class=r>Intervalo</th><th class=r>Excesso</th></tr></thead><tbody>{exc}</tbody></table>
  <p class=note>Os excessos foram de 1 a 3 min, todos na faixa de 12 min. Em 10/11, a saída das 09:46 de Santos só teve sucessora às 10:00 (14 min). A exportação de 10/11 vai até 10:23, por isso a última saída da faixa pôde ser conferida.</p>
  <h3>Critérios</h3>
  <p class=note>Viagem = registro do BSM da travessia Santos/Guarujá. Margem = sentido (1 = saída de Santos; 2 = saída de Guarujá). Horário de saída = "Término Embarque / Início Travessia", em hora e minuto. Faixa analisada = saídas das 05:00 às 09:59 (a saída fixa das 05:00 é aceita a partir das 04:58). Horário fixo: no horário de −2 a +5 min, com atraso de +5 a +15 min, não realizada fora disso (Anexo 8). Conforme demanda: intervalo entre saídas seguidas da mesma margem até o máximo da faixa.</p>

 </div>
 <div class=foot><span><b>Acquavias</b> · Análise de Performance</span><span>Página 2 de 3</span></div>
</div>
<div class=page>
 <div class=pghead><img src=horiz_c_white.png><span class=tag>Santos ⇄ Guarujá · 05:00–10:00 · 09/11 × 10/11</span></div>
 <div class=inner>
  <div class=sec><h2>Volume transportado por classificação</h2>{LEG}</div>
  <table class=sm><thead><tr><th rowspan=2>Classificação</th><th colspan=3 class="c d1">09/11 · saídas de</th><th colspan=3 class="c d2">10/11 · saídas de</th><th rowspan=2 class=r>Variação</th></tr>
  <tr><th class=r>Santos</th><th class=r>Guarujá</th><th class=r>Total</th><th class=r>Santos</th><th class=r>Guarujá</th><th class=r>Total</th></tr></thead><tbody>{cr}</tbody></table>
  <div class=cbox>{bars_cls()}</div>
  <p class=note>* Pesados = micro-ônibus e vans, ônibus e caminhões. O BSM registra quase nenhum pedestre (20 em 09/11 e 43 em 10/11 na faixa), o que não parece refletir o movimento real; a contagem de pedestres precisa ser confirmada em outra fonte. Média de veículos por viagem: {str(round(a['ocup_v'],1)).replace('.',',')} em 09/11 e {str(round(b['ocup_v'],1)).replace('.',',')} em 10/11.</p>
  <div class=two2>
   <div><h3>Embarcações (viagens na faixa)</h3><table class=sm><thead><tr><th>Embarcação</th><th class=r>09/11</th><th class=r>10/11</th></tr></thead><tbody>{er}</tbody></table></div>
   <div><h3>Pontos de atenção nos dados</h3><ul class=obs2>
    <li>Registros com travessia de menos de 1 minuto (início e término quase iguais), o que indica apontamento feito depois: 4 em 09/11 (FB-18, FB-14 ×2, FB-21) e 2 em 10/11 (FB-14, FB-10).</li>
    <li>Em 10/11 há duas saídas seguidas da mesma margem pela mesma embarcação: FB-14 saindo de Guarujá às 05:52 e 05:58 e FB-20 saindo de Guarujá às 08:20 e 08:23. Uma delas em cada par deve ser erro de sentido ou registro duplicado. As contagens deste relatório mantêm os registros como exportados.</li>
    <li>Em 09/11 o FB-16 fez só uma ida e volta na faixa; em 10/11 ele não operou nessa faixa.</li>
   </ul></div>
  </div>
 </div>
 <div class=foot><span><b>Acquavias</b> · Análise de Performance</span><span>Página 3 de 3</span></div>
</div>
</body></html>'''
open('comparativo.html','w').write(html)
