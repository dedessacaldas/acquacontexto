# Comparativo Santos–Guarujá 05:00–10:00 a partir dos exports BSM (um por dia)
import pandas as pd, pickle, sys
from datetime import datetime, timedelta
FILES={'09/11':'Viagens_091011.xlsx','10/11':'Viagens_091011.xlsx','11/11':'Viagens_091011.xlsx','12/11':'Export_1211.xlsx'}
CL=['ped','bic','moto','aut','micro','onib','c2','c3','c4']
OUT={}
for lab,f in FILES.items():
    d=pd.read_excel(f); d.columns=['trav','abert','emb','bsm','dir','ie','te','ped','bic','moto','aut','micro','onib','c2','c3','c4','tipo','tt','td']
    d=d[d.trav=='Santos/Guarujá'].copy()
    for c in ['ie','te','tt','td']: d[c]=pd.to_datetime(d[c],dayfirst=True)
    D=datetime(2026,11,int(lab[:2])); d=d[(d.te>=D-timedelta(hours=2))&(d.te<D+timedelta(hours=26))].copy()
    M=lambda h,m=0: D+timedelta(hours=h,minutes=m)
    d['margem']=d.dir.map(lambda s:'Santos' if s.startswith('1') else 'Guarujá')
    d['saida']=d.te.dt.floor('min')
    d['trav_min']=(d.tt-d.te).dt.total_seconds()/60
    d=d.sort_values('te').reset_index(drop=True)
    W0,W1=M(5),M(10)
    bands=[(M(5),M(6,30),20),(M(6,30),M(10),12)]
    def I(t):
        for a,b,i in bands:
            if a<=t<b: return i
        return 12 if t>=M(10) else None
    res={'D':D,'export_max':d.te.max(),'full':int(((d.te>=D)&(d.te<D+timedelta(days=1))).sum()),'margens':{}}
    win=[]
    for mg in ['Santos','Guarujá']:
        g=d[d.margem==mg].reset_index(drop=True)
        # fixo 05:00: -2/+5 no horário, +5/+15 atraso
        cand=g[(g.saida>=M(4,58))&(g.saida<=M(5,15))]
        fx=None
        if len(cand):
            r=cand.iloc[0]; dv=(r.saida-M(5)).total_seconds()/60
            fx=dict(real=r.te,emb=r.emb,desvio=dv,status='No horário' if dv<=5 else 'Com atraso')
        else: fx=dict(real=None,emb=None,desvio=None,status='Não realizada')
        lo=fx['real'].floor('min') if fx['real'] is not None and fx['real']<W0 else W0
        w=g[(g.saida>=lo)&(g.saida<W1)].copy()
        nxt=g[g.saida>=W1].head(1)
        win.append(w)
        # intervalos
        ts=list(w.saida)+list(nxt.saida); es=list(w.emb)+list(nxt.emb)
        gaps=[]
        for k in range(1,len(ts)):
            p,n=ts[k-1],ts[k]
            t=p+timedelta(minutes=1)
            while not ((t-p).total_seconds()/60>=I(t)): t+=timedelta(minutes=1)
            if t>=W1: continue   # prazo cai fora da janela
            gp=(n-p).total_seconds()/60
            faixa='05h00–06h30' if t<M(6,30) else '06h30–10h00'
            gaps.append(dict(faixa=faixa,imax=I(t),ant=p,prox=n,emb_ant=es[k-1],emb_prox=es[k],gap=gp,exc=n>t,excesso=(n-t).total_seconds()/60 if n>t else 0))
        res['margens'][mg]=dict(fx=fx,n=len(w),gaps=pd.DataFrame(gaps),w=w)
    W=pd.concat(win).sort_values('te')
    res['W']=W
    res['emb']=W.groupby(['emb','margem']).size().unstack(fill_value=0)
    res['classes']=W.groupby('margem')[CL].sum()
    W['h']=W.saida.dt.hour.clip(lower=5)
    res['hora']=W.groupby(['h','margem']).size().unstack(fill_value=0)
    res['hora_vol']=W.groupby('h')[CL].sum()
    res['curtas']=W[W.trav_min<1]
    OUT[lab]=res
    print(lab,'export até',d.te.max(),'| janela',len(W))
    for mg,m in res['margens'].items():
        gg=m['gaps']; print(' ',mg,m['n'],m['fx'],'| intervalos',len(gg),'exc',int(gg.exc.sum()) if len(gg) else 0)
        if len(gg): print(gg[gg.exc].to_string())
    print(res['classes']); print(res['hora']); print(res['emb']); print('curtas',len(res['curtas']))
    dup=W.sort_values('te').groupby('emb').margem.apply(lambda s:(s==s.shift()).sum()); print('sentido repetido',dup.to_dict())
pickle.dump(OUT,open('res.pkl','wb'))
