# Gera comparativo.html (layout Acquavias) – Santos–Guarujá 05h–10h, 09 a 13/11/2026, a partir de res.pkl
import pickle, pandas as pd
from datetime import timedelta
R=pickle.load(open('res.pkl','rb')); DAYS=['09/11','10/11','11/11','12/11','13/11','16/11']; ND=len(DAYS); FULLD=['09/11','10/11','11/11','12/11','13/11']  # 16/11: export parcial (até 16h), fora do rateio
DOW={'09/11':'segunda','10/11':'terça','11/11':'quarta','12/11':'quinta','13/11':'sexta','16/11':'segunda'}
COL={'09/11':'#B7DCE6','10/11':'#5BC8C2','11/11':'#00968F','12/11':'#4A90B8','13/11':'#005B7F','16/11':'#003A52'}
PREV=23  # grade dias úteis 05:00–09:59 por margem: 05:00 fixo + 05:20–06:20 (4) + 06:30–09:54 a cada 12 (18)
PROJ={'09/11':570,'10/11':627,'11/11':622,'12/11':595,'13/11':635,'16/11':570}  # quantitativo projetado Santos/Guarujá, viagens/dia (2 margens)
def n(v): return f"{int(round(v)):,}".replace(",",".")
def p(v,d=0): return (f"{v:.{d}f}%").replace('.',',')
def dec(v,d=1): return f"{v:.{d}f}".replace('.',',')
def var(a,b):
    if a==0: return '–'
    x=100*(b-a)/a; s='+' if x>0 else ''
    cls='up' if x>0 else ('dn' if x<0 else '')
    return f'<span class="var {cls}">{s}{x:.1f}%</span>'.replace('.',',')
def hm(t): return pd.Timestamp(t).strftime('%H:%M')
VE=['moto','aut','micro','onib','c2','c3','c4']
CLS=[('ped','Pedestres'),('bic','Bicicletas'),('moto','Motos'),('aut','Automóveis'),('micro','Micro-ônibus e vans'),('onib','Ônibus'),('c2','Caminhões 2 eixos'),('c3','Caminhões 3 eixos'),('c4','Caminhões 4+ eixos')]
S={}
for d in DAYS:
    r=R[d]; W=r['W'].reset_index(drop=True); s={}
    s['viag']=len(W); s['mg']={mg:r['margens'][mg]['n'] for mg in ['Santos','Guarujá']}
    s['cls']=W[[c for c,_ in CLS]].sum(); s['clsm']=r['classes']
    s['veic']=int(W[VE].sum().sum())
    g=pd.concat([r['margens'][mg]['gaps'].assign(margem=mg) for mg in ['Santos','Guarujá']])
    s['gaps']=g; s['int_n']=len(g); s['int_ok']=int((~g.exc).sum())
    s['fx']={mg:r['margens'][mg]['fx'] for mg in ['Santos','Guarujá']}
    s['emb']=r['emb']; s['hora']=r['hora']; s['W']=W; s['full']=r['full']
    s['cump']=100*s['viag']/(2*PREV)
    s['ocup_v']=s['veic']/s['viag']
    rep=[]
    for e,gg in W.sort_values('te').groupby('emb'):
        gg=gg.reset_index(drop=True)
        for i in range(1,len(gg)):
            if gg.margem[i]==gg.margem[i-1]: rep.append((e,gg.margem[i],hm(gg.saida[i-1]),hm(gg.saida[i])))
    s['rep']=rep
    s['curtas']=[(e,hm(t)) for e,t in zip(r['curtas'].emb,r['curtas'].saida)]
    S[d]=s
share=sum(S[d]['viag'] for d in FULLD)/sum(S[d]['full'] for d in FULLD)
for d in DAYS: S[d]['proj_w']=PROJ[d]*share
TOT=sum(S[d]['viag'] for d in DAYS)
first,last=S[DAYS[0]],S[DAYS[-1]]

def bars_hour():
    Wd,H=520,130; L,B=26,16; hrs=[5,6,7,8,9]; mx=45
    gw=(Wd-L-10)/len(hrs); bw=gw*0.14
    o=[f'<svg viewBox="0 0 {Wd} {H}" class=chart>']
    for y in range(0,mx+1,10):
        yy=H-B-(H-B-12)*y/mx; o.append(f'<line x1={L} x2={Wd-6} y1={yy:.1f} y2={yy:.1f} class=grid /><text x={L-5} y={yy+3:.1f} class=ax text-anchor=end>{y}</text>')
    for i,h in enumerate(hrs):
        x0=L+gw*i+gw*0.12
        for j,d in enumerate(DAYS):
            v=int(S[d]['hora'].loc[h].sum()) if h in S[d]['hora'].index else 0
            hh=(H-B-12)*v/mx; x=x0+j*(bw+2)
            o.append(f'<rect x={x:.1f} y={H-B-hh:.1f} width={bw:.1f} height={hh:.1f} rx=1.2 fill="{COL[d]}"/><text x={x+bw/2:.1f} y={H-B-hh-3:.1f} class=vl text-anchor=middle>{v}</text>')
        o.append(f'<text x={x0+2.5*bw+4:.1f} y={H-3} class=ax text-anchor=middle>{h:02d}h</text>')
    o.append('</svg>'); return ''.join(o)

def bars_cls():
    keys=[('bic','Bicicletas'),('moto','Motos'),('aut','Automóveis'),('pes','Pesados')]
    def val(d,k):
        c=S[d]['cls']
        return int(c.micro+c.onib+c.c2+c.c3+c.c4) if k=='pes' else int(c[k])
    mx=max(val(d,k) for d in DAYS for k,_ in keys)*1.12
    rh=7; gap=1.6; grp=ND*(rh+gap)+7
    Wd,H=520,int(8+4*grp); L=78
    o=[f'<svg viewBox="0 0 {Wd} {H}" class=chart>']
    for i,(k,lab) in enumerate(keys):
        y0=6+i*grp
        o.append(f'<text x={L-6} y={y0+2*(rh+gap)+2} class=lb text-anchor=end>{lab}</text>')
        for j,d in enumerate(DAYS):
            v=val(d,k); w=(Wd-L-60)*v/mx; y=y0+j*(rh+gap)
            o.append(f'<rect x={L} y={y:.1f} width={w:.1f} height={rh} rx=1.2 fill="{COL[d]}"/><text x={L+w+4:.1f} y={y+rh-1.8:.1f} class=vl style="font-size:6.6px">{n(v)}</text>')
    o.append('</svg>'); return ''.join(o)

def timeline(d):
    s=S[d]; D=R[d]['D']; t0=D+timedelta(hours=4,minutes=58); t1=D+timedelta(hours=10,minutes=2)
    Wd=520; L=58; Rr=8; span=(t1-t0).total_seconds()
    X=lambda t:L+(Wd-L-Rr)*(pd.Timestamp(t)-t0).total_seconds()/span
    o=[f'<svg viewBox="0 0 {Wd} 64" class=chart>']
    b1=D+timedelta(hours=5); b2=D+timedelta(hours=6,minutes=30); b3=D+timedelta(hours=10)
    o.append(f'<rect x={X(b1):.1f} y=2 width={X(b2)-X(b1):.1f} height=46 fill="#E5EEF3"/><rect x={X(b2):.1f} y=2 width={X(b3)-X(b2):.1f} height=46 fill="#F2F8F9"/>')
    o.append(f'<text x={(X(b1)+X(b2))/2:.1f} y=9 class=bd text-anchor=middle>até 20 min</text><text x={(X(b2)+X(b3))/2:.1f} y=9 class=bd text-anchor=middle>até 12 min</text>')
    for i,mg in enumerate(['Santos','Guarujá']):
        y=20+i*18; W=s['W'][s['W'].margem==mg]
        o.append(f'<text x={L-6} y={y+3} class=lb text-anchor=end>{mg}</text><line x1={X(b1):.1f} x2={X(b3):.1f} y1={y} y2={y} stroke="#C9D8DF" stroke-width=0.6 />')
        g=s['gaps']; g=g[(g.margem==mg)&g.exc]
        for r in g.itertuples():
            o.append(f'<rect x={X(r.ant):.1f} y={y-6} width={X(r.prox)-X(r.ant):.1f} height=12 fill="#F7D9D4" stroke="#C0392B" stroke-width=.6 rx=1.5 />')
        for t in W.saida: o.append(f'<line x1={X(t):.1f} x2={X(t):.1f} y1={y-5} y2={y+5} stroke="#005B7F" stroke-width=1.1 />')
        fx=s['fx'][mg]
        if fx['real'] is not None: o.append(f'<circle cx={X(fx["real"].floor("min")):.1f} cy={y} r=2.6 fill="#F2B632" stroke="#fff" stroke-width=.6 />')
    for h in range(5,11):
        x=X(D+timedelta(hours=h)); o.append(f'<line x1={x:.1f} x2={x:.1f} y1=48 y2=52 stroke="#9FB3BC" stroke-width=.6 /><text x={x:.1f} y=61 class=ax text-anchor=middle>{h:02d}:00</text>')
    o.append('</svg>'); return ''.join(o)

def kpi(lbl,f,fmt=n,sub=''):
    vals=''.join(f'<div class=kd><i style="background:{COL[d]}"></i><span class=kdl>{d[:2]}</span><b>{fmt(f(S[d]))}</b></div>' for d in DAYS)
    return f'<div class=kc><div class=kl>{lbl}</div><div class=kg>{vals}</div><div class=kf>{sub}</div></div>'
kpis=''.join([
 kpi('Viagens realizadas',lambda s:s['viag'],sub=f'{n(TOT)} nos 6 dias úteis · {var(first["viag"],last["viag"])} de 09 para 16/11'),
 kpi('Cumprimento do quantitativo da grade',lambda s:s['cump'],fmt=lambda v:p(v),sub=f'mínimo de {2*PREV} saídas por dia'),
 kpi('Intervalos dentro do máximo',lambda s:100*s['int_ok']/s['int_n'],fmt=lambda v:p(v,1),sub='acima do máx.: '+' · '.join(f"{S[d]['int_n']-S[d]['int_ok']}" for d in DAYS)),
 kpi('Veículos transportados',lambda s:s['veic'],sub='motos, autos e pesados'),
])
def dh(): return ''.join(f'<th class=r><span class=dot style="background:{COL[d]}"></span>{d}</th>' for d in DAYS)
rows=''
for mg in ['Santos','Guarujá']:
    cells=''.join(f'<td class=r><b>{S[d]["mg"][mg]}</b> <span class=pc>{p(100*S[d]["mg"][mg]/PREV)}</span></td>' for d in DAYS)
    tot=sum(S[d]['mg'][mg] for d in DAYS)
    rows+=f'<tr><td class=m>Saídas de {mg}</td><td class=r>{PREV}</td>{cells}<td class=r>{dec(tot/ND)}</td></tr>'
cells=''.join(f'<td class=r><b>{S[d]["viag"]}</b> <span class=pc>{p(S[d]["cump"])}</span></td>' for d in DAYS)
rows+=f'<tr class=tot><td class=m>Total</td><td class=r>{2*PREV}</td>{cells}<td class=r>{dec(TOT/ND)}</td></tr>'
cells=''.join(f'<td class=r>{n(S[d]["proj_w"])} <span class=pc>{p(100*S[d]["viag"]/S[d]["proj_w"])}</span></td>' for d in DAYS)
rows+=f'<tr class=ref><td class=m>Referência: quantitativo projetado**</td><td class=r>–</td>{cells}<td class=r>{dec(sum(S[d]["proj_w"] for d in DAYS)/ND)}</td></tr>'
def fxcell(f):
    if f['real'] is None: return '<span class="st nr">Não realizada</span>'
    cls='ok' if f['status']=='No horário' else 'at'
    return f'{hm(f["real"])} · {f["emb"]}<br><span class="st {cls}">{f["status"]} ({f["desvio"]:+.0f} min)</span>'
def gcell(s,mg,fx):
    g=s['gaps']; g=g[(g.margem==mg)&(g.faixa==fx)]
    ex=int(g.exc.sum())
    acima=f' · <b class=red>{ex} acima</b>' if ex else ''
    return f'<td class=r>{len(g)-ex}/{len(g)}{acima}<br><span class=pc>maior {g.gap.max():.0f} min</span></td>'
hrows=''
for mg in ['Santos','Guarujá']:
    hrows+=f'<tr><td class=m rowspan=3>{mg}</td><td>05:00 · horário fixo</td>'+''.join(f'<td class=r>{fxcell(S[d]["fx"][mg])}</td>' for d in DAYS)+'</tr>'
    hrows+='<tr><td>05:00–06:30 · até 20 min</td>'+''.join(gcell(S[d],mg,"05h00–06h30") for d in DAYS)+'</tr>'
    hrows+='<tr><td>06:30–10:00 · até 12 min</td>'+''.join(gcell(S[d],mg,"06h30–10h00") for d in DAYS)+'</tr>'
exc=''
for d in DAYS:
    g=S[d]['gaps']; g=g[g.exc].sort_values('ant')
    for r in g.itertuples():
        exc+=f'<tr><td><span class=dot style="background:{COL[d]}"></span>{d}</td><td>{r.margem}</td><td>{hm(r.ant)} ({r.emb_ant})</td><td>{hm(r.prox)} ({r.emb_prox})</td><td class=r><b class=red>{r.gap:.0f} min</b></td><td class=r>+{r.excesso:.0f} min</td></tr>'
EXC_ALL=pd.concat([S[d]['gaps'][S[d]['gaps'].exc].assign(dia=d) for d in DAYS]).reset_index(drop=True)
mxr=EXC_ALL.sort_values('excesso').iloc[-1]
mgs=sorted(set(EXC_ALL.margem)); fxs=sorted(set(EXC_ALL.faixa))
fixo_ok=all(S[d]['fx'][mg]['status']=='No horário' for d in DAYS for mg in ['Santos','Guarujá'])
exc_note=(f"São {len(EXC_ALL)} intervalos acima do máximo nos 6 dias úteis"
          +(", todos na faixa de 12 min" if fxs==['06h30–10h00'] else '')
          +(f" e nas saídas de {mgs[0]}" if len(mgs)==1 else '')
          +f". O maior excesso foi de +{mxr.excesso:.0f} min ({mxr.gap:.0f} min de intervalo), em {mxr.dia}, saindo de {mxr.margem} entre {hm(mxr.ant)} e {hm(mxr.prox)}."
          +(" A saída fixa das 05:00 foi feita no horário nas duas margens em todos os dias." if fixo_ok else ''))
hr=''
for h in [5,6,7,8,9]:
    gr=1 if h==5 else (3 if h==6 else 5)
    cells=''.join(f'<td class=r>{int(S[d]["hora"].loc[h,"Santos"])} / {int(S[d]["hora"].loc[h,"Guarujá"])} · <b>{int(S[d]["hora"].loc[h].sum())}</b></td>' for d in DAYS)
    hr+=f'<tr><td class=m>{h:02d}h</td><td class=r>{gr}</td>{cells}</tr>'
cr=''
for k,lab in CLS:
    v=[int(S[d]['cls'][k]) for d in DAYS]
    cr+=f'<tr><td class=m>{lab}</td>'+''.join(f'<td class=r>{n(x)}</td>' for x in v)+f'<td class=r><b>{n(sum(v))}</b></td><td class=r>{n(sum(v)/ND)}</td></tr>'
v=[S[d]['veic'] for d in DAYS]
cr+=f'<tr class=tot><td class=m>Total de veículos</td>'+''.join(f'<td class=r>{n(x)}</td>' for x in v)+f'<td class=r>{n(sum(v))}</td><td class=r>{n(sum(v)/ND)}</td></tr>'
for mg in ['Santos','Guarujá']:
    vv=[int(S[d]['clsm'].loc[mg,VE].sum()) for d in DAYS]
    cr+=f'<tr><td class=m>Veículos saindo de {mg}</td>'+''.join(f'<td class=r>{n(x)}</td>' for x in vv)+f'<td class=r><b>{n(sum(vv))}</b></td><td class=r>{n(sum(vv)/ND)}</td></tr>'
cr+=f'<tr class=ref><td class=m>Veículos por viagem</td>'+''.join(f'<td class=r>{dec(S[d]["ocup_v"])}</td>' for d in DAYS)+f'<td class=r>{dec(sum(v)/TOT)}</td><td class=r></td></tr>'
embs=sorted(set().union(*[set(S[d]['emb'].index) for d in DAYS]))
er=''.join(f'<tr><td class=m>{e}</td>'+''.join(f'<td class=r>{int(S[d]["emb"].loc[e].sum()) if e in S[d]["emb"].index else "<span class=ni>–</span>"}</td>' for d in DAYS)+'</tr>' for e in embs)
er+='<tr class=tot><td class=m>Em operação</td>'+''.join(f'<td class=r>{len(S[d]["emb"])}</td>' for d in DAYS)+'</tr>'
ob=[]
cur='; '.join(f"{len(S[d]['curtas'])} em {d} ({', '.join(f'{e} {t}' for e,t in S[d]['curtas'])})" for d in DAYS if S[d]['curtas'])
ob.append(f'Registros com travessia de menos de 1 minuto (início e término quase iguais), o que indica apontamento feito depois: {cur}.')
reps=[(d,)+x for d in DAYS for x in S[d]['rep']]
if reps:
    ob.append('Saídas seguidas da mesma margem pela mesma embarcação (erro de sentido ou registro duplicado): '+'; '.join(f'{d} {e} saindo de {mg} às {a} e {b}' for d,e,mg,a,b in reps)+'. As contagens mantêm os registros como exportados.')
pocas=[f'{e} ({d}, {int(S[d]["emb"].loc[e].sum())} viagens)' for d in DAYS for e in S[d]['emb'].index if S[d]['emb'].loc[e].sum()<=2]
if pocas: ob.append('Embarcações com no máximo uma ida e volta na faixa: '+', '.join(pocas)+'.')
ped=[int(S[d]['cls']['ped']) for d in DAYS]
ob.append(f'O registro quase não tem pedestres ({", ".join(str(x) for x in ped)} de 09 a 16/11 na faixa). A contagem de pedestres precisa ser confirmada em outra fonte.')
obs=''.join(f'<li>{x}</li>' for x in ob)

LEG=''.join(f'<span class=lg><i style="background:{COL[d]}"></i>{d}</span>' for d in DAYS)
TAG='Santos ⇄ Guarujá · 05:00–10:00 · 09 a 16/11 (dias úteis)'
html=f'''<!doctype html><html lang=pt-BR><head><meta charset=utf-8><title>Comparativo Santos–Guarujá</title><link rel=stylesheet href=style.css>
<style>
.kg {{ display:grid; grid-template-columns:1fr 1fr; gap:.8mm 2mm; margin:1mm 0 .5mm; }}
.kd {{ font-size:7.4pt; color:var(--muted); white-space:nowrap; }} .kd i {{ display:inline-block; width:2mm; height:2mm; border-radius:50%; margin-right:1mm; }}
.kd b {{ font-weight:900; font-size:11pt; color:var(--ink); margin-left:1mm; }} .kdl {{ font-weight:700; }}
.pc {{ font-size:7.2pt; color:var(--muted); font-weight:400; }}
table.sm td.r .st {{ margin-left:0; margin-top:.4mm; }}
th .dot {{ margin-right:1mm; }}
.kpis {{ margin-bottom:4mm; }}
</style></head><body>
<div class=page>
 <div class=hero><div class=pat></div><img class=logo src=horiz_c_white.png>
  <div class=htxt><div class=eyebrow>Relatório de viagens · Comparativo</div><h1>Santos ⇄ Guarujá</h1><div class=per>Faixa das 05:00 às 10:00 · 09 a 13/11 e 16/11/2026 (dias úteis; 14 e 15/11 fora por terem grade de fim de semana) · grade de dias úteis</div></div>
  <div class=wave></div></div>
 <div class="inner i1">
  <div class=kpis>{kpis}</div>
  <div class=sec><h2>Quantidade de viagens e cumprimento</h2><span>{LEG}</span></div>
  <table class=sm><thead><tr><th>Margem</th><th class=r>Grade (mín.)</th>{dh()}<th class=r>Média/dia</th></tr></thead><tbody>{rows}</tbody></table>
  <p class=note>Em cada dia: viagens realizadas e % de cumprimento (viagens ÷ saídas mínimas da grade). Grade de dias úteis na faixa: saída fixa às 05:00, saídas conforme demanda a cada até 20 min das 05:00 às 06:30 (05:20, 05:40, 06:00, 06:20) e a cada até 12 min das 06:30 às 10:00 (06:30 a 09:54). São {PREV} saídas mínimas por margem e {2*PREV} no total.<br>** O quantitativo projetado é de {PROJ['09/11']}, {PROJ['10/11']}, {PROJ['11/11']}, {PROJ['12/11']} e {PROJ['13/11']} viagens por dia (dia inteiro, 2 margens). Ele não é horário: a parcela da faixa foi estimada pelo perfil realizado de 09 a 12/11 (dias completos), quando {n(sum(S[d]['viag'] for d in FULLD))} das {n(sum(S[d]['full'] for d in FULLD))} viagens ({p(100*share,1)}) saíram entre 05:00 e 10:00. É só referência.</p>
  <div class=sec><h2>Viagens por hora</h2><span>{LEG}</span></div>
  <div class=cbox>{bars_hour()}</div>
  <table class=sm><thead><tr><th>Hora</th><th class=r>Grade mín. por margem</th>{dh()}</tr></thead><tbody>{hr}</tbody></table>
  <p class=note>Em cada dia: saídas de Santos / saídas de Guarujá · total da hora.</p>
 </div>
 <div class=foot><span><b>Acquavias</b> · Análise de Performance</span><span>Página 1 de 4</span></div>
</div>
<div class=page>
 <div class=pghead><img src=horiz_c_white.png><span class=tag>{TAG}</span></div>
 <div class=inner>
  <div class=sec><h2>Viagens nos horários</h2><span>{LEG}</span></div>
  <p class=lead>Às 05:00 a grade é de horário fixo (tolerância de −2 a +5 min). Depois, as saídas são conforme demanda: cumpre-se a grade quando nenhum intervalo entre saídas seguidas da mesma margem passa do máximo da faixa. Nas faixas, cada célula mostra intervalos dentro do máximo / total e o maior intervalo.</p>
  <table class=sm><thead><tr><th>Margem</th><th>Faixa da grade</th>{dh()}</tr></thead><tbody>{hrows}</tbody></table>
  <h3>Saídas ao longo da faixa</h3>
  <div class=tl>{''.join(f'<div class=tlh><span class=dot style="background:{COL[d]}"></span>{d} · {DOW[d]}</div>{timeline(d)}' for d in DAYS)}
  <div class=tlleg><span><i class=tk></i>cada traço é uma saída</span><span><i class=fxd></i>saída das 05:00 (horário fixo)</span><span><i class=exb></i>intervalo acima do máximo</span></div></div>
 </div>
 <div class=foot><span><b>Acquavias</b> · Análise de Performance</span><span>Página 2 de 4</span></div>
</div>
<div class=page>
 <div class=pghead><img src=horiz_c_white.png><span class=tag>{TAG}</span></div>
 <div class=inner>
  <div class=sec><h2>Intervalos acima do máximo</h2><span>{LEG}</span></div>
  <table class=sm><thead><tr><th>Dia</th><th>Saídas de</th><th>Saída anterior</th><th>Saída seguinte</th><th class=r>Intervalo</th><th class=r>Excesso</th></tr></thead><tbody>{exc}</tbody></table>
  <p class=note>{exc_note}</p>
  <div class=sec style="margin-top:5mm"><h2>Volume transportado por classificação</h2><span>{LEG}</span></div>
  <table class=sm><thead><tr><th>Classificação</th>{dh()}<th class=r>6 dias</th><th class=r>Média/dia</th></tr></thead><tbody>{cr}</tbody></table>
  <div class=cbox>{bars_cls()}</div>
 </div>
 <div class=foot><span><b>Acquavias</b> · Análise de Performance</span><span>Página 3 de 4</span></div>
</div>
<div class=page>
 <div class=pghead><img src=horiz_c_white.png><span class=tag>{TAG}</span></div>
 <div class=inner>
  <div class=sec><h2>Embarcações e qualidade dos dados</h2><span>{LEG}</span></div>
  <div class=two2>
   <div><h3 style="margin-top:2mm">Viagens na faixa por embarcação</h3><table class=sm><thead><tr><th>Embarcação</th>{''.join(f'<th class=r>{d[:2]}/11</th>' for d in DAYS)}</tr></thead><tbody>{er}</tbody></table></div>
   <div><h3 style="margin-top:2mm">Pontos de atenção nos dados</h3><ul class=obs2>{obs}</ul>
   <h3>Critérios</h3>
   <p class=note>Viagem = registro de volume transportado da travessia Santos/Guarujá. Margem = sentido (1 = saída de Santos; 2 = saída de Guarujá). Horário de saída = "Término Embarque / Início Travessia", em hora e minuto. Faixa analisada = saídas das 05:00 às 09:59 (a saída fixa das 05:00 é aceita a partir das 04:58). Horário fixo: no horário de −2 a +5 min, com atraso de +5 a +15 min, não realizada fora disso (Anexo 8). Conforme demanda: intervalo entre saídas seguidas da mesma margem até o máximo da faixa. 12/11 (quinta) e 13/11 (sexta) são dias úteis e usam a mesma grade. No gráfico de volume, pesados = micro-ônibus e vans, ônibus e caminhões. A exportação de 13/11 vai até 16h e cobre toda a faixa.</p></div>
  </div>
 </div>
 <div class=foot><span><b>Acquavias</b> · Análise de Performance</span><span>Página 4 de 4</span></div>
</div>
</body></html>'''
open('comparativo.html','w').write(html)
print(TOT,share,[S[d]['viag'] for d in DAYS],len(EXC_ALL),exc_note)
