import pickle, sys, base64, pandas as pd
from datetime import timedelta
R=pickle.load(open(sys.argv[1],'rb')); df=R['df']; FX=R['FX'].copy(); BD=R['BD']; GP=R['GP']; CUT=R['CUT']
A='/mnt/project-files/informativo-indicadores/gerador/'
NAT='Natividade da Serra/B. Natividade da Serra'
FX=FX[~((FX.trav==NAT)&(FX.margem=='B. Natividade da Serra'))]
BD=BD[~((BD.trav==NAT)&(BD.margem=='B. Natividade da Serra'))]
ORDER=[('Baixada Santista',[('Santos/Guarujá','Ferry boat','Santos ⇄ Guarujá'),('Santos/Vicente de Carvalho','Lancha','Santos ⇄ Vicente de Carvalho'),('Bertioga/Guarujá','Ferry boat','Bertioga ⇄ Guarujá')]),
 ('Litoral Norte',[('São Sebastião/Ilhabela','Ferry boat','São Sebastião ⇄ Ilhabela (balsa)'),('São Sebastião/Ilhabela','Lancha','São Sebastião ⇄ Ilhabela (lancha)')]),
 ('Litoral Sul',[('Cananéia/Continente','Ferry boat','Cananéia ⇄ Continente'),('Cananéia/Ilha Comprida','Ferry boat','Cananéia ⇄ Ilha Comprida'),('Iguape/Juréia','Ferry boat','Iguape ⇄ Juréia'),('Cananéia/Ariri','Lancha','Cananéia ⇄ Marujá ⇄ Ariri')]),
 ('Paraibuna',[(NAT,'Ferry boat','Natividade'),('Ribeirão Branco/Capim DAngola','Ferry boat',"Paraitinga (Ribeirão Branco ⇄ Capim D'Angola)"),('Comércio/Varginha','Ferry boat','Varginha (Comércio ⇄ Varginha)')])]
OBS={
('Santos/Guarujá','Ferry boat'):["Horários fixos da madrugada: 21 de 22 no horário. A saída das 02:00 de Guarujá partiu às 01:56, 4 min antes.",
 "Na faixa conforme demanda das 06:30 às 20:00 (máx. 12 min) houve 6 intervalos acima do máximo. Os maiores foram no fim da tarde: Guarujá sem saída das 17:20 às 17:46 (26 min) e Santos das 17:22 às 17:46 (24 min).",
 "19 registros têm travessia com menos de 1 minuto (início e fim quase iguais), o que indica apontamento feito depois da viagem. A maior parte é do FB-14 e do FB-18."],
('Santos/Vicente de Carvalho','Lancha'):["Saídas de Vicente de Carvalho: 47 no horário. As não cumpridas foram 05:00, 06:48, 08:12, 16:12 e 17:24.",
 "Saídas de Santos na madrugada: a lancha sai de Santos entre os horários da grade (00:07, 00:46, 01:20, 02:00, 03:00, 03:59, 04:40), porque a mesma lancha faz os horários de Vicente de Carvalho. A grade indica os mesmos horários nas duas margens, o que uma lancha só não consegue cumprir. Por isso 9 horários de Santos aparecem como não realizados entre 00:20 e 05:36.",
 "Das 05:45 às 08:21, as saídas de Santos partiram de 3 a 5 min antes do horário (10 viagens). Pelo critério do Anexo 8, saída mais de 2 min antes não conta como no horário."],
('Bertioga/Guarujá','Ferry boat'):["Manhã com 2 embarcações cumprida, com 2 atrasos do FB-MF25 saindo de Bertioga (11:20 saiu 11:29; 12:00 saiu 12:06).",
 "Das 13:00 às 16:20 a operação ficou defasada da grade. Após a viagem das 13:00, quem saiu de operação foi o FB-MF25, em Bertioga, e o FB-MF09 seguiu a partir de Guarujá. A grade prevê o contrário (a 2ª embarcação fica em Guarujá). Assim, o FB-MF09 saiu de Guarujá às 13:20, 14:00, 14:40, 15:20 e 16:00, e de Bertioga às 13:40, 14:21, 15:00 e 15:40: 9 viagens feitas, mas nenhuma nos horários da grade. Resultado: 9 horários não realizados.",
 "Na tarde, quem entrou como 2ª embarcação foi o FB-15 (16:20), e não o FB-MF25."],
('São Sebastião/Ilhabela','Ferry boat'):["Horários fixos da madrugada todos cumpridos.","Faixa conforme demanda (máx. 30 min): 3 intervalos acima do máximo, o maior de 39 min (São Sebastião, 11:04 às 11:43).",
 "Viagens com carga individual: 2 de valores (VAL), 4 de inflamáveis (INF) e 1 de lixo (LIXO). Ficam fora do IOE."],
('São Sebastião/Ilhabela','Lancha'):["Uma saída atrasada: 07:30 de São Sebastião, que partiu às 07:38 (LS-03). Demais no horário."],
('Cananéia/Continente','Ferry boat'):["Uma saída atrasada: 06:30 do Continente, que partiu às 06:40 (FB-CA). O FB-CA chegou ao Continente às 06:28, vindo da saída das 06:15 de Cananéia.",
 "O FB-RI fez viagens extras durante o dia; dois registros têm travessia de 49 e 54 min, provavelmente fechados tarde."],
('Cananéia/Ilha Comprida','Ferry boat'):["A saída das 10:00 de Cananéia não foi realizada: não há saída de Cananéia entre 09:02 e 11:01.","A saída das 11:30 de Cananéia partiu às 11:38 (FB-12)."],
('Iguape/Juréia','Ferry boat'):["A saída das 11:30 de Iguape partiu às 11:25 (5 min antes) e a das 12:00 não foi realizada (saídas de Iguape às 11:38 e 12:32).","Uma viagem com carga individual de lixo às 11:31."],
('Cananéia/Ariri','Lancha'):["Segunda-feira tem uma viagem (ida para o Ariri às 13:00). Saiu às 13:09 (9 min de atraso) e chegou às 17:06."],
(NAT,'Ferry boat'):["A travessia tem 3 pontas (Natividade, Pouso Alto e Bairro Alto), mas a exportação só tem 2 sentidos: as saídas de Pouso Alto e Bairro Alto aparecem juntas no sentido 2. Por isso só as saídas de Natividade foram comparadas com a grade.",
 "Madrugada: as 6 saídas fixas de Natividade foram no horário.","Das 08:00 às 20:00 a grade pede saída a cada até 20 min em todas as pontas, mas o FB-SA, sozinho, fecha o ciclo das 3 pontas em cerca de 40 min. Resultado: 15 intervalos acima do máximo em Natividade."],
('Ribeirão Branco/Capim DAngola','Ferry boat'):["Só há 7 viagens registradas, a primeira às 15:33. Não há registro algum entre 00:00 e 15:33, o que inclui os 12 horários fixos da madrugada. É preciso verificar se a balsa não operou ou se o BSM não foi aberto."],
('Comércio/Varginha','Ferry boat'):["A primeira viagem registrada é das 09:01. Não há registro entre 00:00 e 09:01, o que inclui os 12 horários fixos da madrugada. É preciso verificar se houve operação sem apontamento.",
 "Depois das 09:00 a balsa operou com cerca de 45 min de intervalo em cada margem, com 3 intervalos pouco acima do máximo (46 a 53 min)."],
}
def h(t): return '' if pd.isna(t) else pd.Timestamp(t).strftime('%H:%M')
def n(x): return f'{int(x):,}'.replace(',','.')
def pct(a,b): return '–' if b==0 else f'{100*a/b:.0f}%'.replace('.',',')
VCOL=['ped','bic','moto','aut','micro','onib','cam']
rows=[];tot=dict(v=0,**{c:0 for c in VCOL})
sec=[]
for reg,items in ORDER:
    for tr,mo,label in items:
        g=df[(df.trav==tr)&(df.modo==mo)]
        f=FX[(FX.trav==tr)&(FX.modo==mo)&(FX.status!='Pendente')]
        b=BD[(BD.trav==tr)&(BD.modo==mo)]
        p=len(f); ok=(f.status=='No horário').sum(); at=(f.status=='Atrasada').sum(); ad=(f.status=='Adiantada').sum(); nr=(f.status=='Não realizada').sum()
        exc=int(b.excessos.sum()) if len(b) else None
        v={c:int(g[c].sum()) for c in VCOL}
        rows.append((reg,label,len(g),g.emb.nunique(),p,ok,at,ad,nr,exc,v,int(g.veic.sum())))
        tot['v']+=len(g)
        for c in VCOL: tot[c]+=v[c]
        # detail
        marg=[]
        for se in ['1','2']:
            gm=g[g.sent==se]
            if len(gm)==0: continue
            nm=gm.dir.iloc[0][2:].split('/')[0]
            marg.append(f"<tr><td>{nm}</td><td class=r>{len(gm)}</td><td>{h(gm.te.min())}</td><td>{h(gm.te.max())}</td><td class=r>{n(gm.ped.sum())}</td><td class=r>{n(gm.bic.sum())}</td><td class=r>{n(gm.veic.sum())}</td></tr>")
        embs=', '.join(f"{e} ({c})" for e,c in g.emb.value_counts().sort_index().items())
        exr=f[f.status!='No horário'].sort_values(['prog'])
        exhtml=''
        if len(exr):
            exhtml='<table class=t><tr><th>Margem</th><th>Programado</th><th>Saída</th><th>Embarcação</th><th>Desvio</th><th>Situação</th></tr>'+''.join(
              f"<tr><td>{r.margem}</td><td>{h(r.prog)}</td><td>{h(r.real) or '–'}</td><td>{r.emb if isinstance(r.emb,str) else '–'}</td><td class=r>{'' if pd.isna(r.desvio) else f'{r.desvio:+.0f} min'}</td><td><span class='st {r.status[:3]}'>{r.status}</span></td></tr>" for r in exr.itertuples())+'</table>'
        bhtml=''
        if len(b):
            bhtml='<table class=t><tr><th>Margem</th><th>Faixa conforme demanda</th><th>Máx.</th><th>Saídas</th><th>Mínimo p/ cumprir</th><th>Maior intervalo</th><th>Acima do máx.</th></tr>'+''.join(
              f"<tr><td>{r.margem}</td><td>{h(r.ini)}–{'24:00' if r.fim.day!=r.ini.day else h(r.fim)}{' (até '+h(r.ate)+')' if r.ate<r.fim else ''}</td><td class=r>{r.imax} min</td><td class=r>{r.saidas}</td><td class=r>{r.minimo}</td><td class=r>{r.maior_int:.0f} min</td><td class=r>{'<b class=red>'+str(r.excessos)+'</b>' if r.excessos else '0'}</td></tr>" for r in b.itertuples())+'</table>'
        obs=''.join(f'<li>{o}</li>' for o in OBS.get((tr,mo),[]))
        kpi=f"<div class=kp><div><b>{len(g)}</b>viagens</div><div><b>{g.emb.nunique()}</b>embarcações</div><div><b>{n(g.ped.sum()+g.bic.sum())}</b>pedestres e ciclistas</div><div><b>{n(g.veic.sum())}</b>veículos</div>"+(f"<div><b>{ok}/{p}</b>horários fixos no horário</div>" if p else '')+(f"<div><b>{exc}</b>intervalos acima do máximo</div>" if exc is not None else '')+"</div>"
        sec.append(f"""<section class=tr><div class=reg>{reg}</div><h3>{label}</h3>{kpi}<ul class=obs>{obs}</ul>
<table class=t><tr><th>Saídas de</th><th>Viagens</th><th>1ª</th><th>Última</th><th>Pedestres</th><th>Bicicletas</th><th>Veículos</th></tr>{''.join(marg)}</table>
<p class=emb><b>Embarcações (viagens):</b> {embs}</p>
{('<h4>Horários fixos fora do horário</h4>'+exhtml) if exhtml else ''}{('<h4>Faixas conforme demanda</h4>'+bhtml) if bhtml else ''}</section>""")
def row(r):
    reg,label,v,e,p,ok,at,ad,nr,exc,vv,ve=r
    return f"<tr><td>{label}</td><td class=r>{v}</td><td class=r>{e}</td><td class=r>{p or '–'}</td><td class=r>{ok if p else '–'}</td><td class=r>{at or ''}</td><td class=r>{ad or ''}</td><td class=r>{'<b class=red>'+str(nr)+'</b>' if nr else ''}</td><td class=r><b>{pct(ok,p) if p else '–'}</b></td><td class=r>{'–' if exc is None else ('<b class=red>'+str(exc)+'</b>' if exc else '0')}</td><td class=r>{n(vv['ped'])}</td><td class=r>{n(vv['bic'])}</td><td class=r>{n(vv['moto'])}</td><td class=r>{n(vv['aut'])}</td><td class=r>{n(vv['micro']+vv['onib'])}</td><td class=r>{n(vv['cam'])}</td><td class=r><b>{n(ve)}</b></td></tr>"
summ=''
for reg,_ in ORDER:
    summ+=f"<tr class=rg><td colspan=17>{reg}</td></tr>"+''.join(row(r) for r in rows if r[0]==reg)
P=FX[FX.status!='Pendente']; okT=(P.status=='No horário').sum()
summ+=f"<tr class=tot><td>Total</td><td class=r>{tot['v']}</td><td class=r>{df.emb.nunique()}</td><td class=r>{len(P)}</td><td class=r>{okT}</td><td class=r>{(P.status=='Atrasada').sum()}</td><td class=r>{(P.status=='Adiantada').sum()}</td><td class=r>{(P.status=='Não realizada').sum()}</td><td class=r>{pct(okT,len(P))}</td><td class=r>{int(BD.excessos.sum())}</td>"+''.join(f"<td class=r>{n(tot[c])}</td>" for c in ['ped','bic','moto','aut'])+f"<td class=r>{n(tot['micro']+tot['onib'])}</td><td class=r>{n(tot['cam'])}</td><td class=r>{n(df.veic.sum())}</td></tr>"
logo=base64.b64encode(open(A+'horiz_c_white.png','rb').read()).decode()
ncur=int(((df.dur<1)).sum())
html=f"""<!doctype html><html lang=pt-BR><head><meta charset=utf-8><title>Relatório de Viagens 09/11/2026</title><style>
@font-face{{font-family:Lato;font-weight:400;src:url({A}Lato-Regular.ttf)}}@font-face{{font-family:Lato;font-weight:700;src:url({A}Lato-Bold.ttf)}}@font-face{{font-family:Lato;font-weight:900;src:url({A}Lato-Black.ttf)}}
@page{{size:A4;margin:22mm 13mm 14mm}}
body{{font-family:Lato,sans-serif;color:#17303B;font-size:8.6pt;line-height:1.38;-webkit-print-color-adjust:exact;print-color-adjust:exact;margin:0}}
h1{{font-weight:900;color:#005B7F;font-size:20pt;margin:0}} .sub{{color:#5E7480;font-size:10pt;margin:1mm 0 4mm}}
h2{{font-weight:900;color:#005B7F;font-size:13pt;margin:6mm 0 2mm;border-bottom:.5mm solid #00B5AD;padding-bottom:1mm}}
h3{{font-weight:900;color:#005B7F;font-size:12pt;margin:0 0 2mm}} h4{{color:#005B7F;font-size:9pt;margin:3mm 0 1mm}}
.reg{{font-size:7pt;letter-spacing:.14em;text-transform:uppercase;font-weight:700;color:#00B5AD}}
.big{{display:flex;gap:3mm;margin:3mm 0}} .big div{{flex:1;background:#E5EEF3;border-left:1.2mm solid #00B5AD;padding:2.5mm 3mm;color:#5E7480;font-size:8pt}} .big b{{display:block;font-size:17pt;font-weight:900;color:#005B7F;line-height:1.1}}
table.t{{border-collapse:collapse;width:100%;margin:1mm 0 2mm;font-size:7.8pt}} .t th{{background:#005B7F;color:#fff;font-weight:700;text-align:left;padding:1.2mm 1.5mm}} .t td{{padding:1mm 1.5mm;border-bottom:.2mm solid #D3E1E7}}
table.s{{font-size:7.2pt}} .s th{{padding:1.2mm 1mm;font-size:6.8pt;text-align:center}} .s td{{padding:1mm}} .s th:first-child{{text-align:left}}
.r{{text-align:right}} .red{{color:#C0392B}} tr.rg td{{background:#E0F5F3;font-weight:700;color:#005B7F;font-size:7pt;letter-spacing:.08em;text-transform:uppercase}} tr.tot td{{background:#005B7F;color:#fff;font-weight:700}}
section.tr{{break-inside:auto;border:.3mm solid #D3E1E7;border-top:1.2mm solid #005B7F;padding:3mm 4mm;margin:0 0 4mm}}
.kp{{display:flex;flex-wrap:wrap;gap:2mm;margin:1mm 0 2mm}} .kp div{{background:#E5EEF3;padding:1.2mm 2.5mm;font-size:7.4pt;color:#5E7480}} .kp b{{color:#005B7F;font-size:10pt;margin-right:1.2mm}}
ul{{margin:1mm 0 2mm;padding-left:4.5mm}} li{{margin:0 0 1mm}} .emb{{font-size:7.6pt;color:#5E7480;margin:1mm 0}}
.st{{font-weight:700}} .Atr{{color:#C77700}} .Adi{{color:#8E44AD}} .Não{{color:#C0392B}}
.box{{background:#F4F8FA;border:.3mm solid #D3E1E7;padding:3mm 4mm;margin:2mm 0}}
tr{{break-inside:avoid}} h3,h4{{break-after:avoid}} .kp,.reg{{break-after:avoid}}
</style></head><body>
<h1>Relatório de viagens por travessia</h1>
<div class=sub>Segunda-feira, 09/11/2026 · da 00:00 às {CUT:%H:%M} (horário da exportação) · grade de dia útil</div>
<div class=big><div><b>{n(tot['v'])}</b>viagens registradas</div><div><b>{df.emb.nunique()}</b>embarcações em operação</div><div><b>{n(tot['ped']+tot['bic'])}</b>pedestres e ciclistas</div><div><b>{n(df.veic.sum())}</b>veículos</div><div><b>{pct(okT,len(P))}</b>dos horários fixos no horário ({okT} de {len(P)})</div></div>
<h2>Resumo por travessia</h2>
<table class='t s'><tr><th>Travessia</th><th>Viagens</th><th>Embarc.</th><th>Fixos prog.</th><th>No horário</th><th>Atras.</th><th>Adiant.</th><th>Não real.</th><th>% no horário</th><th>Interv. acima do máx.</th><th>Pedestres</th><th>Bicicl.</th><th>Motos</th><th>Autos</th><th>Ônibus/ micro</th><th>Cam.</th><th>Veículos</th></tr>{summ}</table>
<h2>Pontos de atenção</h2><div class=box><ul>
<li><b>Bertioga ⇄ Guarujá:</b> das 13:00 às 16:20 a operação ficou 20 min defasada da grade porque saiu de operação a embarcação errada (o FB-MF25, em Bertioga, em vez da que deveria ficar em Guarujá). Foram 9 horários não cumpridos, embora as viagens tenham acontecido.</li>
<li><b>Paraitinga e Varginha:</b> sem nenhum registro até 15:33 e 09:01, respectivamente, incluindo os horários fixos da madrugada. Confirmar se houve operação sem BSM aberto.</li>
<li><b>Natividade:</b> com uma balsa e 3 pontas, o intervalo real é de cerca de 40 min, contra o máximo de 20 min da grade das 08:00 às 20:00 (15 intervalos acima). A exportação não separa Pouso Alto de Bairro Alto.</li>
<li><b>Santos ⇄ Vicente de Carvalho:</b> na madrugada, a lancha sai de Santos entre os horários da grade (9 horários não cumpridos), e de manhã as saídas de Santos partiram de 3 a 5 min antes do horário (10 viagens).</li>
<li><b>Santos ⇄ Guarujá:</b> 6 intervalos acima de 12 min, os maiores no fim da tarde (até 26 min). Há {ncur} registros no sistema com travessia de menos de 1 min, indício de apontamento fora de hora.</li>
<li><b>Litoral Sul e Norte:</b> poucas falhas pontuais. Atrasaram Cananéia–Continente 06:30 (+10 min), Cananéia–Ilha Comprida 11:30 (+8 min), a lancha de São Sebastião 07:30 (+8 min) e o Ariri 13:00 (+9 min). Não foram realizadas Cananéia–Ilha Comprida 10:00 e Iguape 12:00.</li>
</ul></div>
<h2>Detalhe por travessia</h2>
{''.join(sec)}
<h2>Critérios</h2><div class=box><ul>
<li><b>Fonte:</b> exportação de volume transportado (BSM) do sistema, 09/11/2026 da 00:00 às {CUT:%H:%M}, com {len(df)} viagens. As grades usadas são as de dia útil do pacote "Grade de Horários".</li>
<li><b>Horário de saída:</b> coluna "Término Embarque / Início Travessia", em hora e minuto (Anexo 8, 9.2.2).</li>
<li><b>Horário fixo:</b> no horário é a saída entre 2 min antes e 5 min depois do programado (Anexo 8, 9.2.6). De 5 a 15 min depois conta como atrasada; de 2 a 10 min antes, como adiantada. Sem saída entre 10 min antes e 15 min depois, a viagem conta como não realizada (9.1.5). Cada saída cobre um só horário.</li>
<li><b>Conforme demanda:</b> confere se o tempo entre saídas seguidas da mesma margem passou do intervalo máximo da faixa. O mínimo para cumprir é a duração da faixa dividida pelo intervalo máximo. Faixas ainda abertas foram avaliadas até {CUT:%H:%M}.</li>
<li><b>Volume:</b> soma de pedestres, bicicletas e veículos de cada viagem, sem fator de equivalência. Ônibus inclui micro-ônibus e vans; caminhões somam 2, 3, 4 ou mais eixos.</li>
<li>Os horários programados nos últimos 15 min antes da exportação não foram avaliados. As travessias metropolitanas (Billings) não aparecem na exportação.</li>
</ul></div>
</body></html>"""
open(sys.argv[2],'w').write(html)
open(sys.argv[3],'w').write(f'''<div style="width:100%;height:16mm;margin-top:-4mm;background:#005B7F;border-bottom:1.2mm solid #00B5AD;display:flex;align-items:center;justify-content:space-between;padding:0 13mm;box-sizing:border-box;-webkit-print-color-adjust:exact"><img src="data:image/png;base64,{logo}" style="height:6mm"><span style="color:#fff;font-family:Lato,Arial;font-size:7pt;letter-spacing:.14em;font-weight:700">RELATÓRIO DE VIAGENS · 09/11/2026</span></div>''')
