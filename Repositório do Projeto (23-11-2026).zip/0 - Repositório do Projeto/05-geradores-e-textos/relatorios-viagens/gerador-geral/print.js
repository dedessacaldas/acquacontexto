const { chromium } = require('playwright'); const fs=require('fs');
(async () => {
  const [,, src, out, hdr] = process.argv;
  const b = await chromium.launch(); const p = await b.newPage();
  await p.goto('file://' + src); await p.evaluate(() => document.fonts.ready);
  await p.pdf({ path: out, format: 'A4', printBackground: true, displayHeaderFooter:true,
    headerTemplate: fs.readFileSync(hdr,'utf8'),
    footerTemplate: '<div style="width:100%;font-family:Arial;font-size:7pt;color:#5E7480;padding:0 13mm;display:flex;justify-content:space-between"><span>Acquavias · Análise de Performance</span><span>Página <span class=pageNumber></span> de <span class=totalPages></span></span></div>',
    margin:{top:'22mm',bottom:'14mm',left:'13mm',right:'13mm'} });
  await b.close();
})();
