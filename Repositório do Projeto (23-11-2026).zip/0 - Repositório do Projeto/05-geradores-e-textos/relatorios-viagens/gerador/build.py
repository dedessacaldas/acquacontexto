import pickle, pandas as pd, sys
from datetime import datetime, timedelta
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.drawing.image import Image as XLImage
from openpyxl.chart import BarChart, Reference
from openpyxl.utils import get_column_letter as L
from openpyxl.formatting.rule import FormulaRule
R=pickle.load(open('res.pkl','rb'))
df,fx,gp,cut=R['df'],R['fx'],R['gaps'],R['cut']
D=datetime(2026,11,9); M=lambda h,m=0: D+timedelta(hours=h,minutes=m)
AZ='005B7F'; ES='00B5AD'; CL='EAF4F7'; CZ='5F6B73'; LN='D5E3E9'
VD='E3F6EF'; VDt='1B7F5A'; AM='FFF4D6'; AMt='9A6A00'; VM='FDE7E7'; VMt='B42318'
F=lambda **k: Font(name='Lato',**k)
fill=lambda c: PatternFill('solid',start_color=c,end_color=c)
thin=Side(style='thin',color=LN); BOT=Border(bottom=thin)
wb=Workbook()
def banner(ws,ncols,sub):
    ws.sheet_view.showGridLines=False
    for r in (1,2,3):
        ws.row_dimensions[r].height=16
        for c in range(1,ncols+1): ws.cell(r,c).fill=fill(AZ)
    ws.row_dimensions[4].height=4
    for c in range(1,ncols+1): ws.cell(4,c).fill=fill(ES)
    img=XLImage('logo_s.png'); img.width=210; img.height=25; ws.add_image(img,'B2')
    c=ws.cell(2,ncols,'Relatório de Viagens · Santos ⇄ Guarujá'); c.font=F(bold=True,size=13,color='FFFFFF'); c.alignment=Alignment(horizontal='right',vertical='center')
    c=ws.cell(3,ncols,sub); c.font=F(size=9,color='CDE6EE'); c.alignment=Alignment(horizontal='right',vertical='center')
    ws.column_dimensions['A'].width=2
def title(ws,r,txt,c=2,note=None,span=None):
    x=ws.cell(r,c,txt); x.font=F(bold=True,size=12,color=AZ); ws.row_dimensions[r].height=22
    if note:
        y=ws.cell(r+1,c,note); y.font=F(size=9,italic=True,color=CZ)
        if span:
            ws.merge_cells(start_row=r+1,start_column=c,end_row=r+1,end_column=c+span-1); y.alignment=Alignment(wrap_text=True,vertical='top'); ws.row_dimensions[r+1].height=26
def table(ws,r,c,headers,rows,fmts=None,widths=None,zebra=True,center=None):
    for j,h in enumerate(headers):
        x=ws.cell(r,c+j,h); x.font=F(bold=True,size=10,color='FFFFFF'); x.fill=fill(AZ)
        x.alignment=Alignment(horizontal='center',vertical='center',wrap_text=True)
    ws.row_dimensions[r].height=44 if any(len(str(h))>20 for h in headers) else 32
    for i,row in enumerate(rows):
        for j,v in enumerate(row):
            x=ws.cell(r+1+i,c+j,v); x.font=F(size=10,color='1F2A30'); x.border=BOT
            if zebra and i%2: x.fill=fill(CL)
            if fmts and fmts[j]: x.number_format=fmts[j]
            x.alignment=Alignment(horizontal='left' if j==0 or (center is not None and j not in center) else 'center',vertical='center')
    return r+1+len(rows)
def status_cf(ws,rng,col_letter,first_row):
    for txt,bg,fg in [('OK',VD,VDt),('No horário',VD,VDt),('Excedido',VM,VMt),('Não realizada',VM,VMt),('Com atraso',AM,AMt),('Verificar',AM,AMt)]:
        ws.conditional_formatting.add(rng,FormulaRule(formula=[f'LEFT(${col_letter}{first_row},{len(txt)})="{txt}"'],fill=fill(bg),font=Font(name='Lato',color=fg,bold=True)))
sub=f'Segunda-feira, 09/11/2026 · grade Dias úteis · dados de 00h00 a {cut:%Hh%M}'
marg=['Santos','Guarujá']
# ---------- RESUMO
ws=wb.active; ws.title='Resumo'; banner(ws,12,sub)
for col,w in zip('BCDEFGHIJKL',[26,19,12,12,12,12,20,12,14,14,30]): ws.column_dimensions[col].width=w
ws.column_dimensions['L'].width=4
r=6; title(ws,r,'Visão geral do dia',note=f'Export do sistema de volume transportado (BSM), 382 viagens com início de travessia entre 00h00 e {cut:%Hh%M} de 09/11/2026. O dia ainda não estava fechado.')
r=9
nS=(df.margem=='Santos').sum(); nG=(df.margem=='Guarujá').sum()
fxS=fx[fx.margem=='Santos']; fxG=fx[fx.margem=='Guarujá']
nh=(fx.status=='No horário').sum(); exc=(gp.status=='Excedido').sum()
cards=[('Viagens registradas',len(df),'nas duas margens'),('Saídas de Santos',nS,'sentido Santos → Guarujá'),('Saídas de Guarujá',nG,'sentido Guarujá → Santos'),
       ('Embarcações operando',df.emb.nunique(),'ferry boats com BSM no dia'),('Horários fixos cumpridos',f'{nh} de {len(fx)}','00h00 a 05h00, nas duas margens'),('Intervalos acima do máximo',int(exc),f'de {len(gp)} intervalos conforme demanda')]
for k,(lab,val,desc) in enumerate(cards):
    col=2+ (k%3)*3; rr=r+(k//3)*4
    ws.merge_cells(start_row=rr,start_column=col,end_row=rr,end_column=col+2)
    ws.merge_cells(start_row=rr+1,start_column=col,end_row=rr+1,end_column=col+2)
    ws.merge_cells(start_row=rr+2,start_column=col,end_row=rr+2,end_column=col+2)
    a=ws.cell(rr,col,lab.upper()); a.font=F(bold=True,size=9,color=ES)
    b=ws.cell(rr+1,col,val); b.font=F(bold=True,size=22,color=AZ); b.alignment=Alignment(horizontal='left')
    c=ws.cell(rr+2,col,desc); c.font=F(size=9,color=CZ)
    ws.row_dimensions[rr+1].height=30
    for rrr in range(rr,rr+3):
        for cc in range(col,col+3): ws.cell(rrr,cc).fill=fill(CL)
    ws.cell(rr,col).border=Border(left=Side(style='thick',color=ES)); ws.cell(rr+1,col).border=Border(left=Side(style='thick',color=ES)); ws.cell(rr+2,col).border=Border(left=Side(style='thick',color=ES))
r=r+8
title(ws,r,'Viagens cumpridas × programadas pela grade, por margem de saída',span=10,note=f'Faixa fixa: cada horário vale se a saída for de 2 min antes a 5 min depois (Anexo 8, 9.2.6). Conforme demanda: nenhum intervalo entre saídas da mesma margem pode passar do máximo. Previstas até {cut:%Hh%M} = duração da faixa ÷ intervalo máximo, como na grade.')
r+=2
hdr=['Margem / faixa','Regime','Intervalo máx.','Previstas no dia','Previstas até '+f'{cut:%Hh%M}','Saídas registradas','Cumpridas no critério','Fora do critério','Maior intervalo (min)','Situação']
rows=[]
for m in marg:
    g=df[df.margem==m]; f=fx[fx.margem==m]; q=gp[gp.margem==m]
    nf=(f.status=='No horário').sum(); na=f.status.str.startswith('Com atraso').sum(); nn=(f.status=='Não realizada').sum()
    rows.append([f'{m} · 00h00 a 05h00','Horário fixo','—',11,11,int(((g.saida<M(5))).sum()),f'{nf} de 11 horários',int(na+nn),'—','OK' if na+nn==0 else f'Não realizada: {nn}' if nn else f'Com atraso: {na}'])
    for (_,a,b,I),lab in zip(R['bands'],['05h00 a 06h30','06h30 a 20h00','20h00 a 24h00']):
        dur_day=(b-a).total_seconds()/60; dur_cut=max(0,(min(b,cut)-a).total_seconds()/60)
        qq=q[q.faixa==lab.replace(' a ','–').replace('24h00','24h00')]
        reg=int(((g.saida>=a)&(g.saida<min(b,cut+timedelta(minutes=1)))).sum())
        if dur_cut==0:
            rows.append([f'{m} · {lab}','Conforme demanda',f'{I} min',dur_day/I,0,'—','—','—','—','Sem dados ainda']); continue
        ne=int((qq.status=='Excedido').sum()); ok=int((qq.status=='OK').sum())
        rows.append([f'{m} · {lab}','Conforme demanda',f'{I} min',dur_day/I,dur_cut/I,reg,f'{ok} de {ok+ne} intervalos',ne,qq.gap.max() if len(qq) else '—','OK' if ne==0 else f'Excedido: {ne}'])
    rows.append([f'{m} · total do dia','', '',95, 11+sum(max(0,(min(b,cut)-a).total_seconds()/60)/I for _,a,b,I in R['bands']), int(len(g)),'','','',''])
fm=[None,None,None,'0.0','0.0','0',None,'0','0',None]
end=table(ws,r,2,hdr,rows,fm)
for rr in range(r+1,end):
    if 'total do dia' in str(ws.cell(rr,2).value):
        for cc in range(2,12): ws.cell(rr,cc).font=F(bold=True,size=10,color=AZ); ws.cell(rr,cc).fill=fill('D9EEF3')
status_cf(ws,f'K{r+1}:K{end-1}','K',r+1)
ws.column_dimensions['K'].width=20
r=end+1
title(ws,r,'Leitura rápida')
pts=[f'Santos fez {nS} saídas e Guarujá {nG} até {cut:%Hh%M}. A grade prevê cerca de 62 saídas por margem até esse horário (95 no dia), então a quantidade de viagens ficou bem acima do mínimo.',
     'Horário fixo (madrugada): Santos cumpriu os 11 horários. Guarujá cumpriu 10: a saída das 02h00 não aconteceu na janela, porque a embarcação saiu às 01h56 (4 min antes) e a seguinte só às 02h28.',
     'Conforme demanda: das 05h00 às 06h30 todos os intervalos ficaram dentro de 20 min. Das 06h30 em diante houve 4 intervalos acima de 12 min (1 em Santos e 3 em Guarujá, de 13 a 16 min). Detalhe na aba Intervalos.',
     'Há registros com sentido repetido na mesma embarcação e travessias de menos de 1 minuto, que podem ser erro de apontamento no BSM. Estão na aba Inconsistências e podem mudar alguns intervalos.']
for i,p in enumerate(pts):
    ws.merge_cells(start_row=r+1+i,start_column=2,end_row=r+1+i,end_column=11)
    x=ws.cell(r+1+i,2,'•  '+p); x.font=F(size=10,color='1F2A30'); x.alignment=Alignment(wrap_text=True,vertical='top'); ws.row_dimensions[r+1+i].height=30
# ---------- VOLUME
ws=wb.create_sheet('Volume transportado'); banner(ws,13,sub)
CAT=[('Pedestres','ped'),('Bicicletas','bic'),('Motos','moto'),('Automóveis','aut'),('Micro-ônibus e vans','micro'),('Ônibus','onib'),('Caminhões 2 eixos','c2'),('Caminhões 3 eixos','c3'),('Caminhões 4 ou mais eixos','c4')]
for col,w in zip('BCDEFGHIJKLM',[32,12,12,12,12,12,12,12,12,12,12,12]): ws.column_dimensions[col].width=w
title(ws,6,'Volume transportado por categoria e margem de saída',span=10,note=f'Soma das {len(df)} viagens do export, de 00h00 a {cut:%Hh%M}. Margem de saída = de onde a embarcação partiu.')
rows=[];tot=df[[k for _,k in CAT]].sum().sum()
grp=[('Pessoas sem veículo',['ped','bic']),('Veículos',['moto','aut','micro','onib','c2','c3','c4'])]
for gname,keys in grp:
    for lab,k in CAT:
        if k not in keys: continue
        s=int(df[df.margem=='Santos'][k].sum()); g=int(df[df.margem=='Guarujá'][k].sum())
        rows.append([lab,s,g,s+g,(s+g)/tot])
    s=int(df[df.margem=='Santos'][keys].sum().sum()); g=int(df[df.margem=='Guarujá'][keys].sum().sum())
    rows.append(['Subtotal · '+gname.lower(),s,g,s+g,(s+g)/tot])
s=int(df[df.margem=='Santos'][[k for _,k in CAT]].sum().sum()); g=int(df[df.margem=='Guarujá'][[k for _,k in CAT]].sum().sum())
rows.append(['Total geral (pessoas + veículos)',s,g,s+g,1.0])
end=table(ws,9,2,['Categoria','Saída Santos','Saída Guarujá','Total','% do total'],rows,[None,'#,##0','#,##0','#,##0','0.0%'])
for rr in range(10,end):
    v=str(ws.cell(rr,2).value)
    if v.startswith('Subtotal') or v.startswith('Total geral'):
        for cc in range(2,7): ws.cell(rr,cc).font=F(bold=True,size=10,color=AZ); ws.cell(rr,cc).fill=fill('D9EEF3')
r=end+2; title(ws,r,'Volume por hora (as duas margens)')
hrs=list(range(cut.hour+1))
rows=[]
for h in hrs:
    g=df[df.saida.dt.hour==h]
    rows.append([f'{h:02d}h',len(g)]+[int(g[k].sum()) for _,k in CAT]+[int(g.veic.sum())])
rows.append(['Total',len(df)]+[int(df[k].sum()) for _,k in CAT]+[int(df.veic.sum())])
end2=table(ws,r+1,2,['Hora','Viagens']+[c[0] for c in CAT]+['Total de veículos'],rows,[None]+['#,##0']*11)
for cc in range(2,14): ws.cell(end2-1,cc).font=F(bold=True,size=10,color=AZ); ws.cell(end2-1,cc).fill=fill('D9EEF3')
r=end2+2; title(ws,r,'Volume por embarcação')
rows=[]
for e,g in df.groupby('emb'): rows.append([e,len(g)]+[int(g[k].sum()) for _,k in CAT]+[int(g.veic.sum())])
end3=table(ws,r+1,2,['Embarcação','Viagens']+[c[0] for c in CAT]+['Total de veículos'],rows,[None]+['#,##0']*11)
for rr in (r+1,): ws.row_dimensions[rr].height=44
ws.row_dimensions[end2+3].height=44
ws.freeze_panes='C9'

# ---------- POR HORA
ws=wb.create_sheet('Viagens por hora'); banner(ws,9,sub)
for col,w in zip('BCDEFGHI',[14,14,14,12,14,14,12,30]): ws.column_dimensions[col].width=w
title(ws,6,'Saídas por hora e por margem',note='Previstas = horários fixos da hora + minutos da hora em faixa conforme demanda ÷ intervalo máximo (mesma conta que dá 95 saídas no dia).')
def prev_hour(h):
    a,b=M(h),M(h+1); n=sum(1 for s in R['fixed'] if a<=s<b)
    for _,x,y,I in R['bands']: n+=max(0,(min(b,y)-max(a,x)).total_seconds()/60)/I
    return n
rows=[]
for h in range(cut.hour+1):
    g=df[df.saida.dt.hour==h]
    rows.append([f'{h:02d}h',prev_hour(h),int((g.margem=='Santos').sum()),int((g.margem=='Guarujá').sum()),int(len(g)),g.emb.nunique(),', '.join(sorted(g.emb.unique()))])
rows.append(['Total',sum(x[1] for x in rows),int(nS),int(nG),len(df),df.emb.nunique(),''])
hdr=['Hora','Previstas por margem','Saídas Santos','Saídas Guarujá','Total','Embarcações na hora','Quais embarcações']
end=table(ws,8,2,hdr,rows,[None,'0.0','0','0','0','0',None])
ws.column_dimensions['H'].width=62
for cc in range(2,9): ws.cell(end-1,cc).font=F(bold=True,size=10,color=AZ); ws.cell(end-1,cc).fill=fill('D9EEF3')
ch=BarChart(); ch.type='col'; ch.grouping='clustered'; ch.title='Saídas por hora'; ch.y_axis.title='saídas'; ch.height=8; ch.width=22
data=Reference(ws,min_col=3,max_col=5,min_row=8,max_row=end-2); cats=Reference(ws,min_col=2,min_row=9,max_row=end-2)
ch.add_data(data,titles_from_data=True); ch.set_categories(cats)
for s,c in zip(ch.series,['B8C4CA',AZ,ES]): s.graphicalProperties.solidFill=c; s.graphicalProperties.line.solidFill=c
ch.series[0].graphicalProperties.solidFill='C9D3D8'
ws.add_chart(ch,f'B{end+2}')
ws.freeze_panes='B9'
# ---------- EMBARCAÇÕES
ws=wb.create_sheet('Embarcações'); banner(ws,12,sub)
title(ws,6,'Embarcações operando',note='Saída = término do embarque / início da travessia. Veículos = motos + automóveis + micro-ônibus/vans + ônibus + caminhões.')
rows=[]
for e,g in df.groupby('emb'):
    rows.append([e,int((g.margem=='Santos').sum()),int((g.margem=='Guarujá').sum()),len(g),g.te.min(),g.te.max(),', '.join(str(b) for b in sorted(g.bsm.unique())),int(g.ped.sum()),int(g.bic.sum()),int(g.veic.sum())])
rows.append(['Total',int(nS),int(nG),len(df),df.te.min(),df.te.max(),'',int(df.ped.sum()),int(df.bic.sum()),int(df.veic.sum())])
hdr=['Embarcação','Saídas Santos','Saídas Guarujá','Total de viagens','1ª saída','Última saída','BSM','Pedestres','Bicicletas','Veículos']
for col,w in zip('BCDEFGHIJK',[14,12,12,12,12,12,26,12,12,12]): ws.column_dimensions[col].width=w
end=table(ws,8,2,hdr,rows,[None,'0','0','0','hh:mm','hh:mm',None,'#,##0','#,##0','#,##0'])
for cc in range(2,12): ws.cell(end-1,cc).font=F(bold=True,size=10,color=AZ); ws.cell(end-1,cc).fill=fill('D9EEF3')
r=end+2; title(ws,r,'Viagens por embarcação e hora (as duas margens)')
emb=sorted(df.emb.unique()); hrs=list(range(cut.hour+1))
hdr=['Embarcação']+[f'{h:02d}h' for h in hrs]+['Total']
rows=[[e]+[int(((df.emb==e)&(df.saida.dt.hour==h)).sum()) or None for h in hrs]+[int((df.emb==e).sum())] for e in emb]
rows.append(['Em operação']+[df[df.saida.dt.hour==h].emb.nunique() for h in hrs]+[df.emb.nunique()])
end2=table(ws,r+1,2,hdr,rows,[None]+['0']*(len(hrs)+1))
for j in range(len(hrs)): ws.column_dimensions[L(3+j)].width=max(ws.column_dimensions[L(3+j)].width or 0,7)
from openpyxl.formatting.rule import ColorScaleRule
ws.conditional_formatting.add(f'C{r+2}:{L(2+len(hrs))}{end2-2}',ColorScaleRule(start_type='num',start_value=0,start_color='FFFFFF',end_type='max',end_color='7FD3CF'))
for cc in range(2,4+len(hrs)): ws.cell(end2-1,cc).font=F(bold=True,size=10,color=AZ); ws.cell(end2-1,cc).fill=fill('D9EEF3')
# ---------- HORÁRIOS FIXOS
ws=wb.create_sheet('Horários fixos'); banner(ws,9,sub)
for col,w in zip('BCDEFGH',[12,14,16,12,12,22,40]): ws.column_dimensions[col].width=w
title(ws,6,'Faixa de horário fixo · 00h00 a 05h00',note='No horário: saída de 2 min antes a 5 min depois (Anexo 8, 9.2.6). De 5 a 15 min depois: com atraso. Fora disso: não realizada (Anexo 8, 9.1.5). Hora e minuto da saída, sem segundos.')
rows=[]
for _,x in fx.iterrows():
    obs='' if x.status!='Não realizada' else f'Saída mais próxima às {x.prox:%H:%M} ({x.prox_desv:+.0f} min), fora da janela'
    rows.append([x.margem,x.prog.to_pydatetime(),x.real.to_pydatetime() if pd.notna(x.real) else None,x.emb,x.desvio,x.status,obs])
end=table(ws,8,2,['Margem','Horário programado','Saída realizada','Embarcação','Desvio (min)','Situação','Observação'],rows,[None,'hh:mm','hh:mm:ss',None,'+0;-0;0',None,None])
status_cf(ws,f'G9:G{end-1}','G',9); ws.freeze_panes='B9'
# ---------- INTERVALOS
ws=wb.create_sheet('Intervalos'); banner(ws,11,sub)
for col,w in zip('BCDEFGHIJK',[12,16,12,14,14,12,12,12,14,14]): ws.column_dimensions[col].width=w
title(ws,6,'Faixas conforme demanda · intervalo entre saídas da mesma margem',note='Excedido: a saída seguinte veio depois do intervalo máximo da faixa. Excesso = minutos além do máximo.')
rows=[[x.margem,x.faixa,x.intmax,x.ant.to_pydatetime(),x.prox.to_pydatetime(),x.emb_ant,x.emb_prox,x.gap,x.status,x.excesso or None] for _,x in gp.iterrows()]
end=table(ws,8,2,['Margem','Faixa','Intervalo máx. (min)','Saída anterior','Saída seguinte','Emb. anterior','Emb. seguinte','Intervalo (min)','Situação','Excesso (min)'],rows,[None,None,'0','hh:mm','hh:mm',None,None,'0',None,'0'])
status_cf(ws,f'J9:J{end-1}','J',9); ws.auto_filter.ref=f'B8:K{end-1}'; ws.freeze_panes='B9'
# ---------- INCONSISTÊNCIAS
ws=wb.create_sheet('Inconsistências'); banner(ws,9,sub)
for col,w in zip('BCDEFGH',[12,10,18,14,14,14,56]): ws.column_dimensions[col].width=w
title(ws,6,'Registros para conferir no BSM',note='Contados normalmente no relatório. Podem ser sentido trocado, viagem lançada duas vezes ou horário apontado errado.')
rows=[]
for e,g in df.groupby('emb'):
    g=g.sort_values('te').reset_index(drop=True)
    for i in range(1,len(g)):
        if g.dir[i]==g.dir[i-1]: rows.append([e,int(g.bsm[i]),g.margem[i],g.te[i-1].to_pydatetime(),g.te[i].to_pydatetime(),None,'Duas saídas seguidas da mesma margem (sem a viagem de volta)'])
for _,x in df[(df.trav_min<1)|(df.trav_min>30)].iterrows():
    rows.append([x.emb,int(x.bsm),x.margem,None,x.te.to_pydatetime(),x.trav_min,'Travessia de menos de 1 min' if x.trav_min<1 else 'Travessia de mais de 30 min'])
rows.sort(key=lambda z:(z[0],z[4]))
table(ws,8,2,['Embarcação','BSM','Margem','Saída anterior','Saída','Travessia (min)','O que verificar'],rows,[None,'0',None,'hh:mm','hh:mm','0.0',None])
ws.freeze_panes='B9'
# ---------- BASE
ws=wb.create_sheet('Base de dados'); banner(ws,12,sub)
cols=[('Embarcação','emb',None,12),('BSM','bsm','0',9),('Margem de saída','margem',None,14),('Início embarque','ie','hh:mm:ss',12),('Saída (início travessia)','te','hh:mm:ss',13),('Chegada','tt','hh:mm:ss',12),('Travessia (min)','trav_min','0.0',10),('Pedestres','ped','0',10),('Bicicletas','bic','0',10),('Veículos','veic','0',10),('Hora','h','0',7)]
df['h']=df.te.dt.hour
title(ws,6,'Viagens do export (ordenadas pela saída)')
rows=[[ (x[k].to_pydatetime() if hasattr(x[k],'to_pydatetime') else (int(x[k]) if k in('bsm','ped','bic','veic','h') else x[k])) for _,k,_,_ in cols] for _,x in df.iterrows()]
end=table(ws,8,2,[c[0] for c in cols],rows,[c[2] for c in cols])
for j,c in enumerate(cols): ws.column_dimensions[L(2+j)].width=c[3]
ws.auto_filter.ref=f'B8:{L(1+len(cols))}{end-1}'; ws.freeze_panes='B9'
# ---------- CRITÉRIOS
ws=wb.create_sheet('Critérios'); banner(ws,9,sub); ws.column_dimensions['B'].width=110
title(ws,6,'Como o relatório foi montado')
txt=['Fonte das viagens: ExportDadosVolumeTransportadoReport (BSM), travessia Santos/Guarujá, 382 registros.',
 'Margem de saída: sentido "1-Santos/Guarujá" = saída de Santos; "2-Guarujá/Santos" = saída de Guarujá.',
 'Horário de saída: coluna "Término Embarque / Início Travessia", em hora e minuto (Anexo 8, 9.2.2). O contrato não define o marco exato de partida.',
 'Grade usada: Dias úteis (09/11/2026 é segunda-feira). 00h00 a 05h00 com horários fixos a cada 30 min (11 horários); 05h00 a 06h30 conforme demanda até 20 min; 06h30 a 20h00 até 12 min; 20h00 a 24h00 até 20 min. 95 saídas previstas por margem.',
 'Horário fixo: no horário de 2 min antes a 5 min depois (Anexo 8, 9.2.6); de 5 a 15 min depois, com atraso; fora disso, não realizada (Anexo 8, 9.1.5). Cada saída cumpre só um horário. Saídas a mais na madrugada não contam contra.',
 'Conforme demanda: avalia cada par de saídas seguidas da mesma margem. Passa do máximo quando a seguinte vem depois do intervalo da faixa. Na troca de faixa vale o intervalo da faixa em que a saída seguinte era devida. O intervalo da última saída do regime fixo (antes das 05h00) não entra, porque já é avaliado no horário das 05h00.',
 'Previstas: duração da faixa ÷ intervalo máximo, como a grade faz para chegar a 95. É um mínimo, porque conforme demanda permite sair mais vezes.',
 f'Período: o export vai até {cut:%Hh%M}. As faixas depois disso aparecem como "Sem dados ainda". O intervalo após a última saída de cada margem não foi avaliado.',
 'Nota: o Anexo 8, 3.4.3 tira do IHP e do ITP os horários de atendimento por demanda na madrugada. Na grade atual a madrugada de Santos–Guarujá é de horário fixo, então ela foi avaliada como fixa.']
for i,t in enumerate(txt):
    x=ws.cell(8+i,2,t); x.font=F(size=10); x.alignment=Alignment(wrap_text=True,vertical='top'); ws.row_dimensions[8+i].height=32
for w in wb.worksheets:
    w.sheet_properties.tabColor=AZ if w.title=='Resumo' else ES
    w.page_setup.orientation='landscape'; w.page_setup.fitToWidth=1; w.page_setup.fitToHeight=0; w.sheet_properties.pageSetUpPr.fitToPage=True
wb.save(sys.argv[1])
