import pandas as pd, math, pickle, sys
from datetime import datetime, timedelta
df=pd.read_excel(sys.argv[1])
df.columns=['trav','abert','emb','bsm','dir','ie','te','ped','bic','moto','aut','micro','onib','c2','c3','c4','tipo','tt','td']
for c in ['ie','te','tt','td']: df[c]=pd.to_datetime(df[c],dayfirst=True)
df=df.sort_values('te').reset_index(drop=True)
D=datetime(2026,11,9)
df['margem']=df.dir.map(lambda s:'Santos' if s.startswith('1') else 'Guarujá')
df['saida']=df.te.dt.floor('min')   # hora e minuto (Anexo 8, 9.2.2)
df['veic']=df[['moto','aut','micro','onib','c2','c3','c4']].sum(axis=1)
df['trav_min']=(df.tt-df.te).dt.total_seconds()/60
cut=df.saida.max()
M=lambda h,m=0: D+timedelta(hours=h,minutes=m)
fixed=[M(h,m) for h in range(5) for m in (0,30)]+[M(5)]
bands=[('Conforme demanda',M(5),M(6,30),20),('Conforme demanda',M(6,30),M(20),12),('Conforme demanda',M(20),M(24),20)]
def interval_at(t):
    for _,a,b,i in bands:
        if a<=t<b: return i
    return None
res={'cut':cut,'df':df,'fixed':fixed,'bands':bands}
fx_rows=[];gap_rows=[];summ=[]
for marg in ['Santos','Guarujá']:
    g=df[df.margem==marg].reset_index(drop=True)
    used=set()
    for s in fixed:
        cand=[(abs((t-s).total_seconds()),i) for i,t in enumerate(g.saida) if i not in used and -2<= (t-s).total_seconds()/60 <=15]
        if cand:
            # prefer within [-2,+5]
            cand.sort(key=lambda x:(not(-2<=(g.saida[x[1]]-s).total_seconds()/60<=5),x[0]))
            i=cand[0][1];used.add(i);d=(g.saida[i]-s).total_seconds()/60
            st='No horário' if d<=5 else 'Com atraso (5 a 15 min)'
            fx_rows.append([marg,s,g.te[i],g.emb[i],d,st,None,None])
        else:
            near=min(range(len(g)),key=lambda i:abs((g.saida[i]-s).total_seconds()))
            fx_rows.append([marg,s,None,None,None,'Não realizada',g.te[near],(g.saida[near]-s).total_seconds()/60])
    # gaps
    ts=list(g.saida)
    for k in range(1,len(ts)):
        p,n=ts[k-1],ts[k]
        if p<M(5): continue  # regime de horário fixo até 05h00 (avaliado na aba Horários fixos)
        # deadline: first t>p with t-p >= I(t)
        t=max(p,M(5))
        if p<M(5): t=M(5)
        t=p+timedelta(minutes=1)
        while True:
            I=interval_at(t)
            if t>=M(24) or (I is not None and (t-p).total_seconds()/60>=I): break
            t+=timedelta(minutes=1)
        I=interval_at(t) or interval_at(n)
        gap=(n-p).total_seconds()/60
        exc=n>t
        band=[f'{a:%Hh%M}–{(b if b.day==D.day else b-timedelta(seconds=1)):%Hh%M}'.replace('23h59','24h00') for _,a,b,i in bands if a<=t<b][0]
        gap_rows.append([marg,band,I,p,n,g.emb[k-1],g.emb[k],gap,'Excedido' if exc else 'OK',(n-t).total_seconds()/60 if exc else 0])
    # trailing
    p=ts[-1]
    if (cut-p).total_seconds()/60>interval_at(cut): print('trailing exceed',marg)
res['fx']=pd.DataFrame(fx_rows,columns=['margem','prog','real','emb','desvio','status','prox','prox_desv'])
res['gaps']=pd.DataFrame(gap_rows,columns=['margem','faixa','intmax','ant','prox','emb_ant','emb_prox','gap','status','excesso'])
pickle.dump(res,open('res.pkl','wb'))
fx=res['fx'];gp=res['gaps']
print(fx.groupby(['margem','status']).size())
print(gp.groupby(['margem','faixa','status']).size())
print(gp[gp.status=='Excedido'].to_string())
print(gp.groupby(['margem','faixa']).gap.max())
print(cut)
