import pandas as pd, pickle, openpyxl
C=['trav','abert','emb','bsm','dir','ie','te','ped','bic','moto','aut','micro','onib','c2','c3','c4','tipo','tt','td']
VE=['bic','moto','aut','micro','onib','c2','c3','c4']
def L(f):
    d=pd.read_excel(f); d.columns=C; d['te']=pd.to_datetime(d.te,dayfirst=True,errors='coerce'); d=d.dropna(subset=['te']); d['dia']=d.te.dt.strftime('%d'); d['vol']=d[VE].sum(axis=1); return d
A=L('Viagens_NOV_26.xlsx'); B=L('Export_1611.xlsx')
MAP={'Santos/Guarujá':('Santos ⇄ Guarujá',['Santos/Guarujá'],'VOL SAN_GUA'),
     'Santos/Vicente de Carvalho':('Santos ⇄ Vicente de Carvalho',['Santos/Vicente de Carvalho'],None),
     'Bertioga/Guarujá':('Bertioga ⇄ Guarujá',['Bertioga/Guarujá'],'VOL BER_GUA'),
     'São Sebastião/Ilhabela':('São Sebastião ⇄ Ilhabela',['São Sebastião/Ilhabela - Veículos e Pedestres','São Sebastião/Ilhabela - Pedestres e Ciclistas'],'VOL SS_IB'),
     'Cananéia/Continente':('Cananéia ⇄ Continente',['Cananeia/Continente'],'VOL CA_CON'),
     'Cananéia/Ilha Comprida':('Cananéia ⇄ Ilha Comprida',['Cananeia/Ilha Comprida'],'VOL CA_ILH'),
     'Iguape/Juréia':('Iguape ⇄ Juréia',['Iguape/Jureia'],'VOL IG_JUR'),
     'Cananéia/Ariri':('Cananéia ⇄ Marujá ⇄ Ariri',['Cananeia/Ariri'],None),
     'Natividade da Serra/B. Natividade da Serra':('Natividade',['Natividade'],None),
     'Ribeirão Branco/Capim DAngola':('Paraitinga',['Paraitinga'],None),
     'Comércio/Varginha':('Varginha',['Varginha'],None)}
X=pickle.load(open('/mnt/project-files/relatorios-viagens/relatorio-financeiro/gerador/projecao/rev10.pkl','rb'))['P']; X['Data']=pd.to_datetime(X.Data)
X=X[(X.Data.dt.year==2026)&(X.Data.dt.month==11)]
Q=X.groupby([X.Data.dt.strftime('%d'),'Nome']).V.sum()
wb=openpyxl.load_workbook('Historico.xlsx',read_only=True,data_only=True)
def hist(sh,ym):
    for r in wb[sh].iter_rows(values_only=True):
        if hasattr(r[1],'year') and (r[1].year,r[1].month)==ym: return sum(x or 0 for x in r[2:10])
DU=['09','10','11','12','13']; FS=['14','15']
rows=[]
for k,(lab,qn,sh) in MAP.items():
    g=A[A.trav==k]; q=lambda d: sum(Q.get((d,n),0) for n in qn)
    V={d:(g.dia==d).sum() for d in DU+FS}; W={d:g[g.dia==d].vol.sum() for d in DU+FS}
    qfs=sum(q(d) for d in FS); rfs=sum(V[d] for d in FS)/qfs if qfs else 1
    q20=q('20')
    wdu=sum(W[d] for d in DU)/5; wfs=sum(W[d] for d in FS)/2
    g1=(W['12']+W['13'])/max(W['09']+W['10'],1)   # tendência nos dias úteis
    h25=hist(sh,(2025,11)) if sh else None; h25d=h25/30 if h25 else None
    rows.append(dict(lab=lab,V=V,W=W,Q20=q20,rfs=rfs,P20=round(q20*min(rfs,1.15)) if q20 else round(sum(V[d] for d in FS)/2),
        wdu=wdu,wfs=wfs,g1=g1,h25d=h25d))
R=pd.DataFrame(rows)
sg=lambda d,dd:dd[(dd.trav=='Santos/Guarujá')&(dd.dia==d)&(dd.te.dt.hour<16)]
a,b=sg('09',A),sg('16',B)
WOW=dict(v09=len(a),v16=len(b),w09=a.vol.sum(),w16=b.vol.sum())
pickle.dump(dict(R=R,WOW=WOW),open('res.pkl','wb'))
pd.set_option('display.width',250)
print(R[['lab','Q20','rfs','P20','wdu','wfs','g1','h25d']]); print(R[['Q20','P20','wdu','wfs']].sum()); print(WOW)
