import pandas as pd, pickle, openpyxl
C=['trav','abert','emb','bsm','dir','ie','te','ped','bic','moto','aut','micro','onib','c2','c3','c4','tipo','tt','td']
VE=['bic','moto','aut','micro','onib','c2','c3','c4']
def L(f):
    d=pd.read_excel(f); d.columns=C; d['te']=pd.to_datetime(d.te,dayfirst=True,errors='coerce'); d=d.dropna(subset=['te']); d['dia']=d.te.dt.strftime('%d'); d['vol']=d[VE].sum(axis=1); d['h']=d.te.dt.hour; return d
A=L('Viagens_NOV_26.xlsx'); B=L('Export_1611.xlsx'); H=L('Dia_20-11-2025.xlsx')
D=pickle.load(open('res.pkl','rb')); R=D['R']
SH={'Santos ⇄ Guarujá':('Santos/Guarujá','VOL SAN_GUA'),'Santos ⇄ Vicente de Carvalho':('Santos/Vicente de Carvalho',None),'Bertioga ⇄ Guarujá':('Bertioga/Guarujá','VOL BER_GUA'),
 'São Sebastião ⇄ Ilhabela':('São Sebastião/Ilhabela','VOL SS_IB'),'Cananéia ⇄ Continente':('Cananéia/Continente','VOL CA_CON'),'Cananéia ⇄ Ilha Comprida':('Cananéia/Ilha Comprida','VOL CA_ILH'),
 'Iguape ⇄ Juréia':('Iguape/Juréia','VOL IG_JUR'),'Cananéia ⇄ Marujá ⇄ Ariri':('Cananéia/Ariri',None),'Natividade':('Natividade da Serra/B. Natividade da Serra',None),'Paraitinga':('Ribeirão Branco/Capim DAngola',None),'Varginha':('Comércio/Varginha',None)}
wb=openpyxl.load_workbook('Historico.xlsx',read_only=True,data_only=True)
def hist(sh,ym):
    for r in wb[sh].iter_rows(values_only=True):
        if hasattr(r[1],'year') and (r[1].year,r[1].month)==ym: return sum(x or 0 for x in r[2:10])
out=[]
for r in R.itertuples():
    k,sh=SH[r.lab]; h=H[H.trav==k]; a=A[A.trav==k]
    v25=len(h); w25=h.vol.sum(); p25=h.ped.sum()
    w26=a.vol.sum()/7
    n25=hist(sh,(2025,11))/30 if sh else None
    yoy=w26/n25 if n25 else None
    f=yoy if yoy else 1.0
    wp=w25*f if v25 else r.wfs
    out.append(dict(lab=r.lab,v25=v25,w25=w25,p25=p25,vpv25=w25/v25 if v25 else None,Q20=r.Q20,yoy=yoy,w26=w26,n25=n25,wp=wp,
        vneed=round(v25*f) if v25 else None,P20=r.P20, hp=(h.groupby('h').vol.sum()*f).round() if v25 else None))
O=pd.DataFrame(out)
H['vol2']=H.vol
hh=H.groupby(['trav','h']).vol.sum()
pickle.dump(dict(O=O,H=H,A=A,WOW=D['WOW']),open('res2.pkl','wb'))
pd.set_option('display.width',250)
print(O.drop(columns='hp').round(2)); print(O[['v25','w25','p25','Q20','w26','wp','P20']].sum())
print(H.groupby('h').vol.sum().to_dict())
