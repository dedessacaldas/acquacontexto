import sys, pickle, math, pandas as pd, numpy as np
sys.path.insert(0,'/mnt/project-files/relatorios-viagens/relatorio-diario/gerador')
from grades import grade
from datetime import datetime, timedelta
D=datetime(2026,11,20); td,S=grade(D)
X=pickle.load(open('res2.pkl','rb')); O=X['O']; H=X['H']; A=X['A']; W=X['WOW']; G=W['w16']/W['w09']
for d in (H,A): d['modo']=np.where(d.emb.astype(str).str.startswith('LS'),'Lancha','Ferry boat')
LAB={'Santos/Guarujá':'Santos ⇄ Guarujá','Santos/Vicente de Carvalho':'Santos ⇄ Vicente de Carvalho','Bertioga/Guarujá':'Bertioga ⇄ Guarujá','São Sebastião/Ilhabela':'São Sebastião ⇄ Ilhabela',
 'Cananéia/Continente':'Cananéia ⇄ Continente','Cananéia/Ilha Comprida':'Cananéia ⇄ Ilha Comprida','Iguape/Juréia':'Iguape ⇄ Juréia','Cananéia/Ariri':'Cananéia ⇄ Marujá ⇄ Ariri',
 'Natividade da Serra/B. Natividade da Serra':'Natividade','Ribeirão Branco/Capim DAngola':'Paraitinga','Comércio/Varginha':'Varginha'}
fac=dict(zip(O.lab,O.yoy.fillna(1)))
rows=[]; hrs=[]
for (t,m) in dict.fromkeys((k[0],k[1]) for k in S):
    lab=LAB[t]+(' · lancha' if t=='São Sebastião/Ilhabela' and m=='Lancha' else (' · balsa' if t=='São Sebastião/Ilhabela' else ''))
    gmin=np.zeros(24); reg=['']*24
    for (tt,mm,se),(fx,bd,mg) in S.items():
        if (tt,mm)!=(t,m): continue
        bst={a for a,b,i in bd}
        for s in fx:
            if s not in bst: gmin[s.hour]+=1
        for a,b,i in bd:
            b=b if b>a else b+timedelta(days=1)
            k=0
            while a+timedelta(minutes=i*k)<b:
                w=a+timedelta(minutes=i*k)
                if w.date()==D.date(): gmin[w.hour]+=1
                k+=1
        for h in range(24):
            hs=D+timedelta(hours=h)
            if any(a<=hs<(b if b>a else b+timedelta(days=1)) for a,b,i in bd): reg[h]='demanda'
            elif not reg[h]: reg[h]='fixo'
    a=A[(A.trav==t)&(A.modo==m)]
    cap=a.vol.quantile(.9) if len(a) else 0
    h25=H[(H.trav==t)&(H.modo==m)]
    if len(h25):
        dem=h25.groupby('h').vol.sum().reindex(range(24),fill_value=0).values*fac[LAB[t]]; v25=h25.groupby('h').size().reindex(range(24),fill_value=0).values; src='20/11/2025'
    else:
        b=a[a.dia=='15']; dem=b.groupby('h').vol.sum().reindex(range(24),fill_value=0).values; v25=np.full(24,np.nan); src='15/11/2026'
    for sc,mult in (('base',1),('alta',G)):
        d=dem*mult; needc=np.ceil(d/cap) if cap>0 else np.zeros(24)
        f2=(fac[LAB[t]] if src=='20/11/2025' else 1)*mult
        needd=np.round(v25*f2) if src=='20/11/2025' else needc   # faixa conforme demanda: mantém a ocupação de 20/11/2025
        need=np.where(np.array(reg)=='demanda',needd,needc)
        proj=np.where(np.array(reg)=='demanda',np.maximum(gmin,need),gmin)
        adic=np.where(np.array(reg)=='fixo',np.maximum(0,need-gmin),0)
        rows.append(dict(lab=lab,sc=sc,cap=cap,src=src,gmin=gmin.sum(),dem_h=int(sum(r=='demanda' for r in reg)),
            proj=proj.sum(),proj_dem=proj[np.array(reg)=='demanda'].sum(),gmin_dem=gmin[np.array(reg)=='demanda'].sum(),
            adic=adic.sum(),adic_h=[h for h in range(24) if adic[h]>0],vol=d.sum(),v25=np.nansum(v25),
            hot=[h for h in range(24) if reg[h]=='demanda' and need[h]>gmin[h]]))
        hrs.append(dict(lab=lab,sc=sc,reg=reg,gmin=gmin,need=need,proj=proj,adic=adic,dem=d))
R=pd.DataFrame(rows); pickle.dump(dict(R=R,HR=hrs,G=G),open('res3.pkl','wb'))
pd.set_option('display.width',260); pd.set_option('display.max_colwidth',40)
print(R.round(1).to_string())
print(R.groupby('sc')[['gmin','proj','adic','vol','v25']].sum())
