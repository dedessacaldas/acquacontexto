import pickle, pandas as pd
Z=pickle.load(open('res3.pkl','rb')); RR=Z['R']; RR['tot']=RR.proj+RR.adic
D=pickle.load(open('res2.pkl','rb')); O=D['O']; H=D['H']; A=D['A']; W=D['WOW']
G=W['w16']/W['w09']; GV=W['v16']/W['v09']
n0=lambda x:'–' if x is None or pd.isna(x) else f'{x:,.0f}'.replace(',','.')
pc=lambda x:'–' if x is None or pd.isna(x) else (f'{(x-1)*100:+.1f}%').replace('.',',')
d1=lambda x:'–' if x is None or pd.isna(x) else f'{x:.1f}'.replace('.',',')
O['wa']=O.wp*G; O['vpv']=O.wp/O.P20.where(O.P20>0)
O['vpva']=O.wa/O.P20.where(O.P20>0)
T=O[['v25','w25','p25','Q20','P20','wp','wa']].sum()
TB=RR[RR.sc=='base'].tot.sum(); TA=RR[RR.sc=='alta'].tot.sum()
rows=''
for r in O.itertuples():
    rows+=(f'<tr><td class=m>{r.lab}</td><td class=r>{n0(r.v25) if r.v25 else "–"}</td><td class=r>{n0(r.w25) if r.v25 else "–"}</td><td class=r>{d1(r.vpv25)}</td>'
           f'<td class="r g">{pc(r.yoy)}</td><td class=r>{n0(r.Q20)}</td><td class="r b">{n0(r.P20)}</td><td class="r b">{n0(r.wp)}</td><td class=r>{n0(r.wa)}</td><td class=r>{d1(r.vpva)}</td></tr>')
rows+=(f'<tr class=tot><td class=m>Total</td><td class=r>{n0(T.v25)}</td><td class=r>{n0(T.w25)}</td><td class=r>{d1(T.w25/T.v25)}</td><td class=r>{pc(O.w26[O.n25.notna()].sum()/O.n25.sum())}</td>'
       f'<td class=r>{n0(T.Q20)}</td><td class=r>{n0(T.P20)}</td><td class=r>{n0(T.wp)}</td><td class=r>{n0(T.wa)}</td><td class=r>{d1(T.wa/T.P20)}</td></tr>')
# por hora: 2025 x fator de cada travessia
f=dict(zip(O.lab,O.yoy.fillna(1)))
K={'Santos/Guarujá':'Santos ⇄ Guarujá','Santos/Vicente de Carvalho':'Santos ⇄ Vicente de Carvalho','Bertioga/Guarujá':'Bertioga ⇄ Guarujá','São Sebastião/Ilhabela':'São Sebastião ⇄ Ilhabela','Cananéia/Continente':'Cananéia ⇄ Continente','Cananéia/Ilha Comprida':'Cananéia ⇄ Ilha Comprida','Iguape/Juréia':'Iguape ⇄ Juréia','Cananéia/Ariri':'Cananéia ⇄ Marujá ⇄ Ariri'}
H['wp']=H.vol*H.trav.map(lambda t:f[K[t]])
hb=H.groupby('h').wp.sum().reindex(range(24),fill_value=0); hv=H.groupby('h').size().reindex(range(24),fill_value=0)
hs=H[H.trav=='Santos/Guarujá'].groupby('h').wp.sum().reindex(range(24),fill_value=0)
Wd,Hh,L,B=740,150,34,18; mx=max(hb*G)*1.1; bw=(Wd-L-10)/24
s=[f'<svg viewBox="0 0 {Wd} {Hh}" style="width:100%">']
for y in range(0,int(mx)+1,500):
    yy=Hh-B-(Hh-B-10)*y/mx; s.append(f'<line x1={L} x2={Wd-6} y1={yy:.1f} y2={yy:.1f} stroke="#E3ECF0" stroke-width=.6 /><text x={L-4} y={yy+3:.1f} font-size=7 fill="#5E7480" text-anchor=end>{n0(y)}</text>')
for h in range(24):
    x=L+h*bw+bw*.12; w=bw*.76
    ya=(Hh-B-10)*hb[h]*G/mx; yb=(Hh-B-10)*hb[h]/mx; ys=(Hh-B-10)*hs[h]/mx
    s.append(f'<rect x={x:.1f} y={Hh-B-ya:.1f} width={w:.1f} height={ya-yb:.1f} fill="#B7DCE6" rx=1 />')
    s.append(f'<rect x={x:.1f} y={Hh-B-yb:.1f} width={w:.1f} height={yb:.1f} fill="#005B7F" rx=1 />')
    s.append(f'<rect x={x+w*.3:.1f} y={Hh-B-ys:.1f} width={w*.4:.1f} height={ys:.1f} fill="#00B5AD" />')
    s.append(f'<text x={x+w/2:.1f} y={Hh-5} font-size=7 fill="#5E7480" text-anchor=middle>{h:02d}h</text>')
s.append('</svg>'); chart=''.join(s)
top=hb.sort_values(ascending=False).head(4).index.sort_values()
pico=', '.join(f'{h:02d}h' for h in top)
sgr=O.set_index('lab').loc['Santos ⇄ Guarujá']
hl=lambda L:', '.join(f'{h:02d}h' for h in L) if L else '–'
rg=''
for lab,g in RR.groupby('lab',sort=False):
    b=g[g.sc=='base'].iloc[0]; a=g[g.sc=='alta'].iloc[0]
    regt=('conforme demanda '+str(b.dem_h)+'h/dia' if b.dem_h else 'horário fixo')
    rg+=(f'<tr><td class=m>{lab}</td><td>{regt}</td><td class=r>{n0(b.v25) if b.src=="20/11/2025" else "–"}</td><td class=r>{n0(b.gmin)}</td>'
         f'<td class=r>{n0(b.proj_dem) if b.dem_h else "–"}</td><td class=r>{n0(a.proj_dem) if b.dem_h else "–"}</td>'
         f'<td class=r>{n0(b.adic) if b.adic else "–"}</td><td class=r>{n0(a.adic) if a.adic else "–"}</td><td class="r b">{n0(b.tot)}</td><td class=r>{n0(a.tot)}</td>'
         f'<td class=hh>{hl(a.hot if b.dem_h else a.adic_h)}</td></tr>')
B=RR[RR.sc=='base']; Aa=RR[RR.sc=='alta']
rg+=(f'<tr class=tot><td class=m>Total</td><td></td><td class=r>{n0(B[B.src=="20/11/2025"].v25.sum())}</td><td class=r>{n0(B.gmin.sum())}</td><td class=r>{n0(B.proj_dem.sum())}</td><td class=r>{n0(Aa.proj_dem.sum())}</td>'
     f'<td class=r>{n0(B.adic.sum())}</td><td class=r>{n0(Aa.adic.sum())}</td><td class=r>{n0(TB)}</td><td class=r>{n0(TA)}</td><td></td></tr>')
css=open('/mnt/project-files/relatorios-viagens/relatorio-financeiro/gerador/base.css').read()+'''
.kp{grid-template-columns:repeat(6,1fr)} .pb{break-before:page} td.hh{font-size:6.6pt;color:#5E7480;white-space:normal;max-width:45mm} table.t{width:100%;border-collapse:collapse;font-size:7.6pt;margin:1mm 0 2mm}
table.t th{background:#005B7F;color:#fff;font-size:6.6pt;font-weight:700;padding:1.2mm 1.4mm;text-align:left;vertical-align:bottom}
table.t th.r,table.t td.r{text-align:right} table.t td{padding:1.1mm 1.4mm;border-bottom:.2mm solid #E3ECF0}
table.t td.m{font-weight:700;color:#005B7F} table.t td.b{font-weight:900;color:#003A52;background:#EEF6F8} table.t td.g{color:#00968F;font-weight:700}
table.t tr.tot td{background:#005B7F;color:#fff;font-weight:900;border:none} table.t th.grp{background:#003A52;text-align:center}
.leg{font-size:7pt;color:#5E7480;margin:1mm 0} .leg i{display:inline-block;width:3mm;height:3mm;border-radius:.6mm;vertical-align:-.5mm;margin:0 1mm 0 3mm}
ul.o{margin:1mm 0 0 4mm;padding:0;font-size:7.8pt} ul.o li{margin-bottom:1mm} .crit{font-size:7pt;color:#3A5260}
h2 .n{display:inline-block;background:#00B5AD;color:#fff;border-radius:50%;width:6mm;height:6mm;text-align:center;line-height:6mm;font-size:9pt;margin-right:2mm}'''
html=f'''<!doctype html><html lang=pt-BR><head><meta charset=utf-8><title>Projeção 20/11/2026</title><base href="file:///mnt/project-files/relatorios-viagens/relatorio-financeiro/gerador/"><style>{css}</style></head><body>
<div class=hero><div class=pat></div><div class=eb>Projeção de viagens e demanda</div><h1>20/11/2026 · sexta-feira, feriado</h1>
<div class=per>Base: 20/11/2025 (quinta-feira, feriado) · ajustada pela demanda realizada de 09 a 16/11/2026</div><div class=w></div></div>
<div class=kp><div>Viagens pela demanda<b>{n0(TB)}</b>até {n0(TA)} na alta · quantitativo {n0(T.Q20)} · 2025: {n0(T.v25)}</div>
<div>Veículos e bicicletas<b>{n0(T.wp)}</b>cenário base · 2025: {n0(T.w25)}</div>
<div>Cenário de alta<b>{n0(T.wa)}</b>{pc(G)} sobre o base</div>
<div>Veículos por viagem<b>{d1(T.wp/T.P20)}</b>até {d1(T.wa/T.P20)} na alta · 2025: {d1(T.w25/T.v25)}</div>
<div>Santos ⇄ Guarujá<b>{n0(sgr.wp)}</b>veículos e bic. · {n0(sgr.P20)} viagens</div>
<div>Horas de pico<b style="font-size:12pt">{pico}</b>pelo perfil de 20/11/2025</div></div>
<h2><span class=n>1</span>Projeção por travessia</h2>
<table class=t><tr><th rowspan=2>Travessia</th><th colspan=3 class=grp>20/11/2025 (realizado)</th><th rowspan=2 class=r>Demanda 2026<br>× nov/2025</th><th colspan=5 class=grp>20/11/2026 (projeção)</th></tr>
<tr><th class=r>Viagens</th><th class=r>Veículos e bic.</th><th class=r>Veíc./viagem</th><th class=r>Quantitativo</th><th class=r>Viagens</th><th class=r>Veículos e bic. (base)</th><th class=r>Alta</th><th class=r>Veíc./viagem (alta)</th></tr>{rows}</table>
<h2><span class=n>2</span>Demanda por hora (todas as travessias)</h2>
<div class=leg><i style="background:#005B7F"></i>cenário base <i style="background:#B7DCE6"></i>acréscimo do cenário de alta <i style="background:#00B5AD"></i>Santos ⇄ Guarujá (base)</div>
{chart}
<h2><span class=n>3</span>Leitura</h2><ul class=o>
<li><b>Viagens:</b> pela demanda e pelo regime da grade, {n0(TB)} viagens no cenário base e {n0(TA)} no de alta (detalhe na página 2); o quantitativo de feriado é {n0(T.Q20)}. Em 20/11/2025 foram {n0(T.v25)} viagens nas travessias que já operavam; a diferença vem de Natividade, Paraitinga e Varginha, que passaram a contar em 2026.</li>
<li><b>Demanda:</b> no cenário base, {n0(T.wp)} veículos e bicicletas, próximo de 2025 ({n0(T.w25)}): a demanda de 09 a 15/11/2026 está {pc(O.w26[O.n25.notna()].sum()/O.n25.sum())} sobre a média diária de nov/2025 nas travessias com histórico. No cenário de alta, que repete o crescimento de Santos ⇄ Guarujá de 09/11 para 16/11 ({pc(G)} em veículos, comparando até as 16h), a demanda chega a {n0(T.wa)}.</li>
<li><b>Pressão sobre a oferta:</b> com as mesmas viagens, o cenário de alta leva a {d1(T.wa/T.P20)} veículos por viagem (2025: {d1(T.w25/T.v25)}). Os picos esperados são às {pico}.</li>
<li><b>Pedestres:</b> 20/11/2025 registrou {n0(T.p25)} pedestres; os registros de 2026 quase não trazem pedestres em Santos ⇄ Guarujá, então eles ficam fora da projeção.</li></ul>
<p class=crit><b>Critérios.</b> Viagens: quantitativo de feriado de cada travessia × cumprimento observado em 14 e 15/11/2026 (limitado a 115%). Demanda base: veículos e bicicletas de 20/11/2025 × (média diária de 09 a 15/11/2026 ÷ média diária de nov/2025) de cada travessia; sem histórico, média de 14 e 15/11/2026. Cenário de alta: base × variação de Santos ⇄ Guarujá entre 09/11 e 16/11 até as 16h. Perfil por hora: o de 20/11/2025.</p>
<div class=pb></div>
<h2><span class=n>4</span>Viagens pelo regime da grade de feriado</h2>
<p class=crit>Nas faixas <b>conforme demanda</b>, as viagens acompanham a demanda projetada mantendo a ocupação de 20/11/2025 em cada hora (nunca abaixo do mínimo da grade). Nos períodos de <b>horário fixo</b>, a grade é mantida e, quando a demanda de uma hora passa do que as saídas da grade levam (lotação alta = 90% das viagens de 09 a 15/11/2026 levaram até esse número de veículos e bicicletas), aparecem <b>viagens adicionais</b>. Travessias sem 2025 usam o perfil de 15/11/2026.</p>
<table class=t><tr><th rowspan=2>Travessia</th><th rowspan=2>Regime na grade de feriado</th><th rowspan=2 class=r>Viagens<br>20/11/2025</th><th rowspan=2 class=r>Mínimo<br>da grade</th><th colspan=2 class=grp>Conforme demanda</th><th colspan=2 class=grp>Adicionais em horário fixo</th><th colspan=2 class=grp>Total projetado</th><th rowspan=2>Horas que pedem mais saídas (alta)</th></tr>
<tr><th class=r>Base</th><th class=r>Alta</th><th class=r>Base</th><th class=r>Alta</th><th class=r>Base</th><th class=r>Alta</th></tr>{rg}</table>
<ul class=o>
<li><b>Conforme demanda:</b> Santos ⇄ Guarujá e a balsa de São Sebastião ⇄ Ilhabela concentram o ajuste. Em Santos ⇄ Guarujá, a demanda pede {n0(B[B.lab=="Santos ⇄ Guarujá"].proj_dem.sum())} a {n0(Aa[Aa.lab=="Santos ⇄ Guarujá"].proj_dem.sum())} saídas das 05h30 às 24h, contra o mínimo de {n0(B[B.lab=="Santos ⇄ Guarujá"].gmin_dem.sum())} da grade.</li>
<li><b>Horário fixo com demanda alta:</b> Cananéia ⇄ Ilha Comprida ({n0(B[B.lab=="Cananéia ⇄ Ilha Comprida"].adic.sum())}–{n0(Aa[Aa.lab=="Cananéia ⇄ Ilha Comprida"].adic.sum())} adicionais), Iguape ⇄ Juréia ({n0(B[B.lab=="Iguape ⇄ Juréia"].adic.sum())}–{n0(Aa[Aa.lab=="Iguape ⇄ Juréia"].adic.sum())}) e Cananéia ⇄ Continente ({n0(B[B.lab=="Cananéia ⇄ Continente"].adic.sum())}–{n0(Aa[Aa.lab=="Cananéia ⇄ Continente"].adic.sum())}) devem precisar de saídas extras entre 09h e 19h; Bertioga ⇄ Guarujá só no fim da tarde no cenário de alta.</li>
<li><b>Madrugada em Santos ⇄ Guarujá:</b> entre 00h e 05h a grade é de horário fixo a cada 30 min; o perfil de 2025 indica {n0(B[B.lab=="Santos ⇄ Guarujá"].adic.sum())} a {n0(Aa[Aa.lab=="Santos ⇄ Guarujá"].adic.sum())} adicionais nesse período.</li>
<li>Adicionais em horário fixo entram na receita como (B) se passarem do projetado; nas faixas conforme demanda, contam como (A).</li></ul>
</body></html>'''
open('pagina.html','w').write(html)
print(T.to_dict(), G, pico)
