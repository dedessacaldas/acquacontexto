"""Classifica as ocorrências 09–18/11 pelos incisos do Anexo 8 item 2.6, lendo Tipo e Comentário (pedido da Dedessa, 19/11/2026)."""
import pandas as pd, re, pickle
O = pd.read_excel('Ocorrencias_NOV26_09a18.xlsx')
O.columns = ['trav', 'ref', 'tipo', 'com', 'para', 'ini', 'fim', 'emb', 'margem', 'user']
O['com'] = O.com.fillna('').astype(str).str.replace(r'\s+', ' ', regex=True).str.strip()
O['tipo'] = O.tipo.fillna('(sem tipo)')
# inciso que o TIPO do DRIVE indica (tabela de correlação da Dedessa)
TIPO_INC = {'Maré': 'i', 'Ventos Fortes': 'i', 'Vento': 'i', 'Neblina': 'i', 'Chuva Intensa': 'i', 'Passagem de Navio': 'ii',
            'Derramamento de Combustível': 'iii', 'Queda ao Mar': 'iii', 'Infraestrutura': 'iv', 'Trabalhos': 'iv', 'Problema com a Doca': 'v', 'Problema com Atracadouro': 'v'}
def has(c, *ws): return any(w in c for w in ws)
def classe(r):
    c = r.com.lower(); t = r.tipo
    # 1) problema do DRIVE / sistema de registro: não é ocorrência operacional
    if has(c, 'tablet', 'drive', 'login', 'aparecendo o tempo'): return ('DRIVE', '', 'Falha do DRIVE (tablet, tela ou login)')
    # 2) outras finalidades (não são expurgo)
    if has(c, 'pedágio', 'pedagio', 'máquina de cartão', 'maquina de cartão', 'maquina de cartao', 'máquina de débito', 'maquina de debito', 'cobrança'): return ('NC', '', 'Falha no sistema de cobrança (pedágio)')
    if has(c, 'pmv'): return ('NC', '', 'Aviso de painéis (PMV) inoperantes')
    if t == 'Acidente de Trabalho': return ('NC', '', 'Acidente de trabalho (sem inciso)')
    if has(c, 'especial', 'ambulância', 'ambulancia', 'caminhão do gás', 'caminhao do gas', 'coletora'): return ('NC', '', 'Viagem especial')
    if has(c, 'emergência', 'emergencia', 'mal súbito', 'mal subito', 'samu') or t == 'Mal Súbito do Usuário': return ('NC', '', 'Emergência / atendimento a usuário')
    if has(c, 'demanda', 'fluxo', 'unilateral', 'vazia', 'trocando de margem', 'troca de margem', 'antes do horário', 'antes do horario', 'antecipad', 'antes do tempo'):
        if not has(c, 'navio', 'draga', 'maré', 'vento'): return ('NC', '', 'Ajuste de operação por demanda (saída antecipada, troca de margem)')
    if has(c, 'abastecimento') and t in ('Problema com a Doca', 'Problema com Atracadouro'): return ('NC', '', 'Gaveta interditada para abastecimento')
    # 3) incisos pelo comentário
    if has(c, 'navio', 'draga', 'batelão', 'batelao', 'segurança da navegação', 'passagem de rede'): return ('EL', 'ii', 'Passagem de navio / draga / segurança da navegação')
    if has(c, 'maré', 'mare ', 'mare.', 'vento', 'neblina', 'chuva', 'ressaca', 'temporal'): return ('EL', 'i', 'Evento climático / maré')
    if has(c, 'detrito', 'lixo no mar', 'enrosc', 'hélice', 'helice', 'tronco', 'rede de pesca'): return ('EL', 'iii', 'Avaria por detrito / lixo no mar')
    if t in ('Problema com a Doca', 'Problema com Atracadouro'):
        if has(c, 'reparo', 'troca', 'retirada', 'manutenç', 'manutenc', 'verificar'): return ('EL', 'v', 'Manutenção de flutuante / gaveta (condicionada a comunicação prévia)')
        if has(c, 'carro', 'veículo', 'veiculo'): return ('NC', '', 'Veículo de usuário parado no flutuante')
        return ('NC', '', 'Falha corretiva em gaveta / ponteira (não é manutenção programada)')
    if t == 'Derramamento de Combustível': return ('NC', '', 'Derramamento por veículo de usuário (não é avaria por detrito)')
    if has(c, 'aquec', 'máquina', 'motor', 'mcp'): return ('NC', '', 'Problema mecânico da embarcação (não é inciso)')
    # 4) sem comentário: vale o tipo
    if not c and t in TIPO_INC: return ('EL', TIPO_INC[t], 'Pelo tipo (sem comentário)')
    if t in TIPO_INC and t not in ('Derramamento de Combustível',): return ('EL', TIPO_INC[t], 'Pelo tipo')
    return ('NC', '', 'Outra finalidade / sem relação com inciso')
X = O.apply(classe, axis=1, result_type='expand'); O['cl'], O['inc'], O['mot'] = X[0], X[1], X[2]
O['tipo_inc'] = O.tipo.map(TIPO_INC).fillna('')
# desvios de registro
dur = (O.fim - O.ini).dt.total_seconds() / 60
O['dur'] = dur
def desv(r):
    d = []
    if not r.com: d.append('Sem comentário')
    if r.tipo == '(sem tipo)': d.append('Sem tipo')
    if r.cl == 'EL' and r.tipo_inc != r.inc: d.append(f'Tipo "{r.tipo}" não corresponde ao comentário (inciso {r.inc})')
    if r.cl == 'NC' and r.tipo_inc: d.append(f'Tipo "{r.tipo}" (inciso {r.tipo_inc}) para evento que não é desse inciso')
    if r.cl == 'DRIVE': d.append('Problema do DRIVE registrado como ocorrência')
    if pd.isna(r.fim): d.append('Sem data final')
    elif r.dur <= 0: d.append('Data final igual ou anterior à inicial')
    elif r.dur > 360: d.append(f'Duração de {r.dur / 60:.0f} h')
    if not isinstance(r.emb, str) and (r.tipo == 'Ocorrência com Embarcação' or re.search(r'\bfb[- ]?\w+|\bls[- ]?\w+', r.com.lower())): d.append('Sem embarcação')
    if not isinstance(r.margem, str): d.append('Sem margem')
    if r.para == 'Sim' and r.cl != 'EL': d.append('Marcada como paralisação sem motivo de inciso')
    return d
O['desv'] = O.apply(desv, axis=1)
# duplicadas: mesma travessia e tipo, início a menos de 3 min
O = O.sort_values(['trav', 'tipo', 'ini']).reset_index(drop=True)
dup = (O.trav == O.trav.shift()) & (O.tipo == O.tipo.shift()) & ((O.ini - O.ini.shift()).dt.total_seconds() < 180)
for i in O.index[dup]: O.at[i, 'desv'] = O.at[i, 'desv'] + ['Possível duplicada (mesmo tipo, menos de 3 min)']
O = O.sort_values('ini').reset_index(drop=True)
pickle.dump(O, open('ocorr_class.pkl', 'wb'))
pd.set_option('display.width', 250)
print(O.cl.value_counts().to_dict()); print(O.groupby(['cl', 'inc', 'mot']).size().to_string())
print(pd.crosstab(O.tipo, O.cl))
from collections import Counter
print(Counter(re.sub(r'".*?"', '"X"', x) for d in O.desv for x in d).most_common())
