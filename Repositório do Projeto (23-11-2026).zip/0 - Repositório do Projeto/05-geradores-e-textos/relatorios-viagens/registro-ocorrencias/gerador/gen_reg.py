import pickle, re, html as H, pandas as pd
from collections import Counter
O = pickle.load(open('ocorr_class.pkl', 'rb'))
n0 = lambda x: f'{x:,.0f}'.replace(',', '.')
pc = lambda a, b: f'{100 * a / b:.0f}%' if b else '–'
e = lambda s: H.escape(str(s))
N = len(O); EL = O[O.cl == 'EL']; NC = O[O.cl == 'NC']; DR = O[O.cl == 'DRIVE']
INC = {'i': 'i · clima e maré', 'ii': 'ii · navio, draga, segurança da navegação', 'iii': 'iii · avaria por detrito', 'iv': 'iv · obras', 'v': 'v · manutenção de flutuante'}
def dk(x): return re.sub(r'".*?"', '', x).replace('  ', ' ')
O['desv2'] = O.desv.apply(lambda d: [x for x in d if x != 'Sem margem'])
ND = (O.desv2.str.len() > 0).sum()
# KPIs
kp = (f'<div class="kp k6"><div>Ocorrências registradas<b>{n0(N)}</b>09 a 18/11</div>'
      f'<div class=ok>Consideradas no expurgo<b>{n0(len(EL))}</b>{pc(len(EL), N)} · incisos i a v</div>'
      f'<div class=at>Outras finalidades<b>{n0(len(NC))}</b>{pc(len(NC), N)} · não entram no expurgo</div>'
      f'<div class=cr>Problema do DRIVE<b>{n0(len(DR))}</b>não deveriam ser ocorrência</div>'
      f'<div class=cr>Com desvio de registro<b>{n0(ND)}</b>{pc(ND, N)} · sem contar margem</div>'
      f'<div class=at>Sem margem<b>{pc(O.margem.isna().sum(), N)}</b>{n0(O.margem.isna().sum())} registros</div></div>')
# 1) tipo × classificação
cols = [('i', 'i'), ('ii', 'ii'), ('iii', 'iii'), ('v', 'v'), ('NC', 'Outras finalidades'), ('DRIVE', 'DRIVE')]
def cnt(g, k): return (g.inc == k).sum() if k in ('i', 'ii', 'iii', 'v') else (g.cl == k).sum()
rows = ''
for t, g in sorted(O.groupby('tipo'), key=lambda x: -len(x[1])):
    rows += f'<tr><td class=m>{e(t)}</td><td class=r><b>{n0(len(g))}</b></td>' + ''.join(f'<td class="r {"z" if not cnt(g, k) else ("nc" if k in ("NC", "DRIVE") else "el")}">{n0(cnt(g, k)) if cnt(g, k) else "–"}</td>' for k, _ in cols) + '</tr>'
rows += f'<tr class=tot><td>Total</td><td class=r>{n0(N)}</td>' + ''.join(f'<td class=r>{n0(cnt(O, k))}</td>' for k, _ in cols) + '</tr>'
tab1 = ('<table class="t hm cl"><tr><th>Tipo registrado no DRIVE</th><th class=r>Registros</th>' + ''.join(f'<th class=r>{"Inciso " + l if k in ("i","ii","iii","v") else l}</th>' for k, l in cols) + f'</tr>{rows}</table>')
# 2) desvios de registro
DES = Counter(dk(x) for d in O.desv for x in d)
DEXPL = {'Sem margem': 'Campo Margem vazio: não dá para saber em que ponta o evento aconteceu.',
         'Sem comentário': 'Sem descrição do evento; sem ela não há como provar o nexo com o atraso (Anexo 8, 2.6.1).',
         'Possível duplicada (mesmo tipo, menos de 3 min)': 'Mesmo evento lançado duas vezes (mesma travessia e tipo, com menos de 3 min de diferença).',
         'Tipo não corresponde ao comentário (inciso ii)': 'O comentário descreve passagem de navio, mas o tipo marcado é outro (quase sempre "Ocorrência com Embarcação").',
         'Tipo não corresponde ao comentário (inciso i)': 'O comentário descreve maré ou vento, mas o tipo marcado é outro.',
         'Tipo não corresponde ao comentário (inciso iii)': 'O comentário descreve rede de pesca ou detrito, mas o tipo marcado é outro.',
         'Tipo (inciso v) para evento que não é desse inciso': '"Problema com a Doca" usado para abastecimento, veículo parado ou falha de gaveta, que não são manutenção programada.',
         'Tipo (inciso iii) para evento que não é desse inciso': '"Derramamento de Combustível" para óleo derramado por veículo de usuário, que não é avaria por detrito.',
         'Data final igual ou anterior à inicial': 'Horário final igual ou anterior ao inicial.',
         'Sem data final': 'Ocorrência sem horário de término.',
         'Sem embarcação': 'Evento de embarcação sem o campo Embarcação preenchido.',
         'Problema do DRIVE registrado como ocorrência': 'Falha do sistema lançada como ocorrência operacional (seção 5).',
         'Marcada como paralisação sem motivo de inciso': 'Campo Paralisar = Sim em evento sem inciso.'}
dur = sum(v for k, v in DES.items() if k.startswith('Duração'))
items = [(k, v) for k, v in DES.items() if not k.startswith('Duração')] + ([('Duração acima de 6 h', dur)] if dur else [])
DEXPL['Duração acima de 6 h'] = 'Ocorrência aberta por mais de 6 h (de 6 a 24 h), provavelmente não foi fechada quando o evento acabou.'
items.sort(key=lambda x: -x[1])
tab2 = '<table class="t hm ds"><tr><th>Desvio de registro</th><th class=r>Registros</th><th>O que significa</th></tr>' + ''.join(f'<tr><td class=m>{e(k)}</td><td class=r><b>{n0(v)}</b></td><td>{e(DEXPL.get(k, ""))}</td></tr>' for k, v in items) + '</table>'
# exemplos de tipo errado
mm = O[O.desv.apply(lambda d: any(x.startswith('Tipo ') for x in d))].copy()
mm['sug'] = mm.apply(lambda r: {'i': 'Maré / Vento', 'ii': 'Passagem de Navio', 'iii': 'Ocorrência com Embarcação (detrito) ou Passagem de Navio', 'v': 'Problema com Atracadouro'}.get(r.inc, 'tipo da finalidade real (não é inciso)'), axis=1)
ex = mm.groupby(['tipo', 'sug']).head(3).head(14)
tab2b = ('<table class="t hm sm"><tr><th>Data</th><th>Travessia</th><th>Tipo marcado</th><th>Comentário</th><th>Tipo adequado</th></tr>'
         + ''.join(f'<tr><td>{r.ini:%d/%m %H:%M}</td><td>{e(r.trav)}</td><td>{e(r.tipo)}</td><td class=oc>{e(r.com[:120])}{"…" if len(r.com) > 120 else ""}</td><td><b>{e(r.sug)}</b></td></tr>' for r in ex.itertuples()) + '</table>')
# 3) outras finalidades
g3 = NC.groupby('mot').agg(n=('ref', 'size'), ex=('com', lambda s: max(s, key=len)[:130]), tr=('trav', lambda s: ', '.join(f'{k} {v}' for k, v in s.value_counts().head(3).items()))).sort_values('n', ascending=False)
tab3 = ('<table class="t hm sm"><tr><th>Finalidade</th><th class=r>Registros</th><th>Onde mais aparece</th><th>Exemplo de comentário</th></tr>'
        + ''.join(f'<tr><td class=m>{e(k)}</td><td class=r><b>{n0(r.n)}</b></td><td>{e(r.tr)}</td><td class=oc>{e(r.ex)}…</td></tr>' for k, r in g3.iterrows()) + '</table>')
# 4) DRIVE
tab4 = ('<table class="t hm sm"><tr><th>Data</th><th>Travessia</th><th>Tipo marcado</th><th>Comentário</th></tr>'
        + ''.join(f'<tr><td>{r.ini:%d/%m %H:%M}</td><td>{e(r.trav)}</td><td>{e(r.tipo)}</td><td class=oc>{e(r.com)}</td></tr>' for r in DR.itertuples()) + '</table>')
# por travessia
pt = O.assign(d=O.desv2.str.len() > 0).groupby('trav').agg(n=('ref', 'size'), el=('cl', lambda s: (s == 'EL').sum()), nc=('cl', lambda s: (s == 'NC').sum()), dr=('cl', lambda s: (s == 'DRIVE').sum()), d=('d', 'sum')).sort_values('n', ascending=False)
tab5 = ('<table class="t hm sm"><tr><th>Travessia</th><th class=r>Registros</th><th class=r>Consideradas no expurgo</th><th class=r>Outras finalidades</th><th class=r>DRIVE</th><th class=r>Com desvio de registro</th></tr>'
        + ''.join(f'<tr><td class=m>{e(k)}</td><td class=r><b>{n0(r.n)}</b></td><td class=r>{n0(r.el)}</td><td class=r>{n0(r.nc)}</td><td class=r>{n0(r.dr) if r.dr else "–"}</td><td class=r>{n0(r.d)} ({pc(r.d, r.n)})</td></tr>' for k, r in pt.iterrows()) + '</table>')
incs = ' · '.join(f'{INC[k]}: <b>{n0((EL.inc == k).sum())}</b>' for k in INC if (EL.inc == k).sum())
body = f'''<div class=hero><div class=pat></div><div class=eb>Relatório · registro de ocorrências</div><h1>Ocorrências registradas no DRIVE · 09 a 18/11/2026</h1>
<div class=per>Classificação pelos incisos do Anexo 8, item 2.6 (tipo e comentário) · desvios de registro · ocorrências fora do expurgo · problemas do DRIVE</div><div class=w></div></div>
{kp}
<div class=obs><ul>
<li><b>{pc(len(EL), N)} dos registros podem ser usados no expurgo</b> ({incs}). Para isso, o tipo foi conferido com o comentário. A passagem de navio sozinha responde por {pc((EL.inc == "ii").sum(), len(EL))} deles.</li>
<li><b>{n0(len(NC))} ocorrências têm outra finalidade</b>, como saída antecipada por demanda, troca de margem, emergência, viagem especial, pedágio e abastecimento. Elas continuam úteis para a Operação, mas não entram no filtro dos indicadores.</li>
<li><b>{n0(len(DR))} registros são falhas do DRIVE</b> (tablet ou tela do CCO). Isso não é ocorrência operacional: deve ir para o suporte do sistema, e a viagem deve ser corrigida no lançamento.</li>
<li><b>Principais desvios:</b> {pc(O.margem.isna().sum(), N)} sem margem; {n0(DES["Sem comentário"])} sem comentário; {n0(sum(v for k, v in DES.items() if k.startswith("Tipo ")))} com o tipo diferente do que o comentário descreve; {n0(DES.get("Possível duplicada (mesmo tipo, menos de 3 min)", 0))} possíveis duplicadas; {n0(dur + DES.get("Data final igual ou anterior à inicial", 0) + DES.get("Sem data final", 0))} com horário final inválido ou aberto por mais de 6 h.</li></ul></div>
<h2><span class=n>1</span>Tipo registrado × inciso do expurgo</h2>
<div class=cap>Cada registro foi classificado pelo tipo e conferido pelo comentário. Conta como inciso só o que o Anexo 8, item 2.6, permite (i a v). O inciso vi depende de aceite da ARTESP e não entra no filtro.</div>
{tab1}
<h2><span class=n>2</span>Por travessia</h2>{tab5}
<div class=pb></div>
<h2><span class=n>3</span>Desvios de registro</h2>{tab2}
<h3>Tipo marcado diferente do que o comentário descreve (exemplos)</h3>{tab2b}
<h2><span class=n>4</span>Ocorrências que não entram no expurgo</h2>
<div class=cap>São registros com outras finalidades. Devem continuar sendo lançados, se a Operação precisar deles, mas não justificam atraso nem viagem não realizada nos indicadores.</div>{tab3}
<h2><span class=n>5</span>Problemas do DRIVE registrados como ocorrência</h2>
<div class=cap>Falha do sistema não é ocorrência operacional. O caminho é abrir chamado no suporte do DRIVE e corrigir o horário da viagem no lançamento.</div>{tab4}
<h2><span class=n>6</span>O que ajustar no registro</h2><div class=obs><ul>
<li><b>Usar o tipo do que aconteceu:</b> passagem de navio em "Passagem de Navio" e maré ou vento em "Maré" ou "Ventos Fortes", e não em "Ocorrência com Embarcação".</li>
<li><b>Sempre preencher Comentário, Margem e Embarcação.</b> Sem comentário não há como provar o nexo com o atraso (item 2.6.1).</li>
<li><b>Fechar a ocorrência quando o evento acabar</b> e conferir o horário final antes de salvar.</li>
<li><b>Não lançar a mesma ocorrência duas vezes.</b></li>
<li><b>"Problema com a Doca" só para manutenção ou obra no flutuante.</b> Gaveta fechada para abastecimento não é inciso v. Manutenção programada precisa de comunicação prévia à ARTESP.</li>
<li><b>Falhas do DRIVE ou do pedágio</b> vão para o suporte, e não para ocorrência com tipo de inciso.</li></ul></div>
<h3>Critérios</h3><ol class=crit><li>Base: export de ocorrências do DRIVE de 09/11 00:10 a 18/11 23:43, com {n0(N)} registros.</li>
<li>Incisos (Anexo 8, item 2.6): i eventos climáticos (neblina, vento, ressaca; maré pela tabela de tipos do DRIVE); ii normas de navegação, como a preferência para passagem de embarcações; iii avarias por detritos e lixo no mar; iv obras de melhoria comunicadas; v manutenção programada de pontes e flutuantes comunicada; vi demais casos, a critério da ARTESP.</li>
<li>Leitura do comentário: as palavras do texto definem o inciso. Exemplos: "navio", "draga" e "batelão" = ii; "maré", "vento" e "neblina" = i; "rede de pesca" e "detrito" = iii; "demanda", "antes do horário", "emergência", "viagem especial", "pedágio" e "abastecimento" = outra finalidade; "tablet", "DRIVE" e "login" = problema do DRIVE. Sem comentário, vale o tipo.</li>
<li>Possível duplicada: mesma travessia e tipo, com início a menos de 3 min da anterior.</li></ol>'''
css = open('../../relatorio-financeiro/gerador/base.css').read() + '''
.k6{grid-template-columns:repeat(6,1fr)!important;gap:2mm;margin-bottom:3mm} .k6 div{font-size:6.4pt;padding:1.6mm 2.2mm} .k6 b{font-size:13pt}
.kp div.ok{border-left:1.2mm solid #00A79D} .kp div.at{border-left:1.2mm solid #E39B2D} .kp div.cr{border-left:1.2mm solid #C8553D}
.hero{padding:4mm 6mm 3.5mm;margin-bottom:3mm} .hero h1{font-size:17pt} h2{font-size:12pt;margin-top:3.5mm} h3{font-size:9pt;color:#005B7F;margin:2.5mm 0 1mm}
.obs{font-size:7.6pt} .obs li{margin:0 0 1mm} .cap{font-size:7pt;color:#5E7480;margin:0 0 1.2mm}
.cl td{font-size:7.4pt;padding:.7mm 1.4mm} .cl th{font-size:6.2pt} td.el{background:#E0F4F2;color:#00756F;font-weight:700} td.nc{background:#FCEFD9;color:#94600F;font-weight:700} td.z{color:#B7C6CD}
.ds td{font-size:7.2pt;padding:.8mm 1.4mm;vertical-align:top} .ds td.m{white-space:nowrap}
.sm td{font-size:6.9pt;padding:.6mm 1.3mm;vertical-align:top} .sm th{font-size:6pt} td.oc{font-size:6.6pt;color:#3A5260}
.crit{font-size:6.8pt} .pb{break-after:page} tr{break-inside:avoid} table{margin-bottom:1.5mm}'''
open('pagina_reg.html', 'w').write(f'<!doctype html><html lang=pt-BR><head><meta charset=utf-8><title>Ocorrências</title><base href="file:///mnt/project-files/relatorios-viagens/relatorio-financeiro/gerador/"><style>{css}</style></head><body>{body}</body></html>')
# planilha de apoio
X = O[['ini', 'fim', 'trav', 'ref', 'tipo', 'com', 'emb', 'margem', 'para', 'user']].copy()
X['Classificação'] = O.cl.map({'EL': 'Considerada no expurgo', 'NC': 'Outra finalidade', 'DRIVE': 'Problema do DRIVE'})
X['Inciso'] = O.inc; X['Motivo da classificação'] = O.mot; X['Desvios de registro'] = O.desv.apply('; '.join)
X.columns = ['Data inicial', 'Data final', 'Travessia', 'Referência', 'Tipo', 'Comentário', 'Embarcação', 'Margem', 'Paralisação', 'Usuário', 'Classificação', 'Inciso', 'Motivo da classificação', 'Desvios de registro']
X.to_excel('/mnt/project-files/relatorios-viagens/registro-ocorrencias/Ocorrências classificadas - 09 a 18-11-2026.xlsx', index=False)
print(N, len(EL), len(NC), len(DR), ND, items)
