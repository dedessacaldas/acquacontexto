# build.py res.pkl SAIDA_DIR  → diretoria.html, operacao.html, header_*.html
import pickle, base64, sys, os, pandas as pd
from datetime import timedelta
from grades import ORDER, NOME_DIA

R = pickle.load(open(sys.argv[1], 'rb')); OUT = sys.argv[2]
df, PROG, FX, BD, GP, D, TD, QT, CUT, FULL = (R[k] for k in ['df', 'PROG', 'FX', 'BD', 'GP', 'D', 'TD', 'QT', 'CUT', 'FULL'])
VA = 2314.05; VB = round(VA * 0.6, 2)          # multiplicadores de receita por viagem
TR = [(reg, t, m, l, q) for reg, it in ORDER for t, m, l, q in it]
SEM = ['Segunda-feira', 'Terça-feira', 'Quarta-feira', 'Quinta-feira', 'Sexta-feira', 'Sábado', 'Domingo'][D.weekday()]
DSTR = D.strftime('%d/%m/%Y')
PER = [('00h–05h', 0, 5), ('05h–07h', 5, 7), ('07h–09h', 7, 9), ('09h–12h', 9, 12), ('12h–16h', 12, 16), ('16h–19h', 16, 19), ('19h–24h', 19, 24)]
df['h'] = df.saida.dt.hour
PROG['h'] = PROG.hora.dt.hour

def n(x): return f'{int(round(x)):,}'.replace(',', '.')
def brl(x, cents=True):
    s = f'{x:,.2f}' if cents else f'{x:,.0f}'
    return 'R$ ' + s.replace(',', 'X').replace('.', ',').replace('X', '.')
def kbrl(x): return 'R$ ' + (f'{x/1e3:,.1f} mil' if x < 1e6 else f'{x/1e6:,.2f} mi').replace(',', 'X').replace('.', ',').replace('X', '.')
def pc(a, b, d=0): return '–' if not b else f'{100*a/b:.{d}f}%'.replace('.', ',')
def hm(t): return '' if pd.isna(t) else pd.Timestamp(t).strftime('%H:%M')
def sel(X, t, m): return X[(X.trav == t) & (X.modo == m)]
def margens(t, m):
    p = sel(PROG, t, m).margem.unique().tolist()
    for x in sel(df, t, m).margem.unique():
        if x not in p: p.append(x)
    return p[:2] + [None] * (2 - len(p[:2]))

def stats(t=None, m=None, mg=None, h0=None, h1=None):
    g = df if t is None else sel(df, t, m); p = PROG if t is None else sel(PROG, t, m)
    if mg is not None: g = g[g.margem == mg]; p = p[p.margem == mg]
    if h0 is not None: g = g[(g.h >= h0) & (g.h < h1)]; p = p[(p.h >= h0) & (p.h < h1)]
    prev = len(p); pend = int(p.real.isna().sum())
    a = int((g.cls == 'A').sum()); b = int((g.cls == 'B').sum())
    return dict(prev=prev, a=a, b=b, nr=prev - pend - a, pend=pend, tot=a + b)

T = stats()
# ---- acumulado do mês (ledger com o realizado de cada dia já processado) ----
LED = os.path.join(os.path.dirname(os.path.abspath(sys.argv[1])), 'acumulado.csv')
rows = [dict(data=D.strftime('%Y-%m-%d'), trav=l, realizadas=len(sel(df, t, m)), a=int((sel(df, t, m).cls == 'A').sum()), b=int((sel(df, t, m).cls == 'B').sum()), proj_dia=(lambda v: None if v is None or pd.isna(v) else float(v))(QT.get(q)) if QT else None, completo=bool(FULL)) for reg, it in ORDER for t, m, l, q in it]
led = pd.read_csv(LED) if os.path.exists(LED) else pd.DataFrame(columns=list(rows[0]))
led = pd.concat([led[led.data != D.strftime('%Y-%m-%d')], pd.DataFrame(rows)]).sort_values(['data']); led.to_csv(LED, index=False)
ml = led[(pd.to_datetime(led.data) >= (R['MES_INI'] or D.replace(day=1))) & (pd.to_datetime(led.data) <= D) & (pd.to_datetime(led.data).dt.month == D.month)]
ACC = dict(real=int(ml.realizadas.sum()), dias=ml.data.nunique(), proj_mes=sum(R['QTM'].get(q, 0) for *_, q in [x for x in [(t, m, l, q) for _, it in ORDER for t, m, l, q in it]]) if R['QTM'] else 0,
           proj_ate=sum(R['QTMD'].get(q, 0) for *_, q in [(t, m, l, q) for _, it in ORDER for t, m, l, q in it]) if R['QTMD'] else 0)
MESES = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro']
def acc_block():
    if not ACC['proj_mes']: return ''
    pm = ACC['real'] / ACC['proj_mes']; pa = ACC['real'] / ACC['proj_ate'] if ACC['proj_ate'] else 0
    ini = pd.Timestamp(R['MES_INI']).strftime('%d/%m'); fim = pd.Timestamp(R['MES_FIM']).strftime('%d/%m')
    return f'''<div class=acc><div class=acl><i>Acumulado de {MESES[D.month-1]}/{D.year} · {ini} a {DSTR[:5]} ({ACC["dias"]} {"dia" if ACC["dias"]==1 else "dias"})</i><b>{pc(ACC["real"], ACC["proj_mes"], 1)}</b> do fechamento do mês<small>{n(ACC["real"])} de {n(ACC["proj_mes"])} viagens projetadas para {ini} a {fim} · ritmo: {pc(ACC["real"], ACC["proj_ate"], 1)} do projetado até hoje ({n(ACC["proj_ate"])})</small></div>
<div class=acb><div class=acf style="width:{min(100, pm*100):.1f}%"></div><div class=acm style="left:{min(100, ACC["proj_ate"]/ACC["proj_mes"]*100):.1f}%"></div></div><div class=acx><span>0%</span><span>▲ projetado até {DSTR[:5]}</span><span>100% do mês</span></div></div>'''
def proj(q):
    v = QT.get(q)
    return None if v is None or pd.isna(v) else int(round(float(v)))
T['proj'] = sum(proj(q) or 0 for _, _, _, _, q in TR) if QT else None
PROJ_TXT = (f'{pc(T["tot"], T["proj"], 1)} da projeção ({n(T["proj"])})' if T['proj'] else '')
logo = base64.b64encode(open('horiz_c_white.png', 'rb').read()).decode()
CSS = open('base.css').read() + '''
.kp{grid-template-columns:repeat(5,1fr)}
.kp div.a{border-top-color:#005B7F}.kp div.b{border-top-color:#00B5AD}.kp div.rs{border-top-color:#008C86;background:#F4F8FA}
.kp small{display:block;font-size:6.6pt;color:#5E7480;margin-top:.4mm}
.mult{display:grid;grid-template-columns:1fr 1fr;gap:2.5mm;margin:0 0 4mm}
.mult div{border-radius:1.5mm;padding:2.2mm 3mm;color:#fff;font-size:7.4pt;line-height:1.3;display:flex;justify-content:space-between;align-items:center}
.mult div b{font-size:13pt;font-weight:900}
.mult .a{background:#005B7F}.mult .b{background:#00B5AD}
.mult span i{display:block;font-style:normal;font-size:6.4pt;opacity:.85;letter-spacing:.08em;text-transform:uppercase;font-weight:700}
.tag{display:inline-block;font-size:6.2pt;font-weight:900;border-radius:.8mm;padding:0 1.2mm;color:#fff;margin-right:1mm;letter-spacing:.04em}
.tag.a{background:#005B7F}.tag.b{background:#00B5AD}
.it td{text-align:right;white-space:nowrap}.it td.m,.it td.k{text-align:left}
.it tr.ra td{border-bottom:0;padding-bottom:.2mm}.it tr.rb td{padding-top:.2mm}
.it td{padding-top:.75mm;padding-bottom:.75mm}.it td small{font-size:6pt;color:#8AA0AA;margin-left:.4mm}.it td.miss small{color:#C0392B;font-weight:700}
.it tr.rb td:not(.m){color:#008C86}
.it th.pp{text-align:right}
.qt{font-size:7.2pt}.qt td{padding:.75mm 1.2mm}.qt th{padding:.9mm 1.2mm}.qt tr.tot .red{color:#FFD2CC}.qt th{text-align:right}.qt th:first-child{text-align:left}
.qt th.g{text-align:center;border-bottom:.3mm solid #9FB9C4;color:#005B7F;font-weight:900;letter-spacing:.04em}
.qt th.g.b{color:#008C86}
.qt td{text-align:right;white-space:nowrap}.qt td.m{text-align:left}
.qt td.m span{display:inline;margin-left:1.5mm;font-weight:400;color:#5E7480;font-size:6.4pt}
.qt td.s{background:#F4F8FA;font-weight:700}.qt td.sep{border-left:.3mm solid #D3E1E7}
.qt tr.st td{background:#E8F1F5;font-weight:700;color:#005B7F}
.qt tr.tot td.s{background:#004A68}
.hab th:first-child{width:47mm}.hab td.m{white-space:nowrap;overflow:hidden}
.box.b1{margin:0 0 4mm}.box.b1 div{padding:1.5mm 3mm}.box.b1 b{font-size:11pt}
.k6{grid-template-columns:repeat(6,1fr)}.k6 div.rv{background:#F4F8FA}.k6 div.rv b{font-size:10.5pt;line-height:1.6;white-space:nowrap;letter-spacing:-.01em}.k6 div.rv.b b{color:#008C86}.k6 div.rv.t{background:#005B7F;color:#CFE3EA;border-top-color:#00B5AD}.k6 div.rv.t b{color:#fff}
.acc{border:.3mm solid #D3E1E7;border-left:1.2mm solid #00B5AD;border-radius:1.5mm;padding:1.4mm 3.5mm;margin:0 0 3mm;display:grid;grid-template-columns:1.1fr 1fr;column-gap:5mm;align-items:center}.acc .acx{grid-column:2}
.acl{font-size:7.4pt;color:#5E7480}.acl i{display:block;font-style:normal;font-size:6.6pt;letter-spacing:.1em;text-transform:uppercase;font-weight:700;color:#008C86}
.acl b{font-size:13pt;font-weight:900;color:#005B7F;margin-right:1.5mm}.acl small{display:block;font-size:6.8pt;margin-top:.3mm}
.acb{position:relative;height:3mm;background:#E8F1F5;border-radius:1.5mm;grid-column:2;grid-row:1;align-self:end;margin-bottom:1mm}.acf{height:100%;background:linear-gradient(90deg,#005B7F,#00B5AD);border-radius:1.5mm}
.acm{position:absolute;top:-.8mm;width:.5mm;height:4.6mm;background:#C0392B}.acx{grid-row:1;align-self:start;margin-top:0!important;display:flex;justify-content:space-between;font-size:6pt;color:#8AA0AA;margin-top:.5mm}
.box{display:grid;grid-template-columns:repeat(3,1fr);gap:2.5mm;margin:3mm 0}
.box div{border:.3mm solid #D3E1E7;border-radius:1.5mm;padding:2mm 3mm;font-size:7pt;color:#5E7480}
.box b{display:block;font-size:12pt;font-weight:900;color:#005B7F}
.box div.b b{color:#008C86}.box div.nr b{color:#C0392B}
'''

def hero(tag, sub):
    rng = '00:00 às 23:59' if FULL else f'00:00 às {hm(CUT)} (dados parciais)'
    return f'''<div class=hero><div class=pat></div><div class=eb>{tag}</div><h1>{SEM}, {DSTR}</h1><div class=per>{sub} · {rng} · grade de {NOME_DIA[TD]} · {n(len(df))} viagens</div><div class=w></div></div>'''

# ---------- quadro por intervalo (página 1) ----------
def interval_table(show_nr=True):
    o = '<table class="t it"><thead><tr><th>Travessia</th><th></th>' + ''.join(f'<th class=pp>{p}</th>' for p, _, _ in PER) + '<th class=pp>Dia</th></tr></thead><tbody>'
    cur = None
    def cellA(s):
        cls = ' class=miss' if show_nr and s['nr'] > 0 else ''
        sm = f'<small>/{s["prev"]}</small>' if s['prev'] != s['a'] else ''
        return f'<td{cls}>{s["a"] if (s["a"] or s["prev"]) else "<span class=z>·</span>"}{sm}</td>'
    def cellB(s): return f'<td>{s["b"] if s["b"] else "<span class=z>·</span>"}</td>'
    for reg, t, m, l, q in TR:
        if reg != cur: o += f'<tr class=rg><td colspan=10>{reg}</td></tr>'; cur = reg
        ps = [stats(t, m, h0=a, h1=b) for _, a, b in PER]; dd = stats(t, m)
        o += f'<tr class=ra><td class=m>{l}</td><td class=k><span class="tag a">A</span></td>' + ''.join(cellA(s) for s in ps) + cellA(dd).replace('<td', '<td style="font-weight:900"', 1) + '</tr>'
        o += f'<tr class=rb><td class=m></td><td class=k><span class="tag b">B</span></td>' + ''.join(cellB(s) for s in ps) + cellB(dd).replace('<td', '<td style="font-weight:900"', 1) + '</tr>'
    ps = [stats(h0=a, h1=b) for _, a, b in PER]
    o += '<tr class=tot><td class=m>Total (A) obrigatórias</td><td></td>' + ''.join(f'<td>{s["a"]}<small style="color:#CFE3EA">/{s["prev"]}</small></td>' for s in ps) + f'<td>{T["a"]}<small style="color:#CFE3EA">/{T["prev"]}</small></td></tr>'
    o += '<tr class=tot><td class=m>Total (B) adicionais</td><td></td>' + ''.join(f'<td>{s["b"]}</td>' for s in ps) + f'<td>{T["b"]}</td></tr>'
    return o + '</tbody></table>'
INT_LEAD = '<p class=lead><span class="tag a">A</span> viagens obrigatórias realizadas (as da grade: horários fixos e o mínimo de cada intervalo), com o previsto em cinza quando diferente; em vermelho, faixas com obrigatória não realizada. <span class="tag b">B</span> viagens adicionais, feitas além da grade. As duas margens somadas; faixa pela hora de saída.</p>'

# ---------- quantitativo e receita por margem ----------
def qty_table(rev=False, show_nr=True):
    if not rev:
        head = f'''<thead><tr><th rowspan=2 style="text-align:left">Travessia</th><th colspan={6 if show_nr else 5} class=g>(A) Viagens obrigatórias</th><th colspan=3 class="g b">(B) Viagens adicionais</th><th rowspan=2>Total<br>realizadas</th><th colspan=2 class=g>Projeção</th></tr>
<tr><th>Previstas</th><th>Margem 1</th><th>Margem 2</th><th class=s>Total</th>{'<th>Não realiz.</th>' if show_nr else ''}<th>% cumpr.</th><th>Margem 1</th><th>Margem 2</th><th>Total</th><th>Viagens</th><th>% cumprido</th></tr></thead>'''
    else:
        head = f'''<thead><tr><th rowspan=2 style="text-align:left">Travessia</th><th colspan=3 class=g>(A) Obrigatórias × {brl(VA)}</th><th colspan=3 class="g b">(B) Adicionais × {brl(VB)}</th><th rowspan=2>Receita<br>total</th>{'<th rowspan=2>Não auferida<br>(A não realiz.)</th>' if show_nr else ''}</tr>
<tr><th>Margem 1</th><th>Margem 2</th><th class=s>Total</th><th>Margem 1</th><th>Margem 2</th><th class=s>Total</th></tr></thead>'''
    def row(lab, sub, s1, s2, st, cls=''):
        if not rev:
            nr = st['nr']
            return f'''<tr class="{cls}"><td class=m>{lab}{f"<span>{sub}</span>" if sub else ""}</td><td>{st["prev"]}</td><td>{s1["a"] if s1 else ""}</td><td>{s2["a"] if s2 else ""}</td><td class=s>{st["a"]}</td>{(f"<td><b class=red>{nr}</b></td>" if nr else "<td>0</td>") if show_nr else ""}<td><b>{pc(st["a"], st["prev"]-st["pend"], 1)}</b></td>
<td class=sep>{s1["b"] if s1 else ""}</td><td>{s2["b"] if s2 else ""}</td><td class=s>{st["b"]}</td><td class=sep><b>{n(st["tot"])}</b></td><td class=sep>{n(st["proj"]) if st.get("proj") else "–"}</td><td><b>{pc(st["tot"], st["proj"], 1) if st.get("proj") else "–"}</b></td></tr>'''
        f = lambda s, k, v: brl(s[k] * v, False) if s else ''
        return f'''<tr class="{cls}"><td class=m>{lab}{f"<span>{sub}</span>" if sub else ""}</td><td>{f(s1,"a",VA)}</td><td>{f(s2,"a",VA)}</td><td class=s>{f(st,"a",VA)}</td>
<td class=sep>{f(s1,"b",VB)}</td><td>{f(s2,"b",VB)}</td><td class=s>{f(st,"b",VB)}</td><td class=sep><b>{brl(st["a"]*VA+st["b"]*VB, False)}</b></td>{(f"<td><span class=red>{brl(st['nr']*VA, False)}</span></td>" if st["nr"] else "<td>–</td>") if show_nr else ""}</tr>'''
    o = f'<table class="t qt">{head}<tbody>'
    for reg, it in ORDER:
        for t, m, l, q in it:
            m1, m2 = margens(t, m)
            s1 = stats(t, m, m1) if m1 else None; s2 = stats(t, m, m2) if m2 else None
            sub = ' · '.join(x for x in (m1, m2) if x)
            st = stats(t, m); st['proj'] = proj(q)
            o += row(l, '' if l.startswith(m1 or '#') and (m2 or '') in l else sub, s1, s2, st)
        rs = [dict(stats(t, m), proj=proj(q) or 0) for t, m, _, q in it]; agg = {k: sum(r[k] for r in rs) for k in rs[0]}
        o += row(f'Subtotal {reg}', '', None, None, agg, 'st')
    o += row('Total geral', '', None, None, T, 'tot')
    return o + '</tbody></table>'

# ---------- pontos de atenção automáticos ----------
def compress(times):
    return ', '.join(hm(x) for x in times[:10]) + (f' e mais {len(times)-10}' if len(times) > 10 else '')
def attention(diretoria):
    out = []
    for reg, t, m, l, q in TR:
        p = sel(PROG, t, m); g = sel(df, t, m)
        nr = p[p.real == False]
        if len(nr) and not diretoria:
            parts = []
            for mg, s in nr.groupby('margem', sort=False):
                parts.append(f'{len(s)} saídas de {mg} ({compress(list(s.hora))})')
            txt = f'<b>{l}:</b> {len(nr)} obrigatórias não realizadas: ' + '; '.join(parts) + '.'
            out.append(txt)
        # períodos longos sem BSM
        if len(g):
            ts = [D] + list(g.saida) + [min(CUT, D + timedelta(days=1))]
            big = [(a, b) for a, b in zip(ts, ts[1:]) if (b - a) > timedelta(hours=2) and len(p[(p.hora >= a) & (p.hora < b)]) >= 2]
            for a, b in big:
                out.append(f'<b>{l}:</b> nenhum registro de viagem das {hm(a)} às {hm(b)}. Confirmar se houve operação sem apontamento.')
        elif len(p):
            out.append(f'<b>{l}:</b> nenhum registro de viagem no dia.')
    if TD != 'DU': out.append('<b>Bertioga ⇄ Guarujá:</b> só há grade de dia útil; ela foi usada também neste dia.')
    if TD == 'SAB': out.append('<b>Santos ⇄ Vicente de Carvalho:</b> a grade de sábado mostra Santos sem saídas das 16h às 22h (48 previstas). Conferir a grade.')
    return '<div class=obs><ul>' + ''.join(f'<li>{x}</li>' for x in out) + '</ul></div>' if out else ''

CRIT = f'''<ul class=crit>
<li><b>Base:</b> {n(len(df))} viagens registradas em {DSTR}, comparadas com a grade de {NOME_DIA[TD]}.</li>
<li><b>Viagem:</b> cada saída registrada de uma margem para a outra. Horário de saída = término do embarque / início da travessia. A margem é o sentido do registro.</li>
<li><b>(A) Obrigatórias:</b> as viagens da grade. Em horário fixo, a saída mais próxima de cada horário, de 10 min antes a 15 min depois. Nas faixas conforme demanda, a faixa é dividida em janelas do intervalo máximo (por exemplo, 06:30–20:00 a cada 12 min = 68 janelas) e a 1ª saída de cada janela é a obrigatória. Janela sem saída = obrigatória não realizada.</li>
<li><b>(B) Adicionais:</b> todas as outras saídas: as que sobram em cada janela e as que não casam com nenhum horário fixo.</li>
<li><b>Receita:</b> {brl(VA)} por viagem obrigatória realizada e {brl(VB)} (60%) por viagem adicional. "Não auferida" = obrigatórias não realizadas × {brl(VA)}.</li>
<li><b>Natividade:</b> o registro junta Pouso Alto e Bairro Alto num só sentido; esse sentido foi comparado com a grade como se fosse uma ponta só.</li>
</ul>'''

def write(name, body, title, tag):
    html = f'<!doctype html><html lang=pt-BR><head><meta charset=utf-8><title>{title}</title><style>{CSS}</style></head><body>{body}</body></html>'
    open(os.path.join(OUT, name + '.html'), 'w').write(html)
    open(os.path.join(OUT, 'header_' + name + '.html'), 'w').write(f'''<div style="width:100%;height:16mm;margin-top:-4mm;background:#005B7F;border-bottom:1.2mm solid #00B5AD;display:flex;align-items:center;justify-content:space-between;padding:0 12mm;box-sizing:border-box;-webkit-print-color-adjust:exact"><img src="data:image/png;base64,{logo}" style="height:6mm"><span style="color:#fff;font-family:Lato,Arial;font-size:7pt;letter-spacing:.14em;font-weight:700">{tag} · {DSTR}</span></div>''')

RA, RB = T['a'] * VA, T['b'] * VB
# =================== DIRETORIA ===================
dir_body = hero('Relatório diário de viagens · Diretoria Acquavias', 'Todas as travessias') + f'''
<div class=mult><div class=a><span><i>(A) Viagem obrigatória</i>multiplicador de receita por viagem</span><b>{brl(VA)}</b></div><div class=b><span><i>(B) Viagem adicional</i>60% do valor da obrigatória</span><b>{brl(VB)}</b></div></div>
<div class="kp k6"><div><b>{n(T["tot"])}</b>viagens realizadas<small>{PROJ_TXT or str(df.emb.nunique()) + " embarcações"}</small></div><div class=a><b>{n(T["a"])}</b>(A) obrigatórias<small>de {n(T["prev"])} previstas · {pc(T["a"], T["prev"]-T["pend"], 1)}</small></div><div class=b><b>{n(T["b"])}</b>(B) adicionais<small>{pc(T["b"], T["tot"])} das viagens</small></div><div class="rv a"><b>{brl(RA, False)}</b>receita (A)<small>{n(T["a"])} × {brl(VA)}</small></div><div class="rv b"><b>{brl(RB, False)}</b>receita (B)<small>{n(T["b"])} × {brl(VB)}</small></div><div class="rv t"><b>{brl(RA+RB, False)}</b>receita total do dia</div></div>
{acc_block()}<h2>Viagens obrigatórias e adicionais por travessia e intervalo</h2>{INT_LEAD.replace("; em vermelho, faixas com obrigatória não realizada", "")}{interval_table(False)}
<div class=sec><h2>Análise dos quantitativos</h2>
<p class=lead>Margem 1 é a primeira margem de saída do nome da travessia e margem 2, a segunda (quando o nome não deixa claro, as margens vêm ao lado). Acima, a quantidade de viagens; abaixo, a receita correspondente. % cumprido da projeção = total de viagens realizadas (A + B) ÷ viagens projetadas para o dia.</p>
<h3>Quantidade de viagens</h3>{qty_table(show_nr=False)}
<h3>Receita</h3>{qty_table(True, show_nr=False)}

</div>
<div class=sec><h2>Critérios</h2>{CRIT.replace(' "Não auferida" = obrigatórias não realizadas × ' + brl(VA) + '.', '').replace(' Janela sem saída = obrigatória não realizada.', '')}</div>'''
write('diretoria', dir_body, 'Relatório Diário de Viagens · Diretoria', 'RELATÓRIO DIÁRIO DE VIAGENS · DIRETORIA')

# =================== OPERAÇÃO ===================
VE = ['moto', 'aut', 'micro', 'onib', 'c2', 'c3', 'c4']
CL = [('ped', 'Pedestres'), ('bic', 'Bicicletas'), ('moto', 'Motos'), ('aut', 'Automóveis'), ('micro', 'Micro-ônibus e vans'), ('onib', 'Ônibus'), ('c2', 'Cam. 2 eixos'), ('c3', 'Cam. 3 eixos'), ('c4', 'Cam. 4+ eixos')]
def heat(x):
    x = max(0, min(1, x)); r = int(255 - (255 - 176) * x); g = int(255 - (255 - 222) * x); b = int(255 - (255 - 230) * x); return f'rgb({r},{g},{b})'
def k(v): return f'{v/1000:.1f}k'.replace('.', ',') if v >= 1000 else str(int(v))
def vol_table():
    o = '<table class=t><thead><tr><th>Travessia</th><th class=r>Viagens</th>' + ''.join(f'<th class=r>{lab}</th>' for _, lab in CL) + '<th class=r>Total veículos</th></tr></thead><tbody>'; cur = None
    for reg, t, m, l, q in TR:
        if reg != cur: o += f'<tr class=rg><td colspan=12>{reg}</td></tr>'; cur = reg
        g = sel(df, t, m)
        o += f'<tr><td class=m>{l}</td><td class=r>{len(g)}</td>' + ''.join(f'<td class=r>{n(g[c].sum()) if g[c].sum() else "<span class=z>0</span>"}</td>' for c, _ in CL) + f'<td class=r><b>{n(g.veic.sum())}</b></td></tr>'
    return o + '<tr class=tot><td class=m>Total</td><td class=r>' + n(len(df)) + '</td>' + ''.join(f'<td class=r>{n(df[c].sum())}</td>' for c, _ in CL) + f'<td class=r>{n(df.veic.sum())}</td></tr></tbody></table>'
def per_table(field, lab):
    o = f'<table class="t hm"><thead><tr><th>{lab}</th>' + ''.join(f'<th class=r>{p}</th>' for p, _, _ in PER) + '<th class=r>Dia</th></tr></thead><tbody>'
    for _, t, m, l, _ in TR:
        g = sel(df, t, m); vals = [g[(g.h >= a) & (g.h < b)][field].sum() for _, a, b in PER]; tot = sum(vals) or 1
        o += f'<tr><td class=m>{l}</td>' + ''.join(f'<td class=r style="background:{heat(v/tot*len(PER)/3)}">{n(v) if v else "<span class=z>0</span>"}<small>{pc(v,tot)}</small></td>' for v in vals) + f'<td class=r><b>{n(sum(vals))}</b></td></tr>'
    vals = [df[(df.h >= a) & (df.h < b)][field].sum() for _, a, b in PER]
    return o + '<tr class=tot><td class=m>Total</td>' + ''.join(f'<td class=r>{n(v)}<small>{pc(v,sum(vals))}</small></td>' for v in vals) + f'<td class=r>{n(sum(vals))}</td></tr></tbody></table>'
def hour_heat(fn, lab, fmt=lambda v: str(int(v)), last=None):
    o = f'<table class="t hh"><thead><tr><th>{lab}</th>' + ''.join(f'<th>{h:02d}</th>' for h in range(24)) + '<th class=r>Dia</th></tr></thead><tbody>'
    for _, t, m, l, c in TR:
        g = sel(df, t, m); vals = [fn(g[g.h == h]) for h in range(24)]; mx = max(vals) or 1
        o += f'<tr><td class=m>{l}</td>' + ''.join(f'<td style="background:{heat(v/mx)}">{fmt(v) if v else "<span class=z>·</span>"}</td>' for v in vals) + f'<td class=r><b>{fmt(sum(vals)) if last is None else last(g)}</b></td></tr>'
    vals = [fn(df[df.h == h]) for h in range(24)]
    return o + '<tr class=tot><td class=m>Total</td>' + ''.join(f'<td>{fmt(v)}</td>' for v in vals) + f'<td class=r>{fmt(sum(vals)) if last is None else last(df)}</td></tr></tbody></table>'
def hour_ab():
    o = '<table class="t hh hab"><thead><tr><th>Travessia</th><th style="width:6mm"></th>' + ''.join(f'<th>{h:02d}</th>' for h in range(24)) + '<th class=r>Dia</th></tr></thead><tbody>'
    for _, t, m, l, c in TR:
        g = sel(df, t, m); p = sel(PROG, t, m)
        A = [int(((g.h == h) & (g.cls == 'A')).sum()) for h in range(24)]; P = [int((p.h == h).sum()) for h in range(24)]
        B = [int(((g.h == h) & (g.cls == 'B')).sum()) for h in range(24)]
        o += f'<tr><td class=m>{l}</td><td><span class="tag a">A</span></td>' + ''.join(f'<td style="background:{"#F7D9D4" if A[h] < P[h] and p[(p.h==h)].real.eq(False).any() else "#EAF2F6" if A[h] else "#fff"}">{A[h] if (A[h] or P[h]) else "<span class=z>·</span>"}</td>' for h in range(24)) + f'<td class=r><b>{sum(A)}</b></td></tr>'
        o += f'<tr><td class=m></td><td><span class="tag b">B</span></td>' + ''.join(f'<td style="background:{"#DDF3F1" if B[h] else "#fff"}">{B[h] if B[h] else "<span class=z>·</span>"}</td>' for h in range(24)) + f'<td class=r><b>{sum(B)}</b></td></tr>'
    return o + '</tbody></table>'
def gantt():
    o = '<table class="t gt"><thead><tr><th>Travessia</th><th>Embarcação</th>' + ''.join(f'<th>{h:02d}</th>' for h in range(24)) + '<th class=r>Viagens</th><th class=r>1ª – última</th></tr></thead><tbody>'
    for _, t, m, l, c in TR:
        g = sel(df, t, m)
        for i, e in enumerate(sorted(g.emb.unique())):
            ge = g[g.emb == e]; cnt = ge.groupby('h').size()
            o += f'<tr class="{"fst" if i == 0 else ""}"><td class=m>{l if i == 0 else ""}</td><td><b>{e}</b></td>' + ''.join(f'<td class=gc>{"<i style=opacity:" + str(round(.35 + .65 * min(1, cnt[h] / max(cnt.max(), 1)), 2)) + ">" + str(cnt[h]) + "</i>" if h in cnt.index else ""}</td>' for h in range(24)) + f'<td class=r>{len(ge)}</td><td class=r>{hm(ge.te.min())}–{hm(ge.te.max())}</td></tr>'
    return o + '</tbody></table>'
CLS = {'Atrasada': 'at', 'Adiantada': 'ad', 'Não realizada': 'nr'}
def fixed_section():
    fr = ''; cur = None; items = []
    for reg, t, m, l, c in TR:
        f = sel(FX, t, m)
        if not len(f): continue
        if reg != cur: fr += f'<tr class=rg><td colspan=8>{reg}</td></tr>'; cur = reg
        for mg, s in f.groupby('margem', sort=False):
            st = s.status.value_counts(); nr = st.get('Não realizada', 0)
            fr += f'<tr><td class=m>{l}</td><td>Saídas de {mg}</td><td class=r>{len(s)}</td><td class=r>{st.get("No horário",0)}</td><td class=r>{st.get("Atrasada",0) or ""}</td><td class=r>{st.get("Adiantada",0) or ""}</td><td class=r>{"<b class=red>"+str(nr)+"</b>" if nr else ""}</td><td class=r><b>{pc(st.get("No horário",0),len(s))}</b></td></tr>'
            items += [(l, mg, r) for r in s[s.status.isin(CLS)].itertuples()]
    ok = (FX.status == 'No horário').sum()
    fr += f'<tr class=tot><td class=m colspan=2>Total</td><td class=r>{len(FX)}</td><td class=r>{ok}</td><td class=r>{(FX.status=="Atrasada").sum()}</td><td class=r>{(FX.status=="Adiantada").sum()}</td><td class=r>{(FX.status=="Não realizada").sum()}</td><td class=r>{pc(ok,len(FX))}</td></tr>'
    ch = ''; cur = None
    for l, mg, r in items:
        if (l, mg) != cur:
            if cur: ch += '</div></div>'
            ch += f'<div class=chl><div class=chh>{l} <span>· saídas de {mg}</span></div><div class=chs>'; cur = (l, mg)
        lab = hm(r.prog) + (f' → {hm(r.real)} ({r.desvio:+.0f})' if r.status != 'Não realizada' else ' · não realizada')
        ch += f'<span class="ch {CLS[r.status]}">{lab}{(" · " + r.emb) if isinstance(r.emb, str) else ""}</span>'
    if cur: ch += '</div></div>'
    return fr, ch, ok
def band_section():
    br = ''; cur = None
    for reg, t, m, l, c in TR:
        b = sel(BD, t, m)
        if not len(b): continue
        if reg != cur: br += f'<tr class=rg><td colspan=9>{reg}</td></tr>'; cur = reg
        for r in b.itertuples():
            p = sel(PROG, t, m); p = p[(p.margem == r.margem) & (p.tipo == 'Intervalo') & (p.hora >= r.ini) & (p.hora < r.fim)]
            a = int((p.real == True).sum())
            fim = '24:00' if r.fim.day != r.ini.day else hm(r.fim)
            br += f'<tr><td class=m>{l}</td><td>{r.margem}</td><td>{hm(r.ini)}–{fim}</td><td class=r>{r.imax} min</td><td class=r>{r.saidas}</td><td class=r>{len(p)}</td><td class=r>{a if a == len(p) else f"<b class=red>{a}</b>"}</td><td class=r>{r.maior_int:.0f} min</td><td class=r>{"<b class=red>"+str(r.excessos)+"</b>" if r.excessos else "0"}</td></tr>'
    gl = ''
    for _, t, m, l, c in TR:
        g = sel(GP, t, m)
        for mg, s in g.groupby('margem', sort=False):
            gl += f'<div class=chl><div class=chh>{l} <span>· saídas de {mg} · máx. {s.imax.iloc[0]} min</span></div><div class=chs>' + ''.join(f'<span class="ch nr">{hm(r.de)} → {hm(r.ate)} · {r.gap:.0f} min</span>' for r in s.itertuples()) + '</div></div>'
    return br, gl

# ---------- observações para a Operação: horários fixos fora da tolerância (−2/+5 min) ----------
def obs_operacao():
    rows = []; resumo = {}
    for reg, t, m, l, c in TR:
        f = sel(FX, t, m)
        for r in f[f.status.isin(['Atrasada', 'Adiantada', 'Não realizada'])].sort_values('prog').itertuples():
            g = df[(df.trav == t) & (df.modo == m)]
            gm = g[g.margem == r.margem]
            st = r.status; real = hm(r.real); emb = r.emb if isinstance(r.emb, str) else ''; dv = '' ; tx = ''; cls = CLS[st]
            if st == 'Atrasada':
                dv = f'+{r.desvio:.0f} min'; tx = f'Atraso de {r.desvio:.0f} min ({r.desvio-5:.0f} min além da tolerância de 5 min).'
            elif st == 'Adiantada':
                dv = f'{r.desvio:.0f} min'; tx = f'Saiu {-r.desvio:.0f} min antes do horário (tolerância de 2 min antes).'
            else:
                late = gm[(gm.otipo != 'Horário fixo') & (gm.saida > r.prog + timedelta(minutes=15)) & (gm.saida <= r.prog + timedelta(minutes=60))]
                opp = g[(g.margem != r.margem) & (g.otipo != 'Horário fixo') & ((g.saida - r.prog).abs() <= timedelta(minutes=15))]
                if len(late):
                    x = late.iloc[0]; d = (x.saida - r.prog).total_seconds() / 60
                    real = hm(x.te); emb = x.emb; dv = f'+{d:.0f} min'; st = 'Atraso > 15 min'; cls = 'nr'
                    tx = f'Saiu às {hm(x.te)}: atraso de {d:.0f} min. Fora da janela de 15 min, conta como não realizada.'
                elif len(opp):
                    x = opp.iloc[0]
                    tx = f'Sem saída desta margem. Há registro de {x.emb} às {hm(x.te)} no sentido oposto, sem horário correspondente: conferir o sentido lançado no BSM.'
                else:
                    ant = gm[gm.saida < r.prog].saida.max(); prx = gm[gm.saida > r.prog].saida.min()
                    tx = 'Sem saída registrada ' + ((f'entre {hm(ant)} e {hm(prx)}.' if not pd.isna(prx) else f'depois de {hm(ant)} até o fim do dia.') if not pd.isna(ant) else (f'desde o início do dia até {hm(prx)}.' if not pd.isna(prx) else 'no dia.'))
                    if r.prog.hour == 0 and r.prog.minute == 0: tx += ' Se a saída foi antes da 00:00, ela está no dia anterior.'
            rows.append((reg, l, r.margem, hm(r.prog), real, emb, dv, st, cls, tx))
            k = resumo.setdefault(l, [0, 0, 0, []]); k[0 if r.status == 'Atrasada' else (1 if r.status == 'Adiantada' else 2)] += 1
            if r.status == 'Atrasada': k[3].append(r.desvio)
    if not rows: return '<p class=lead>Todos os horários fixos saíram dentro da tolerância.</p>'
    sm = ''.join(f'<tr><td class=m>{l}</td><td class=r>{a or ""}</td><td class=r>{(f"{sum(v)/len(v):.0f} min".replace(".", ",") if v else "")}</td><td class=r>{(f"{max(v):.0f} min" if v else "")}</td><td class=r>{ad or ""}</td><td class=r>{("<b class=red>"+str(nr)+"</b>") if nr else ""}</td></tr>' for l, (a, ad, nr, v) in resumo.items())
    o = f'''<table class=t><thead><tr><th>Travessia</th><th class=r>Atrasadas</th><th class=r>Atraso médio</th><th class=r>Maior atraso</th><th class=r>Adiantadas</th><th class=r>Não realizadas</th></tr></thead><tbody>{sm}</tbody></table>
<h3>Saídas fora da tolerância, uma a uma</h3><table class="t ob"><thead><tr><th>Travessia</th><th>Saídas de</th><th class=r>Progr.</th><th class=r>Saída</th><th>Embarc.</th><th class=r>Desvio</th><th>Situação</th><th>Observação</th></tr></thead><tbody>'''
    cur = None
    for reg, l, mg, p, real, emb, dv, st, cls, tx in rows:
        if reg != cur: o += f'<tr class=rg><td colspan=8>{reg}</td></tr>'; cur = reg
        o += f'<tr><td class=m>{l}</td><td>{mg}</td><td class=r><b>{p}</b></td><td class=r>{real or "–"}</td><td>{emb or "–"}</td><td class=r>{dv or "–"}</td><td><span class="ch {cls}">{st}</span></td><td class=ot>{tx}</td></tr>'
    return o + '</tbody></table>'
fr, fxl, okfx = fixed_section(); br, gl = band_section()
nint = int(BD.saidas.sum() + len(BD)); nex = int(BD.excessos.sum())
df['pb'] = df.ped + df.bic
op_body = hero('Relatório diário de viagens · Operação', 'Todas as travessias') + f'''
<div class=kp><div><b>{n(T["tot"])}</b>viagens realizadas<small>{PROJ_TXT or str(df.emb.nunique()) + " embarcações"}</small></div><div class=a><b>{n(T["a"])}</b>(A) obrigatórias<small>de {n(T["prev"])} · {pc(T["a"], T["prev"]-T["pend"], 1)} cumpridas</small></div><div class=b><b>{n(T["b"])}</b>(B) adicionais</div><div><b>{pc(okfx, len(FX), 1)}</b>horários fixos no horário<small>{okfx} de {len(FX)}</small></div><div><b>{pc(nint-nex, nint, 1)}</b>intervalos dentro do máximo<small>{nint-nex} de {nint}</small></div></div>
{acc_block()}<h2>Viagens obrigatórias e adicionais por travessia e intervalo</h2>{INT_LEAD}{interval_table()}
<div class=sec><h2><span class=n>1</span>Quantitativo por margem</h2>
<p class=lead>Margem 1 é a primeira margem de saída do nome da travessia e margem 2, a segunda (quando o nome não deixa claro, as margens vêm ao lado). % de cumprimento = obrigatórias realizadas ÷ previstas. % cumprido da projeção = total de viagens realizadas (A + B) ÷ viagens projetadas para o dia.</p>
{qty_table()}
<h3>Pontos de atenção</h3>{attention(False)}</div>
<div class=sec><h2><span class=n>!</span>Observações para a Operação: horários fixos fora da tolerância</h2>
<p class=lead>Tolerância de saída: até 2 min antes e até 5 min depois do horário programado. O desvio é contado a partir do horário programado. Quando não há saída até 15 min depois, a viagem conta como não realizada; se houve saída mais tarde, o atraso aparece na observação.</p>{obs_operacao()}</div>
<div class=sec><h2><span class=n>2</span>Viagens por horário</h2>
<p class=lead>Viagens obrigatórias (A) e adicionais (B) em cada hora, as duas margens somadas. Vermelho: hora com obrigatória não realizada.</p>{hour_ab()}</div>
<div class=sec><h2><span class=n>3</span>Volume transportado</h2>
<p class=lead>Total do dia por classificação, somado nas duas margens.</p>{vol_table()}
<h3>Veículos por faixa horária</h3>{per_table("veic", "Veículos")}
<h3>Pedestres e ciclistas por faixa horária</h3>{per_table("pb", "Pedestres e ciclistas")}</div>
<div class=sec><h2><span class=n>4</span>Volume e frota por hora</h2>
<h3>Veículos</h3>{hour_heat(lambda g: g.veic.sum(), "Veículos", k)}
<h3>Pedestres e ciclistas</h3>{hour_heat(lambda g: g.pb.sum(), "Ped. + bic.", k)}
<h3>Frota por horário: embarcações que saíram em cada hora</h3>{hour_heat(lambda g: g.emb.nunique(), "Frota", last=lambda g: g.emb.nunique())}</div>
<div class=sec><h3 style="margin-top:0">Frota por horário: escala de cada embarcação</h3>
<p class=lead>Número de viagens de cada embarcação em cada hora (as duas margens), com a primeira e a última saída do dia.</p>{gantt()}</div>
<div class=sec><h2><span class=n>5</span>Viagens em horário fixo</h2>
<p class=lead>No horário: de 2 min antes a 5 min depois do programado. Atrasada: de 5 a 15 min depois. Adiantada: de 2 a 10 min antes. Não realizada: nenhuma saída nessa janela.</p>
<table class=t><thead><tr><th>Travessia</th><th>Margem</th><th class=r>Programados</th><th class=r>No horário</th><th class=r>Atrasadas</th><th class=r>Adiantadas</th><th class=r>Não realizadas</th><th class=r>% no horário</th></tr></thead><tbody>{fr}</tbody></table>
<h3>Horários fora do horário</h3>
<div class=leg><span class="ch at">atrasada</span><span class="ch ad">adiantada</span><span class="ch nr">não realizada</span><span class=lg>programado → saída (desvio em min) · embarcação</span></div>{fxl}</div>
<div class=sec><h2><span class=n>6</span>Viagens nos intervalos (conforme demanda)</h2>
<p class=lead>Obrigatórias = janelas do intervalo máximo com ao menos uma saída. Também se verifica se algum intervalo entre saídas seguidas da mesma margem passou do máximo.</p>
<table class=t><thead><tr><th>Travessia</th><th>Margem</th><th>Faixa</th><th class=r>Máx.</th><th class=r>Saídas</th><th class=r>Obrig. previstas</th><th class=r>Obrig. realizadas</th><th class=r>Maior intervalo</th><th class=r>Acima do máx.</th></tr></thead><tbody>{br}</tbody></table>
<h3>Intervalos acima do máximo</h3>{gl}
<h3>Critérios</h3>{CRIT.replace("<li><b>Receita:</b>", "<li style=display:none><b>Receita:</b>")}</div>'''
write('operacao', op_body, 'Relatório Diário de Viagens · Operação', 'RELATÓRIO DIÁRIO DE VIAGENS · OPERAÇÃO')
print('ok', T, round(RA + RB, 2))
