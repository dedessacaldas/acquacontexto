# calc.py EXPORT.xlsx AAAA-MM-DD res.pkl [BD_QT.xlsx]
# Classifica cada viagem do export BSM em (A) obrigatória (da grade) ou (B) adicional.
import pandas as pd, pickle, sys, math
from datetime import datetime, timedelta
from grades import grade, ORDER

exp, dia, out = sys.argv[1:4]
bdqt = sys.argv[4] if len(sys.argv) > 4 else None
D = datetime.strptime(dia, '%Y-%m-%d')
df = pd.read_excel(exp)
df.columns = ['trav', 'abert', 'emb', 'bsm', 'dir', 'ie', 'te', 'ped', 'bic', 'moto', 'aut', 'micro', 'onib', 'c2', 'c3', 'c4', 'tipo', 'tt', 'td']
for c in ['ie', 'te', 'tt', 'td']: df[c] = pd.to_datetime(df[c], dayfirst=True)
df = df[(df.te >= D) & (df.te < D + timedelta(days=1))].sort_values('te').reset_index(drop=True)
CUT = df.te.max().floor('min')
FULL = CUT >= D + timedelta(hours=23, minutes=30)   # export cobre o dia inteiro?
df['saida'] = df.te.dt.floor('min')
df['sent'] = df.dir.astype(str).str[0]
df['modo'] = df.emb.astype(str).str.startswith('LS').map({True: 'Lancha', False: 'Ferry boat'})
df['veic'] = df[['moto', 'aut', 'micro', 'onib', 'c2', 'c3', 'c4']].sum(axis=1)
df['dur'] = (df.tt - df.te).dt.total_seconds() / 60
df['cls'] = 'B'; df['otipo'] = ''; df['oref'] = pd.NaT
TD, S = grade(D)

prog = []   # uma linha por viagem obrigatória prevista
fx = []; bd = []; gaps = []
df['margem'] = ''
for (tr, mo, se), (fixed, bands, mg) in S.items():
    idx = df.index[(df.trav == tr) & (df.modo == mo) & (df.sent == se)]
    df.loc[idx, 'margem'] = mg
    g = df.loc[idx]
    bstarts = {a for a, b, i in bands}
    slots = [s for s in fixed if s not in bstarts]
    # 1) horários fixos: casa cada horário com a saída mais próxima na janela −10/+15 min
    pairs = sorted([(abs((t - s).total_seconds()), si, gi) for si, s in enumerate(slots) for gi, t in zip(g.index, g.saida) if -10 <= (t - s).total_seconds() / 60 <= 15])
    us, ug = {}, set()
    for _, si, gi in pairs:
        if si in us or gi in ug: continue
        us[si] = gi; ug.add(gi)
    for si, s in enumerate(slots):
        if si in us:
            gi = us[si]; d = (df.saida[gi] - s).total_seconds() / 60
            st = 'No horário' if -2 <= d <= 5 else ('Atrasada' if d > 5 else 'Adiantada')
            df.loc[gi, ['cls', 'otipo', 'oref']] = ['A', 'Horário fixo', s]
            fx.append([tr, mo, mg, s, df.te[gi], df.emb[gi], d, st])
            prog.append([tr, mo, mg, 'Horário fixo', s, True, df.saida[gi]])
        else:
            st = 'Pendente' if (CUT - s).total_seconds() / 60 < 15 else 'Não realizada'
            fx.append([tr, mo, mg, s, None, None, None, st])
            prog.append([tr, mo, mg, 'Horário fixo', s, False if st != 'Pendente' else None, None])
    # 2) faixas conforme demanda: janelas consecutivas de "intervalo máximo";
    #    a 1ª saída de cada janela é a obrigatória, as demais são adicionais
    free = [gi for gi in g.index if gi not in ug]
    allt = list(g.saida)
    for a, b, I in bands:
        k = 0
        while a + timedelta(minutes=I * k) < b:
            w0 = a + timedelta(minutes=I * k); w1 = min(a + timedelta(minutes=I * (k + 1)), b)
            hit = [gi for gi in free if w0 <= df.saida[gi] < w1 and df.cls[gi] == 'B']
            if hit:
                gi = hit[0]; df.loc[gi, ['cls', 'otipo', 'oref']] = ['A', 'Intervalo', w0]
                prog.append([tr, mo, mg, 'Intervalo', w0, True, df.saida[gi]])
            else:
                prog.append([tr, mo, mg, 'Intervalo', w0, None if w1 > CUT else False, None])
            k += 1
        # conformidade de intervalo (critério do relatório geral): nenhum intervalo acima do máximo
        if a > CUT: continue
        e = min(b, CUT)
        ins = [t for t in allt if a <= t < b and t <= CUT]
        prev = [t for t in allt if t < a]
        anchor = prev[-1] if prev and (a - prev[-1]).total_seconds() / 60 <= I else a
        seq = [anchor] + ins + ([e] if e < b else [b])
        mx = 0; exc = 0
        for j in range(1, len(seq)):
            gp = (seq[j] - seq[j - 1]).total_seconds() / 60
            if gp > I:
                exc += 1; gaps.append([tr, mo, mg, I, seq[j - 1], seq[j], gp])
            mx = max(mx, gp)
        bd.append([tr, mo, mg, a, b, I, len(ins), math.ceil((e - a).total_seconds() / 60 / I), mx, exc])

PROG = pd.DataFrame(prog, columns=['trav', 'modo', 'margem', 'tipo', 'hora', 'real', 'saida'])
FX = pd.DataFrame(fx, columns=['trav', 'modo', 'margem', 'prog', 'real', 'emb', 'desvio', 'status'])
BD = pd.DataFrame(bd, columns=['trav', 'modo', 'margem', 'ini', 'fim', 'imax', 'saidas', 'minimo', 'maior_int', 'excessos'])
GP = pd.DataFrame(gaps, columns=['trav', 'modo', 'margem', 'imax', 'de', 'ate', 'gap'])
# margem de viagens sem grade (sentido não previsto)
df.loc[df.margem == '', 'margem'] = df.dir.astype(str).str[2:].str.split('/').str[0]

QT = {}; QTM = {}; QTMD = {}; MES_INI = MES_FIM = None
if bdqt:
    q = pd.read_excel(bdqt)
    r = q[pd.to_datetime(q.iloc[:, 0]).dt.normalize() == D]
    if len(r): QT = {c: r.iloc[0][c] for c in q.columns[2:]}
    dq = pd.to_datetime(q.iloc[:, 0]).dt.normalize()
    mes = q[(dq.dt.year == D.year) & (dq.dt.month == D.month)]
    QTM = {c: float(pd.to_numeric(mes[c], errors='coerce').fillna(0).sum()) for c in q.columns[2:]}   # projeção do mês inteiro
    QTMD = {c: float(pd.to_numeric(mes[dq[mes.index] <= D][c], errors='coerce').fillna(0).sum()) for c in q.columns[2:]}  # até o dia
    MES_INI, MES_FIM = dq[mes.index].min(), dq[mes.index].max()

pickle.dump(dict(df=df, PROG=PROG, FX=FX, BD=BD, GP=GP, CUT=CUT, FULL=FULL, D=D, TD=TD, QT=QT, QTM=QTM, QTMD=QTMD, MES_INI=MES_INI, MES_FIM=MES_FIM, EXP=exp.split('/')[-1]), open(out, 'wb'))
print('dia', D.date(), TD, 'corte', CUT, 'viagens', len(df))
known = {(t, m) for _, it in ORDER for t, m, *_ in it}
print('fora da ordem:', df[[(t, m) not in known for t, m in zip(df.trav, df.modo)]].groupby(['trav', 'modo']).size().to_dict())
print(df.groupby(['trav', 'modo', 'margem', 'cls']).size().unstack(fill_value=0).to_string())
print(PROG.groupby(['trav', 'modo', 'margem']).agg(prev=('hora', 'size'), real=('real', lambda x: (x == True).sum())).to_string())
print(QT)
