#!/bin/bash
# Uso: ./gerar.sh "EXPORT_BSM.xlsx" AAAA-MM-DD ["Quantitativo de Viagens - BD_QT.xlsx"] [PASTA_SAIDA]
# Gera "Relatório Diário de Viagens - Diretoria - DD-MM-AAAA.pdf" e "... - Operação - ....pdf"
set -e
cd "$(dirname "$0")"
EXP="$1"; DIA="$2"; QT="${3:-}"; OUT="${4:-..}"
DD=$(date -d "$DIA" +%d-%m-%Y)
if [ -n "$QT" ]; then python3 calc.py "$EXP" "$DIA" res.pkl "$QT" >/dev/null; else python3 calc.py "$EXP" "$DIA" res.pkl >/dev/null; fi
python3 build.py res.pkl .
node print.js "$PWD/diretoria.html" "$OUT/Relatório Diário de Viagens - Diretoria - $DD.pdf" "$PWD/header_diretoria.html"
node print.js "$PWD/operacao.html" "$OUT/Relatório Diário de Viagens - Operação - $DD.pdf" "$PWD/header_operacao.html"
echo "PDFs em $OUT"
