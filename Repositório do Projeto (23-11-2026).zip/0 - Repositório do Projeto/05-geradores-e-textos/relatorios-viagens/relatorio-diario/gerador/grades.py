# Grades de horários por travessia (pacote "Grade de Horários - *.pdf" de 10/11/2026).
# grade(D) devolve {(trav, modo, sentido): (horarios_fixos, faixas, nome_da_margem)}
#   horarios_fixos: lista de datetime; faixas: lista (inicio, fim, intervalo_max_min)
# trav/modo/sentido seguem o export BSM (sentido 1/2 = 1º/2º nome de "De/Para").
from datetime import datetime, timedelta, date

FERIADOS = {  # nacionais + SP (9/jul) + 20/nov; incluir municipais se necessário
    '2026-11-15', '2026-11-20', '2026-12-25', '2027-01-01', '2027-02-08', '2027-02-09', '2027-03-26',
    '2027-04-21', '2027-05-01', '2027-05-27', '2027-07-09', '2027-09-07', '2027-10-12', '2027-11-02',
    '2027-11-15', '2027-11-20', '2027-12-25'}

def tipo_dia(D):
    if D.strftime('%Y-%m-%d') in FERIADOS or D.weekday() == 6: return 'DOM'
    if D.weekday() == 5: return 'SAB'
    return 'DU'

NOME_DIA = {'DU': 'dia útil', 'SAB': 'sábado', 'DOM': 'domingo/feriado'}

def grade(D):
    td = tipo_dia(D)
    def T(s):
        h, m = map(int, s.split(':')); return D + timedelta(hours=h, minutes=m)
    def L(s): return [T(x) for x in s.split()]
    def step(a, b, st):
        out = []; t = T(a)
        while t <= T(b): out.append(t); t += timedelta(minutes=st)
        return out
    def band(a, b, i): return (T(a), D + timedelta(hours=24) if b == '24:00' else T(b), i)
    H05 = [D + timedelta(hours=h) for h in range(6)]

    # ---- Santos ⇄ Guarujá (faixas contínuas; o horário fixo que coincide com o início de faixa conta na faixa)
    if td == 'DU':
        SG = (step('00:00', '04:30', 30), [band('05:00', '06:30', 20), band('06:30', '20:00', 12), band('20:00', '24:00', 20)])
    elif td == 'SAB':
        SG = (step('00:00', '06:00', 30), [band('06:30', '09:00', 15), band('09:00', '20:30', 12), band('20:30', '24:00', 15)])
    else:
        SG = (step('00:00', '05:00', 30), [band('05:30', '09:00', 20), band('09:00', '21:00', 12), band('21:00', '24:00', 20)])
    # ---- Santos ⇄ Vicente de Carvalho (lancha, horários fixos por margem)
    VS0 = L('00:00 00:40 01:20 02:00 03:00 04:00 04:40'); VV0 = L('00:20 01:00 01:40 02:30 03:30 04:20')
    if td == 'DU':  # 16/11/2026: grade do Excel da Dedessa
        VS = VS0 + step('05:18', '08:42', 12) + step('09:00', '15:40', 20) + step('16:06', '19:06', 12) + step('19:15', '20:00', 15) + step('20:20', '22:40', 20) + L('22:54 23:25')
        VV = VV0 + step('05:00', '08:24', 12) + step('08:40', '15:40', 20) + step('16:00', '19:00', 12) + step('19:15', '20:00', 15) + step('20:20', '22:40', 20) + L('23:10 23:40')
    elif td == 'SAB':  # 16/11/2026: manhã 12 min intercalado; 20 min simultâneo
        VS = VS0 + step('05:18', '08:42', 12) + step('09:00', '22:40', 20) + L('22:54 23:25')
        VV = VV0 + step('05:00', '08:24', 12) + step('08:40', '22:40', 20) + L('23:10 23:40')
    else:  # domingo/feriado: dia todo 20 min simultâneo
        VS = VS0 + step('05:00', '22:40', 20) + L('22:54 23:25')
        VV = VV0 + step('05:00', '22:40', 20) + L('23:10 23:40')
    # ---- Bertioga ⇄ Guarujá (dia útil; fim de semana/feriado abaixo)
    BB = L('00:20 01:00 01:40 02:20 03:00 03:40 04:20 05:00 05:40 06:20 06:40') + step('07:00', '12:40', 20) + L('13:00 13:20 14:00 14:40 15:20 16:00 16:40 17:00 17:20 17:40 18:00 18:20 19:00 19:40 20:20 21:00 21:40 22:20 23:00 23:40')
    BG = L('00:00 00:40 01:20 02:00 02:40 03:20 04:00 04:40 05:20 06:00 06:40') + step('07:00', '12:40', 20) + L('13:00 13:40 14:20 15:00 15:40 16:20 16:40 17:00 17:20 17:40 18:00 18:20 18:40 19:20 20:00 20:40 21:20 22:00 22:40 23:20')
    # 16/11/2026 ~17h30: Dedessa confirmou que Bertioga tem a mesma grade todos os dias (49/margem)
    # ---- Iguape ⇄ Juréia
    if td == 'DU':
        IG = step('00:00', '02:30', 30) + L('03:30 04:30 05:30 06:30') + step('07:00', '20:30', 30) + L('21:30 22:30 23:30')
        JU = step('00:15', '01:45', 30) + L('02:15 03:15 04:15 05:15') + step('06:15', '19:45', 30) + L('20:15 21:15 22:15 23:15 23:45')
    else:
        IG = L('00:00 01:00 01:30 02:00 02:30 03:30 04:30 05:30 06:30') + step('07:00', '20:30', 30) + L('21:30 22:00 22:30 23:00 23:30')
        JU = step('00:15', '02:15', 30) + L('03:15 04:15 05:15') + step('06:15', '23:45', 30)
    # ---- Natividade (3 pontas, mesmos horários em todas)
    if td == 'DU':
        NAT = (H05, [band('06:00', '08:00', 40), band('08:00', '20:00', 20), band('20:00', '24:00', 40)])
    else:
        NAT = (H05, [band('06:00', '10:00', 40), band('10:00', '12:00', 20), band('12:00', '16:00', 40), band('16:00', '20:00', 20), band('20:00', '24:00', 40)])
    # ---- Cananéia ⇄ Marujá ⇄ Ariri (linha semanal; sentido 1 = Cananéia → Ariri, 2 = Ariri → Cananéia)
    wd = D.weekday()
    ARI1 = {0: ['13:00'], 2: ['08:00'], 3: ['08:00']}.get(wd, [])
    ARI2 = {1: ['07:00'], 2: ['13:00'], 4: ['08:00']}.get(wd, [])

    S = {
        ('Santos/Guarujá', 'Ferry boat', '1'): (SG[0], SG[1], 'Santos'),
        ('Santos/Guarujá', 'Ferry boat', '2'): (SG[0], SG[1], 'Guarujá'),
        ('Santos/Vicente de Carvalho', 'Lancha', '1'): (VS, [], 'Santos'),
        ('Santos/Vicente de Carvalho', 'Lancha', '2'): (VV, [], 'Vicente de Carvalho'),
        ('Bertioga/Guarujá', 'Ferry boat', '1'): (BB, [], 'Bertioga'),
        ('Bertioga/Guarujá', 'Ferry boat', '2'): (BG, [], 'Guarujá'),
        ('São Sebastião/Ilhabela', 'Ferry boat', '1'): (H05, [band('05:30', '24:00', 30)], 'São Sebastião'),
        ('São Sebastião/Ilhabela', 'Ferry boat', '2'): (L('00:00 00:30 01:30 02:30 03:30 04:30 05:30'), [band('06:00', '24:00', 30)], 'Ilhabela'),
        ('São Sebastião/Ilhabela', 'Lancha', '1'): (step('06:30', '19:30', 60), [], 'São Sebastião'),
        ('São Sebastião/Ilhabela', 'Lancha', '2'): (step('07:00', '20:00', 60), [], 'Ilhabela'),
        ('Cananéia/Continente', 'Ferry boat', '1'): (L('00:00 00:30 02:30 04:00 05:00 06:15') + step('07:00', '11:00', 60) + [T('12:05')] + step('13:00', '23:00', 60), [], 'Cananéia'),
        ('Cananéia/Continente', 'Ferry boat', '2'): (L('00:15 01:00 03:00') + step('04:30', '22:30', 60), [], 'Continente'),
        ('Cananéia/Ilha Comprida', 'Ferry boat', '1'): (L('00:00 00:30 02:30 04:00 05:00 06:00 06:30 07:00 07:30 08:00 08:30 09:00 10:00 11:00 11:30 12:00 12:30 13:00 13:30 14:00 15:00 16:00 17:00 17:30 18:00 18:30 19:00 19:30 20:00 21:00 22:00 23:00'), [], 'Cananéia'),
        ('Cananéia/Ilha Comprida', 'Ferry boat', '2'): (L('00:15 01:00 03:00 04:30 05:45 06:15 06:45 07:15 07:45 08:15 08:45 09:30 10:30 11:15 11:45 12:15 12:45 13:15 13:45 14:30 15:30 16:30 17:15 17:45 18:15 18:45 19:15 19:45 20:30 21:30 22:30 23:30'), [], 'Ilha Comprida'),
        ('Iguape/Juréia', 'Ferry boat', '1'): (IG, [], 'Iguape'),
        ('Iguape/Juréia', 'Ferry boat', '2'): (JU, [], 'Juréia'),
        ('Cananéia/Ariri', 'Lancha', '1'): (L(' '.join(ARI1)) if ARI1 else [], [], 'Cananéia'),
        ('Cananéia/Ariri', 'Lancha', '2'): (L(' '.join(ARI2)) if ARI2 else [], [], 'Ariri'),
        ('Natividade da Serra/B. Natividade da Serra', 'Ferry boat', '1'): (NAT[0], NAT[1], 'Natividade'),
        ('Natividade da Serra/B. Natividade da Serra', 'Ferry boat', '2'): (NAT[0], NAT[1], 'Pouso Alto / Bairro Alto'),
        ('Ribeirão Branco/Capim DAngola', 'Ferry boat', '1'): (H05, [band('06:00', '24:00', 40)], 'Ribeirão Branco'),
        ('Ribeirão Branco/Capim DAngola', 'Ferry boat', '2'): (H05, [band('06:00', '24:00', 40)], "Capim D'Angola"),
        ('Comércio/Varginha', 'Ferry boat', '1'): (H05, [band('06:00', '24:00', 45)], 'Comércio'),
        ('Comércio/Varginha', 'Ferry boat', '2'): (H05, [band('06:00', '24:00', 45)], 'Varginha'),
    }
    return td, S

# Ordem e rótulos no relatório: (região, [(trav, modo, rótulo, coluna BD_QT)])
ORDER = [
    ('Baixada Santista', [('Santos/Guarujá', 'Ferry boat', 'Santos ⇄ Guarujá', 'Santos/Guarujá'),
                          ('Santos/Vicente de Carvalho', 'Lancha', 'Santos ⇄ Vicente de Carvalho', 'Santos/Vicente de Carvalho'),
                          ('Bertioga/Guarujá', 'Ferry boat', 'Bertioga ⇄ Guarujá', 'Bertioga/Guarujá')]),
    ('Litoral Norte', [('São Sebastião/Ilhabela', 'Ferry boat', 'São Sebastião ⇄ Ilhabela · balsa', 'São Sebastião/Ilhabela - Veículos e Pedestres'),
                       ('São Sebastião/Ilhabela', 'Lancha', 'São Sebastião ⇄ Ilhabela · lancha', 'São Sebastião/Ilhabela - Pedestres e Ciclistas')]),
    ('Litoral Sul', [('Cananéia/Continente', 'Ferry boat', 'Cananéia ⇄ Continente', 'Cananeia/Continente'),
                     ('Cananéia/Ilha Comprida', 'Ferry boat', 'Cananéia ⇄ Ilha Comprida', 'Cananeia/Ilha Comprida'),
                     ('Iguape/Juréia', 'Ferry boat', 'Iguape ⇄ Juréia', 'Iguape/Jureia'),
                     ('Cananéia/Ariri', 'Lancha', 'Cananéia ⇄ Marujá ⇄ Ariri', 'Cananeia/Ariri')]),
    ('Paraibuna e Natividade da Serra', [('Natividade da Serra/B. Natividade da Serra', 'Ferry boat', 'Natividade', 'Natividade'),
                                         ('Ribeirão Branco/Capim DAngola', 'Ferry boat', 'Paraitinga', 'Paraitinga'),
                                         ('Comércio/Varginha', 'Ferry boat', 'Varginha', 'Varginha')]),
]
