import pickle, pandas as pd, numpy as np
Z = pickle.load(open('dados.pkl', 'rb')); S, N, O, PZ, M, T = Z['S'], Z['N'], Z['O'], Z['PZ'], Z['M'], Z['T']
R = {}
SG = 'Santos/Guarujá'; SSI = 'São Sebastião/Ilhabela'
n = N[N.Travessia == SG].copy(); n = n[n.ini < '2026-11-17']
R['nav'] = dict(total=len(n), por_dia=len(n) / 8, dur_med=n.dur.median(), dur_p90=n[n.dur <= 60].dur.quantile(.9),
                min_dia=n[n.dur <= 60].dur.sum() / 8, longas=n[n.dur > 60][['ini', 'dur']].values.tolist(), outras=N[N.Travessia != SG][['Travessia', 'ini', 'dur']].values.tolist())
R['nav_h'] = n.groupby(n.ini.dt.hour).size().reindex(range(24), fill_value=0).tolist()
R['nav_d'] = n.groupby(n.ini.dt.day).size().to_dict()
# estudo de evento: fila de −60 a +90 min do início da passagem
s = S[S.trav == SG].set_index('dt').sort_index()
offs = list(range(-4, 7)); ev = []
for r in n.itertuples():
    t0 = r.ini.floor('15min'); v = {o: s.fila.get(t0 + pd.Timedelta(minutes=15 * o), np.nan) for o in offs}
    b = np.nanmean([v[o] for o in (-4, -3, -2)])
    if np.isnan(b): continue
    ev.append({o: v[o] - b for o in offs} | {'h': t0.hour, 'd': t0.day, 'base': b})
EV = pd.DataFrame(ev)
R['ev_all'] = EV[offs].mean().tolist(); R['ev_dia'] = EV[(EV.h >= 6) & (EV.h < 22)][offs].mean().tolist(); R['ev_912'] = EV[EV.d <= 12][offs].mean().tolist()
R['ev_n'] = len(EV); R['offs'] = offs
# saídas depois da passagem
V = pd.read_excel('entradas/Viagens_NOV26.xlsx'); c = 'Término Embarque\nInício Travessia'
V['t'] = pd.to_datetime(V[c], format='%d/%m/%Y %H:%M:%S', errors='coerce'); V = V[V.t.notna()]
VE = ['Moto', 'Aut.', 'Micro-ônibus e vans', 'Onibus', 'Caminhões 2 Eixos', 'Caminhões 3 Eixos', 'Caminhões 4 ou mais Eixos']; V['veic'] = V[VE].sum(axis=1)
v = V[V.Travessia == SG].copy(); v['sent'] = v['De/Para'].str[0]; out = []
for sn, g in v.sort_values('t').groupby('sent'):
    g = g.reset_index(drop=True); g['gap'] = g.t.diff().dt.total_seconds() / 60; g['h'] = g.t.dt.hour; g['d'] = g.t.dt.date
    mg = g.groupby(['d', 'h']).gap.median(); mv = g.groupby(['d', 'h']).veic.median()
    for r in n[n.dur <= 60].itertuples():
        nx = g[g.t >= r.fim].head(1)
        if nx.empty or nx.index[0] == 0: continue
        i = nx.index[0]; k = (g.d[i], g.h[i])
        out.append(dict(sent=sn, h=r.ini.hour, gap=g.gap[i], mg=mg.get(k), veic=g.veic[i], mv=mv.get(k), espera=(g.t[i] - r.fim).total_seconds() / 60))
Q = pd.DataFrame(out)
R['saida'] = dict(gap_med=Q.gap.median(), mg_med=Q.mg.median(), pct_maior=(Q.gap > Q.mg).mean(), veic=Q.veic.mean(), mv=Q.mv.mean(), espera_med=Q.espera.median(), n=len(Q))
FX = [(0, 6, '00h–06h'), (6, 10, '06h–10h'), (10, 17, '10h–17h'), (17, 20, '17h–20h'), (20, 24, '20h–24h')]
R['saida_fx'] = [(lab, len(n[(n.ini.dt.hour >= a) & (n.ini.dt.hour < b)]) / 8, Q[(Q.h >= a) & (Q.h < b)].gap.median(), Q[(Q.h >= a) & (Q.h < b)].mg.median(),
                  Q[(Q.h >= a) & (Q.h < b)].veic.mean(), Q[(Q.h >= a) & (Q.h < b)].mv.mean()) for a, b, lab in FX]
# fila alta × fatores
def alta(t, thr):
    x = S[(S.trav == t) & (S.h >= 6) & (S.h < 22)].copy(); x['alta'] = x.fila >= thr
    x['veic_rel'] = x.veic / x.groupby('h').veic.transform('median')
    g = x.groupby('alta')[['fila', 'frota', 'manut', 'viag', 'veic', 'veic_rel', 'navmin60', 'ocor']].mean()
    return dict(n=int(x.alta.sum()), tot=len(x), g=g, dias=x[x.alta].groupby(x.d.dt.day).size().reindex(range(9, 17), fill_value=0).tolist(),
                fila_dia=x.groupby(x.d.dt.day).fila.mean().reindex(range(9, 17)).tolist(), zeros=x[x.fila == 0].groupby(x.d.dt.day).size().reindex(range(9, 17), fill_value=0).tolist())
R['sg'] = alta(SG, 30); R['ssi'] = alta(SSI, 60)
# SSI por dia (08–18h): balsas em operação/manutenção ao meio-dia e fila por margem
x = T[T.Travessia == SSI].copy(); x['h'] = x.dt.dt.hour; x['d'] = x.dt.dt.day; x = x[(x.h >= 8) & (x.h < 18)]
fm = x.pivot_table(index='d', columns='Margem', values='Tempo', aggfunc='mean')
m = M[(M.trav == SSI) & M.Embarcação.str.startswith('FB')]
vs = V[(V.Travessia == SSI) & V['Embarcação'].str.startswith('FB') & (V.t.dt.hour >= 8) & (V.t.dt.hour < 18)]
dd = []
for d in range(9, 17):
    slots = pd.date_range(f'2026-11-{d} 08:00', f'2026-11-{d} 17:45', freq='15min')
    op = np.mean([m[(m.ini <= t) & (m.fim > t) & (m.Condição == 'Operação')].Embarcação.nunique() for t in slots])
    mn = np.mean([m[(m.ini <= t) & (m.fim > t) & m.Condição.isin(['Manutenção', 'Abastecimento', 'Vistoria'])].Embarcação.nunique() for t in slots])
    ms = sorted(set(m[(m.ini < slots[-1]) & (m.fim > slots[0]) & (m.Condição == 'Manutenção')].Embarcação))
    vv = vs[vs.t.dt.day == d]
    dd.append(dict(d=d, op=op, mn=mn, ms=', '.join(ms), viag=len(vv), veic=int(vv.veic.sum()), fss=fm.loc[d, 'São Sebastião'], fib=fm.loc[d, 'Ilhabela']))
R['ssi_dia'] = pd.DataFrame(dd)
R['ssi_corr'] = R['ssi_dia'][['op', 'fss', 'fib']].corr().round(2)
# paralisações: fila antes / durante / depois
pz = []
for r in PZ.itertuples():
    ss = S[S.trav == r.Travessia].set_index('dt').fila
    a = ss[(ss.index >= r.ini - pd.Timedelta(minutes=60)) & (ss.index < r.ini.floor('15min'))].mean()
    du = ss[(ss.index >= r.ini.floor('15min')) & (ss.index <= r.fim)].mean()
    de = ss[(ss.index > r.fim) & (ss.index <= r.fim + pd.Timedelta(minutes=60))].mean()
    pz.append(dict(trav=r.Travessia, tipo=r.Tipo, ini=r.ini, dur=(r.fim - r.ini).total_seconds() / 60, antes=a, durante=du, depois=de))
R['pz'] = pd.DataFrame(pz)
# ocorrências por categoria: fila (desvio da média do mesmo dia e hora) com e sem a categoria ativa
oc = []
for t in (SG, SSI):
    x = S[S.trav == t].copy(); x['res'] = x.fila - x.groupby(['d', 'h']).fila.transform('mean')
    oo = O[O.trav == t]
    for cat, g in oo.groupby('cat'):
        if cat == 'Navio/draga': continue
        act = x.ocat.str.contains(cat, regex=False)
        if act.sum() < 3: continue
        oc.append(dict(trav=t, cat=cat, n=len(g), slots=int(act.sum()), fila_on=x[act].fila.mean(), fila_off=x[~act].fila.mean(), res=x[act].res.mean()))
R['oc'] = pd.DataFrame(oc)
R['oc_q'] = dict(total=len(O), sem_tipo=O.Tipo.isna().mean(), sem_com=(O.com == '').mean(), sem_emb=O['Emb.'].isna().mean(), cats=O.cat.value_counts().to_dict(), por_trav=O.Travessia.value_counts().to_dict())
R['mov'] = dict(total=len(M), abertas=int(M.aberta.sum()), cond=M.Condição.value_counts().to_dict())
R['viag'] = dict(total=len(V), ini=V.t.min(), fim=V.t.max())
R['fila_base'] = dict(registros=len(T), ini=T.dt.min(), fim=T.dt.max())
pickle.dump(R, open('res.pkl', 'wb'))
for k in ('nav', 'saida', 'pz', 'oc', 'ssi_dia', 'ssi_corr', 'oc_q'): print(k, R[k] if not isinstance(R[k], pd.DataFrame) else R[k].round(1).to_string())
print(R['saida_fx']); print(R['ev_all'], R['ev_dia'], R['ev_912']); print(R['sg']['g'].round(2), R['sg']['dias'], R['sg']['zeros'])
