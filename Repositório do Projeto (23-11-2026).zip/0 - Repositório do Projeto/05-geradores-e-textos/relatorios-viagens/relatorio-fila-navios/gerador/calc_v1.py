# Cruza tempo de fila (15 min) × passagens de navio, ocorrências, paralisações, frota em operação e volume.
import pandas as pd, numpy as np, pickle
E = 'entradas/'
F = lambda s: pd.to_datetime(s, format='%d/%m/%Y %H:%M:%S', errors='coerce')
T = pd.read_excel(E + 'TempoEmbarque_NOV26.xlsx'); T['dt'] = F(T['Data Hora'])
N = pd.read_excel(E + 'PassagensNavio_NOV26.xlsx'); N['ini'] = N['Data Inicial']; N['fim'] = N['Data Final']; N['dur'] = (N.fim - N.ini).dt.total_seconds() / 60
O = pd.read_excel(E + 'Ocorrencias_NOV26.xlsx'); O['ini'] = O['Data Inicial']; O['fim'] = O['Data Final'].fillna(O['Data Inicial'])
O['com'] = O['Comentário'].fillna('').astype(str).str.replace(r'\s+', ' ', regex=True).str.strip()
PZ = pd.read_excel(E + 'Paralisacao_NOV26.xlsx')
M = pd.read_excel(E + 'Movimentacoes_NOV26.xlsx'); M['ini'] = F(M['Início']); M['fim'] = F(M['Término'])
V = pd.read_excel(E + 'Viagens_NOV26.xlsx'); c = 'Término Embarque\nInício Travessia'
V['t'] = F(V[c]); V = V[V.t.notna()]
VE = ['Moto', 'Aut.', 'Micro-ônibus e vans', 'Onibus', 'Caminhões 2 Eixos', 'Caminhões 3 Eixos', 'Caminhões 4 ou mais Eixos']
V['veic'] = V[VE].sum(axis=1)
COD = {'ST/GJ': 'Santos/Guarujá', 'SS/IB': 'São Sebastião/Ilhabela', 'ST/VC': 'Santos/Vicente de Carvalho', 'BE/GJ': 'Bertioga/Guarujá',
       'CN/CO': 'Cananéia/Continente', 'CN/IC': 'Cananéia/Ilha Comprida', 'IG/JU': 'Iguape/Juréia', 'CN/AR': 'Cananéia/Ariri'}
M['trav'] = M.Travessia.map(COD)
FIM_EXPORT = pd.Timestamp('2026-11-17 11:17'); M['aberta'] = M.fim.isna(); M['fim'] = M.fim.fillna(FIM_EXPORT)   # movimentação sem término = ainda em curso
M = M.sort_values(['Embarcação', 'ini']); M['fim'] = M[['fim']].assign(p=M.groupby('Embarcação').ini.shift(-1)).min(axis=1)   # status termina quando começa o próximo da mesma embarcação

def categ(r):
    c = r.com.lower(); t = str(r.Tipo)
    if 'navio' in c or 'draga' in c or c in ('entrada', 'saída', 'saida', 'entrada.', 'saída.'): return 'Navio/draga'
    if t == 'Maré' or 'maré' in c or 'mare' in c: return 'Maré'
    if t == 'Ventos Fortes' or 'vento' in c: return 'Vento'
    if 'emergência' in c or 'emergencia' in c or 'ambulân' in c or 'especial' in c: return 'Emergência / viagem especial'
    if 'vazia' in c or 'unilateral' in c or 'troca' in c or 'antes do hor' in c or 'antecip' in c or 'zarp' in c or 'deslocando' in c: return 'Ajuste de demanda (vazia, troca, antecipada)'
    if 'manuten' in c or 'avaria' in c or 'pane' in c or 'falha' in c or 'mecân' in c: return 'Falha / manutenção'
    if 'interdit' in c or 'gaveta' in c or 'rampa' in c or 'atracad' in c: return 'Infraestrutura / atracadouro'
    if not c: return 'Sem descrição'
    return 'Outras'
O['cat'] = O.apply(categ, axis=1)

# ---------- grade de 15 min por travessia (média das margens) ----------
G = T.groupby(['Travessia', 'dt']).Tempo.mean().reset_index().rename(columns={'Travessia': 'trav', 'Tempo': 'fila'})
G['d'] = G.dt.dt.normalize(); G['h'] = G.dt.dt.hour
def overlap(df, trav, a, b, ini='ini', fim='fim'):
    x = df[(df.trav == trav) & (df[ini] < b) & (df[fim] >= a)] if 'trav' in df else None
    return x
N['trav'] = N.Travessia; O['trav'] = O.Travessia; PZ['trav'] = PZ.Travessia; PZ['ini'] = PZ['Data Inicial']; PZ['fim'] = PZ['Data Final']
NC = N.copy(); NC.loc[NC.dur > 60, 'fim'] = NC.ini + pd.Timedelta(minutes=15)   # 2 registros com duração irreal (79 e 421 min): limita a 15 min
rows = []
G = G[G.trav.isin(['Santos/Guarujá', 'São Sebastião/Ilhabela', 'Santos/Vicente de Carvalho', 'Bertioga/Guarujá', 'Cananéia/Ilha Comprida', 'Cananéia/Continente', 'Iguape/Juréia'])]
for r in G.itertuples():
    a, b = r.dt, r.dt + pd.Timedelta(minutes=15)
    n30 = NC[(NC.trav == r.trav) & (NC.ini < b) & (NC.fim >= a - pd.Timedelta(minutes=30))]
    n60m = NC[(NC.trav == r.trav) & (NC.ini < b) & (NC.fim >= a - pd.Timedelta(minutes=60))]
    oc = O[(O.trav == r.trav) & (O.ini < b) & (O.fim >= a - pd.Timedelta(minutes=30)) & (O.cat != 'Navio/draga')]
    pz = PZ[(PZ.trav == r.trav) & (PZ.ini < b) & (PZ.fim >= a - pd.Timedelta(minutes=30))]
    mm = M[(M.trav == r.trav) & (M.ini <= a + pd.Timedelta(minutes=7)) & (M.fim > a + pd.Timedelta(minutes=7))]
    fl = mm[(mm.Condição == 'Operação') & mm.Embarcação.str.startswith('FB')].Embarcação.nunique()
    man = mm[mm.Condição.isin(['Manutenção', 'Abastecimento'])].Embarcação.nunique()
    vento = mm.Motivo.fillna('').str.contains('condições favoráveis').any()
    vv = V[(V.Travessia == r.trav) & (V.t >= a) & (V.t < b)]
    rows.append(dict(trav=r.trav, dt=r.dt, d=r.d, h=r.h, fila=r.fila, navio=len(n30) > 0, nnav60=len(n60m),
                     navmin60=float(((n60m.fim.clip(upper=b) - n60m.ini.clip(lower=a - pd.Timedelta(minutes=60))).dt.total_seconds() / 60).sum()) if len(n60m) else 0.0,
                     ocor=len(oc) > 0, ocat='; '.join(sorted(set(oc.cat))), paral=len(pz) > 0, frota=fl, manut=man, espera_clima=bool(vento), viag=len(vv), veic=int(vv.veic.sum())))
S = pd.DataFrame(rows)
pickle.dump(dict(S=S, N=N, O=O, PZ=PZ, M=M, T=T), open('dados.pkl', 'wb'))
print(S.groupby('trav')[['fila', 'navio', 'ocor', 'paral', 'frota', 'viag', 'veic']].mean().round(2))
