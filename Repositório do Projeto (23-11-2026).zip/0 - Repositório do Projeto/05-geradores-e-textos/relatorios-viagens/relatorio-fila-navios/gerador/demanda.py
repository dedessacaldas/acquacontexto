# Fila (horários sob demanda) × volume transportado na margem: veículos embarcados na hora seguinte ao registro
import pandas as pd, numpy as np, pickle
RG = pickle.load(open('regime.pkl', 'rb')); X = pickle.load(open('mov.pkl', 'rb'))
V = pd.read_excel('entradas/Viagens_NOV26.xlsx'); c = 'Término Embarque\nInício Travessia'
V['t'] = pd.to_datetime(V[c], dayfirst=True, errors='coerce'); V = V[V.t.notna()]
VE = ['Moto', 'Aut.', 'Micro-ônibus e vans', 'Onibus', 'Caminhões 2 Eixos', 'Caminhões 3 Eixos', 'Caminhões 4 ou mais Eixos']; V['veic'] = V[VE].sum(axis=1)
ORIG = {'1-Santos/Guarujá': ('Santos/Guarujá', 'Santos'), '2-Guarujá/Santos': ('Santos/Guarujá', 'Guarujá'),
        '1-São Sebastião/Ilhabela': ('São Sebastião/Ilhabela', 'São Sebastião'), '2-Ilhabela/São Sebastião': ('São Sebastião/Ilhabela', 'Ilhabela')}
V = V[V['De/Para'].isin(ORIG)]; V['trav'] = V['De/Para'].map(lambda k: ORIG[k][0]); V['marg'] = V['De/Para'].map(lambda k: ORIG[k][1])
D = RG[RG.reg == 'DEM'].copy(); D = D[D.Travessia.isin(['Santos/Guarujá', 'São Sebastião/Ilhabela'])]; D['h'] = D.dt.dt.hour
out = []
for (tr, mg), g in D.groupby(['Travessia', 'Margem']):
    v = V[(V.trav == tr) & (V.marg == mg)].sort_values('t'); tv = v.t.values; cv = np.r_[0, v.veic.cumsum().values]
    a = np.searchsorted(tv, g.dt.values); b = np.searchsorted(tv, (g.dt + pd.Timedelta(minutes=60)).values)
    g = g.assign(veic60=cv[b] - cv[a], viag60=b - a); g['vpv'] = g.veic60 / g.viag60.replace(0, np.nan); out.append(g)
D = pd.concat(out)
x = X[['trav', 'dt', 'oper', 'aguard', 'disp', 'manut']].rename(columns={'trav': 'Travessia'}); D = D.merge(x, on=['Travessia', 'dt'], how='left')
pickle.dump(D, open('demanda.pkl', 'wb'))
pd.set_option('display.width', 250)
for (tr, mg), g in D[(D.h >= 6) & (D.h < 22) | (D.Travessia == 'Santos/Guarujá')].groupby(['Travessia', 'Margem']):
    g = g.copy(); g['alta'] = g.Tempo >= (60 if tr.startswith('São') else 30)
    g['vq'] = pd.qcut(g.veic60, 4, labels=['volume baixo', 'médio-baixo', 'médio-alto', 'volume alto'])
    print(tr, mg, 'corr veic60', round(g.Tempo.corr(g.veic60), 2), 'corr vpv', round(g.Tempo.corr(g.vpv), 2), 'corr oper', round(g.Tempo.corr(g.oper), 2))
    print(g.groupby('vq', observed=True).agg(veic=('veic60', 'mean'), fila=('Tempo', 'mean'), alta=('alta', 'mean'), viag=('viag60', 'mean'), vpv=('vpv', 'mean')).round(2).to_string())
    print(g.groupby('alta').agg(veic=('veic60', 'mean'), viag=('viag60', 'mean'), vpv=('vpv', 'mean'), oper=('oper', 'mean'), manut=('manut', 'mean')).round(2).to_string())
    print(g.groupby('h').agg(veic=('veic60', 'mean'), vpv=('vpv', 'mean'), alta=('alta', 'mean')).round(1).T.to_string())
