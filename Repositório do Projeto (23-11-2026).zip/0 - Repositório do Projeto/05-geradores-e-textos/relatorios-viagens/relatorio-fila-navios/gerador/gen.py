import pickle, pandas as pd, numpy as np
R = pickle.load(open('res.pkl', 'rb'))
n0 = lambda x: f'{x:,.0f}'.replace(',', '.')
f1 = lambda x: f'{x:,.1f}'.replace(',', '#').replace('.', ',').replace('#', '.')
pct = lambda x: f'{x*100:.1f}%'.replace('.', ',')
sg1 = lambda x: ('+' if x > 0.05 else ('−' if x < -0.05 else '±')) + f1(abs(x))
nv, sd, SG, SS = R['nav'], R['saida'], R['sg'], R['ssi']
DS = {9: 'seg', 10: 'ter', 11: 'qua', 12: 'qui', 13: 'sex', 14: 'sáb', 15: 'dom', 16: 'seg'}

# ---- gráfico 1: estudo de evento
def ev_chart():
    W, H, pl, pr, pt, pb = 360, 120, 34, 10, 12, 26
    offs = R['offs']; ys = R['ev_all']; y2 = R['ev_dia']
    lo, hi = -4, 4
    X = lambda i: pl + i * (W - pl - pr) / (len(offs) - 1); Y = lambda v: pt + (hi - v) / (hi - lo) * (H - pt - pb)
    g = [f'<svg viewBox="0 0 {W} {H}" class=chart>']
    x0 = X(offs.index(0)); x1 = X(offs.index(0)) + (X(1) - X(0)) * 0.5
    g.append(f'<rect x={x0-4:.1f} y={pt} width={x1-x0+8:.1f} height={H-pt-pb} fill="#00B5AD" opacity=".14"/><text x={x0+2:.1f} y={pt+8} style="font-size:6.5px;fill:#008C86;font-weight:700">passagem</text>')
    for v in (-4, -2, 0, 2, 4):
        g.append(f'<line x1={pl} x2={W-pr} y1={Y(v):.1f} y2={Y(v):.1f} stroke="{"#5E7480" if v==0 else "#E3ECF0"}" stroke-width="{0.8 if v==0 else 0.5}"/><text x={pl-4} y={Y(v)+2.5:.1f} text-anchor=end class=ax>{("+" if v>0 else "")}{v} min</text>')
    for i, o in enumerate(offs):
        g.append(f'<text x={X(i):.1f} y={H-pb+10} text-anchor=middle class=ax>{("+" if o>0 else "")}{o*15}</text>')
    g.append(f'<text x={(pl+W-pr)/2:.0f} y={H-4} text-anchor=middle class=ax>minutos em relação ao início da passagem</text>')
    for ys_, col, w in ((y2, '#9CC3D3', 1.2), (ys, '#005B7F', 1.8)):
        g.append('<polyline fill=none stroke="%s" stroke-width=%s points="%s"/>' % (col, w, ' '.join(f'{X(i):.1f},{Y(v):.1f}' for i, v in enumerate(ys_))))
        g += [f'<circle cx={X(i):.1f} cy={Y(v):.1f} r=1.6 fill="{col}"/>' for i, v in enumerate(ys_)]
    g.append('</svg>'); return ''.join(g)
# ---- gráfico 2: passagens por hora
def nh_chart():
    W, H, pl, pr, pt, pb = 360, 120, 20, 6, 10, 20; v = R['nav_h']; mx = max(v) * 1.15
    bw = (W - pl - pr) / 24; g = [f'<svg viewBox="0 0 {W} {H}" class=chart>']
    for i, x in enumerate(v):
        h = x / mx * (H - pt - pb); xx = pl + i * bw
        g.append(f'<rect x={xx+bw*.15:.1f} y={H-pb-h:.1f} width={bw*.7:.1f} height={h:.1f} fill="#005B7F" rx="1"/><text x={xx+bw/2:.1f} y={H-pb-h-2:.1f} text-anchor=middle style="font-size:5.5px;fill:#17303B">{x}</text>')
        if i % 2 == 0: g.append(f'<text x={xx+bw/2:.1f} y={H-pb+9} text-anchor=middle class=ax>{i:02d}h</text>')
    g.append('</svg>'); return ''.join(g)
# ---- gráfico 3: SSI por dia (balsas em operação × fila por margem)
def ssi_chart():
    D = R['ssi_dia']; W, H, pl, pr, pt, pb = 740, 112, 34, 34, 14, 24; n = len(D); bw = (W - pl - pr) / n
    Yf = lambda v: H - pb - v / 120 * (H - pt - pb); Yo = lambda v: H - pb - v / 8 * (H - pt - pb)
    g = [f'<svg viewBox="0 0 {W} {H}" class=chart>']
    for v in (0, 30, 60, 90, 120):
        g.append(f'<line x1={pl} x2={W-pr} y1={Yf(v):.1f} y2={Yf(v):.1f} stroke="#E3ECF0" stroke-width=".5"/><text x={pl-4} y={Yf(v)+2.5:.1f} text-anchor=end class=ax>{v} min</text>')
    for v in (0, 2, 4, 6, 8):
        g.append(f'<text x={W-pr+4} y={Yo(v)+2.5:.1f} class=ax style="fill:#008C86">{v}</text>')
    pss, pib = [], []
    for i, r in enumerate(D.itertuples()):
        x = pl + i * bw; h = r.op / 8 * (H - pt - pb)
        g.append(f'<rect x={x+bw*.3:.1f} y={H-pb-h:.1f} width={bw*.4:.1f} height={h:.1f} fill="#A8E3DF" rx="1.5"/><text x={x+bw/2:.1f} y={H-pb-h+8:.1f} text-anchor=middle style="font-size:6.5px;fill:#00796F;font-weight:700">{f1(r.op)}</text>')
        g.append(f'<text x={x+bw/2:.1f} y={H-pb+9} text-anchor=middle class=ax>{DS[r.d]} {r.d:02d}/11</text>')
        pss.append((x + bw / 2, Yf(r.fss))); pib.append((x + bw / 2, Yf(r.fib)))
    for pts, col in ((pss, '#005B7F'), (pib, '#E39B2D')):
        g.append('<polyline fill=none stroke="%s" stroke-width=1.6 points="%s"/>' % (col, ' '.join(f'{a:.1f},{b:.1f}' for a, b in pts)))
        g += [f'<circle cx={a:.1f} cy={b:.1f} r=2 fill="{col}"/>' for a, b in pts]
    g.append('</svg>'); return ''.join(g)

ev0 = R['ev_all']; i0 = R['offs'].index(0)
mx_ev = max(abs(v) for v in ev0)
D = R['ssi_dia']
# tabela faixa horária
fx = ''.join(f'<tr><td class=m>{lab}</td><td class=r>{f1(pd_)}</td><td class=r><b>{f1(g)}</b> min</td><td class=r>{f1(m)} min</td><td class=r>{f1(v)}</td><td class=r>{f1(mv)}</td></tr>' for lab, pd_, g, m, v, mv in R['saida_fx'])
gg = SG['g']; gs = SS['g']
def lin(lab, a, b, fmt=f1, suf=''):
    return f'<tr><td class=m>{lab}</td><td class=r>{fmt(a)}{suf}</td><td class=r><b>{fmt(b)}{suf}</b></td></tr>'
tab_sg = (lin('Tempo de fila registrado', gg.fila[False], gg.fila[True], suf=' min') + lin('Balsas em operação', gg.frota[False], gg.frota[True])
          + lin('Saídas na janela de 15 min', gg.viag[False], gg.viag[True]) + lin('Veículos embarcados na janela', gg.veic[False], gg.veic[True], n0)
          + lin('Minutos de passagem de navio na última hora', gg.navmin60[False], gg.navmin60[True], suf=' min') + lin('Janelas com ocorrência registrada', gg.ocor[False], gg.ocor[True], pct))
tab_ss = (lin('Tempo de fila registrado', gs.fila[False], gs.fila[True], suf=' min') + lin('Balsas em operação', gs.frota[False], gs.frota[True])
          + lin('Embarcações em manutenção ou abastecimento', gs.manut[False], gs.manut[True]) + lin('Veículos embarcados na janela', gs.veic[False], gs.veic[True], n0)
          + lin('Janelas com ocorrência registrada', gs.ocor[False], gs.ocor[True], pct))
ssd = ''.join(f'<tr><td class=m>{DS[r.d]} {r.d:02d}/11</td><td class=r>{f1(r.op)}</td><td class=r>{f1(r.mn)}</td><td>{r.ms or "–"}</td><td class=r>{n0(r.veic)}</td>'
              f'<td class="r {"hi" if r.fss >= 60 else ""}">{f1(r.fss)}</td><td class="r {"hi" if r.fib >= 60 else ""}">{f1(r.fib)}</td></tr>' for r in D.itertuples())
pz = R['pz']
pzt = ''.join(f'<tr><td class=m>{r.trav.replace("/", " ⇄ ")}</td><td>{r.tipo}</td><td>{r.ini:%d/%m %H:%M}</td><td class=r>{f1(r.dur)} min</td><td class=r>{f1(r.antes)}</td><td class=r>{f1(r.durante)}</td><td class=r>{f1(r.depois)}</td></tr>' for r in pz.itertuples())
oc = R['oc']
oct_ = ''.join(f'<tr><td class=m>{r.trav.replace("/", " ⇄ ")}</td><td>{r.cat}</td><td class=r>{r.n}</td><td class=r>{r.slots}</td><td class=r>{f1(r.fila_on)}</td><td class=r>{f1(r.fila_off)}</td><td class=r><b>{sg1(r.res)}</b></td></tr>' for r in oc.sort_values(['trav', 'slots'], ascending=[True, False]).itertuples())
q = R['oc_q']
zeros = SG['zeros']; altas = SG['dias']
dayrow = lambda vals: ''.join(f'<td class=r>{v}</td>' for v in vals)
d13 = D.set_index('d')

html = f'''<div class=hero><div class=pat></div><div class=eb>Relatório de análise · operação</div><h1>Tempo de fila × passagens de navio e ocorrências</h1>
<div class=per>09 a 16/11/2026 · viagens, tempos de fila a cada 15 min, passagens de navio, ocorrências, paralisações e movimentação da frota cruzados por travessia e horário</div><div class=w></div></div>
<div class="kp k6"><div>Passagens de navio<b>{n0(nv['total'])}</b>Santos ⇄ Guarujá · {f1(nv['por_dia'])} por dia</div>
<div>Duração típica<b>{f1(nv['dur_med'])} min</b>9 em cada 10 até {f1(nv['dur_p90'])} min</div>
<div>Fila em volta da passagem<b>{sg1(ev0[i0])} min</b>variação máx. {f1(mx_ev)} min entre −1h e +1h30</div>
<div>Saída seguinte à passagem<b>{f1(sd['gap_med'])} min</b>de intervalo · normal {f1(sd['mg_med'])} min na mesma hora</div>
<div>Fila alta · Santos ⇄ Guarujá<b>{pct(SG['n']/SG['tot'])}</b>{SG['n']} de {SG['tot']} janelas (≥ 30 min, 06h–22h)</div>
<div>Fila alta · São Sebastião ⇄ Ilhabela<b>{pct(SS['n']/SS['tot'])}</b>{SS['n']} de {SS['tot']} janelas (≥ 60 min, 06h–22h)</div></div>
<div class=sum><b>Em resumo.</b> As passagens de navio em Santos ⇄ Guarujá são frequentes ({f1(nv['por_dia'])} por dia, cerca de {n0(nv['min_dia']/60)} h somadas por dia) e curtas. Elas <b>abrem um vão nas saídas</b>: a primeira saída depois da passagem vem com {f1(sd['gap_med'])} min de intervalo, contra {f1(sd['mg_med'])} min no normal. Mas o <b>tempo de fila registrado não sobe</b> por causa delas: em volta das {n0(R['ev_n'])} passagens, a fila variou menos de {f1(mx_ev+0.05)} min. A fila alta também não coincide com menos balsas, mais veículos, ocorrências ou paralisações em Santos ⇄ Guarujá. Em São Sebastião ⇄ Ilhabela, ao contrário, <b>a fila alta acompanha os dias com balsas paradas em manutenção</b>.</div>

<h2><span class=n>1</span>Passagens de navio × fila · Santos ⇄ Guarujá</h2>
<div class=g2><div class=cbox><div class=ct>Tempo de fila antes, durante e depois da passagem</div>{ev_chart()}
<div class=lg><i style="background:#005B7F"></i>todas as {n0(R['ev_n'])} passagens <i style="background:#9CC3D3"></i>só 06h–22h · variação em relação à média da hora anterior</div></div>
<div class=cbox><div class=ct>Passagens de navio por hora do dia (09–16/11)</div>{nh_chart()}<div class=lg>as passagens se espalham pelo dia inteiro, sem concentração no pico</div></div></div>
<table class="t hm"><tr><th>Faixa horária</th><th class=r>Passagens por dia</th><th class=r>Intervalo até a saída seguinte</th><th class=r>Intervalo normal na hora</th><th class=r>Veículos na saída seguinte</th><th class=r>Veículos por saída na hora</th></tr>{fx}</table>
<div class=obs><ul><li><b>O navio pausa a travessia, mas pouco:</b> a saída seguinte acontece, em média, {f1(sd['espera_med'])} min depois do fim da passagem. Em {pct(sd['pct_maior'])} das passagens, o intervalo entre saídas ficou maior que o normal da hora.</li>
<li><b>A saída seguinte não sai mais cheia:</b> leva {f1(sd['veic'])} veículos, contra {f1(sd['mv'])} por saída na mesma hora. As balsas já operam perto da capacidade, então o acúmulo da pausa se dilui nas saídas seguintes.</li>
<li><b>Por isso a fila registrada não muda:</b> uma pausa de 7 a 10 min fica dentro da janela de 15 min do registro de fila, que anda em degraus (12, 20, 30 min).</li>
<li><b>Paralisações por navio:</b> só 2 passagens viraram paralisação formal ({pz[pz.tipo=="Passagem de Navio"].dur.round(0).astype(int).astype(str).str.cat(sep=" e ")} min, de madrugada), sem efeito na fila.</li></ul></div>

<h2><span class=n>2</span>O que acompanha a fila alta</h2>
<div class=g2><div><div class=ct2>Santos ⇄ Guarujá · janelas de 15 min, 06h–22h</div>
<table class="t hm"><tr><th></th><th class=r>Fila normal</th><th class=r>Fila alta (≥ 30 min)</th></tr>{tab_sg}</table>
<div class=nt>Nas janelas de fila alta, frota, saídas, veículos, navio e ocorrências ficam iguais às de fila normal. O que muda é o dia: {sum(altas[:4])} das {SG['n']} janelas de fila alta são de 09 a 12/11. A partir de 13/11, o registro passou a ter muitos zeros (40 a 45 janelas por dia), o que indica mudança no jeito de registrar, e não queda real da fila.</div></div>
<div><div class=ct2>São Sebastião ⇄ Ilhabela · janelas de 15 min, 06h–22h</div>
<table class="t hm"><tr><th></th><th class=r>Fila normal</th><th class=r>Fila alta (≥ 60 min)</th></tr>{tab_ss}</table>
<div class=nt>Na janela isolada a diferença é pequena, mas no dia ela aparece: veja abaixo. Os veículos embarcados são os mesmos, então a fila alta não vem de demanda maior, e sim de capacidade menor.</div></div></div>
<div class=cbox><div class=ct>São Sebastião ⇄ Ilhabela · balsas em operação e fila média das 08h às 18h</div>{ssi_chart()}
<div class=lg><i style="background:#A8E3DF"></i>balsas em operação (média, eixo da direita) <i style="background:#005B7F"></i>fila em São Sebastião <i style="background:#E39B2D"></i>fila em Ilhabela</div></div>
<table class="t hm ssd"><tr><th>Dia</th><th class=r>Balsas em operação</th><th class=r>Em manutenção / abastec.</th><th>Balsas que pararam para manutenção</th><th class=r>Veículos (08h–18h)</th><th class=r>Fila São Sebastião</th><th class=r>Fila Ilhabela</th></tr>{ssd}</table>
<div class=obs><ul><li><b>Menos balsas, mais fila:</b> em 10/11, com média de {f1(d13.op[10])} balsas em operação e {f1(d13.mn[10])} paradas, a fila passou de 50 min nas duas margens. Em 14 e 15/11, com {f1(d13.op[14])} e {f1(d13.op[15])} balsas, a fila ficou em 30 min o dia todo, mesmo com o maior volume da semana em 15/11 ({n0(d13.veic[15])} veículos).</li>
<li><b>16/11:</b> FB-19 e FB-30 em manutenção, e a fila de Ilhabela chegou a {f1(d13.fib[16])} min em média.</li>
<li><b>13/11 é a exceção:</b> {f1(d13.op[13])} balsas em operação e fila de {f1(d13.fss[13])} min em São Sebastião, sem ocorrência, paralisação ou volume maior que explique. Vale checar com a operação o que houve nesse dia.</li>
<li><b>Vento em 12/11:</b> a paralisação de {f1(pz[pz.tipo=="Ventos Fortes"].dur.iloc[0])} min (10h49–11h34) teve fila de {f1(pz[pz.tipo=="Ventos Fortes"].antes.iloc[0])} min antes e {f1(pz[pz.tipo=="Ventos Fortes"].depois.iloc[0])} min depois. Durante a paralisação, o registro caiu para {f1(pz[pz.tipo=="Ventos Fortes"].durante.iloc[0])} min, o que não faz sentido com a travessia parada.</li></ul></div>

<h2><span class=n>3</span>Ocorrências e paralisações × fila</h2>
<table class="t hm"><tr><th>Travessia</th><th>Paralisação</th><th>Início</th><th class=r>Duração</th><th class=r>Fila 1h antes</th><th class=r>Fila durante</th><th class=r>Fila 1h depois</th></tr>{pzt}</table>
<table class="t hm" style="margin-top:2mm"><tr><th>Travessia</th><th>Tipo de ocorrência (pelo comentário)</th><th class=r>Ocorrências</th><th class=r>Janelas afetadas</th><th class=r>Fila com ocorrência</th><th class=r>Fila sem ocorrência</th><th class=r>Diferença no mesmo dia e hora</th></tr>{oct_}</table>
<div class=obs><ul><li><b>Nenhum tipo de ocorrência mexe na fila:</b> comparando com o mesmo dia e hora, a diferença fica abaixo de 1 min em todos. A fila parece mais alta com "Emergência" ou "Outras" em Santos ⇄ Guarujá só porque essas ocorrências caem em horários que já têm fila maior.</li>
<li><b>Qualidade dos registros:</b> das {n0(q['total'])} ocorrências, {pct(q['sem_tipo'])} estão sem Tipo, {pct(q['sem_com'])} sem comentário e {pct(q['sem_emb'])} sem embarcação. Por isso, a categoria acima foi lida pelo comentário.</li></ul></div>

<h2><span class=n>4</span>Limites dos dados e próximos passos</h2>
<div class=obs><ul>
<li><b>O tempo de fila é registrado, não medido.</b> Nas travessias de horário fixo (Bertioga, Cananéia, Iguape, Santos ⇄ Vicente de Carvalho), ele repete o intervalo da grade: 20, 30, 60 ou 120 min conforme a hora. Por isso, só Santos ⇄ Guarujá e São Sebastião ⇄ Ilhabela foram analisadas.</li>
<li><b>Santos ⇄ Guarujá mudou de padrão em 13/11:</b> janelas com fila zero por dia: {" · ".join(f"{d:02d}/11 {z}" for d, z in zip(range(9, 17), zeros))}. Vale alinhar com a operação o que significa "0" (sem fila ou sem registro).</li>
<li><b>Passagens de navio:</b> {len(nv['longas'])} registros com duração irreal ({", ".join(f"{a:%d/%m %H:%M} com {f1(b)} min" for a, b in nv['longas'])}) foram limitados a 15 min. Fora de Santos ⇄ Guarujá, há só {len(nv['outras'])} passagens (Santos ⇄ Vicente de Carvalho e São Sebastião ⇄ Ilhabela).</li>
<li><b>Movimentação da frota:</b> as movimentações sem horário de término foram tratadas como em curso até o fim do período.</li>
<li><b>Para medir o efeito do navio de verdade:</b> cronometrar a fila (entrada no bolsão até a 1ª posição) nos horários de passagem, ou registrar o tempo de fila a cada 5 min em Santos ⇄ Guarujá. Também ajuda preencher o Tipo e a embarcação nas ocorrências.</li></ul></div>
<div class=crit>Critérios: janelas de 15 min do registro de tempo de fila (média das duas margens; em São Sebastião ⇄ Ilhabela, também por margem). Fila alta: ≥ 30 min em Santos ⇄ Guarujá (intervalo normal de 12 a 20 min) e ≥ 60 min em São Sebastião ⇄ Ilhabela (intervalo normal de 30 min), das 06h às 22h. Passagem "na janela": passagem de navio na janela ou nos 30 min antes. Variação em volta da passagem: fila de cada janela menos a média das janelas de 1h a 30 min antes. Intervalo até a saída seguinte: tempo entre a última saída antes do fim da passagem e a primeira depois, por sentido; o normal é a mediana do intervalo naquela hora e dia. Balsas em operação: embarcações FB com condição "Operação" na movimentação da frota.</div>'''

css = open('../../relatorio-financeiro/gerador/base.css').read() + '''
.kp.k6{grid-template-columns:repeat(6,1fr)!important} .kp div{font-size:6pt} .kp b{font-size:12pt}
.sum{font-size:7.6pt;line-height:1.45;background:#EEF5F8;border-left:1.2mm solid #00B5AD;border-radius:1.2mm;padding:2mm 3.5mm;margin:2.5mm 0 1mm}
.g2{display:grid;grid-template-columns:1fr 1fr;gap:3mm;margin-bottom:2mm} .cbox{border:.3mm solid #D3E1E7;border-radius:1.5mm;padding:1.5mm 2.5mm;margin-bottom:2mm}
.ct,.ct2{font-size:7pt;font-weight:900;color:#005B7F;text-transform:uppercase;letter-spacing:.3pt;margin-bottom:1mm} svg.chart{width:100%;height:auto;display:block}
svg .ax{font-size:6px;fill:#5E7480} .lg{font-size:6pt;color:#5E7480;margin-top:.8mm} .lg i{display:inline-block;width:3mm;height:2mm;border-radius:.5mm;margin:0 1mm 0 2mm;vertical-align:-.2mm}
.t td,.t th{font-size:6.8pt} .t td:nth-child(2){white-space:nowrap} .t td.hi{background:#FBE9CF;color:#8A5A00;font-weight:700} .nt{font-size:6.6pt;color:#17303B;line-height:1.35;margin-top:1mm}
.obs{font-size:7pt} .obs li{margin-bottom:.8mm} .crit{font-size:6pt;color:#5E7480;line-height:1.35;margin-top:2mm} h2{break-after:avoid} .cbox,.t,.g2{break-inside:avoid}
'''
open('pagina.html', 'w').write(f'<!doctype html><html lang=pt-BR><head><meta charset=utf-8><title>Fila e navios</title><base href="file:///mnt/project-files/relatorios-viagens/relatorio-financeiro/gerador/"><style>{css}</style></head><body>{html}</body></html>')
