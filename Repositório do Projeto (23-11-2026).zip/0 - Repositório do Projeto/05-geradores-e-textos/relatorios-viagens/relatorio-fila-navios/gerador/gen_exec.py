import pickle, pandas as pd, numpy as np
R = pickle.load(open('res.pkl', 'rb'))
n0 = lambda x: f'{x:,.0f}'.replace(',', '.')
f1 = lambda x: f'{x:,.1f}'.replace(',', '#').replace('.', ',').replace('#', '.')
pct = lambda x: f'{x*100:.0f}%'
nv, sd, SG, SS, D, pz = R['nav'], R['saida'], R['sg'], R['ssi'], R['ssi_dia'], R['pz']
DS = {9: 'seg', 10: 'ter', 11: 'qua', 12: 'qui', 13: 'sex', 14: 'sáb', 15: 'dom', 16: 'seg'}
q = R['oc_q']; ev = R['ev_all']; offs = R['offs']

def ev_chart():
    W, H, pl, pr, pt, pb = 300, 170, 34, 8, 14, 22
    lo, hi = -10, 10
    X = lambda i: pl + i * (W - pl - pr) / (len(offs) - 1); Y = lambda v: pt + (hi - v) / (hi - lo) * (H - pt - pb)
    g = [f'<svg viewBox="0 0 {W} {H}" class=chart>']
    g.append(f'<rect x={pl} y={Y(1):.1f} width={W-pl-pr} height={Y(-1)-Y(1):.1f} fill="#00B5AD" opacity=".12"/>')
    i0 = offs.index(0); x0 = X(i0)
    g.append(f'<line x1={x0:.1f} x2={x0:.1f} y1={pt} y2={H-pb} stroke="#E39B2D" stroke-width="1.2" stroke-dasharray="3 2"/><text x={x0+3:.1f} y={pt+8} style="font-size:9px;fill:#B5731A;font-weight:700">navio passa</text>')
    for v in (-10, -5, 0, 5, 10):
        g.append(f'<line x1={pl} x2={W-pr} y1={Y(v):.1f} y2={Y(v):.1f} stroke="{"#5E7480" if v==0 else "#E3ECF0"}" stroke-width="{0.8 if v==0 else 0.5}"/><text x={pl-4} y={Y(v)+3:.1f} text-anchor=end class=ax>{("+" if v>0 else "")}{v} min</text>')
    for i, o in enumerate(offs):
        if o % 2 == 0: g.append(f'<text x={X(i):.1f} y={H-pb+13} text-anchor=middle class=ax>{("+" if o>0 else "")}{o*15} min</text>')
    g.append('<polyline fill=none stroke="#005B7F" stroke-width="2.4" points="%s"/>' % ' '.join(f'{X(i):.1f},{Y(v):.1f}' for i, v in enumerate(ev)))
    g += [f'<circle cx={X(i):.1f} cy={Y(v):.1f} r="2.4" fill="#005B7F"/>' for i, v in enumerate(ev)]
    g.append(f'<text x={W-pr-2} y={Y(1)-3:.1f} text-anchor=end style="font-size:9px;fill:#008C86;font-weight:700">faixa de ±1 min</text>')
    g.append('</svg>'); return ''.join(g)

def gap_chart():
    W, H = 300, 120; mx = 10
    rows = [('Intervalo normal entre saídas', sd['mg_med'], '#9CC3D3'), ('Intervalo na saída após o navio', sd['gap_med'], '#005B7F')]
    g = [f'<svg viewBox="0 0 {W} {H}" class=chart>']
    for i, (lab, v, col) in enumerate(rows):
        y = 10 + i * 52; w = v / mx * (W - 80)
        g.append(f'<text x=0 y={y+11} style="font-size:11px;fill:#17303B;font-weight:700">{lab}</text>')
        g.append(f'<rect x=0 y={y+16} width={w:.1f} height=20 rx="3" fill="{col}"/><text x={w+6:.1f} y={y+31} style="font-size:14px;font-weight:900;fill:{col if i else "#5E7480"}">{f1(v)} min</text>')
    g.append('</svg>'); return ''.join(g)

def ssi_chart():
    W, H, pl, pr, pt, pb = 600, 140, 38, 44, 14, 26; n = len(D); bw = (W - pl - pr) / n
    Yf = lambda v: H - pb - v / 120 * (H - pt - pb); Yo = lambda v: H - pb - v / 8 * (H - pt - pb)
    g = [f'<svg viewBox="0 0 {W} {H}" class=chart>']
    for v in (0, 30, 60, 90, 120):
        g.append(f'<line x1={pl} x2={W-pr} y1={Yf(v):.1f} y2={Yf(v):.1f} stroke="{"#C8553D" if v==60 else "#E3ECF0"}" stroke-width="{0.8 if v==60 else 0.5}" {"stroke-dasharray=\"3 2\"" if v==60 else ""}/><text x={pl-5} y={Yf(v)+3:.1f} text-anchor=end class=ax>{v}%</text>')
    for v in (0, 4, 8): g.append(f'<text x={W-pr+5} y={Yo(v)+3:.1f} class=ax style="fill:#008C86">{v} balsas</text>')
    pss, pib = [], []
    for i, r in enumerate(D.itertuples()):
        x = pl + i * bw; h = r.op / 8 * (H - pt - pb)
        g.append(f'<rect x={x+bw*.28:.1f} y={H-pb-h:.1f} width={bw*.44:.1f} height={h:.1f} fill="#CDEFEC" rx="2"/><text x={x+bw/2:.1f} y={H-pb-4:.1f} text-anchor=middle style="font-size:8px;fill:#00796F;font-weight:700">{f1(r.op)}</text>')
        g.append(f'<text x={x+bw/2:.1f} y={H-pb+12} text-anchor=middle class=ax style="font-size:8px">{DS[r.d]} {r.d:02d}/11</text>')
        pss.append((x + bw / 2, Yf(r.fss))); pib.append((x + bw / 2, Yf(r.fib)))
    for pts, col in ((pss, '#005B7F'), (pib, '#E39B2D')):
        g.append('<polyline fill=none stroke="%s" stroke-width="2.2" points="%s"/>' % (col, ' '.join(f'{a:.1f},{b:.1f}' for a, b in pts)))
        g += [f'<circle cx={a:.1f} cy={b:.1f} r="3" fill="{col}"/>' for a, b in pts]
    g.append('</svg>'); return ''.join(g)


DD = pickle.load(open('dados.pkl', 'rb')); S0 = DD['S']; NN = DD['N']
sgx = S0[S0.trav == 'Santos/Guarujá']; ssx = S0[S0.trav == 'São Sebastião/Ilhabela']
HSG = sgx.groupby('h').agg(fila=('fila', 'mean'), frota=('frota', 'mean'))
HSG['nav'] = NN[NN.trav == 'Santos/Guarujá'].ini.dt.hour.value_counts().reindex(range(24), fill_value=0) / 8
HSS = ssx.groupby('h').agg(fila=('fila', 'mean'), frota=('frota', 'mean'))
sgd = sgx[(sgx.h >= 6) & (sgx.h < 22)].groupby(sgx.d.dt.day).agg(fila=('fila', 'mean'), zero=('fila', lambda z: (z == 0).mean()), veic=('veic', 'sum'))
f_a, f_b = sgd.fila.loc[9:12].mean(), sgd.fila.loc[13:16].mean(); z_b = sgd.zero.loc[13:16].mean()
nmad = HSG.fila.loc[0:5].mean(); fmad = HSG.frota.loc[0:5].mean(); ndia = HSG.fila.loc[6:21].mean(); fdia = HSG.frota.loc[6:21].mean()

def hour_chart(H_, bars, bl, mxf=40, mxb=4):
    W, H, pl, pr, pt, pb = 600, 130, 38, 30, 12, 22; n = 24; bw = (W - pl - pr) / n
    Yf = lambda v: H - pb - v / mxf * (H - pt - pb); Yb = lambda v: H - pb - v / mxb * (H - pt - pb)
    g = [f'<svg viewBox="0 0 {W} {H}" class=chart>']
    for v in range(0, mxf + 1, 10):
        g.append(f'<line x1={pl} x2={W-pr} y1={Yf(v):.1f} y2={Yf(v):.1f} stroke="#E3ECF0" stroke-width=".5"/><text x={pl-5} y={Yf(v)+3:.1f} text-anchor=end class=ax>{v}%</text>')
    for v in (0, mxb / 2, mxb): g.append(f'<text x={W-pr+5} y={Yb(v)+3:.1f} class=ax style="fill:#008C86">{v:g}</text>')
    pts = []
    for h in range(24):
        x = pl + h * bw; b = bars[h]
        g.append(f'<rect x={x+bw*.2:.1f} y={Yb(b):.1f} width={bw*.6:.1f} height={Yb(0)-Yb(b):.1f} fill="#CDEFEC" rx="1.5"/>')
        if h % 2 == 0: g.append(f'<text x={x+bw/2:.1f} y={H-pb+12} text-anchor=middle class=ax>{h:02d}h</text>')
        pts.append((x + bw / 2, Yf(H_.fila[h])))
    g.append('<polyline fill=none stroke="#005B7F" stroke-width="2.2" points="%s"/>' % ' '.join(f'{a:.1f},{b:.1f}' for a, b in pts))
    g += [f'<circle cx={a:.1f} cy={b:.1f} r="2.2" fill="#005B7F"/>' for a, b in pts]
    g.append('</svg>'); return ''.join(g)

OC = R['oc']; LAB = {'Ajuste de demanda (vazia, troca, antecipada)': 'Ajuste de demanda (viagem vazia, troca, antecipação)', 'Emergência / viagem especial': 'Emergência / viagem especial',
     'Maré': 'Maré', 'Infraestrutura / atracadouro': 'Atracadouro / rampa / interdição', 'Falha / manutenção': 'Falha / manutenção', 'Vento': 'Vento', 'Outras': 'Outros comentários', 'Sem descrição': 'Sem comentário'}
def octab():
    rows = []
    for cat in LAB:
        a = OC[(OC.cat == cat) & (OC.trav == 'Santos/Guarujá')]; b = OC[(OC.cat == cat) & (OC.trav == 'São Sebastião/Ilhabela')]
        na = int(a.n.sum()) if len(a) else 0; nb = int(b.n.sum()) if len(b) else 0
        if na + nb == 0: continue
        ra = f'{a.res.iloc[0]:+.1f} min'.replace('.', ',') if na else '–'; rb = f'{b.res.iloc[0]:+.1f} min'.replace('.', ',') if nb else '–'
        rows.append(f'<tr><td class=m>{LAB[cat]}</td><td class=r>{na or "–"}</td><td class=r>{ra}</td><td class=r>{nb or "–"}</td><td class=r>{rb}</td></tr>')
    return '<table class="t big"><tr><th>Ocorrência (pelo comentário)</th><th class=r>Santos ⇄ Guarujá</th><th class=r>Efeito na fila</th><th class=r>S. Sebastião ⇄ Ilhabela</th><th class=r>Efeito na fila</th></tr>' + ''.join(rows) + '</table>'

X = pickle.load(open('mov.pkl', 'rb')); XG = X[X.trav == 'Santos/Guarujá']; XS = X[X.trav == 'São Sebastião/Ilhabela']; XSD = XS[XS.reg == 'DEM']
HG = XG.groupby('h')[['fila', 'oper', 'aguard', 'disp', 'manut']].mean(); HS = XS.groupby('h')[['oper', 'aguard', 'disp', 'manut']].mean(); HS['fila'] = XSD[XSD.h >= 6].groupby('h').fila.mean()
gn = XG[(XG.h >= 3) & (XG.h < 6)]; g_alta = (XG.fila >= 30).sum(); g_alta_n = (XG[XG.h < 6].fila >= 30).sum()
st = XSD[(XSD.h >= 12) & (XSD.h < 19)]; sm = XSD[(XSD.h >= 6) & (XSD.h < 12)]
RG = pickle.load(open('regime.pkl', 'rb')); RD = RG[RG.reg == 'DEM'].copy(); RD['h'] = RD.dt.dt.hour
TRS = [('Santos/Guarujá', 'Santos ⇄ Guarujá', 'DU 06h30–20h · sáb. e dom. 09h–21h'), ('São Sebastião/Ilhabela', 'São Sebastião ⇄ Ilhabela', '05h30–23h30'),
       ('Natividade da Serra/B. Natividade da Serra', 'Natividade da Serra', 'faixas da grade'), ('Ribeirão Branco/Capim DAngola', "Ribeirão Branco ⇄ Capim D'Angola", '06h–23h20'), ('Comércio/Varginha', 'Comércio ⇄ Varginha', '06h–23h15')]
def demtab():
    rows = ''
    def row(nm, sub, g):
        ph = g.groupby('h').Tempo.mean(); pk = f'{ph.idxmax():02d}h' if ph.max() > 0 else '–'
        return (f'<tr><td class=m>{nm}<br><span style="font-weight:400;color:#5E7480">{sub}</span></td><td class=r>{n0(g.Tempo.mode()[0])} min</td><td class=r>{pct((g.Tempo == 0).mean())}</td>'
                f'<td class=r>{pct((g.Tempo >= 30).mean())}</td><td class="r {"hi" if (g.Tempo >= 60).mean() >= .1 else ""}">{pct((g.Tempo >= 60).mean())}</td><td class=r>{n0(g.Tempo.max())} min</td><td class=r>{pk}</td></tr>')
    for t, nm, hr in TRS[:2]:
        for mg, g in RD[RD.Travessia == t].groupby('Margem'): rows += row(f'{nm} · {mg}', f'sob demanda {hr}', g)
    rows += row('Paraibuna · Natividade, Paraitinga e Varginha', 'sob demanda nas faixas da grade, as duas margens', RD[RD.Travessia.isin([t for t, _, _ in TRS[2:]])])
    return ('<table class="t big"><tr><th>Travessia · margem</th><th class=r>Fila mais comum</th><th class=r>Sem fila</th><th class=r>30 min ou mais</th>'
            '<th class=r>60 min ou mais</th><th class=r>Máxima</th><th class=r>Hora de maior fila</th></tr>' + rows + '</table>')
PAR = RD[RD.Travessia.isin([t for t, _, _ in TRS[2:]])]
COLS = [('oper', '#005B7F', 'em operação'), ('aguard', '#E39B2D', 'tripulada aguardando demanda'), ('disp', '#C9D6DC', 'disponível (não tripulada)'), ('manut', '#C8553D', 'em manutenção')]
def frota_chart(Hd, mxf, mxb, fix_ate=None, fix_de=None):
    W, H, pl, pr, pt, pb = 600, 112, 38, 34, 8, 20; bw = (W - pl - pr) / 24
    Yf = lambda v: H - pb - v / mxf * (H - pt - pb); Yb = lambda v: H - pb - v / mxb * (H - pt - pb)
    g = [f'<svg viewBox="0 0 {W} {H}" class=chart>']
    if fix_ate:
        g.append(f'<rect x={pl} y={pt} width={fix_ate*bw:.1f} height={H-pt-pb} fill="#F1F4F6"/><text x={pl+fix_ate*bw/2:.1f} y={pt+9} text-anchor=middle style="font-size:8.5px;fill:#5E7480;font-weight:700">regime fixo</text>')
    if fix_de:
        g.append(f'<rect x={pl+fix_de*bw:.1f} y={pt} width={(24-fix_de)*bw:.1f} height={H-pt-pb} fill="#F1F4F6"/><text x={pl+(fix_de+(24-fix_de)/2)*bw:.1f} y={pt+9} text-anchor=middle style="font-size:8.5px;fill:#5E7480;font-weight:700">regime fixo</text>')
    for v in range(0, mxf + 1, mxf // 4):
        g.append(f'<line x1={pl} x2={W-pr} y1={Yf(v):.1f} y2={Yf(v):.1f} stroke="#E3ECF0" stroke-width=".5"/><text x={pl-5} y={Yf(v)+3:.1f} text-anchor=end class=ax>{v}%</text>')
    for v in (0, mxb // 2, mxb): g.append(f'<text x={W-pr+5} y={Yb(v)+3:.1f} class=ax style="fill:#5E7480">{v}</text>')
    pts = []
    for h in range(24):
        x = pl + h * bw; acc = 0
        for k, col, _ in COLS:
            v = Hd[k][h]
            if v > 0.02: g.append(f'<rect x={x+bw*.18:.1f} y={Yb(acc+v):.1f} width={bw*.64:.1f} height={Yb(acc)-Yb(acc+v):.1f} fill="{col}" opacity="{.85 if k=="oper" else 1}"/>')
            acc += v
        if h % 2 == 0: g.append(f'<text x={x+bw/2:.1f} y={H-pb+12} text-anchor=middle class=ax>{h:02d}h</text>')
        fv = Hd.alta.get(h, np.nan)
        if pd.notna(fv): pts.append((x + bw / 2, Yf(fv)))
    g.append('<polyline fill=none stroke="#17303B" stroke-width="2.4" points="%s"/>' % ' '.join(f'{a:.1f},{b:.1f}' for a, b in pts))
    g += [f'<circle cx={a:.1f} cy={b:.1f} r="2.4" fill="#fff" stroke="#17303B" stroke-width="1.4"/>' for a, b in pts]
    g.append('</svg>'); return ''.join(g)
LGF = '<div class=lg>' + ''.join(f'<i style="background:{c}"></i>{l} ' for _, c, l in COLS) + '<i style="background:#17303B;height:.6mm;vertical-align:.6mm"></i>% de registros com fila alta (eixo à esquerda) · balsas no eixo à direita</div>'

DM = pickle.load(open('demanda.pkl', 'rb')); DM['d'] = DM.dt.dt.day
DM['thr'] = np.where(DM.Travessia == 'Santos/Guarujá', 30, 60); DM['alta'] = DM.Tempo >= DM.thr
HG['alta'] = DM[DM.Travessia == 'Santos/Guarujá'].groupby('h').alta.mean() * 100
HS['alta'] = DM[(DM.Travessia == 'São Sebastião/Ilhabela') & (DM.h >= 6)].groupby('h').alta.mean() * 100
def pico(tr, mg, faixa=None):
    g = DM[(DM.Travessia == tr) & (DM.Margem == mg)]
    if faixa: g = g[(g.h >= faixa[0]) & (g.h < faixa[1])]
    ph = g.groupby('h').alta.mean(); return ph.idxmax(), ph.max()
pIB = pico('São Sebastião/Ilhabela', 'Ilhabela', (6, 24)); pSS = pico('São Sebastião/Ilhabela', 'São Sebastião', (6, 24)); pGJ = pico('Santos/Guarujá', 'Guarujá'); pST = pico('Santos/Guarujá', 'Santos')
sgx2 = DM[DM.Travessia == 'Santos/Guarujá']; pre, pos = sgx2[sgx2.d <= 12], sgx2[sgx2.d >= 13]
gjm = DM[(DM.Travessia == 'Santos/Guarujá') & (DM.Margem == 'Guarujá') & (DM.h >= 7) & (DM.h < 9)]
stt = DM[(DM.Travessia == 'Santos/Guarujá') & (DM.Margem == 'Santos') & (DM.h >= 17) & (DM.h < 20)]
def heat():
    rows = [('Ilhabela', 'São Sebastião/Ilhabela', 'Ilhabela'), ('São Sebastião', 'São Sebastião/Ilhabela', 'São Sebastião'), ('Guarujá', 'Santos/Guarujá', 'Guarujá'), ('Santos', 'Santos/Guarujá', 'Santos')]
    W, cw, lw, rh = 720, 26, 96, 22; H = 18 + rh * len(rows) + 4
    g = [f'<svg viewBox="0 0 {W} {H}" class=chart>']
    for h in range(24): g.append(f'<text x={lw+h*cw+cw/2} y=11 text-anchor=middle style="font-size:9px;fill:#5E7480;font-weight:700">{h:02d}h</text>')
    for r, (nm, tr, mg) in enumerate(rows):
        y = 16 + r * rh; x_ = DM[(DM.Travessia == tr) & (DM.Margem == mg)]; ph = x_.groupby('h').alta.mean()
        g.append(f'<text x={lw-6} y={y+rh/2+4} text-anchor=end style="font-size:10px;font-weight:900;fill:#17303B">{nm}</text>')
        for h in range(24):
            x = lw + h * cw
            if h not in ph.index:
                g.append(f'<rect x={x+1} y={y+1} width={cw-2} height={rh-2} rx="2" fill="#EEF1F3"/><text x={x+cw/2} y={y+rh/2+3} text-anchor=middle style="font-size:7px;fill:#9AA9B1">fixo</text>'); continue
            v = ph[h]; col = '#E8F6F5' if v < .1 else '#FBE7C6' if v < .25 else '#F3B28C' if v < .45 else '#D9694E' if v < .6 else '#A23E28'
            g.append(f'<rect x={x+1} y={y+1} width={cw-2} height={rh-2} rx="2" fill="{col}"/><text x={x+cw/2} y={y+rh/2+3.5} text-anchor=middle style="font-size:8.5px;font-weight:700;fill:{"#fff" if v >= .45 else "#17303B"}">{v*100:.0f}</text>')
    g.append('</svg>'); return ''.join(g)
HLEG = ('<div class=lg>% dos registros com fila alta (Ilhabela e São Sebastião: 60 min ou mais · Santos e Guarujá: 30 min ou mais) '
        + ''.join(f'<i style="background:{c}"></i>{l}' for c, l in [('#E8F6F5', 'menos de 10%'), ('#FBE7C6', '10–24%'), ('#F3B28C', '25–44%'), ('#D9694E', '45–59%'), ('#A23E28', '60% ou mais'), ('#EEF1F3', 'horário fixo')]) + '</div>')
moda = lambda tr, mg: DM[(DM.Travessia == tr) & (DM.Margem == mg)].Tempo.mode()[0]
ib = DM[(DM.Travessia == 'São Sebastião/Ilhabela') & (DM.Margem == 'Ilhabela') & (DM.h >= 6) & (DM.h < 22)]
ibv = ib.Tempo.value_counts(normalize=True)
ibt, ibm = ib[(ib.h >= 14) & (ib.h < 18)], ib[(ib.h >= 6) & (ib.h < 11)]
def voltab():
    rows = ''
    for tr, mg, nm in [('São Sebastião/Ilhabela', 'Ilhabela', 'Ilhabela'), ('São Sebastião/Ilhabela', 'São Sebastião', 'São Sebastião'), ('Santos/Guarujá', 'Guarujá', 'Guarujá'), ('Santos/Guarujá', 'Santos', 'Santos')]:
        g = DM[(DM.Travessia == tr) & (DM.Margem == mg)].copy()
        if tr.startswith('São'): g = g[(g.h >= 6) & (g.h < 22)]
        g['vq'] = pd.qcut(g.veic60.rank(method='first'), 4, labels=False)
        q = g.groupby('vq').agg(v=('veic60', 'mean'), p=('vpv', 'mean'), a=('alta', 'mean'))
        cells = ''.join(f'<td class="r {"hi" if r.a >= .3 else ""}">{pct(r.a)}<br><span class=sm>{n0(r.v)} veíc./h · {n0(r.p)} por viagem</span></td>' for r in q.itertuples())
        a, b = g[g.alta], g[~g.alta]
        rows += (f'<tr><td class=m>{nm}<br><span class=sm>fila alta = {"60" if tr.startswith("São") else "30"} min ou mais</span></td>{cells}'
                 f'<td class=r>{f1(a.oper.mean())} × {f1(b.oper.mean())}</td><td class=r>{f1(a.viag60.mean())} × {f1(b.viag60.mean())}</td></tr>')
    return ('<table class="t big vt"><tr><th>Margem de embarque</th><th class=r>Volume baixo</th><th class=r>Médio-baixo</th><th class=r>Médio-alto</th><th class=r>Volume alto</th>'
            '<th class=r>Balsas operando<br>fila alta × resto</th><th class=r>Viagens na hora<br>fila alta × resto</th></tr>' + rows + '</table>')
SD = DM[(DM.Travessia == 'São Sebastião/Ilhabela') & (DM.h >= 8) & (DM.h < 18)].groupby(['d', 'Margem']).alta.mean().unstack()
d = D.set_index('d')
mxev = max(abs(v) for v in ev)
ssd = ''.join(f'<tr><td class=m>{DS[r.d]} {r.d:02d}/11</td><td class=r>{f1(r.op)}</td><td>{r.ms or "–"}</td><td class=r>{n0(r.veic)}</td>'
              f'<td class="r {"hi" if SD.loc[r.d, "São Sebastião"] >= .3 else ""}">{pct(SD.loc[r.d, "São Sebastião"])}</td><td class="r {"hi" if SD.loc[r.d, "Ilhabela"] >= .3 else ""}">{pct(SD.loc[r.d, "Ilhabela"])}</td></tr>' for r in D.itertuples())
hh = lambda h: f'{h:02d}h'

NG, NR = pickle.load(open('navio.pkl', 'rb'))
evG, evS = NR['ev']['Guarujá'][0] * 100, NR['ev']['Santos'][0] * 100
s_antes, s_dep = evS[:4].mean(), evS[6:10].mean(); g_antes, g_dep = evG[:4].mean(), evG[6:10].mean()
PN = NR['por_n_m']
def ev2_chart():
    W, H, pl, pr, pt, pb = 300, 165, 34, 10, 14, 22; lo, hi = 0, 30; offs2 = list(range(-4, 7))
    X = lambda i: pl + i * (W - pl - pr) / 10; Y = lambda v: pt + (hi - v) / (hi - lo) * (H - pt - pb)
    g = [f'<svg viewBox="0 0 {W} {H}" class=chart>']
    for v in (0, 10, 20, 30): g.append(f'<line x1={pl} x2={W-pr} y1={Y(v):.1f} y2={Y(v):.1f} stroke="#E3ECF0" stroke-width=".5"/><text x={pl-4} y={Y(v)+3:.1f} text-anchor=end class=ax>{v}%</text>')
    x0 = X(4); g.append(f'<line x1={x0:.1f} x2={x0:.1f} y1={pt} y2={H-pb} stroke="#E39B2D" stroke-width="1.2" stroke-dasharray="3 2"/><text x={x0+3:.1f} y={pt+8} style="font-size:9px;fill:#B5731A;font-weight:700">navio passa</text>')
    for i, o in enumerate(offs2):
        if o % 2 == 0: g.append(f'<text x={X(i):.1f} y={H-pb+13} text-anchor=middle class=ax>{("+" if o>0 else "")}{o*15} min</text>')
    for ser, col, nm in ((evG, '#9CC3D3', 'Guarujá'), (evS, '#005B7F', 'Santos')):
        g.append('<polyline fill=none stroke="%s" stroke-width="2.4" points="%s"/>' % (col, ' '.join(f'{X(i):.1f},{Y(v):.1f}' for i, v in enumerate(ser))))
        g += [f'<circle cx={X(i):.1f} cy={Y(v):.1f} r="2.3" fill="{col}"/>' for i, v in enumerate(ser)]
        g.append(f'<text x={W-pr} y={Y(ser[-2])-5:.1f} text-anchor=end style="font-size:9px;font-weight:900;fill:{col}">{nm}</text>')
    g.append('</svg>'); return ''.join(g)
def nn_chart():
    W, H, pl, pb = 300, 165, 10, 34; mx = 25; bw = 26
    g = [f'<svg viewBox="0 0 {W} {H}" class=chart>']
    lab = ['nenhum', '1', '2', '3 ou mais']
    for k in range(4):
        x = pl + 8 + k * 72
        for j, (mg, col) in enumerate((('Guarujá', '#9CC3D3'), ('Santos', '#005B7F'))):
            v = PN.loc[(mg, k), 'alta'] * 100; h = v / mx * (H - pb - 18); xx = x + j * (bw + 3)
            g.append(f'<rect x={xx} y={H-pb-h:.1f} width={bw} height={h:.1f} rx="2" fill="{col}"/><text x={xx+bw/2} y={H-pb-h-4:.1f} text-anchor=middle style="font-size:10px;font-weight:900;fill:{"#5E7480" if j == 0 else col}">{v:.0f}%</text>')
        g.append(f'<text x={x+bw+1.5} y={H-pb+14} text-anchor=middle style="font-size:10px;font-weight:700;fill:#17303B">{lab[k]}</text>')
    g.append(f'<text x={W/2} y={H-4} text-anchor=middle class=ax>navios na última hora</text>')
    g.append('</svg>'); return ''.join(g)
def nh_chart():
    H_ = NR['h']; hs = list(H_.index); W, H, pl, pr, pt, pb = 600, 120, 36, 44, 10, 22; bw = (W - pl - pr) / len(hs)
    Yb = lambda v: H - pb - v / 4 * (H - pt - pb); Yl = lambda v: H - pb - v / 60 * (H - pt - pb)
    g = [f'<svg viewBox="0 0 {W} {H}" class=chart>']
    for v in (0, 20, 40, 60): g.append(f'<line x1={pl} x2={W-pr} y1={Yl(v):.1f} y2={Yl(v):.1f} stroke="#E3ECF0" stroke-width=".5"/><text x={pl-4} y={Yl(v)+3:.1f} text-anchor=end class=ax>{v}%</text>')
    for v in (0, 2, 4): g.append(f'<text x={W-pr+5} y={Yb(v)+3:.1f} class=ax style="fill:#B5731A">{v} navios</text>')
    pts = []
    for i, h in enumerate(hs):
        x = pl + i * bw; b = H_.nav[h]
        g.append(f'<rect x={x+bw*.25:.1f} y={Yb(b):.1f} width={bw*.5:.1f} height={Yb(0)-Yb(b):.1f} rx="2" fill="#F6D8A8"/><text x={x+bw/2:.1f} y={H-pb+12} text-anchor=middle class=ax>{h:02d}h</text>')
        pts.append((x + bw / 2, Yl(H_.alta[h] * 100)))
    g.append('<polyline fill=none stroke="#005B7F" stroke-width="2.4" points="%s"/>' % ' '.join(f'{a:.1f},{b:.1f}' for a, b in pts))
    g += [f'<circle cx={a:.1f} cy={b:.1f} r="2.4" fill="#005B7F"/>' for a, b in pts]
    g.append('</svg>'); return ''.join(g)

html = f'''<div class=hero><div class=pat></div><div class=eb>Relatório executivo · operação</div><h1>Passagens de navio e tempo de fila</h1>
<div class=per>09 a 16/11/2026 · Santos ⇄ Guarujá e São Sebastião ⇄ Ilhabela · só horários de regime sob demanda (grade REV04)</div><div class=w></div></div>
<div class=part>Parte 1 · Passagens de navio</div>
<div class=kp4>
<div><span>Passagens de navio</span><b>{n0(nv['por_dia'])}/dia</b><small>{NR['n_dem']} das {NR['n_tot']} em horário sob demanda · {f1(nv['dur_med'])} min cada</small></div>
<div class=at><span>Frequência</span><b>{pct(NR['Guarujá']['pct_nav'])}</b><small>das janelas de 15 min têm navio na meia hora anterior</small></div>
<div class=at><span>Intervalo entre saídas após o navio</span><b>{f1(sd['gap_med'])} min</b><small>no normal, uma balsa sai a cada {f1(sd['mg_med'])} min</small></div>
<div class=cr><span>Fila alta em Santos após o navio</span><b>{n0(s_antes)}% → {n0(s_dep)}%</b><small>dos registros com fila de 30 min ou mais, antes e 30 a 75 min depois · Guarujá sem mudança</small></div></div>
<div class=conc>
<div><i>1</i><p><b>O navio passa o tempo todo.</b> São cerca de 2 por hora nos horários sob demanda, e quase toda janela tem navio por perto. O horário com mais navios não é o de mais fila.</p></div>
<div><i>2</i><p><b>Ele pausa as saídas por cerca de 5 min,</b> mas a balsa seguinte leva {n0(sd['veic'])} veículos, o mesmo que as outras ({n0(sd['mv'])}).</p></div>
<div><i>3</i><p><b>Em Santos a fila alta sobe um pouco depois do navio:</b> de {n0(s_antes)}% para {n0(s_dep)}% dos registros, entre 30 e 75 min depois. Em Guarujá não muda ({n0(g_antes)}% → {n0(g_dep)}%).</p></div>
<div><i>4</i><p><b>O efeito cresce quando passam vários navios seguidos:</b> com 3 ou mais na última hora, {pct(PN.loc[("Santos", 3), "alta"])} dos registros em Santos têm fila alta, contra {pct(PN.loc[("Santos", 0), "alta"])} sem navio. É efeito secundário: a causa principal da fila é a demanda (Parte 2).</p></div></div>
<h2><span class=n>1</span>Santos ⇄ Guarujá · passagens de navio × fila</h2>
<div class=g2><div class=cbox><div class=ct>% de registros com fila alta antes e depois da passagem</div>{ev2_chart()}<div class=cap>Santos sobe de {n0(s_antes)}% para {n0(s_dep)}% entre +30 e +75 min. Guarujá fica estável.</div></div>
<div class=cbox><div class=ct>% de registros com fila alta × navios na última hora</div>{nn_chart()}<div class=cap><i class=lgd style="background:#9CC3D3"></i>Guarujá <i class=lgd style="background:#005B7F"></i>Santos · volume de veículos parecido nos 4 grupos.</div></div></div>
<div class=cbox style="margin-top:2.5mm"><div class=ct>Navios por hora × fila alta por hora (Santos ⇄ Guarujá, horários sob demanda)</div>{nh_chart()}<div class=cap><i class=lgd style="background:#F6D8A8"></i>navios por hora <i class=lgd style="background:#005B7F"></i>% de registros com fila alta. Os navios se espalham pelo dia (1 a 3 por hora); a fila alta sobe às 07h–08h e 18h–19h, nos picos de volume. Após o navio, a saída seguinte vem com {f1(sd['gap_med'])} min de intervalo (× {f1(sd['mg_med'])} no normal) e leva {n0(sd['veic'])} veículos, o mesmo que as outras. Paralisações por navio: só 2, ambas em horário fixo.</div></div>
'''
html1b = f'''<div class=part>Parte 2 · Tempo de fila</div>
<div class=kp4>
<div class=cr><span>Ilhabela · maior fila</span><b>{hh(pIB[0])}</b><small><b class=s>{pct(pIB[1])}</b> dos registros com 60 min ou mais</small></div>
<div class=at><span>São Sebastião · maior fila</span><b>{hh(pSS[0])}</b><small><b class=s>{pct(pSS[1])}</b> dos registros com 60 min ou mais</small></div>
<div><span>Guarujá · maior fila</span><b>{hh(pGJ[0])}</b><small><b class=s>{pct(pGJ[1])}</b> dos registros com 30 min ou mais</small></div>
<div class=ok><span>Santos · maior fila</span><b>{hh(pST[0])}</b><small><b class=s>{pct(pST[1])}</b> dos registros com 30 min ou mais</small></div></div>
<div class=hm2><div class=ct>Mapa dos horários de fila alta · só horários sob demanda</div>{heat()}{HLEG}<div class=cap style="font-size:8.5pt"><b>Como ler:</b> o tempo é registrado em degraus (30, 45, 60, 90 ou 120 min). Em Ilhabela, {pct(ibv.get(30, 0))} dos registros são de 30 min; uma média como "50 min" mistura degraus e não aconteceu. Por isso mostramos a % de registros com fila alta.</div></div>
<div class=conc>
<div><i>1</i><p><b>A fila alta acompanha a demanda.</b> Quanto mais veículos embarcam na hora, mais registros de fila alta, nas 4 margens (seção 3).</p></div>
<div><i>2</i><p><b>Santos ⇄ Guarujá tem dois picos:</b> Guarujá das 07h às 09h ({n0(gjm.veic60.mean())} veículos por hora, {n0(gjm.vpv.mean())} por viagem) e Santos das 17h às 20h ({n0(stt.veic60.mean())} por hora, {n0(stt.vpv.mean())} por viagem).</p></div>
<div><i>3</i><p><b>Ilhabela concentra a fila à tarde.</b> Das 14h às 18h saem {n0(ibt.veic60.mean())} veículos por hora, com {n0(ibt.vpv.mean())} por viagem, contra {n0(ibm.veic60.mean())} e {n0(ibm.vpv.mean())} de manhã, com a frota no máximo.</p></div>
<div><i>4</i><p><b>Santos ⇄ Guarujá melhorou a partir de 13/11:</b> registros de 30 min ou mais caíram de {pct(pre.alta.mean())} para {pct(pos.alta.mean())}, com volume parecido.</p></div></div>
'''
html2 = f'''<h2><span class=n>2</span>Hora a hora · situação da frota × fila alta</h2>
<div class=cbox><div class=ct>Santos ⇄ Guarujá · linha = % dos registros com 30 min ou mais (só horários sob demanda)</div>{frota_chart(HG, 100, 10, fix_ate=6, fix_de=21)}
<div class=cap>Nos picos (07h–09h e 17h–20h) operam {f1(DM[(DM.Travessia == 'Santos/Guarujá') & DM.h.isin([7, 8, 17, 18, 19])].oper.mean())} balsas, quase toda a frota. A fila alta sobe com o volume, não com falta de balsa.</div></div>
<div class=cbox style="margin-top:2.5mm"><div class=ct>São Sebastião ⇄ Ilhabela · linha = % dos registros com 60 min ou mais (sob demanda 05h30–23h30)</div>{frota_chart(HS, 100, 8, fix_ate=6)}
<div class=cap>Das 06h às 11h quase nenhum registro chega a 60 min. Das 12h às 18h, de 40% a 55% chegam, com {f1(st.oper.mean())} balsas operando e {f1(st.manut.mean())} em manutenção.</div></div>
{LGF}
<h2><span class=n>3</span>Fila × volume transportado e frota</h2>
{voltab()}
<div class=cap>Cada registro foi comparado com os veículos embarcados naquela margem na hora seguinte e dividido em 4 grupos de volume. Célula = % de registros com fila alta no grupo. <b>Nas 4 margens, mais volume = mais fila alta: é demanda.</b> Nas janelas de fila alta o número de balsas operando é praticamente o mesmo das demais.</div>
<h2><span class=n>4</span>São Sebastião ⇄ Ilhabela · dia a dia (08h–18h)</h2>
<div class=g2b><table class="t hm big"><tr><th>Dia</th><th class=r>Balsas em operação</th><th>Paradas (manutenção)</th><th class=r>Veículos no dia</th><th class=r>Fila alta S. Sebastião</th><th class=r>Fila alta Ilhabela</th></tr>{ssd}</table>
<div class=side><div class=pt><b>10/11:</b> {f1(d.op[10])} balsas operando, a menor média da semana. São Sebastião teve fila alta em {pct(SD.loc[10, "São Sebastião"])} dos registros.</div>
<div class=pt><b>14 e 15/11:</b> frota cheia e nenhuma fila alta, mesmo com o maior volume da semana ({n0(d.veic[15])} veículos em 15/11).</div>
<div class=pt><b>16/11:</b> FB-19, FB-30 e FB-GREGA II paradas. Ilhabela teve fila alta em {pct(SD.loc[16, "Ilhabela"])} dos registros.</div>
<div class="pt at"><b>13/11:</b> frota normal e fila alta nas duas margens. Nenhuma ocorrência ou paralisação explica.</div>
</div></div>
<div class=cap>Fila alta = registros de 60 min ou mais, das 08h às 18h.</div>
<h2><span class=n>5</span>Tempo de fila por travessia · só horários sob demanda</h2>
{demtab()}<div class=cap>Registros a cada 15 min, por margem, de 09 a 16/11. Valor 0 = sem fila. Paraibuna: {pct((PAR.Tempo == 0).mean())} dos registros sem fila.</div>
<h2><span class=n>6</span>Ocorrências · classificadas pelo comentário</h2>
{octab()}<div class=cap><b>Nenhuma ocorrência muda a fila em mais de 1 min</b> na comparação com a mesma hora do mesmo dia. As sem Tipo foram classificadas pelo comentário; as de navio estão na seção 1.</div>
<h2><span class=n>7</span>Ações recomendadas</h2>
<div class=acts>
<div><b>Picos de Santos ⇄ Guarujá</b><p>Guarujá 07h–09h e Santos 17h–20h. Programar manutenção fora desses horários e garantir a frota completa.</p></div>
<div><b>Tarde em Ilhabela</b><p>A fila vem do volume. Programar manutenção fora das 12h–18h para ter a frota inteira no pico ({f1(st.manut.mean())} balsa parada em média hoje).</p></div>
<div><b>Santos ⇄ Guarujá desde 13/11</b><p>Identificar o que mudou na operação para a fila cair e manter.</p></div>
</div>
<div class=crit>Como foi feito: só os horários de regime sob demanda da grade REV04 (Santos ⇄ Guarujá DU 06h30–20h, sáb. 09h–20h30, dom. 09h–21h; as faixas "demais" são horário fixo; São Sebastião ⇄ Ilhabela, veículos, 05h30–23h30; Paraibuna nas faixas da aba Conforme Demanda). Nesses horários o tempo registrado é o tempo de fila, e 0 = sem fila. Os horários de regime fixo ficaram fora da análise. Horário do export de tempo ajustado em +3 h para coincidir com o horário das demais bases. Cruzado com viagens, passagens de navio, ocorrências (sem Tipo = classificadas pelo comentário), paralisações e movimentação da frota (situação de cada balsa a cada 15 min). Volume: veículos embarcados na margem na hora seguinte ao registro (base de viagens, campo Término Embarque). Fila alta: 60 min ou mais em São Sebastião ⇄ Ilhabela e 30 min ou mais em Santos ⇄ Guarujá. Variação da fila: cada janela de 15 min comparada com a hora anterior à passagem. Dois registros de passagem com duração irreal (421 e 79 min) foram limitados a 15 min.</div>'''

css = open('../../relatorio-financeiro/gerador/base.css').read() + '''
body{font-size:9pt} .hero h1{font-size:20pt} .hero .per{font-size:9.5pt}
.kp4{display:grid;grid-template-columns:repeat(4,1fr);gap:3mm;margin:3mm 0}
.kp4>div{border:.3mm solid #D3E1E7;border-top:1.4mm solid #005B7F;border-radius:1.8mm;padding:2.2mm 3.5mm}
.kp4 .ok{border-top-color:#00B5AD} .kp4 .at{border-top-color:#E39B2D} .kp4 .cr{border-top-color:#C8553D}
.kp4 span{display:block;font-size:7.5pt;color:#5E7480;text-transform:uppercase;letter-spacing:.3pt;font-weight:700}
.kp4 b{display:block;font-size:22pt;color:#005B7F;line-height:1.15;margin:.8mm 0} .kp4 .ok b{color:#008C86} .kp4 .at b{color:#B5731A} .kp4 .cr b{color:#C8553D}
.kp4 small{font-size:8pt;color:#17303B}
h2{font-size:13pt;margin:4mm 0 2mm;break-after:avoid}
.conc{display:grid;grid-template-columns:1fr 1fr;gap:2.5mm 4mm}
.conc>div{display:flex;gap:3mm;align-items:flex-start;background:#EEF5F8;border-radius:1.8mm;padding:2.5mm 3.5mm}
.conc i{font-style:normal;flex:0 0 7mm;height:7mm;border-radius:50%;background:#005B7F;color:#fff;font-weight:900;font-size:11pt;display:flex;align-items:center;justify-content:center}
.conc p{margin:0;font-size:9.5pt;line-height:1.35} .conc b{color:#005B7F}
.g2{display:grid;grid-template-columns:1fr 1fr;gap:4mm} .cbox{border:.3mm solid #D3E1E7;border-radius:1.8mm;padding:2.5mm 3.5mm;break-inside:avoid}
.ct{font-size:8.5pt;font-weight:900;color:#005B7F;text-transform:uppercase;letter-spacing:.3pt;margin-bottom:1.5mm}
svg.chart{width:100%;height:auto;display:block} svg .ax{font-size:9px;fill:#5E7480}
.cap{font-size:10pt;margin-top:1.5mm;line-height:1.35} .pz{font-size:8.5pt;margin-top:2mm;padding-top:2mm;border-top:.3mm dashed #D3E1E7}
.lg{font-size:8pt;color:#5E7480;margin-top:1mm} .lg i{display:inline-block;width:4mm;height:2.5mm;border-radius:.5mm;margin:0 1.2mm 0 3mm;vertical-align:-.3mm}
.g2b{display:grid;grid-template-columns:1.6fr 1fr;gap:4mm;margin-top:3mm;align-items:start}
.t.big td,.t.big th{font-size:8.5pt;padding:1.1mm 1.8mm} .t td.hi{background:#FBE3DC;color:#A23E28;font-weight:900}
.side .pt{font-size:8.8pt;line-height:1.35;border-left:1mm solid #00B5AD;padding:.6mm 0 .6mm 2.5mm;margin-bottom:1.8mm} .side .pt.at{border-left-color:#E39B2D}
.t td,.t th{white-space:normal} .acts{display:grid;grid-template-columns:repeat(3,1fr);gap:3mm} .acts>div{background:#005B7F;color:#fff;border-radius:1.8mm;padding:2.5mm 3.5mm}
.acts b{display:block;font-size:9.5pt;color:#BFE9E6;margin-bottom:1mm} .acts p{margin:0;font-size:8.8pt;line-height:1.35}
.acts.a4{grid-template-columns:1fr 1fr} .conc .wide{grid-column:1/-1} .note{background:#FFF6E8;border-left:1.2mm solid #E39B2D;border-radius:1.5mm;padding:2.5mm 3.5mm;font-size:9.5pt;line-height:1.4} .sm{font-size:7pt;color:#5E7480;font-weight:400} .vt td{vertical-align:top} .hm2{border:.3mm solid #D3E1E7;border-radius:1.8mm;padding:2.5mm 3.5mm;margin:1mm 0 2mm} .kp4 b.s{display:inline;font-size:inherit;color:inherit;margin:0} table.t,.cbox,.g2b,.acts,.hm2{break-inside:avoid} .part{font-size:15pt;font-weight:900;color:#005B7F;margin:3mm 0 1mm;padding-bottom:1mm;border-bottom:.6mm solid #00B5AD} .lgd{display:inline-block;width:3.5mm;height:2.5mm;border-radius:.5mm;margin:0 1mm 0 2mm;vertical-align:-.2mm} .crit{font-size:7pt;color:#5E7480;line-height:1.4;margin-top:4mm} .pb{break-before:page}
'''
open('pagina_exec.html', 'w').write(f'<!doctype html><html lang=pt-BR><head><meta charset=utf-8><title>Navios e fila</title><base href="file:///mnt/project-files/relatorios-viagens/relatorio-financeiro/gerador/"><style>{css}</style></head><body>{html}{html1b}{html2}</body></html>')
