import pickle, pandas as pd, numpy as np
R = pickle.load(open('res.pkl', 'rb'))
n0 = lambda x: f'{x:,.0f}'.replace(',', '.')
f1 = lambda x: f'{x:,.1f}'.replace(',', '#').replace('.', ',').replace('#', '.')
pct = lambda x: f'{x*100:.0f}%'
nv, sd, SG, SS, D, pz = R['nav'], R['saida'], R['sg'], R['ssi'], R['ssi_dia'], R['pz']
DS = {9: 'seg', 10: 'ter', 11: 'qua', 12: 'qui', 13: 'sex', 14: 'sáb', 15: 'dom', 16: 'seg'}
q = R['oc_q']; ev = R['ev_all']; offs = R['offs']

def ev_chart():
    W, H, pl, pr, pt, pb = 300, 170, 34, 8, 14, 22
    lo, hi = -10, 10
    X = lambda i: pl + i * (W - pl - pr) / (len(offs) - 1); Y = lambda v: pt + (hi - v) / (hi - lo) * (H - pt - pb)
    g = [f'<svg viewBox="0 0 {W} {H}" class=chart>']
    g.append(f'<rect x={pl} y={Y(1):.1f} width={W-pl-pr} height={Y(-1)-Y(1):.1f} fill="#00B5AD" opacity=".12"/>')
    i0 = offs.index(0); x0 = X(i0)
    g.append(f'<line x1={x0:.1f} x2={x0:.1f} y1={pt} y2={H-pb} stroke="#E39B2D" stroke-width="1.2" stroke-dasharray="3 2"/><text x={x0+3:.1f} y={pt+8} style="font-size:9px;fill:#B5731A;font-weight:700">navio passa</text>')
    for v in (-10, -5, 0, 5, 10):
        g.append(f'<line x1={pl} x2={W-pr} y1={Y(v):.1f} y2={Y(v):.1f} stroke="{"#5E7480" if v==0 else "#E3ECF0"}" stroke-width="{0.8 if v==0 else 0.5}"/><text x={pl-4} y={Y(v)+3:.1f} text-anchor=end class=ax>{("+" if v>0 else "")}{v} min</text>')
    for i, o in enumerate(offs):
        if o % 2 == 0: g.append(f'<text x={X(i):.1f} y={H-pb+13} text-anchor=middle class=ax>{("+" if o>0 else "")}{o*15} min</text>')
    g.append('<polyline fill=none stroke="#005B7F" stroke-width="2.4" points="%s"/>' % ' '.join(f'{X(i):.1f},{Y(v):.1f}' for i, v in enumerate(ev)))
    g += [f'<circle cx={X(i):.1f} cy={Y(v):.1f} r="2.4" fill="#005B7F"/>' for i, v in enumerate(ev)]
    g.append(f'<text x={W-pr-2} y={Y(1)-3:.1f} text-anchor=end style="font-size:9px;fill:#008C86;font-weight:700">faixa de ±1 min</text>')
    g.append('</svg>'); return ''.join(g)

def gap_chart():
    W, H = 300, 120; mx = 10
    rows = [('Intervalo normal entre saídas', sd['mg_med'], '#9CC3D3'), ('Intervalo na saída após o navio', sd['gap_med'], '#005B7F')]
    g = [f'<svg viewBox="0 0 {W} {H}" class=chart>']
    for i, (lab, v, col) in enumerate(rows):
        y = 10 + i * 52; w = v / mx * (W - 80)
        g.append(f'<text x=0 y={y+11} style="font-size:11px;fill:#17303B;font-weight:700">{lab}</text>')
        g.append(f'<rect x=0 y={y+16} width={w:.1f} height=20 rx="3" fill="{col}"/><text x={w+6:.1f} y={y+31} style="font-size:14px;font-weight:900;fill:{col if i else "#5E7480"}">{f1(v)} min</text>')
    g.append('</svg>'); return ''.join(g)

def ssi_chart():
    W, H, pl, pr, pt, pb = 600, 140, 38, 44, 14, 26; n = len(D); bw = (W - pl - pr) / n
    Yf = lambda v: H - pb - v / 120 * (H - pt - pb); Yo = lambda v: H - pb - v / 8 * (H - pt - pb)
    g = [f'<svg viewBox="0 0 {W} {H}" class=chart>']
    for v in (0, 30, 60, 90, 120):
        g.append(f'<line x1={pl} x2={W-pr} y1={Yf(v):.1f} y2={Yf(v):.1f} stroke="{"#C8553D" if v==60 else "#E3ECF0"}" stroke-width="{0.8 if v==60 else 0.5}" {"stroke-dasharray=\"3 2\"" if v==60 else ""}/><text x={pl-5} y={Yf(v)+3:.1f} text-anchor=end class=ax>{v} min</text>')
    for v in (0, 4, 8): g.append(f'<text x={W-pr+5} y={Yo(v)+3:.1f} class=ax style="fill:#008C86">{v} balsas</text>')
    pss, pib = [], []
    for i, r in enumerate(D.itertuples()):
        x = pl + i * bw; h = r.op / 8 * (H - pt - pb)
        g.append(f'<rect x={x+bw*.28:.1f} y={H-pb-h:.1f} width={bw*.44:.1f} height={h:.1f} fill="#CDEFEC" rx="2"/><text x={x+bw/2:.1f} y={H-pb-4:.1f} text-anchor=middle style="font-size:8px;fill:#00796F;font-weight:700">{f1(r.op)}</text>')
        g.append(f'<text x={x+bw/2:.1f} y={H-pb+12} text-anchor=middle class=ax style="font-size:8px">{DS[r.d]} {r.d:02d}/11</text>')
        pss.append((x + bw / 2, Yf(r.fss))); pib.append((x + bw / 2, Yf(r.fib)))
    for pts, col in ((pss, '#005B7F'), (pib, '#E39B2D')):
        g.append('<polyline fill=none stroke="%s" stroke-width="2.2" points="%s"/>' % (col, ' '.join(f'{a:.1f},{b:.1f}' for a, b in pts)))
        g += [f'<circle cx={a:.1f} cy={b:.1f} r="3" fill="{col}"/>' for a, b in pts]
    g.append('</svg>'); return ''.join(g)


DD = pickle.load(open('dados.pkl', 'rb')); S0 = DD['S']; NN = DD['N']
sgx = S0[S0.trav == 'Santos/Guarujá']; ssx = S0[S0.trav == 'São Sebastião/Ilhabela']
HSG = sgx.groupby('h').agg(fila=('fila', 'mean'), frota=('frota', 'mean'))
HSG['nav'] = NN[NN.trav == 'Santos/Guarujá'].ini.dt.hour.value_counts().reindex(range(24), fill_value=0) / 8
HSS = ssx.groupby('h').agg(fila=('fila', 'mean'), frota=('frota', 'mean'))
sgd = sgx[(sgx.h >= 6) & (sgx.h < 22)].groupby(sgx.d.dt.day).agg(fila=('fila', 'mean'), zero=('fila', lambda z: (z == 0).mean()), veic=('veic', 'sum'))
f_a, f_b = sgd.fila.loc[9:12].mean(), sgd.fila.loc[13:16].mean(); z_b = sgd.zero.loc[13:16].mean()
nmad = HSG.fila.loc[0:5].mean(); fmad = HSG.frota.loc[0:5].mean(); ndia = HSG.fila.loc[6:21].mean(); fdia = HSG.frota.loc[6:21].mean()

def hour_chart(H_, bars, bl, mxf=40, mxb=4):
    W, H, pl, pr, pt, pb = 600, 130, 38, 30, 12, 22; n = 24; bw = (W - pl - pr) / n
    Yf = lambda v: H - pb - v / mxf * (H - pt - pb); Yb = lambda v: H - pb - v / mxb * (H - pt - pb)
    g = [f'<svg viewBox="0 0 {W} {H}" class=chart>']
    for v in range(0, mxf + 1, 10):
        g.append(f'<line x1={pl} x2={W-pr} y1={Yf(v):.1f} y2={Yf(v):.1f} stroke="#E3ECF0" stroke-width=".5"/><text x={pl-5} y={Yf(v)+3:.1f} text-anchor=end class=ax>{v} min</text>')
    for v in (0, mxb / 2, mxb): g.append(f'<text x={W-pr+5} y={Yb(v)+3:.1f} class=ax style="fill:#008C86">{v:g}</text>')
    pts = []
    for h in range(24):
        x = pl + h * bw; b = bars[h]
        g.append(f'<rect x={x+bw*.2:.1f} y={Yb(b):.1f} width={bw*.6:.1f} height={Yb(0)-Yb(b):.1f} fill="#CDEFEC" rx="1.5"/>')
        if h % 2 == 0: g.append(f'<text x={x+bw/2:.1f} y={H-pb+12} text-anchor=middle class=ax>{h:02d}h</text>')
        pts.append((x + bw / 2, Yf(H_.fila[h])))
    g.append('<polyline fill=none stroke="#005B7F" stroke-width="2.2" points="%s"/>' % ' '.join(f'{a:.1f},{b:.1f}' for a, b in pts))
    g += [f'<circle cx={a:.1f} cy={b:.1f} r="2.2" fill="#005B7F"/>' for a, b in pts]
    g.append('</svg>'); return ''.join(g)

OC = R['oc']; LAB = {'Ajuste de demanda (vazia, troca, antecipada)': 'Ajuste de demanda (viagem vazia, troca, antecipação)', 'Emergência / viagem especial': 'Emergência / viagem especial',
     'Maré': 'Maré', 'Infraestrutura / atracadouro': 'Atracadouro / rampa / interdição', 'Falha / manutenção': 'Falha / manutenção', 'Vento': 'Vento', 'Outras': 'Outros comentários', 'Sem descrição': 'Sem comentário'}
def octab():
    rows = []
    for cat in LAB:
        a = OC[(OC.cat == cat) & (OC.trav == 'Santos/Guarujá')]; b = OC[(OC.cat == cat) & (OC.trav == 'São Sebastião/Ilhabela')]
        na = int(a.n.sum()) if len(a) else 0; nb = int(b.n.sum()) if len(b) else 0
        if na + nb == 0: continue
        ra = f'{a.res.iloc[0]:+.1f} min'.replace('.', ',') if na else '–'; rb = f'{b.res.iloc[0]:+.1f} min'.replace('.', ',') if nb else '–'
        rows.append(f'<tr><td class=m>{LAB[cat]}</td><td class=r>{na or "–"}</td><td class=r>{ra}</td><td class=r>{nb or "–"}</td><td class=r>{rb}</td></tr>')
    return '<table class="t big"><tr><th>Ocorrência (pelo comentário)</th><th class=r>Santos ⇄ Guarujá</th><th class=r>Efeito na fila</th><th class=r>S. Sebastião ⇄ Ilhabela</th><th class=r>Efeito na fila</th></tr>' + ''.join(rows) + '</table>'

X = pickle.load(open('mov.pkl', 'rb')); XG = X[X.trav == 'Santos/Guarujá']; XS = X[X.trav == 'São Sebastião/Ilhabela']; XSD = XS[XS.reg == 'DEM']
HG = XG.groupby('h')[['fila', 'oper', 'aguard', 'disp', 'manut']].mean(); HS = XS.groupby('h')[['oper', 'aguard', 'disp', 'manut']].mean(); HS['fila'] = XSD[XSD.h >= 6].groupby('h').fila.mean()
gn = XG[(XG.h >= 3) & (XG.h < 6)]; g_alta = (XG.fila >= 30).sum(); g_alta_n = (XG[XG.h < 6].fila >= 30).sum()
st = XSD[(XSD.h >= 12) & (XSD.h < 19)]; sm = XSD[(XSD.h >= 6) & (XSD.h < 12)]
RG = pickle.load(open('regime.pkl', 'rb')); FX = RG[(RG.reg == 'FIX') & RG.grade_int.notna() & (RG.grade_int <= 180) & (RG.Tempo > 0)]
NOMES = {'Bertioga/Guarujá': 'Bertioga ⇄ Guarujá', 'Iguape/Juréia': 'Iguape ⇄ Juréia', 'Santos/Vicente de Carvalho': 'Santos ⇄ Vicente de Carvalho', 'Cananéia/Ilha Comprida': 'Cananéia ⇄ Ilha Comprida',
         'Cananéia/Continente': 'Cananéia ⇄ Continente', 'São Sebastião/Ilhabela': 'São Sebastião ⇄ Ilhabela (00h–05h30)'}
FXa = FX.assign(ok=FX.Tempo == FX.grade_int, ok10=(FX.Tempo - FX.grade_int).abs() <= 10, ab=FX.Tempo < FX.grade_int, ac=FX.Tempo > FX.grade_int).groupby('Travessia').agg(
    ok=('ok', 'mean'), ok10=('ok10', 'mean'), ab=('ab', 'mean'), ac=('ac', 'mean'), reg=('Tempo', 'mean'), gr=('grade_int', 'mean')).reindex(list(NOMES)).dropna()
def fixtab():
    rows = ''.join(f'<tr><td class=m>{NOMES[t]}</td><td class="r {"hi" if r.ok < .75 else ""}">{pct(r.ok)}</td><td class=r>{pct(r.ok10)}</td><td class=r>{pct(r.ab)}</td><td class=r>{pct(r.ac)}</td><td class=r>{n0(r.reg)} min</td><td class=r>{n0(r.gr)} min</td></tr>' for t, r in FXa.iterrows())
    return ('<table class="t big"><tr><th>Travessia (regime fixo)</th><th class=r>Igual à grade</th><th class=r>Até 10 min de diferença</th><th class=r>Intervalo menor</th><th class=r>Intervalo maior</th>'
            '<th class=r>Média registrada</th><th class=r>Média da grade</th></tr>' + rows + '</table>')
COLS = [('oper', '#005B7F', 'em operação'), ('aguard', '#E39B2D', 'tripulada aguardando demanda'), ('disp', '#C9D6DC', 'disponível (não tripulada)'), ('manut', '#C8553D', 'em manutenção')]
def frota_chart(Hd, mxf, mxb, fix_ate=None):
    W, H, pl, pr, pt, pb = 600, 112, 38, 34, 8, 20; bw = (W - pl - pr) / 24
    Yf = lambda v: H - pb - v / mxf * (H - pt - pb); Yb = lambda v: H - pb - v / mxb * (H - pt - pb)
    g = [f'<svg viewBox="0 0 {W} {H}" class=chart>']
    if fix_ate:
        g.append(f'<rect x={pl} y={pt} width={fix_ate*bw:.1f} height={H-pt-pb} fill="#F1F4F6"/><text x={pl+fix_ate*bw/2:.1f} y={pt+9} text-anchor=middle style="font-size:8.5px;fill:#5E7480;font-weight:700">regime fixo</text>')
    for v in range(0, mxf + 1, mxf // 4):
        g.append(f'<line x1={pl} x2={W-pr} y1={Yf(v):.1f} y2={Yf(v):.1f} stroke="#E3ECF0" stroke-width=".5"/><text x={pl-5} y={Yf(v)+3:.1f} text-anchor=end class=ax>{v} min</text>')
    for v in (0, mxb // 2, mxb): g.append(f'<text x={W-pr+5} y={Yb(v)+3:.1f} class=ax style="fill:#5E7480">{v}</text>')
    pts = []
    for h in range(24):
        x = pl + h * bw; acc = 0
        for k, col, _ in COLS:
            v = Hd[k][h]
            if v > 0.02: g.append(f'<rect x={x+bw*.18:.1f} y={Yb(acc+v):.1f} width={bw*.64:.1f} height={Yb(acc)-Yb(acc+v):.1f} fill="{col}" opacity="{.85 if k=="oper" else 1}"/>')
            acc += v
        if h % 2 == 0: g.append(f'<text x={x+bw/2:.1f} y={H-pb+12} text-anchor=middle class=ax>{h:02d}h</text>')
        fv = Hd.fila.get(h, np.nan)
        if pd.notna(fv): pts.append((x + bw / 2, Yf(fv)))
    g.append('<polyline fill=none stroke="#17303B" stroke-width="2.4" points="%s"/>' % ' '.join(f'{a:.1f},{b:.1f}' for a, b in pts))
    g += [f'<circle cx={a:.1f} cy={b:.1f} r="2.4" fill="#fff" stroke="#17303B" stroke-width="1.4"/>' for a, b in pts]
    g.append('</svg>'); return ''.join(g)
LGF = '<div class=lg>' + ''.join(f'<i style="background:{c}"></i>{l} ' for _, c, l in COLS) + '<i style="background:#17303B;height:.6mm;vertical-align:.6mm"></i>tempo de fila (eixo à esquerda) · balsas no eixo à direita</div>'

d = D.set_index('d')
mxev = max(abs(v) for v in ev)
vento = pz[pz.tipo == 'Ventos Fortes'].iloc[0]
ssd = ''.join(f'<tr><td class=m>{DS[r.d]} {r.d:02d}/11</td><td class=r>{f1(r.op)}</td><td>{r.ms or "–"}</td>'
              f'<td class="r {"hi" if r.fss >= 60 else ""}">{f1(r.fss)} min</td><td class="r {"hi" if r.fib >= 60 else ""}">{f1(r.fib)} min</td></tr>' for r in D.itertuples())
fb = FXa.loc[['Bertioga/Guarujá', 'Iguape/Juréia']].ok.min(); fsv = FXa.loc['Santos/Vicente de Carvalho']

html = f'''<div class=hero><div class=pat></div><div class=eb>Relatório executivo · operação</div><h1>Passagens de navio e tempo de fila</h1>
<div class=per>09 a 16/11/2026 · fila nos horários sob demanda e intervalo nos horários de regime fixo (grade REV04)</div><div class=w></div></div>
<div class=kp4>
<div><span>Passagens de navio</span><b>{n0(nv['por_dia'])}/dia</b><small>{n0(nv['total'])} no período · {f1(nv['dur_med'])} min cada</small></div>
<div class=ok><span>Efeito na fila</span><b>±{f1(mxev)} min</b><small>a fila não sobe com o navio</small></div>
<div class=at><span>Fila à tarde em Ilhabela</span><b>{n0(st.fila.mean())} min</b><small>12h–19h · {n0(sm.fila.mean())} min de manhã</small></div>
<div class=cr><span>Regime fixo × grade</span><b>{pct(fb)}+</b><small>Bertioga e Juréia seguem a grade</small></div></div>
<h2><span class=n>!</span>Conclusões</h2>
<div class=conc>
<div><i>1</i><p><b>O navio não aumenta a fila.</b> Ele pausa as saídas por cerca de 5 min, e a espera se dilui nas saídas seguintes.</p></div>
<div><i>2</i><p><b>A fila de Santos ⇄ Guarujá é maior de madrugada.</b> Das 03h às 06h: {f1(gn.fila.mean())} min, com {f1(gn.oper.mean())} balsas operando e {f1(gn.disp.mean())} disponíveis.</p></div>
<div><i>3</i><p><b>Em São Sebastião ⇄ Ilhabela a fila sobe à tarde,</b> no pico de demanda: {f1(st.fila.mean())} min das 12h às 19h, com a frota no máximo ({f1(st.oper.mean())} balsas) e {f1(st.manut.mean())} em manutenção.</p></div>
<div><i>4</i><p><b>Em Santos ⇄ Guarujá a fila caiu a partir de 13/11.</b> Média de {f1(f_a)} min (09–12/11) para {f1(f_b)} min (13–16/11), sem fila em {pct(z_b)} do dia, com o mesmo volume.</p></div>
<div class=wide><i>5</i><p><b>Nas travessias de regime fixo, o intervalo registrado segue a grade.</b> Bertioga ⇄ Guarujá e Iguape ⇄ Juréia batem em mais de {pct(fb)} dos horários; Santos ⇄ Vicente de Carvalho em {pct(fsv.ok)} ({pct(fsv.ok10)} com até 10 min). As de Cananéia ficam abaixo (seção 4).</p></div></div>
<h2><span class=n>1</span>Santos ⇄ Guarujá · o navio e a fila</h2>
<div class=g2><div class=cbox><div class=ct>Variação do tempo de fila em volta da passagem</div>{ev_chart()}<div class=cap>A linha fica dentro de ±1 min: <b>sem efeito na fila</b>.</div></div>
<div class=cbox><div class=ct>Saídas logo após o navio</div>{gap_chart()}<div class=cap>A saída seguinte leva <b>{n0(sd['veic'])} veículos</b>, o mesmo que as outras ({n0(sd['mv'])}). A pausa não forma fila extra.</div>
<div class=pz><b>Paralisações por navio:</b> só 2 no período, de madrugada ({pz[pz.tipo=="Passagem de Navio"].dur.round(0).astype(int).astype(str).str.cat(sep=" e ")} min), sem efeito na fila.</div></div></div>
'''
html2 = f'''<h2><span class=n>2</span>Hora a hora · situação da frota × fila (horários sob demanda)</h2>
<div class=cbox><div class=ct>Santos ⇄ Guarujá · sob demanda 24 h</div>{frota_chart(HG, 40, 10)}
<div class=cap>Das 03h às 06h operam só {f1(gn.oper.mean())} balsas, com {f1(gn.disp.mean())} disponíveis não tripuladas, e a fila fica em {f1(gn.fila.mean())} min. <b>{g_alta_n} das {g_alta} janelas de fila alta (30 min ou mais) são entre 00h e 06h.</b> De dia, os picos são às 08h e às 18h.</div></div>
<div class=cbox style="margin-top:2.5mm"><div class=ct>São Sebastião ⇄ Ilhabela · sob demanda das 05h30 às 23h30</div>{frota_chart(HS, 60, 8, fix_ate=6)}
<div class=cap>A fila vai de {f1(sm.fila.mean())} min de manhã para <b>{f1(st.fila.mean())} min das 12h às 19h</b>, quando o volume é maior e já operam {f1(st.oper.mean())} balsas. Ainda há {f1(st.manut.mean())} balsa em manutenção nesse horário. À noite (21h–23h30) a fila fica em cerca de 33 min.</div></div>
{LGF}
<h2><span class=n>3</span>São Sebastião ⇄ Ilhabela · dia a dia (08h–18h)</h2>
<div class=g2b><table class="t hm big"><tr><th>Dia</th><th class=r>Balsas em operação</th><th>Paradas (manutenção)</th><th class=r>Fila S. Sebastião</th><th class=r>Fila Ilhabela</th></tr>{ssd}</table>
<div class=side><div class=pt><b>10/11:</b> 4,2 balsas operando, a menor média da semana. São Sebastião chegou a {f1(d.fss[10])} min.</div>
<div class=pt><b>14 e 15/11:</b> frota cheia. A fila ficou em 30 min, mesmo com o maior volume da semana ({n0(d.veic[15])} veículos em 15/11).</div>
<div class=pt><b>16/11:</b> FB-19, FB-30 e FB-GREGA II paradas. Ilhabela chegou a {f1(d.fib[16])} min.</div>
<div class="pt at"><b>13/11:</b> frota normal e {f1(d.fss[13])} min em São Sebastião. Nenhuma ocorrência ou paralisação explica.</div>
</div></div>
<div class=pb></div><h2><span class=n>4</span>Regime fixo · intervalo registrado × grade REV04</h2>
{fixtab()}<div class=cap>Nos horários de regime fixo, o tempo registrado é o intervalo até a próxima viagem e foi comparado com o intervalo da grade no mesmo horário e margem. Em Paraibuna (Natividade, Paraitinga e Varginha) o registro de madrugada vem como 0, sem intervalo informado.</div>
<h2><span class=n>5</span>Ocorrências · classificadas pelo comentário</h2>
{octab()}<div class=cap><b>Nenhuma ocorrência muda a fila em mais de 1 min</b> na comparação com a mesma hora do mesmo dia. As sem Tipo foram classificadas pelo comentário; as de navio estão na seção 1.</div>
<h2><span class=n>6</span>Ações recomendadas</h2>
<div class="acts a4">
<div><b>Madrugada em Santos ⇄ Guarujá</b><p>Das 03h às 06h a fila fica em {f1(gn.fila.mean())} min com {f1(gn.oper.mean())} balsas operando e {f1(gn.disp.mean())} disponíveis. Avaliar mais uma balsa nesse horário.</p></div>
<div><b>Tarde em São Sebastião ⇄ Ilhabela</b><p>Das 12h às 19h a fila chega a {f1(st.fila.mean())} min. Programar manutenção fora desse horário para ganhar a balsa que fica parada ({f1(st.manut.mean())} em média).</p></div>
<div><b>Santos ⇄ Guarujá desde 13/11</b><p>Identificar o que mudou na operação para a fila cair de {f1(f_a)} para {f1(f_b)} min e manter.</p></div>
<div><b>Intervalos em Cananéia</b><p>Continente e Ilha Comprida seguem a grade em {pct(FXa.loc["Cananéia/Continente"].ok)} e {pct(FXa.loc["Cananéia/Ilha Comprida"].ok)} dos horários. Conferir o praticado com a operação.</p></div></div>
<div class=crit>Como foi feito: tempo registrado (a cada 15 min, por margem) separado pelo regime da grade REV04. Sob demanda (Santos ⇄ Guarujá 24 h; São Sebastião ⇄ Ilhabela 05h30–23h30; Paraibuna nas faixas da aba Conforme Demanda) = tempo de fila, com 0 = sem fila. Regime fixo = intervalo até a próxima viagem, comparado com a grade. O horário do export de tempo foi ajustado em +3 h: assim o intervalo registrado bate com a grade (ex.: Iguape ⇄ Juréia 95% × 56% sem o ajuste; Bertioga 93% × 61%). Cruzado com viagens, passagens de navio, ocorrências (sem Tipo = classificadas pelo comentário), paralisações e movimentação da frota (situação de cada balsa a cada 15 min). Variação da fila: cada janela de 15 min comparada com a hora anterior à passagem. Dois registros de passagem com duração irreal (421 e 79 min) foram limitados a 15 min.</div>'''

css = open('../../relatorio-financeiro/gerador/base.css').read() + '''
body{font-size:9pt} .hero h1{font-size:20pt} .hero .per{font-size:9.5pt}
.kp4{display:grid;grid-template-columns:repeat(4,1fr);gap:3mm;margin:3mm 0}
.kp4>div{border:.3mm solid #D3E1E7;border-top:1.4mm solid #005B7F;border-radius:1.8mm;padding:2.2mm 3.5mm}
.kp4 .ok{border-top-color:#00B5AD} .kp4 .at{border-top-color:#E39B2D} .kp4 .cr{border-top-color:#C8553D}
.kp4 span{display:block;font-size:7.5pt;color:#5E7480;text-transform:uppercase;letter-spacing:.3pt;font-weight:700}
.kp4 b{display:block;font-size:20pt;color:#005B7F;line-height:1.15;margin:.8mm 0} .kp4 .ok b{color:#008C86} .kp4 .at b{color:#B5731A} .kp4 .cr b{color:#C8553D}
.kp4 small{font-size:8pt;color:#17303B}
h2{font-size:13pt;margin:4mm 0 2mm;break-after:avoid}
.conc{display:grid;grid-template-columns:1fr 1fr;gap:2.5mm 4mm}
.conc>div{display:flex;gap:3mm;align-items:flex-start;background:#EEF5F8;border-radius:1.8mm;padding:2.5mm 3.5mm}
.conc i{font-style:normal;flex:0 0 7mm;height:7mm;border-radius:50%;background:#005B7F;color:#fff;font-weight:900;font-size:11pt;display:flex;align-items:center;justify-content:center}
.conc p{margin:0;font-size:9.5pt;line-height:1.35} .conc b{color:#005B7F}
.g2{display:grid;grid-template-columns:1fr 1fr;gap:4mm} .cbox{border:.3mm solid #D3E1E7;border-radius:1.8mm;padding:2.5mm 3.5mm;break-inside:avoid}
.ct{font-size:8.5pt;font-weight:900;color:#005B7F;text-transform:uppercase;letter-spacing:.3pt;margin-bottom:1.5mm}
svg.chart{width:100%;height:auto;display:block} svg .ax{font-size:9px;fill:#5E7480}
.cap{font-size:10pt;margin-top:1.5mm;line-height:1.35} .pz{font-size:8.5pt;margin-top:2mm;padding-top:2mm;border-top:.3mm dashed #D3E1E7}
.lg{font-size:8pt;color:#5E7480;margin-top:1mm} .lg i{display:inline-block;width:4mm;height:2.5mm;border-radius:.5mm;margin:0 1.2mm 0 3mm;vertical-align:-.3mm}
.g2b{display:grid;grid-template-columns:1.6fr 1fr;gap:4mm;margin-top:3mm;align-items:start}
.t.big td,.t.big th{font-size:8.5pt;padding:1.1mm 1.8mm} .t td.hi{background:#FBE3DC;color:#A23E28;font-weight:900}
.side .pt{font-size:8.8pt;line-height:1.35;border-left:1mm solid #00B5AD;padding:.6mm 0 .6mm 2.5mm;margin-bottom:1.8mm} .side .pt.at{border-left-color:#E39B2D}
.t td,.t th{white-space:normal} .acts{display:grid;grid-template-columns:repeat(3,1fr);gap:3mm} .acts>div{background:#005B7F;color:#fff;border-radius:1.8mm;padding:2.5mm 3.5mm}
.acts b{display:block;font-size:9.5pt;color:#BFE9E6;margin-bottom:1mm} .acts p{margin:0;font-size:8.8pt;line-height:1.35}
.acts.a4{grid-template-columns:1fr 1fr} .conc .wide{grid-column:1/-1} .crit{font-size:7pt;color:#5E7480;line-height:1.4;margin-top:4mm} .pb{break-before:page}
'''
open('pagina_exec.html', 'w').write(f'<!doctype html><html lang=pt-BR><head><meta charset=utf-8><title>Navios e fila</title><base href="file:///mnt/project-files/relatorios-viagens/relatorio-financeiro/gerador/"><style>{css}</style></head><body>{html}<div class=pb></div>{html2}</body></html>')
