# Situação da frota (FB) por janela de 15 min × fila — SG e SSI
import pandas as pd, numpy as np, pickle
D = pickle.load(open('dados.pkl', 'rb')); S = D['S']
M = pd.read_excel('entradas/Movimentacoes_NOV26.xlsx')
F = lambda s: pd.to_datetime(s, dayfirst=True, errors='coerce')
M['ini'] = F(M['Início']); M['fim'] = F(M['Término']).fillna(pd.Timestamp('2026-11-17 11:17'))
M = M[M['Embarcação'].astype(str).str.startswith('FB')].sort_values(['Embarcação', 'ini'])
M['prox'] = M.groupby('Embarcação').ini.shift(-1); M['fim'] = M[['fim', 'prox']].min(axis=1)   # status termina quando começa o próximo da mesma embarcação
def st(r):
    c, m = str(r['Condição']), str(r['Motivo'])
    if c == 'Operação': return 'oper'
    if c == 'Manutenção': return 'manut'
    if c == 'Abastecimento': return 'abast'
    if 'condições favoráveis' in m: return 'clima'
    if 'Aguardando demanda' in m: return 'aguard'
    if c == 'Disponível': return 'disp'
    return 'outro'
M['st'] = M.apply(st, axis=1)
COD = {'ST/GJ': 'Santos/Guarujá', 'SS/IB': 'São Sebastião/Ilhabela'}
out = []
for cod, trav in COD.items():
    m = M[M.Travessia == cod]; x = S[S.trav == trav][['dt', 'd', 'h', 'fila', 'veic']].copy()
    for k in ['oper', 'aguard', 'disp', 'manut', 'abast', 'clima']:
        mk = m[m.st == k]; x[k] = [((mk.ini < t + pd.Timedelta(minutes=15)) & (mk.fim > t)).sum() for t in x.dt]
    x['trav'] = trav; out.append(x)
X = pd.concat(out); X['ocioso'] = X.aguard + X.disp
tm = X.dt.dt.hour * 60 + X.dt.dt.minute   # regime REV04: SG sob demanda 24 h; SSI (veículos) sob demanda 05h30–23h30, fixo no resto
RG = pickle.load(open('regime.pkl', 'rb')); rg = RG.groupby(['Travessia', 'dt']).reg.first().reset_index().rename(columns={'Travessia': 'trav'})
X = X.merge(rg, on=['trav', 'dt'], how='left'); X['reg'] = X.reg.fillna('FIX')
pd.set_option('display.width', 250)
for t, x in X[X.reg == 'DEM'].groupby('trav'):
    print(t); print(x.groupby('h')[['fila', 'oper', 'aguard', 'disp', 'manut', 'abast', 'clima']].mean().round(1).T.to_string())
    print(x.groupby(x.d.dt.day)[['fila', 'oper', 'aguard', 'disp', 'manut', 'abast']].mean().round(1).T.to_string())
    thr = 30 if t.startswith('Santos') else 60
    y = x.copy(); y['alta'] = y.fila >= thr
    print('alta x ocioso', y.groupby('alta')[['oper', 'aguard', 'disp', 'manut', 'abast']].mean().round(2).to_string())
    print('janelas fila alta com balsa aguardando/disponível:', ((y.alta) & (y.ocioso > 0)).sum(), 'de', y.alta.sum())
    print(y[y.alta].groupby('h').size().to_dict())
pickle.dump(X, open('mov.pkl', 'wb'))
