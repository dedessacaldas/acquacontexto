# Passagens de navio × fila (Santos ⇄ Guarujá, só horários sob demanda), por margem
import pandas as pd, numpy as np, pickle
DM = pickle.load(open('demanda.pkl', 'rb')); Z = pickle.load(open('dados.pkl', 'rb')); N = Z['N']
N = N[N.trav == 'Santos/Guarujá'].copy(); N.loc[N.dur > 60, 'fim'] = N.ini + pd.Timedelta(minutes=15)
G = DM[DM.Travessia == 'Santos/Guarujá'].copy(); G['alta'] = G.Tempo >= 30
ini, fim = N.ini.values, N.fim.values
def nav_em(t, a, b):  # navio passando entre t+a e t+b (min)
    lo, hi = np.datetime64(t + pd.Timedelta(minutes=a)), np.datetime64(t + pd.Timedelta(minutes=b))
    return bool(((ini < hi) & (fim >= lo)).any())
G['nav'] = [nav_em(t, -30, 15) for t in G.dt]
G['nnav'] = [int(((ini < np.datetime64(t + pd.Timedelta(minutes=15))) & (fim >= np.datetime64(t - pd.Timedelta(minutes=45)))).sum()) for t in G.dt]
G['navmin'] = [float(((np.minimum(fim, np.datetime64(t + pd.Timedelta(minutes=15))) - np.maximum(ini, np.datetime64(t - pd.Timedelta(minutes=45)))) / np.timedelta64(1, 'm')).clip(0).sum()) for t in G.dt]
R = {}
# 1) com × sem navio, mesma hora (média ponderada das diferenças por hora)
def strat(g):
    rows = []
    for h, x in g.groupby('h'):
        a, b = x[x.nav], x[~x.nav]
        if len(a) >= 3 and len(b) >= 3: rows.append((h, len(a), len(b), a.Tempo.mean(), b.Tempo.mean(), a.alta.mean(), b.alta.mean()))
    r = pd.DataFrame(rows, columns=['h', 'na', 'nb', 'fa', 'fb', 'aa', 'ab']); w = r.na
    return r, dict(dfila=float(((r.fa - r.fb) * w).sum() / w.sum()), dalta=float(((r.aa - r.ab) * w).sum() / w.sum()), pct_nav=float(g.nav.mean()), alta_com=float((r.aa * w).sum() / w.sum()), alta_sem=float((r.ab * w).sum() / w.sum()))
for mg, g in G.groupby('Margem'):
    r, s = strat(g); R[mg] = s; print(mg, {k: round(v, 3) for k, v in s.items()})
# 2) por nº de navios na última hora
G['nq'] = G.nnav.clip(upper=3)
print(G.groupby(['Margem', 'nq']).agg(fila=('Tempo', 'mean'), alta=('alta', 'mean'), n=('alta', 'size'), veic=('veic60', 'mean')).round(2))
R['por_n'] = G.groupby('nq').agg(alta=('alta', 'mean'), n=('alta', 'size'), veic=('veic60', 'mean'))
# 3) navios por hora (horas sob demanda) e % fila alta por hora
dias = G.dt.dt.normalize().nunique()
N['h'] = N.ini.dt.hour; N['d'] = N.ini.dt.normalize()
dem = set(zip(G.dt.dt.normalize(), G.h))
Nd = N[[(d, h) in dem for d, h in zip(N.d, N.h)]]
nh = Nd.groupby('h').size() / G.groupby('h').dt.apply(lambda s: s.dt.normalize().nunique())
R['h'] = pd.DataFrame({'nav': nh, 'alta': G.groupby('h').alta.mean(), 'veic': G.groupby('h').veic60.mean()})
print(R['h'].round(2).T.to_string())
print('corr hora nav×alta', round(R['h'].nav.corr(R['h'].alta), 2), 'n passagens em DEM', len(Nd), 'de', len(N))
# 4) navio nos picos
pk = G[((G.Margem == 'Guarujá') & G.h.isin([7, 8])) | ((G.Margem == 'Santos') & G.h.isin([17, 18, 19]))]
r, s = strat(pk); R['pico'] = s; print('pico', {k: round(v, 3) for k, v in s.items()})
R['n_dem'] = len(Nd); R['n_tot'] = len(N)
pickle.dump((G, R), open('navio.pkl', 'wb'))
# 5) antes × depois da passagem: % fila alta por margem, de −60 a +90 min
R['ev'] = {}
for mg, g in G.groupby('Margem'):
    s = g.set_index('dt').alta.astype(float); E = []
    for t in N.ini:
        t0 = t.floor('15min'); E.append([s.get(t0 + pd.Timedelta(minutes=15 * o), np.nan) for o in range(-4, 7)])
    E = np.array(E); ok = ~np.isnan(E).any(1); R['ev'][mg] = (E[ok].mean(0), int(ok.sum()))
R['por_n_m'] = G.groupby(['Margem', 'nq']).agg(alta=('alta', 'mean'), n=('alta', 'size'), veic=('veic60', 'mean'))
pickle.dump((G, R), open('navio.pkl', 'wb'))
print({k: (np.round(v[0] * 100), v[1]) for k, v in R['ev'].items()})
