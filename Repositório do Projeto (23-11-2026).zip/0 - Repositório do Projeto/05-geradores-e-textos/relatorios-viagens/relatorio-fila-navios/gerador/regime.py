# Regime da grade REV04 por travessia × horário: DEM (tempo registrado = fila) ou FIX (tempo registrado = intervalo até a próxima viagem)
import pandas as pd, numpy as np, unicodedata, pickle, datetime as dtm
G = '/mnt/project-files/template-horarios/Template_Horarios_Detalhado_REV04.xlsx'
HF = pd.read_excel(G, sheet_name='Horário Fixo'); CD = pd.read_excel(G, sheet_name='Conforme Demanda')
T = pd.read_excel('entradas/TempoEmbarque_NOV26.xlsx'); T = T[T.Travessia != 'Inoperante'].copy()
T['dt'] = pd.to_datetime(T['Data Hora'], dayfirst=True) + pd.Timedelta(hours=3); T = T[T.dt <= '2026-11-16 23:45'].copy()
nrm = lambda s: unicodedata.normalize('NFKD', str(s)).encode('ascii', 'ignore').decode().lower().strip()
MAPF = {'Bertioga/Guarujá': 'Bertioga/Guarujá', 'Cananeia/Continente': 'Cananéia/Continente', 'Cananeia/Ilha Comprida': 'Cananéia/Ilha Comprida',
        'Iguape/Jureia': 'Iguape/Juréia', 'Santos/Vicente de Carvalho': 'Santos/Vicente de Carvalho', 'São Sebastião/Ilhabela': 'São Sebastião/Ilhabela',
        'Natividade': 'Natividade da Serra/B. Natividade da Serra', 'Paraitinga': 'Ribeirão Branco/Capim DAngola', 'Varginha': 'Comércio/Varginha', 'Cananeia/Ariri': 'Cananéia/Ariri'}
MAPD = {'São Sebastião ↔ Ilhabela': 'São Sebastião/Ilhabela', 'Santos ↔ Guarujá': 'Santos/Guarujá', 'Natividade ↔ Pouso Alto ↔ Bairro Alto': 'Natividade da Serra/B. Natividade da Serra',
        "Capim D'Angola ↔ Ribeirão Branco": 'Ribeirão Branco/Capim DAngola', 'Comércio ↔ Varginha': 'Comércio/Varginha'}
DS = ['SEG', 'TER', 'QUA', 'QUI', 'SEX', 'SAB', 'DOM']
def tipo_ok(cod, day):   # day = date
    wd = day.weekday(); c = str(cod).upper()
    if c in ('TODOS_OS_DIAS', 'NAN', ''): return True
    if c == 'DU': return wd < 5
    if c == 'SAB': return wd == 5
    if c in ('DOM/FER', 'DOM'): return wd == 6
    if c == 'SAB_DOM_FER': return wd >= 5
    return c == DS[wd]
def tipo_dem(lbl, day):
    l = nrm(lbl); wd = day.weekday()
    if l.startswith('dias uteis'): return wd < 5
    if l.startswith('sabados'): return wd == 5
    if l.startswith('domingos'): return wd == 6
    if l.startswith('sab., dom'): return wd >= 5
    return True
# faixas DEM (só a de veículos em SSI)
CD = CD[CD.Rota.isin(MAPD) & ~((CD.Rota == 'São Sebastião ↔ Ilhabela') & (CD['Tipo de Embarque'] == 'Pedestres e Ciclistas'))].copy(); CD['trav'] = CD.Rota.map(MAPD)
CD = CD[~CD['Tipo de Embarque'].str.contains('demais')]   # faixas "(demais)" = horário fixo (Dedessa 17/11)
def is_dem(trav, t):
    for r in CD[CD.trav == trav].itertuples():
        for day in (t.date(), (t - pd.Timedelta(days=1)).date()):
            if not tipo_dem(r[3], day): continue
            a = pd.Timestamp.combine(day, r[4]); b = pd.Timestamp.combine(day, r[5])
            if b <= a: b += pd.Timedelta(days=1)
            if a <= t < b: return True
    return False
# saídas FIX por travessia e margem de partida
HF['trav'] = HF.Travessia.map(MAPF)
def orig(rota):
    if '↔' in rota: return None
    a, b = (rota.split('→') if '→' in rota else rota.split('←')[::-1])
    return nrm(a.split('←')[0])
HF['orig'] = HF.Rota.map(orig)
def saidas(trav, marg, day0, day1):
    h = HF[HF.trav == trav]; m = nrm(marg)
    h = h[h.orig.isna() | h.orig.map(lambda o: isinstance(o, str) and (m.startswith(o[:6]) or o.startswith(m[:6])))]
    out = []
    for day in pd.date_range(day0, day1):
        for r in h.itertuples():
            if tipo_ok(r[5], day.date()) and isinstance(r[7], dtm.time): out.append(pd.Timestamp.combine(day.date(), r[7]))
    return np.array(sorted(set(out)), dtype='datetime64[ns]')
T['reg'] = [('DEM' if is_dem(tr, t) else 'FIX') for tr, t in zip(T.Travessia, T.dt)]
# SSI: faixa sob demanda começa 05h30 em São Sebastião e 06h00 em Ilhabela (Dedessa 17/11), termina 23h30
tm = T.dt.dt.hour * 60 + T.dt.dt.minute; ssi = T.Travessia == 'São Sebastião/Ilhabela'
ini = np.where(T.Margem == 'Ilhabela', 360, 330)
T.loc[ssi, 'reg'] = np.where((tm[ssi] >= ini[ssi]) & (tm[ssi] < 1410), 'DEM', 'FIX')
T['grade_int'] = np.nan; T['grade_prox'] = np.nan
for (tr, mg), g in T[T.reg == 'FIX'].groupby(['Travessia', 'Margem']):
    sd = saidas(tr, mg, '2026-11-08', '2026-11-17')
    if len(sd) < 2: continue
    tt = g.dt.values.astype('datetime64[ns]'); i = np.searchsorted(sd, tt, side='left')   # prev < t ≤ próxima
    i = np.clip(i, 1, len(sd) - 1)
    T.loc[g.index, 'grade_int'] = (sd[i] - sd[i - 1]) / np.timedelta64(1, 'm')
    T.loc[g.index, 'grade_prox'] = (sd[i] - tt) / np.timedelta64(1, 'm')
pickle.dump(T, open('regime.pkl', 'wb'))
pd.set_option('display.width', 250)
print(T.groupby(['Travessia', 'reg']).size().unstack(fill_value=0))
F = T[(T.reg == 'FIX') & T.grade_int.notna()]
print(F.assign(ok=(F.Tempo == F.grade_int), ok2=(F.Tempo - F.grade_int).abs() <= 10, z=F.Tempo == 0).groupby('Travessia')[['ok', 'ok2', 'z']].mean().round(3), F.groupby('Travessia')[['Tempo', 'grade_int']].mean().round(1))
