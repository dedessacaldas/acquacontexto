import pickle, pandas as pd, numpy as np
exec(open('regime.py').read().split("T['reg'] =")[0])
T = pickle.load(open('regime.pkl', 'rb'))
for tr in ['Bertioga/Guarujá', 'Cananéia/Continente', 'Cananéia/Ilha Comprida', 'Iguape/Juréia', 'Santos/Vicente de Carvalho', 'São Sebastião/Ilhabela']:
    res = []
    margs = T[T.Travessia == tr].Margem.unique()
    for swap in (False,):
        for k in range(-240, 241, 15):
            ok = n = 0
            for mg in margs:
                g = T[(T.Travessia == tr) & (T.Margem == mg) & (T.reg == 'FIX')]
                src = [m for m in margs if m != mg][0] if swap else mg
                sd = saidas(tr, src, '2026-11-07', '2026-11-18'); tt = (g.dt + pd.Timedelta(minutes=k)).values.astype('datetime64[ns]')
                i = np.clip(np.searchsorted(sd, tt, side='right'), 1, len(sd) - 1); gi = (sd[i] - sd[i - 1]) / np.timedelta64(1, 'm')
                gi2 = (sd[np.clip(i + 1, 0, len(sd) - 1)] - sd[i]) / np.timedelta64(1, 'm')
                ok += (g.Tempo.values == gi).sum(); n += len(g)
            res.append((round(ok / n, 3), swap, k))
    print(tr, sorted(res)[-3:])
