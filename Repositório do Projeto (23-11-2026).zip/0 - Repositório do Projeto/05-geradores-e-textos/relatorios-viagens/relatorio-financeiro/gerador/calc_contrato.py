"""Regra 12/11/2026 15h: obrigatórias = grade cumprida + todas as viagens dentro de faixa conforme demanda (Anexo 3A);
adicionais (B) = viagens fora da grade em período de horário fixo, menos as saídas atrasadas de horário fixo não realizado."""
import pickle, pandas as pd, sys
sys.path.insert(0, '/mnt/project-files/relatorios-viagens/relatorio-diario/gerador')
from grades import ORDER, grade
from datetime import timedelta
LAB = {(t, m): (reg, l, q) for reg, it in ORDER for t, m, l, q in it}
out = []; trips = []
for d in ['09', '10', '11']:
    X = pickle.load(open(f'dia{d}.pkl', 'rb')); df, FX, PROG, D, QT = X['df'], X['FX'], X['PROG'], X['D'], X['QT']
    df = df.copy(); df['cat'] = df.cls.map({'A': 'A'}); df['excl'] = ''
    cand = df[(df.cls == 'B') & (df.saida.dt.hour < 5)]
    # saídas atrasadas: 1ª saída fora da grade até 60 min após um horário fixo não realizado, mesma travessia/margem
    used = set()
    for r in FX[FX.status == 'Não realizada'].sort_values('prog').itertuples():
        g = df[(df.trav == r.trav) & (df.modo == r.modo) & (df.margem == r.margem) & (df.cls == 'B') & (df.saida > r.prog) & (df.saida <= r.prog + timedelta(minutes=60))]
        g = g[~g.index.isin(used)]
        if len(g):
            i = g.index[0]; used.add(i); df.loc[i, 'excl'] = f'atrasada do horário {r.prog:%H:%M} (+{(df.saida[i]-r.prog).total_seconds()/60:.0f} min)'
    _, S = grade(D)
    def in_band(r):
        bands = S.get((r.trav, r.modo, r.sent), ([], [], ''))[1]
        return any(a <= r.saida < b for a, b, i in bands)
    ext = df[df.cls == 'B']
    inb = pd.Series([in_band(r) for r in ext.itertuples()], index=ext.index, dtype=bool)
    df.loc[ext.index[inb], 'cat'] = 'AD'                       # sob demanda: conta como realizada normal
    df.loc[ext.index[~inb], 'cat'] = 'B'                       # fora da grade em horário fixo
    df.loc[(df.cat == 'B') & (df.excl != ''), 'cat'] = 'Xatraso'
    df['cat'] = df.cat.fillna('N')     # fora da grade, depois das 05h: não considerada
    for (t, m), g in df.groupby(['trav', 'modo']):
        reg, l, q = LAB[(t, m)]
        p = PROG[(PROG.trav == t) & (PROG.modo == m)]
        out.append(dict(Data=D, Regiao=reg, Travessia=l, Grade=len(p), Proj=float(QT.get(q, 0) or 0), Real=len(g), A=(g.cat.isin(['A', 'Xatraso'])).sum(), AD=(g.cat == 'AD').sum(), B=(g.cat == 'B').sum(), Bm=((g.cat == 'B') & (g.saida.dt.hour < 5)).sum(), Reg=('Conforme demanda' if any(v[1] for k, v in S.items() if k[0] == t and k[1] == m) else 'Horário fixo'),
                        Xat=(g.cat == 'Xatraso').sum(), N=(g.cat == 'N').sum(), NR=(p.real == False).sum() - (g.cat == 'Xatraso').sum()))
    for r in df[df.cat.isin(['B', 'AD', 'Xatraso'])].itertuples():
        trips.append(dict(Data=D, Travessia=LAB[(r.trav, r.modo)][1], Margem=r.margem, Saida=r.saida, Emb=r.emb, cat=r.cat, excl=r.excl))
O = pd.DataFrame(out); TR = pd.DataFrame(trips)
pickle.dump(dict(O=O, TR=TR), open('contrato.pkl', 'wb'))
print(O.groupby('Data')[['Grade', 'Real', 'A', 'AD', 'B', 'Bm', 'Xat', 'N', 'NR']].sum())
print(O.groupby('Travessia')[['Grade', 'Real', 'A', 'AD', 'B', 'Bm', 'Xat', 'N', 'NR']].sum())
print(TR[TR.cat == 'Xatraso'].to_string())
