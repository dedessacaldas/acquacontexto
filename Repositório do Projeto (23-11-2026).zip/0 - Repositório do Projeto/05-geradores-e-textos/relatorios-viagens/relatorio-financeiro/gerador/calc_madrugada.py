"""B = só viagens fora da grade entre 00:00 e 04:59, tirando saídas atrasadas de horário fixo não realizado (até +60 min)."""
import pickle, pandas as pd, sys
sys.path.insert(0, '/mnt/project-files/relatorios-viagens/relatorio-diario/gerador')
from grades import ORDER
from datetime import timedelta
LAB = {(t, m): (reg, l, q) for reg, it in ORDER for t, m, l, q in it}
out = []; trips = []
for d in ['09', '10', '11']:
    X = pickle.load(open(f'dia{d}.pkl', 'rb')); df, FX, PROG, D, QT = X['df'], X['FX'], X['PROG'], X['D'], X['QT']
    df = df.copy(); df['cat'] = df.cls.map({'A': 'A'}); df['excl'] = ''
    cand = df[(df.cls == 'B') & (df.saida.dt.hour < 5)]
    # saídas atrasadas: 1ª saída fora da grade até 60 min após um horário fixo não realizado, mesma travessia/margem
    used = set()
    for r in FX[FX.status == 'Não realizada'].sort_values('prog').itertuples():
        g = df[(df.trav == r.trav) & (df.modo == r.modo) & (df.margem == r.margem) & (df.cls == 'B') & (df.saida > r.prog) & (df.saida <= r.prog + timedelta(minutes=60))]
        g = g[~g.index.isin(used)]
        if len(g):
            i = g.index[0]; used.add(i); df.loc[i, 'excl'] = f'atrasada do horário {r.prog:%H:%M} (+{(df.saida[i]-r.prog).total_seconds()/60:.0f} min)'
    df.loc[cand.index, 'cat'] = 'B'
    df.loc[(df.cat == 'B') & (df.excl != ''), 'cat'] = 'Xatraso'
    df.loc[df.cat.isna() & (df.excl != ''), 'cat'] = 'Xatraso_dia'
    df['cat'] = df.cat.fillna('N')     # fora da grade, depois das 05h: não considerada
    for (t, m), g in df.groupby(['trav', 'modo']):
        reg, l, q = LAB[(t, m)]
        p = PROG[(PROG.trav == t) & (PROG.modo == m)]
        out.append(dict(Data=D, Regiao=reg, Travessia=l, Grade=len(p), Proj=float(QT.get(q, 0) or 0), Real=len(g), A=(g.cat == 'A').sum(), B=(g.cat == 'B').sum(),
                        Xat=(g.cat == 'Xatraso').sum(), N=(g.cat.isin(['N', 'Xatraso_dia'])).sum(), NR=(p.real == False).sum()))
    for r in df[df.cat.isin(['B', 'Xatraso'])].itertuples():
        trips.append(dict(Data=D, Travessia=LAB[(r.trav, r.modo)][1], Margem=r.margem, Saida=r.saida, Emb=r.emb, cat=r.cat, excl=r.excl))
O = pd.DataFrame(out); TR = pd.DataFrame(trips)
pickle.dump(dict(O=O, TR=TR), open('madrugada.pkl', 'wb'))
print(O.groupby('Data')[['Grade', 'Proj', 'Real', 'A', 'B', 'Xat', 'N', 'NR']].sum())
print(O.groupby('Travessia')[['Grade', 'Real', 'A', 'B', 'Xat', 'N', 'NR']].sum())
print(TR[TR.cat == 'Xatraso'].to_string())
