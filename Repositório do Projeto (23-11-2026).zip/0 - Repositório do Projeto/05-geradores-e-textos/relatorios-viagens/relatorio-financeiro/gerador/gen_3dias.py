"""Relatório financeiro do realizado, 1 página por dia + análise. Usa res.pkl de gerar.py (R = realizado por dia/travessia).
python3 gen_3dias.py && node print.js $PWD/tres_dias.html <saida.pdf> $PWD/header3.html"""
import pickle, pandas as pd
R0 = pickle.load(open('res.pkl', 'rb')); R, VA, VB = R0['R'].copy(), R0['VA'], R0['VB']
DS = ['Segunda-feira', 'Terça-feira', 'Quarta-feira', 'Quinta-feira', 'Sexta-feira', 'Sábado', 'Domingo']
REG = ['Baixada Santista', 'Litoral Norte', 'Litoral Sul', 'Paraibuna', 'Metropolitana']
n0 = lambda x: f'{x:,.0f}'.replace(',', '.')
def brl(x, d=0): return ('−' if round(x, d) < 0 else '') + 'R$ ' + f'{abs(x):,.{d}f}'.replace(',', '#').replace('.', ',').replace('#', '.')
pct = lambda x: f'{x*100:.1f}%'.replace('.', ',')
R['A'] = R.rA; R['Bg'] = R.rB                                # adicionais segundo a grade
R['NC'] = (R.Grade - R.Realizadas).clip(lower=0)             # grade não cumprida (em quantidade)
R['Bp'] = (R.Realizadas - R.Projetadas).clip(lower=0)        # acima da projeção
R['Fp'] = (R.Projetadas - R.Realizadas).clip(lower=0)        # abaixo da projeção
R['RA'] = R.A * VA; R['RB'] = R.Bg * VB; R['RT'] = R.RA + R.RB
COLS = ['Grade', 'Projetadas', 'Realizadas', 'A', 'Bg', 'NC', 'Bp', 'RA', 'RB', 'RT']

def tabela(df):
    hd = ('<tr><th>Travessia</th><th class=r>Grade</th><th class=r>Projeção</th><th class=r>Realizadas</th><th class=r>Obrigat. (A)</th>'
          '<th class=r>Adicionais<br>pela grade (B)</th><th class=r>Grade não<br>cumprida</th><th class=r>Acima da<br>projeção</th>'
          '<th class=r>Receita (A)</th><th class=r>Receita (B)</th><th class=r>Receita total</th></tr>')
    def lin(lab, r, cls='', lcls='m'):
        z = lambda v, red=False: f'<td class="r{" z" if v == 0 else (" red" if red else "")}">{n0(v) if v else "–"}</td>'
        return (f'<tr class="{cls}"><td class={lcls}>{lab}</td><td class=r>{n0(r.Grade)}</td><td class=r>{n0(r.Projetadas)}</td><td class=r><b>{n0(r.Realizadas)}</b></td>'
                f'<td class=r>{n0(r.A)}</td>{z(r.Bg)}{z(r.NC, True)}{z(r.Bp)}<td class=r>{brl(r.RA)}</td><td class=r>{brl(r.RB)}</td><td class=r><b>{brl(r.RT)}</b></td></tr>')
    rows = ''
    for g in REG:
        t = df[df.Regiao == g].sort_values('Ordem')
        if t.empty: continue
        rows += f'<tr class=rg><td colspan=11>{g}</td></tr>'
        for r in t.itertuples(): rows += lin(r.Travessia, r)
        if len(t) > 1: rows += lin(f'Subtotal', t[COLS].sum(), lcls='"m" style="color:#008C86"')
    s = df[COLS].sum()
    return f'<table class="t hm">{hd}{rows}{lin("Total", s, "tot")}</table>', s

def kpis(s, extra=''):
    return (f'<div class=kp><div>Viagens realizadas<b>{n0(s.Realizadas)}</b>{pct(s.Realizadas/s.Projetadas)} da projeção{extra}</div>'
            f'<div>Obrigatórias (A)<b>{n0(s.A)}</b>de {n0(s.Grade)} na grade</div><div>Adicionais pela grade (B)<b>{n0(s.Bg)}</b>acima da grade</div>'
            f'<div>Receita (A)<b>{brl(s.RA)}</b></div><div>Receita (B)<b>{brl(s.RB)}</b></div><div>Receita total<b>{brl(s.RT)}</b></div></div>')

def obs(df):
    li = []
    g = df[df.Bg > 0].sort_values('Bg', ascending=False)
    li.append('<li><b>Adicionais pela grade:</b> ' + ('; '.join(f'{r.Travessia} {n0(r.Bg)}' for r in g.itertuples()) if len(g) else 'nenhuma travessia passou da grade') + '.</li>')
    p = df[df.Bp > 0].sort_values('Bp', ascending=False)
    li.append('<li><b>Acima da projeção:</b> ' + ('; '.join(f'{r.Travessia} +{n0(r.Bp)}' for r in p.itertuples()) if len(p) else 'nenhuma travessia passou da projeção') + '.</li>')
    nc = df[df.NC > 0].sort_values('NC', ascending=False)
    if len(nc): li.append('<li><b>Grade não cumprida:</b> ' + '; '.join(f'{r.Travessia} {n0(r.NC)} viagens a menos' for r in nc.itertuples()) + '.</li>')
    return '<div class=obs><ul>' + ''.join(li) + '</ul></div>'

nota = f'<p class=lead>Valor por viagem: obrigatória (A) R$ 2.314,05 × 0,75 ÷ 4 = <b>{brl(VA,2)}</b>; adicional (B) 60% = <b>{brl(VB,2)}</b>. (A) = realizadas até o limite da grade do dia; (B) = realizadas acima da grade.</p>'
h = []
dias = sorted(R.Data.unique())
for i, d in enumerate(dias):
    d = pd.Timestamp(d); df = R[R.Data == d]
    tb, s = tabela(df)
    h.append(f'''<div class="{'sec' if i else ''}"><div class=hero><div class=pat></div><div class=eb>Relatório financeiro de viagens · dia {i+1} de {len(dias)}</div>
<h1>{DS[d.weekday()]}, {d:%d/%m/%Y}</h1><div class=per>Viagens realizadas, obrigatórias e adicionais por travessia</div><div class=w></div></div>
{kpis(s)}{nota}<h2><span class=n>{i+1}</span>Viagens e receita por travessia</h2>{tb}{obs(df)}</div>''')

# análise dos 3 dias
D = R.groupby('Data')[COLS].sum()
T = R.groupby(['Regiao', 'Travessia', 'Ordem'])[COLS].sum().reset_index()
tb, s = tabela(T)
rows = ''.join(f'<tr><td class=m>{DS[pd.Timestamp(d).weekday()].split("-")[0]} {pd.Timestamp(d):%d/%m}</td><td class=r>{n0(r.Grade)}</td><td class=r>{n0(r.Projetadas)}</td><td class=r><b>{n0(r.Realizadas)}</b></td><td class=r>{pct(r.Realizadas/r.Projetadas)}</td>'
               f'<td class=r>{n0(r.A)}</td><td class=r>{n0(r.Bg)}</td><td class="r red">{n0(r.NC)}</td><td class=r>{n0(r.Bp)}</td><td class=r>{brl(r.RA)}</td><td class=r>{brl(r.RB)}</td><td class=r><b>{brl(r.RT)}</b></td></tr>' for d, r in D.iterrows())
rows += (f'<tr class=tot><td class=m>3 dias</td><td class=r>{n0(s.Grade)}</td><td class=r>{n0(s.Projetadas)}</td><td class=r>{n0(s.Realizadas)}</td><td class=r>{pct(s.Realizadas/s.Projetadas)}</td><td class=r>{n0(s.A)}</td>'
         f'<td class=r>{n0(s.Bg)}</td><td class=r>{n0(s.NC)}</td><td class=r>{n0(s.Bp)}</td><td class=r>{brl(s.RA)}</td><td class=r>{brl(s.RB)}</td><td class=r>{brl(s.RT)}</td></tr>')
evo = (f'<table class="t hm"><tr><th>Dia</th><th class=r>Grade</th><th class=r>Projeção</th><th class=r>Realizadas</th><th class=r>% da projeção</th><th class=r>Obrigat. (A)</th>'
       f'<th class=r>Adicionais<br>pela grade (B)</th><th class=r>Grade não<br>cumprida</th><th class=r>Acima da<br>projeção</th><th class=r>Receita (A)</th><th class=r>Receita (B)</th><th class=r>Receita total</th></tr>{rows}</table>')
d0, d2 = D.iloc[0], D.iloc[-1]
sg = T.set_index('Travessia')
pp = T[T.Bp > 0].sort_values('Bp', ascending=False); fp = T.assign(f=T.Projetadas - T.Realizadas).sort_values('f', ascending=False)
nc = T[T.NC > 0].sort_values('NC', ascending=False)
ana = [f'<li><b>Receita dos 3 dias: {brl(s.RT)}</b>, média de {brl(s.RT/3)} por dia. Subiu de {brl(d0.RT)} em 09/11 para {brl(d2.RT)} em 11/11 ({pct(d2.RT/d0.RT-1)}).</li>',
       f'<li><b>Grade:</b> {n0(s.A)} das {n0(s.Grade)} viagens da grade foram feitas ({pct(s.A/s.Grade)}); a grade não cumprida caiu de {n0(d0.NC)} para {n0(d2.NC)} viagens.</li>',
       f'<li><b>Adicionais pela grade:</b> {n0(s.Bg)} viagens ({pct(s.Bg/s.Realizadas)} das realizadas), {brl(s.RB)} de receita. Santos ⇄ Guarujá respondeu por {n0(sg.Bg["Santos ⇄ Guarujá"])} ({pct(sg.Bg["Santos ⇄ Guarujá"]/s.Bg)}).</li>',
       f'<li><b>Projeção:</b> foram realizadas {n0(s.Realizadas)} de {n0(s.Projetadas)} viagens projetadas ({pct(s.Realizadas/s.Projetadas)}). Ficaram acima da projeção: ' +
       '; '.join(f'{r.Travessia} +{n0(r.Bp)}' for r in pp.itertuples()) + '.</li>',
       '<li><b>Mais abaixo da projeção:</b> ' + '; '.join(f'{r.Travessia} {n0(r.f)} viagens a menos' for r in fp.head(3).itertuples()) + '.</li>',
       '<li><b>Grade não cumprida nos 3 dias:</b> ' + '; '.join(f'{r.Travessia} {n0(r.NC)}' for r in nc.itertuples()) + '.</li>']
crit = ['Realizadas: viagens com início de travessia no dia. Não contam viagens de serviço nem registros repetidos da mesma embarcação e sentido em menos de 3 minutos.',
        'Grade: viagens das grades de horários do tipo de dia (horário fixo = 1 por margem; faixa conforme demanda = 1 por janela do intervalo máximo, por margem). Comparação por quantidade no dia.',
        'Obrigatórias (A): realizadas até o limite da grade. Adicionais (B): realizadas acima da grade. Grade não cumprida: grade menos realizadas, quando negativo.',
        'Projeção: usada só como comparação (acima ou abaixo da projeção); não entra no cálculo da receita.',
        'Receita = viagens ÷ 4 × R$ 2.314,05 × 0,75; adicionais a 60%. Valores antes do desconto por desempenho (IQS), da receita tarifária e do ônus de fiscalização.']
h.append(f'''<div class=sec><div class=hero><div class=pat></div><div class=eb>Relatório financeiro de viagens · análise</div>
<h1>Análise de 09 a 11/11/2026</h1><div class=per>Três dias somados, por dia e por travessia</div><div class=w></div></div>
<h2><span class=n>4</span>Evolução dos 3 dias</h2>{evo}<div class=obs><ul>{"".join(ana)}</ul></div>
<h3>Por travessia, 3 dias somados</h3>{tb}<h3>Critérios</h3><ol class=crit>{"".join(f"<li>{c}</li>" for c in crit)}</ol></div>''')
css = open('base.css').read()
open('tres_dias.html', 'w').write(f'<!doctype html><html lang=pt-BR><head><meta charset=utf-8><title>Relatório Financeiro de Viagens</title><style>{css}\n.kp{{grid-template-columns:repeat(6,1fr)!important}} .kp div{{font-size:6.4pt}} .kp b{{font-size:12pt;white-space:nowrap}} .hm th{{font-size:5.9pt}} .hm td{{font-size:7.3pt}} .hero h1{{font-size:20pt}}</style></head><body>{"".join(h)}</body></html>')
print(D[COLS].round(0).to_string()); print(s.round(0).to_dict())
