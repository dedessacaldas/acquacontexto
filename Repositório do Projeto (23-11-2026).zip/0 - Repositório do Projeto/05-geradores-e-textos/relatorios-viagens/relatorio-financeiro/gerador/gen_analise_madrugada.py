"""Página única: análise 09–11/11 com adicionais só de 00h–05h fora da grade (madrugada.pkl + res.pkl p/ projeção)."""
import pickle, pandas as pd
M = pickle.load(open('madrugada.pkl', 'rb')); O, TR = M['O'], M['TR']
R0 = pickle.load(open('res.pkl', 'rb')); VA, VB = R0['VA'], R0['VB']; R = R0['R']
pj = R.set_index(['Data', 'Travessia']).Projetadas
O['Proj'] = [pj.get((d, t), 0) for d, t in zip(O.Data, O.Travessia)]
O['NR'] = O.NR.astype(int); O['RA'] = O.A * VA; O['RB'] = O.B * VB; O['RT'] = O.RA + O.RB
ORD = ['Santos ⇄ Guarujá', 'Santos ⇄ Vicente de Carvalho', 'Bertioga ⇄ Guarujá', 'São Sebastião ⇄ Ilhabela · balsa', 'São Sebastião ⇄ Ilhabela · lancha',
       'Cananéia ⇄ Continente', 'Cananéia ⇄ Ilha Comprida', 'Iguape ⇄ Juréia', 'Cananéia ⇄ Marujá ⇄ Ariri', 'Natividade', 'Paraitinga', 'Varginha']
REG = ['Baixada Santista', 'Litoral Norte', 'Litoral Sul', 'Paraibuna e Natividade da Serra']
DS = ['Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado', 'Domingo']
C = ['Grade', 'Proj', 'Real', 'A', 'NR', 'B', 'Xat', 'N', 'RA', 'RB', 'RT']
n0 = lambda x: f'{x:,.0f}'.replace(',', '.')
def brl(x, d=0): return ('−' if round(x, d) < 0 else '') + 'R$ ' + f'{abs(x):,.{d}f}'.replace(',', '#').replace('.', ',').replace('#', '.')
pct = lambda x: f'{x*100:.1f}%'.replace('.', ',')
def z(v, cls=''): return f'<td class="r{" z" if v == 0 else (" " + cls if cls else "")}">{n0(v) if v else "–"}</td>'
HD = ('<th class=r>Grade</th><th class=r>Projeção</th><th class=r>Realizadas</th><th class=r>Obrigat.<br>(A)</th><th class=r>Grade não<br>realizada</th>'
      '<th class=r>Adicionais<br>00h–05h (B)</th><th class=r>Excluídas<br>por atraso</th><th class=r>Fora da grade<br>não consideradas</th>'
      '<th class=r>Receita (A)</th><th class=r>Receita (B)</th><th class=r>Receita total</th>')
def lin(lab, r, cls='', lc='m'):
    return (f'<tr class="{cls}"><td class={lc}>{lab}</td><td class=r>{n0(r.Grade)}</td><td class=r>{n0(r.Proj)}</td><td class=r><b>{n0(r.Real)}</b></td><td class=r>{n0(r.A)}</td>'
            f'{z(r.NR, "red")}{z(r.B)}{z(r.Xat)}{z(r.N)}<td class=r>{brl(r.RA)}</td><td class=r>{brl(r.RB)}</td><td class=r><b>{brl(r.RT)}</b></td></tr>')
s = O[C].sum(); D = O.groupby('Data')[C].sum()
dias = ''.join(lin(f'{DS[d.weekday()]} {d:%d/%m}', r) for d, r in D.iterrows()) + lin('3 dias', s, 'tot')
T = O.groupby(['Regiao', 'Travessia'])[C].sum().reset_index(); T['o'] = T.Travessia.map(ORD.index); T = T.sort_values('o')
trs = ''
for g in REG:
    t = T[T.Regiao == g]
    trs += f'<tr class=rg><td colspan=12>{g}</td></tr>' + ''.join(lin(r.Travessia, r) for r in t.itertuples())
trs += lin('Total', s, 'tot')
B = TR[TR.cat == 'B']; X = TR[TR.cat == 'Xatraso']
hh = B.groupby(['Travessia', B.Saida.dt.hour]).size().unstack(fill_value=0).reindex(columns=range(5), fill_value=0)
hh = hh.loc[[t for t in ORD if t in hh.index]]
hrows = ''.join(f'<tr><td class=m>{t}</td>' + ''.join(z(v) for v in r) + f'<td class=r><b>{r.sum()}</b></td></tr>' for t, r in hh.iterrows())
hrows += '<tr class=tot><td class=m>Total</td>' + ''.join(f'<td class=r>{v}</td>' for v in hh.sum()) + f'<td class=r>{hh.values.sum()}</td></tr>'
xl = '; '.join(f'{r.Travessia} ({r.Margem}) {r.Data:%d/%m} saída {r.Saida:%H:%M}, {r.excl.replace("atrasada do horário", "do horário")}' for r in X.itertuples())
sg = T.set_index('Travessia')
d0, d2 = D.iloc[0], D.iloc[-1]
ana = [f'<li><b>Receita dos 3 dias: {brl(s.RT)}</b>, sendo {brl(s.RA)} das obrigatórias e {brl(s.RB)} das adicionais da madrugada. Passou de {brl(d0.RT)} em 09/11 para {brl(d2.RT)} em 11/11.</li>',
       f'<li><b>Grade:</b> {n0(s.A)} das {n0(s.Grade)} viagens da grade foram realizadas ({pct(s.A/s.Grade)}). A grade não realizada caiu de {n0(d0.NR)} para {n0(d2.NR)} viagens; nos 3 dias, Natividade ({n0(sg.NR["Natividade"])}), Paraitinga ({n0(sg.NR["Paraitinga"])}), Varginha ({n0(sg.NR["Varginha"])}) e Bertioga ⇄ Guarujá ({n0(sg.NR["Bertioga ⇄ Guarujá"])}) concentram a maior parte.</li>',
       f'<li><b>Adicionais (B):</b> só {n0(s.B)} viagens fora da grade entre 00h e 05h contam como adicionais; {n0(s.B and hh.loc["Santos ⇄ Guarujá"].sum())} delas em Santos ⇄ Guarujá. Caíram de {n0(d0.B)} em 09/11 para {n0(d2.B)} em 11/11.</li>',
       f'<li><b>Excluídas por atraso ({n0(s.Xat)}):</b> {xl}.</li>',
       f'<li><b>Fora da grade não consideradas:</b> {n0(s.N)} viagens ({pct(s.N/s.Real)} das realizadas) saíram fora da grade depois das 05h e não entram na receita; {n0(sg.N["Santos ⇄ Guarujá"])} são de Santos ⇄ Guarujá.</li>',
       f'<li><b>Projeção:</b> as {n0(s.Real)} viagens realizadas equivalem a {pct(s.Real/s.Proj)} das {n0(s.Proj)} projetadas.</li>']
crit = [f'Receita = viagens ÷ 4 × R$ 2.314,05 × 0,75: obrigatória (A) {brl(VA,2)} e adicional (B) a 60%, {brl(VB,2)}. Valores antes do desconto por desempenho, da receita tarifária e do ônus de fiscalização.',
        'Obrigatórias (A): viagens que cumpriram um horário da grade. Horário fixo: saída mais próxima entre 10 min antes e 15 min depois. Faixa conforme demanda: 1ª saída de cada janela do intervalo máximo.',
        'Adicionais (B): somente viagens fora da grade com saída entre 00h00 e 04h59, em todas as travessias. Fora da grade depois das 05h00 não é considerada.',
        'Excluídas por atraso: saída fora da grade até 60 min depois de um horário fixo não realizado, na mesma travessia e margem. É a viagem do horário que saiu atrasada, por isso não conta como adicional.',
        'Grade não realizada: horários da grade sem saída na janela. Projeção: só para comparação. Não contam viagens de serviço nem registros repetidos (mesma embarcação e sentido, menos de 3 min).']
html = f'''<div class=hero><div class=pat></div><div class=eb>Relatório financeiro de viagens · análise</div><h1>Análise de 09 a 11/11/2026</h1>
<div class=per>Obrigatórias pela grade e adicionais somente da madrugada (00h às 05h)</div><div class=w></div></div>
<div class=kp><div>Viagens realizadas<b>{n0(s.Real)}</b>{pct(s.Real/s.Proj)} da projeção</div><div>Obrigatórias (A)<b>{n0(s.A)}</b>de {n0(s.Grade)} na grade ({pct(s.A/s.Grade)})</div>
<div>Adicionais 00h–05h (B)<b>{n0(s.B)}</b>{n0(s.Xat)} excluídas por atraso</div><div>Receita (A)<b>{brl(s.RA)}</b></div><div>Receita (B)<b>{brl(s.RB)}</b></div><div>Receita total<b>{brl(s.RT)}</b>média de {brl(s.RT/3)}/dia</div></div>
<h2><span class=n>1</span>Os 3 dias</h2><table class="t hm"><tr><th>Dia</th>{HD}</tr>{dias}</table>
<div class=obs><ul>{"".join(ana)}</ul></div>
<h3>Por travessia, 3 dias somados</h3><table class="t hm"><tr><th>Travessia</th>{HD}</tr>{trs}</table>
<div style="display:grid;grid-template-columns:78mm 1fr;gap:5mm;align-items:start"><div><h3>Adicionais (B) por hora de saída</h3>
<table class="t hm"><tr><th>Travessia</th><th class=r>00h</th><th class=r>01h</th><th class=r>02h</th><th class=r>03h</th><th class=r>04h</th><th class=r>Total</th></tr>{hrows}</table></div>
<div><h3>Critérios</h3><ol class=crit>{"".join(f"<li>{c}</li>" for c in crit)}</ol></div></div>'''
css = open('base.css').read()
open('analise_madrugada.html', 'w').write(f'<!doctype html><html lang=pt-BR><head><meta charset=utf-8><title>Análise de Viagens</title><style>{css}\n.kp{{grid-template-columns:repeat(6,1fr)!important;margin-bottom:3mm}} .kp div{{font-size:6.2pt}} .kp b{{font-size:11.5pt;white-space:nowrap}} .hm th{{font-size:5.6pt}} .hm td{{font-size:6.9pt;padding:.55mm 1.1mm}} .hero{{padding:4mm 6mm 3.5mm;margin-bottom:3mm}} .hero h1{{font-size:18pt}} .obs{{font-size:7.1pt;padding:1.5mm 3mm}} .obs li{{margin:0 0 .5mm}} h3{{margin:2.5mm 0 1mm}} .crit{{font-size:6.6pt;padding-left:4mm;margin:0}} tr.rg td{{padding:.5mm 1.1mm}}</style></head><body>{html}</body></html>')
print(s.round(0).to_dict())
