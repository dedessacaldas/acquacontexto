"""Página única: análise 09–11/11 com adicionais só de 00h–05h fora da grade (madrugada.pkl + res.pkl p/ projeção)."""
import pickle, pandas as pd
M = pickle.load(open('regime.pkl', 'rb')); O, TR = M['O'], M['TR']
R0 = pickle.load(open('res.pkl', 'rb')); VA, VB = R0['VA'], R0['VB']; R = R0['R']
pj = R.set_index(['Data', 'Travessia']).Projetadas
O['Proj'] = [pj.get((d, t), 0) for d, t in zip(O.Data, O.Travessia)]
O['NR'] = O.NR.astype(int); O['Bt'] = O.B + O.BD; O['RA'] = O.A * VA; O['RB'] = O.Bt * VB; O['RT'] = O.RA + O.RB
ORD = ['Santos ⇄ Guarujá', 'Santos ⇄ Vicente de Carvalho', 'Bertioga ⇄ Guarujá', 'São Sebastião ⇄ Ilhabela · balsa', 'São Sebastião ⇄ Ilhabela · lancha',
       'Cananéia ⇄ Continente', 'Cananéia ⇄ Ilha Comprida', 'Iguape ⇄ Juréia', 'Cananéia ⇄ Marujá ⇄ Ariri', 'Natividade', 'Paraitinga', 'Varginha']
REG = ['Baixada Santista', 'Litoral Norte', 'Litoral Sul', 'Paraibuna e Natividade da Serra']
DS = ['Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado', 'Domingo']
C = ['Grade', 'Proj', 'Real', 'A', 'NR', 'B', 'BD', 'Bt', 'Xat', 'N', 'RA', 'RB', 'RT']
n0 = lambda x: f'{x:,.0f}'.replace(',', '.')
def brl(x, d=0): return ('−' if round(x, d) < 0 else '') + 'R$ ' + f'{abs(x):,.{d}f}'.replace(',', '#').replace('.', ',').replace('#', '.')
pct = lambda x: f'{x*100:.1f}%'.replace('.', ',')
def z(v, cls=''): return f'<td class="r{" z" if v == 0 else (" " + cls if cls else "")}">{n0(v) if v else "–"}</td>'
HD = ('<th class=r>Grade</th><th class=r>Projeção</th><th class=r>Realizadas</th><th class=r>Obrigat.<br>(A)</th><th class=r>Grade não<br>realizada</th>'
      '<th class=r>Adicionais<br>00h–05h</th><th class=r>Adicionais<br>sob demanda</th><th class=r>Total<br>adicionais (B)</th><th class=r>Excluídas<br>por atraso</th><th class=r>Fora da grade<br>em horário fixo</th>'
      '<th class=r>Receita (A)</th><th class=r>Receita (B)</th><th class=r>Receita total</th>')
def lin(lab, r, cls='', lc='m'):
    return (f'<tr class="{cls}"><td class={lc}>{lab}</td><td class=r>{n0(r.Grade)}</td><td class=r>{n0(r.Proj)}</td><td class=r><b>{n0(r.Real)}</b></td><td class=r>{n0(r.A)}</td>'
            f'{z(r.NR, "red")}{z(r.B)}{z(r.BD)}<td class=r><b>{n0(r.Bt) if r.Bt else "–"}</b></td>{z(r.Xat)}{z(r.N)}<td class=r>{brl(r.RA)}</td><td class=r>{brl(r.RB)}</td><td class=r><b>{brl(r.RT)}</b></td></tr>')
s = O[C].sum(); D = O.groupby('Data')[C].sum()
dias = ''.join(lin(f'{DS[d.weekday()]} {d:%d/%m}', r) for d, r in D.iterrows()) + lin('3 dias', s, 'tot')
T = O.groupby(['Regiao', 'Travessia', 'Reg'])[C].sum().reset_index(); T['o'] = T.Travessia.map(ORD.index); T = T.sort_values('o')
trs = ''
for g in REG:
    t = T[T.Regiao == g]
    trs += f'<tr class=rg><td colspan=14>{g}</td></tr>' + ''.join(lin(f'{r.Travessia}<small>{"demanda" if r.Reg == "Conforme demanda" else "fixo"}</small>', r) for r in t.itertuples())
trs += lin('Total', s, 'tot')
B = TR[TR.cat.isin(['B', 'BD'])]; X = TR[TR.cat == 'Xatraso']
FX_ = pd.cut(B.Saida.dt.hour, [-1, 4, 6, 8, 11, 15, 18, 23], labels=['00–05', '05–07', '07–09', '09–12', '12–16', '16–19', '19–24'])
hh = B.groupby(['Travessia', FX_], observed=False).size().unstack(fill_value=0)
hh = hh.loc[[t for t in ORD if t in hh.index]]
hrows = ''.join(f'<tr><td class=m>{t}</td>' + ''.join(z(v) for v in r) + f'<td class=r><b>{r.sum()}</b></td></tr>' for t, r in hh.iterrows())
hrows += '<tr class=tot><td class=m>Total</td>' + ''.join(f'<td class=r>{v}</td>' for v in hh.sum()) + f'<td class=r>{hh.values.sum()}</td></tr>'
xl = '; '.join(f'{r.Travessia} ({r.Margem}) {r.Data:%d/%m} saída {r.Saida:%H:%M}, {r.excl.replace("atrasada do horário", "do horário")}' for r in X.itertuples())
sg = T.set_index('Travessia')
d0, d2 = D.iloc[0], D.iloc[-1]
dem = T[T.Reg == 'Conforme demanda'].sort_values('BD', ascending=False)
fixN = T[(T.N > 0)].sort_values('N', ascending=False)
PA = s.Bt / 4; PM = s.A / 4
ana = [f'<li><b>Contraprestação efetiva dos 3 dias (antes do desconto por desempenho): {brl(s.RT)}</b>. Parcela fixa {brl(s.RA)} e parcela variável {brl(s.RB)}. Passou de {brl(d0.RT)} em 09/11 para {brl(d2.RT)} em 11/11.</li>',
       f'<li><b>Grade:</b> {n0(s.A)} das {n0(s.Grade)} viagens da grade foram realizadas ({pct(s.A/s.Grade)}). A grade não realizada caiu de {n0(d0.NR)} para {n0(d2.NR)}; Natividade ({n0(sg.NR["Natividade"])}), Paraitinga ({n0(sg.NR["Paraitinga"])}), Varginha ({n0(sg.NR["Varginha"])}) e Bertioga ⇄ Guarujá ({n0(sg.NR["Bertioga ⇄ Guarujá"])}) concentram a maior parte.</li>',
       f'<li><b>Adicionais (B): {n0(s.Bt)} viagens</b>, {n0(s.B)} na madrugada (00h–05h) e {n0(s.BD)} dentro das faixas conforme demanda: ' + '; '.join(f'{r.Travessia} {n0(r.BD)}' for r in dem.itertuples() if r.BD) + '.</li>',
       f'<li><b>Excluídas por atraso ({n0(s.Xat)}):</b> {xl}.</li>',
       f'<li><b>Fora da grade em horário fixo ({n0(s.N)}):</b> viagens extras depois das 05h em períodos de horário fixo, que não entram na receita: ' + '; '.join(f'{r.Travessia} {n0(r.N)}' for r in fixN.itertuples()) + '.</li>']
crit = ['Anexo 14, itens 2.1.2 e 2.1.3: CPE = (PF + PV) × (1 − DD); PF = PUP × PMF × FO; PV = PUP × 0,6 × PA × FO. Partidas = viagens ÷ 4 (na Tabela 1, viagens = 4 × partidas). PUP R$ 2.314,05 e FO 0,75 (ano 1).',
        'PF (parcela fixa): viagens que cumpriram a grade. Horário fixo: saída mais próxima entre 10 min antes e 15 min depois. Faixa conforme demanda: 1ª saída de cada janela do intervalo máximo.',
        'PV (parcela variável): viagens fora da grade (a) com saída entre 00h00 e 04h59, em todas as travessias, ou (b) dentro de uma faixa conforme demanda, conforme o regime de cada travessia. Fora da grade em período de horário fixo depois das 05h não conta.',
        'Excluídas por atraso: saída fora da grade até 60 min depois de um horário fixo não realizado, na mesma travessia e margem (é a viagem do horário que atrasou).',
        'DD = 1 − (0,8 + 0,2 × IQS) (item 2.2.1). A contraprestação paga ainda desconta a receita tarifária e o ônus de fiscalização (item 2.1.1). Não contam viagens de serviço nem registros repetidos (mesma embarcação e sentido, menos de 3 min).']
hhd = ''.join(f'<th class=r>{c}</th>' for c in hh.columns)
iqs = ''.join(f'<tr><td class=m>IQS {q:.2f}</td><td class=r>{pct(1-(0.8+0.2*q))}</td><td class=r><b>{brl(s.RT*(0.8+0.2*q))}</b></td></tr>'.replace('.', ',', 1) for q in (1, 0.95, 0.9))
html = f"""<div class=hero><div class=pat></div><div class=eb>Relatório financeiro de viagens · análise pelo Anexo 14</div><h1>Análise de 09 a 11/11/2026</h1>
<div class=per>Parcela fixa pela grade · parcela variável na madrugada e nas faixas conforme demanda</div><div class=w></div></div>
<div class=kp><div>Viagens realizadas<b>{n0(s.Real)}</b>{pct(s.Real/s.Proj)} da projeção</div><div>Na grade · PF<b>{n0(s.A)}</b>{n0(PM).replace(',', '.')} partidas · {pct(s.A/s.Grade)} da grade</div>
<div>Adicionais · PV<b>{n0(s.Bt)}</b>{n0(PA)} partidas · {n0(s.Xat)} excl. por atraso</div><div>Parcela fixa (PF)<b>{brl(s.RA)}</b></div><div>Parcela variável (PV)<b>{brl(s.RB)}</b></div><div>PF + PV<b>{brl(s.RT)}</b>média de {brl(s.RT/3)}/dia</div></div>
<h2><span class=n>1</span>Os 3 dias</h2><table class="t hm"><tr><th>Dia</th>{HD}</tr>{dias}</table>
<div class=obs><ul>{"".join(ana)}</ul></div>
<h3>Por travessia, 3 dias somados</h3><table class="t hm"><tr><th>Travessia <small>regime</small></th>{HD}</tr>{trs}</table>
<div style="display:grid;grid-template-columns:118mm 1fr;gap:6mm;align-items:start"><div><h3>Adicionais (B) por faixa horária</h3>
<table class="t hm"><tr><th>Travessia</th>{hhd}<th class=r>Total</th></tr>{hrows}</table></div>
<div><h3>Desconto por desempenho (simulação)</h3><table class="t hm"><tr><th>IQS</th><th class=r>DD</th><th class=r>CPE (PF + PV) × (1 − DD)</th></tr>{iqs}</table></div></div>
<h3>Critérios</h3><ol class=crit>{"".join(f"<li>{c}</li>" for c in crit)}</ol>"""
css = open('base.css').read()
open('analise_regime.html', 'w').write(f'<!doctype html><html lang=pt-BR><head><meta charset=utf-8><title>Análise de Viagens</title><style>{css}\n.kp{{grid-template-columns:repeat(6,1fr)!important;margin-bottom:3mm}} .kp div{{font-size:6.1pt}} .kp b{{font-size:11.5pt;white-space:nowrap}} .hm th{{font-size:5.4pt}} .hm td{{font-size:6.7pt;padding:.5mm 1mm}} .hm td small{{font-size:5.4pt}} .hero{{padding:4mm 6mm 3.5mm;margin-bottom:3mm}} .hero h1{{font-size:18pt}} .obs{{font-size:7pt;padding:1.5mm 3mm}} .obs li{{margin:0 0 .5mm}} h3{{margin:2.5mm 0 1mm}} .crit{{font-size:6.5pt;padding-left:4mm;margin:0}} tr.rg td{{padding:.5mm 1mm}}</style></head><body>{{html}}</body></html>'.replace('{html}', html))
print(s.round(0).to_dict())
