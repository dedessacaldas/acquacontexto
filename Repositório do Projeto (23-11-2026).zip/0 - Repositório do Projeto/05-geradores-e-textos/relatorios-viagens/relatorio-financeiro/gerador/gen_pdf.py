"""res.pkl (gerar.py) -> financeiro.html; depois: node print.js $PWD/financeiro.html <saida.pdf> $PWD/header.html"""
import pickle, pandas as pd
R0 = pickle.load(open('res.pkl', 'rb'))
P, R, VA, VB = R0['P'], R0['R'], R0['VA'], R0['VB']
MESES = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez']
n0 = lambda x: f'{x:,.0f}'.replace(',', '.')
def brl(x, d=0): return ('−' if round(x, d) < 0 else '') + 'R$ ' + f'{abs(x):,.{d}f}'.replace(',', '#').replace('.', ',').replace('#', '.')
def mi(x): return 'R$ ' + f'{x/1e6:,.2f}'.replace('.', ',') + ' mi'
def mil(x): return f'{x/1e3:,.0f}'.replace(',', '.')
pct = lambda x: f'{x*100:.1f}%'.replace('.', ',')
REG = ['Baixada Santista', 'Litoral Norte', 'Litoral Sul', 'Paraibuna', 'Metropolitana']

def mlab(m, full=False):
    d = P[P.Mes == m].Data; s = f'{MESES[m.month-1]}/{m.year%100:02d}'
    if full and (d.dt.day.min() > 1 or d.max().day != m.days_in_month): s += f' <small>({d.min():%d}–{d.max():%d})</small>'
    return s

tot = P[['Projetadas', 'Grade', 'A', 'B', 'RA', 'RB', 'RT']].sum()
M = P.groupby('Mes')[['Projetadas', 'Grade', 'A', 'B', 'RA', 'RB', 'RT']].sum()
T = P.groupby(['Regiao', 'Travessia', 'Ordem'])[['Projetadas', 'Grade', 'A', 'B', 'RA', 'RB', 'RT']].sum().reset_index().sort_values('Ordem')
MT = P.pivot_table(index='Travessia', columns='Mes', values='RT', aggfunc='sum')
cheios = M.iloc[1:-1].RT.mean()

h = []
h.append(f'''<div class=hero><div class=pat></div><div class=eb>Relatório financeiro · projeção de viagens</div>
<h1>Receita projetada do ano contratual 1</h1><div class=per>09/11/2026 a 08/11/2027 · viagens obrigatórias e adicionais por mês e por travessia</div><div class=w></div></div>
<div class=kp><div>Viagens projetadas<b>{n0(tot.Projetadas)}</b></div><div>Obrigatórias (A)<b>{n0(tot.A)}</b>{pct(tot.A/tot.Projetadas)} das projetadas</div>
<div>Adicionais (B)<b>{n0(tot.B)}</b>{pct(tot.B/tot.Projetadas)} das projetadas</div><div>Receita (A)<b>{mi(tot.RA)}</b></div><div>Receita (B)<b>{mi(tot.RB)}</b></div>
<div>Receita total<b>{mi(tot.RT)}</b>média de {mi(cheios)} por mês cheio</div></div>
<div class=obs><ul><li><b>Valor por viagem:</b> obrigatória (A) = R$ 2.314,05 × 0,75 ÷ 4 = <b>{brl(VA,2)}</b>; adicional (B) = 60% = <b>{brl(VB,2)}</b>.</li>
<li><b>Obrigatórias (A)</b> são as viagens da grade de horários do dia, até o limite da projeção; <b>adicionais (B)</b> são as viagens projetadas acima da grade.</li></ul></div>''')

# gráfico mensal empilhado
W, H, pl, pb, pt = 760, 210, 44, 22, 14
mx = M.RT.max() * 1.12; bw = (W - pl - 10) / len(M)
svg = [f'<svg class=chart viewBox="0 0 {W} {H}">']
for k in range(0, 30, 5):
    y = H - pb - (k * 1e6) / mx * (H - pb - pt)
    if y < pt: break
    svg.append(f'<line class=grid x1={pl} x2={W-6} y1={y:.1f} y2={y:.1f} /><text class=ax x={pl-5} y={y+2.5:.1f} text-anchor=end>{k} mi</text>')
for i, (m, r) in enumerate(M.iterrows()):
    x = pl + i * bw + bw * .18; w = bw * .64
    ha = r.RA / mx * (H - pb - pt); hb = r.RB / mx * (H - pb - pt); y0 = H - pb
    svg.append(f'<rect x={x:.1f} y={y0-ha:.1f} width={w:.1f} height={ha:.1f} fill="#005B7F" rx=1 />')
    svg.append(f'<rect x={x:.1f} y={y0-ha-hb:.1f} width={w:.1f} height={hb:.1f} fill="#00B5AD" rx=1 />')
    svg.append(f'<text x={x+w/2:.1f} y={y0-ha-hb-3:.1f} text-anchor=middle style="font-size:7.5px;font-weight:700;fill:#005B7F">{r.RT/1e6:.1f}</text>'.replace('.', ',', 0))
    svg.append(f'<text class=ax x={x+w/2:.1f} y={H-8} text-anchor=middle>{mlab(m)}</text>')
svg.append('</svg>')
svg = ''.join(svg)
import re
svg = re.sub(r'>(\d+)\.(\d)</text>', r'>\1,\2</text>', svg)
h.append(f'<h2><span class=n>1</span>Receita projetada por mês</h2><p class=lead>Mês do calendário. Nov/26 começa em 09/11 e nov/27 termina em 08/11, por isso são meses parciais.</p>')
h.append(f'<div class=cbox><div class=lg><i style="background:#005B7F;margin-left:0"></i>Receita (A) obrigatórias<i style="background:#00B5AD"></i>Receita (B) adicionais <span style="float:right">valores em R$ milhões</span></div>{svg}</div>')
rows = ''.join(f'<tr><td class=m>{mlab(m,True)}</td><td class=r>{n0(r.Projetadas)}</td><td class=r>{n0(r.A)}</td><td class=r>{n0(r.B)}</td><td class=r>{brl(r.RA)}</td><td class=r>{brl(r.RB)}</td><td class=r><b>{brl(r.RT)}</b></td></tr>' for m, r in M.iterrows())
h.append(f'''<table class="t hm"><tr><th>Mês</th><th class=r>Projetadas</th><th class=r>Obrigatórias (A)</th><th class=r>Adicionais (B)</th><th class=r>Receita (A)</th><th class=r>Receita (B)</th><th class=r>Receita total</th></tr>{rows}
<tr class=tot><td class=m>Total</td><td class=r>{n0(tot.Projetadas)}</td><td class=r>{n0(tot.A)}</td><td class=r>{n0(tot.B)}</td><td class=r>{brl(tot.RA)}</td><td class=r>{brl(tot.RB)}</td><td class=r>{brl(tot.RT)}</td></tr></table>''')

# 2 por travessia
h.append('<div class=sec><h2><span class=n>2</span>Receita do ano por travessia</h2><p class=lead>Grade = viagens previstas nas grades de horários nos dias em que a travessia tem viagens projetadas.</p>')
rows = ''
for g in REG:
    t = T[T.Regiao == g]
    if t.empty: continue
    rows += f'<tr class=rg><td colspan=9>{g}</td></tr>'
    for r in t.itertuples():
        w = r.RT / T.RT.max() * 13
        rows += f'<tr><td class=m>{r.Travessia}</td><td class=r>{n0(r.Projetadas)}</td><td class=r>{n0(r.Grade)}</td><td class=r>{n0(r.A)}</td><td class=r>{n0(r.B)}</td><td class=r>{brl(r.RA)}</td><td class=r>{brl(r.RB)}</td><td class=r><b>{brl(r.RT)}</b></td><td style="white-space:nowrap"><span style="display:inline-block;height:2.6mm;width:{w:.1f}mm;background:#00B5AD;border-radius:.5mm;vertical-align:-.4mm"></span> {pct(r.RT/tot.RT)}</td></tr>'
    s = t[['Projetadas', 'Grade', 'A', 'B', 'RA', 'RB', 'RT']].sum()
    rows += f'<tr><td class=m style="color:#008C86">Subtotal {g}</td><td class=r><b>{n0(s.Projetadas)}</b></td><td class=r><b>{n0(s.Grade)}</b></td><td class=r><b>{n0(s.A)}</b></td><td class=r><b>{n0(s.B)}</b></td><td class=r><b>{brl(s.RA)}</b></td><td class=r><b>{brl(s.RB)}</b></td><td class=r><b>{brl(s.RT)}</b></td><td><b>{pct(s.RT/tot.RT)}</b></td></tr>'
h.append(f'''<table class="t hm"><tr><th>Travessia</th><th class=r>Projetadas</th><th class=r>Grade</th><th class=r>Obrigat. (A)</th><th class=r>Adicion. (B)</th><th class=r>Receita (A)</th><th class=r>Receita (B)</th><th class=r>Receita total</th><th>% da receita</th></tr>{rows}
<tr class=tot><td class=m>Total</td><td class=r>{n0(tot.Projetadas)}</td><td class=r>{n0(tot.Grade)}</td><td class=r>{n0(tot.A)}</td><td class=r>{n0(tot.B)}</td><td class=r>{brl(tot.RA)}</td><td class=r>{brl(tot.RB)}</td><td class=r>{brl(tot.RT)}</td><td>100%</td></tr></table>''')
h.append('<div class=obs><ul><li><b>Santos ⇄ Guarujá</b> responde por ' + pct(T.set_index('Travessia').RT['Santos ⇄ Guarujá'] / tot.RT) +
         ' da receita, com ' + pct(T.set_index('Travessia').B['Santos ⇄ Guarujá'] / tot.B) + ' das viagens adicionais do ano.</li>' +
         '<li>João Basso, Taquacetuba e Bororé entram a partir do mês em que passam a ter viagens projetadas.</li></ul></div></div>')

# 3 matriz
meses = list(MT.columns)
h.append('<div class=sec><h2><span class=n>3</span>Receita por mês e travessia</h2><p class=lead>Receita total (A + B) em R$ mil.</p>')
hd = ''.join(f'<th class=r>{mlab(m)}</th>' for m in meses)
rows = ''
for g in REG:
    t = T[T.Regiao == g]
    if t.empty: continue
    rows += f'<tr class=rg><td colspan={len(meses)+2}>{g}</td></tr>'
    for tr in t.Travessia:
        rows += f'<tr><td class=m>{tr}</td>' + ''.join(f'<td class="r{" z" if MT.loc[tr, m] == 0 else ""}">{mil(MT.loc[tr, m]) if MT.loc[tr, m] else "–"}</td>' for m in meses) + f'<td class=r><b>{mil(MT.loc[tr].sum())}</b></td></tr>'
rows += '<tr class=tot><td class=m>Total</td>' + ''.join(f'<td class=r>{mil(MT[m].sum())}</td>' for m in meses) + f'<td class=r>{mil(MT.values.sum())}</td></tr>'
h.append(f'<table class="t hm" style="font-size:6.9pt"><tr><th>Travessia</th>{hd}<th class=r>Total</th></tr>{rows}</table></div>')

# 4 realizado
dd = sorted(R.Data.unique()); R['rP'] = R.A * VA + R.B * VB
h.append(f'<div class=sec><h2><span class=n>4</span>Realizado × projetado · {pd.Timestamp(dd[0]):%d/%m} a {pd.Timestamp(dd[-1]):%d/%m/%Y}</h2><p class=lead>Mesma regra aplicada às viagens realizadas: (A) até o limite da grade do dia e (B) acima dela. Viagens de serviço e registros repetidos não contam.</p>')
D = R.groupby('Data')[['Projetadas', 'Realizadas', 'rA', 'rB', 'rP', 'rRT']].sum()
rows = ''.join(f'<tr><td class=m>{pd.Timestamp(d):%d/%m/%Y}</td><td class=r>{n0(r.Projetadas)}</td><td class=r>{n0(r.Realizadas)}</td><td class=r>{pct(r.Realizadas/r.Projetadas)}</td><td class=r>{n0(r.rA)}</td><td class=r>{n0(r.rB)}</td><td class=r>{brl(r.rP)}</td><td class=r><b>{brl(r.rRT)}</b></td><td class="r{" red" if r.rRT-r.rP < 0 else ""}">{brl(r.rRT-r.rP)}</td></tr>' for d, r in D.iterrows())
s = D.sum()
h.append(f'''<table class="t hm"><tr><th>Dia</th><th class=r>Projetadas</th><th class=r>Realizadas</th><th class=r>% da projeção</th><th class=r>Realizadas (A)</th><th class=r>Realizadas (B)</th><th class=r>Receita projetada</th><th class=r>Receita realizada</th><th class=r>Diferença</th></tr>{rows}
<tr class=tot><td class=m>Período</td><td class=r>{n0(s.Projetadas)}</td><td class=r>{n0(s.Realizadas)}</td><td class=r>{pct(s.Realizadas/s.Projetadas)}</td><td class=r>{n0(s.rA)}</td><td class=r>{n0(s.rB)}</td><td class=r>{brl(s.rP)}</td><td class=r>{brl(s.rRT)}</td><td class=r>{brl(s.rRT-s.rP)}</td></tr></table>''')
Tr = R.groupby(['Regiao', 'Travessia', 'Ordem'])[['Grade', 'Projetadas', 'Realizadas', 'rA', 'rB', 'rP', 'rRT']].sum().reset_index().sort_values('Ordem')
rows = ''
for g in REG:
    t = Tr[Tr.Regiao == g]
    if t.empty: continue
    rows += f'<tr class=rg><td colspan=9>{g}</td></tr>'
    for r in t.itertuples():
        df_ = r.rRT - r.rP
        rows += f'<tr><td class=m>{r.Travessia}</td><td class=r>{n0(r.Grade)}</td><td class=r>{n0(r.Projetadas)}</td><td class=r>{n0(r.Realizadas)}</td><td class="r{" red" if r.Realizadas < r.Projetadas*.9 else ""}">{pct(r.Realizadas/r.Projetadas)}</td><td class=r>{brl(r.rP)}</td><td class=r><b>{brl(r.rRT)}</b></td><td class="r{" red" if df_ < 0 else ""}">{brl(df_)}</td></tr>'
h.append(f'<h3>Por travessia, acumulado do período</h3><table class="t hm"><tr><th>Travessia</th><th class=r>Grade</th><th class=r>Projetadas</th><th class=r>Realizadas</th><th class=r>% da projeção</th><th class=r>Receita projetada</th><th class=r>Receita realizada</th><th class=r>Diferença</th></tr>{rows}' +
         f'<tr class=tot><td class=m>Total</td><td class=r>{n0(Tr.Grade.sum())}</td><td class=r>{n0(s.Projetadas)}</td><td class=r>{n0(s.Realizadas)}</td><td class=r>{pct(s.Realizadas/s.Projetadas)}</td><td class=r>{brl(s.rP)}</td><td class=r>{brl(s.rRT)}</td><td class=r>{brl(s.rRT-s.rP)}</td></tr></table>')
neg = Tr.assign(d=Tr.rRT - Tr.rP).sort_values('d')
pos = neg[neg.d > 0].sort_values('d', ascending=False)
li = ''.join(f'<li><b>{r.Travessia}</b>: {brl(r.d)} ({n0(r.Realizadas)} realizadas de {n0(r.Projetadas)} projetadas).</li>' for r in neg.head(3).itertuples())
li += ''.join(f'<li><b>{r.Travessia}</b>: +{brl(r.d)}, viagens acima da grade além do projetado.</li>' for r in pos.head(1).itertuples())
h.append(f'<div class=obs><ul>{li}</ul></div>')

# critérios
crit = ['Receita por viagem = PUP × FO ÷ 4, com PUP de R$ 2.314,05 e fator de operação 0,75 (ano contratual 1). Viagem adicional vale 60% da obrigatória.',
        'Obrigatórias (A): viagens da grade de horários do tipo de dia (dia útil, sábado, domingo ou feriado), limitadas às viagens projetadas do dia.',
        'Adicionais (B): viagens projetadas acima da grade do dia.',
        'Grade: cada horário fixo conta 1 viagem por margem; cada faixa conforme demanda conta 1 viagem por janela do intervalo máximo, por margem.',
        'Travessia sem viagens projetadas no dia não entra no cálculo, nem na grade.',
        'Valores antes do desconto por desempenho (IQS), da receita tarifária e do ônus de fiscalização.',
        'Realizado: viagens com início de travessia no dia; não contam viagens de serviço nem registros repetidos da mesma embarcação e sentido em menos de 3 minutos.']
h.append('<h3 style="margin-top:6mm">Critérios</h3><ol class=crit>' + ''.join(f'<li>{c}</li>' for c in crit) + '</ol></div>')

css = open('base.css').read()
open('financeiro.html', 'w').write(f'<!doctype html><html lang=pt-BR><head><meta charset=utf-8><title>Relatório Financeiro de Viagens</title><style>{css}\n.hm td small{{font-size:6pt}} .kp{{grid-template-columns:repeat(6,1fr)!important}} .kp div{{font-size:6.4pt}} .kp b{{font-size:12pt;white-space:nowrap}}</style></head><body>{"".join(h)}</body></html>')
print('ok')
