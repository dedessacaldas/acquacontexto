"""Relatório financeiro das viagens (projeção × grade) + realizado.
Uso: python3 gerar.py <BD_QT.xlsx> <export BSM.xlsx> <saida.xlsx>
Regra (Dedessa, 12/11/2026): receita = viagens ÷ 4 × PUP × FO; obrigatórias (A) = viagens da grade,
limitadas à projeção; adicionais (B) = projeção acima da grade, a 60%.
"""
import sys, numpy as np, pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.drawing.image import Image as XLImage
from openpyxl.utils import get_column_letter as L

BDQT, EXP, OUT = sys.argv[1:4]
BASES = '/mnt/project-files/power-bi-travessias/Bases BI - Travessias.xlsx'
LOGO = '/mnt/project-files/relatorios-viagens/gerador/logo_s.png'
PUP, FO, PCT, DIV = 2314.05, 0.75, 0.60, 4
VA = PUP * FO / DIV; VB = VA * PCT
MESES = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez']

x = pd.ExcelFile(BASES)
dT = x.parse('dTravessia'); cal = x.parse('dCalendario'); dG = x.parse('dGrade')
# grade por travessia × código do dia (cada horário fixo e cada janela conforme demanda = 1 viagem por margem)
GR = dG.groupby(['TravessiaID', 'CodDiaGrade']).size().rename('Grade').reset_index()

q = pd.read_excel(BDQT)
q = q.rename(columns={'DATA': 'Data'}).drop(columns='DIA')
P = q.melt('Data', var_name='NomeQuantitativo', value_name='Projetadas')
P = P.merge(dT[['NomeQuantitativo', 'TravessiaID', 'Travessia', 'Regiao', 'Ordem']], on='NomeQuantitativo')
P = P.merge(cal[['Data', 'DiaSemana', 'Feriado', 'CodDiaGrade', 'TipoDia']], on='Data')
P = P.merge(GR, on=['TravessiaID', 'CodDiaGrade'], how='left')
P['Grade'] = P.Grade.fillna(0).astype(int)
P['Projetadas'] = P.Projetadas.round(0).astype(int)   # JB e Bororé têm decimais na BD_QT
P.loc[P.Projetadas == 0, 'Grade'] = 0   # travessia sem projeção no dia = fora de operação: grade não entra
P['A'] = np.minimum(P.Grade, P.Projetadas)
P['B'] = (P.Projetadas - P.A).clip(lower=0)
P['RA'] = P.A * VA; P['RB'] = P.B * VB; P['RT'] = P.RA + P.RB
P['Mes'] = P.Data.dt.to_period('M')
P = P.sort_values(['Data', 'Ordem']).reset_index(drop=True)

# ---------- realizado (export BSM) ----------
v = pd.read_excel(EXP)
v.columns = ['TravessiaExport', 'AberturaBSM', 'Embarcacao', 'NumBSM', 'DePara', 'InicioEmbarque', 'Saida', 'Ped', 'Bic', 'Moto', 'Aut', 'Micro', 'Onibus', 'Cam2', 'Cam3', 'Cam4', 'TipoBSM', 'Chegada', 'FimDesembarque']
v['Saida'] = pd.to_datetime(v.Saida, dayfirst=True)
v['ModoExport'] = np.where(v.Embarcacao.astype(str).str.startswith('LS'), 'Lancha', 'Ferry boat')
v = v.merge(dT[['NomeExportViagens', 'ModoExport', 'TravessiaID']], left_on=['TravessiaExport', 'ModoExport'], right_on=['NomeExportViagens', 'ModoExport'], how='left')
v['Sentido'] = v.DePara.astype(str).str[0]
v['Data'] = v.Saida.dt.normalize()
v = v.sort_values(['Embarcacao', 'Saida'])
dup = (v.Saida - v.groupby(['Embarcacao', 'Sentido']).Saida.shift(1)).dt.total_seconds().div(60).lt(3)
v['Desc'] = v.TipoBSM.notna() | dup
semid = v.TravessiaID.isna().sum()
RV = v[~v.Desc].groupby(['Data', 'TravessiaID']).size().rename('Realizadas').reset_index()
desc = v.groupby('Data').Desc.sum()
R = P[P.Data.isin(RV.Data.unique())].merge(RV, on=['Data', 'TravessiaID'], how='left')
R['Realizadas'] = R.Realizadas.fillna(0).astype(int)
R = R[(R.Projetadas > 0) | (R.Realizadas > 0)]
R['rA'] = np.minimum(R.Grade, R.Realizadas); R['rB'] = R.Realizadas - R.rA
R['rRT'] = R.rA * VA + R.rB * VB

# ---------- Excel ----------
AZ = '005B7F'; ES = '00B5AD'; CL = 'EAF4F7'; CZ = '5F6B73'; LN = 'D5E3E9'; TX = '1F2A30'
F = lambda **k: Font(name='Lato', **k)
fill = lambda c: PatternFill('solid', start_color=c, end_color=c)
BOT = Border(bottom=Side(style='thin', color=LN))
TOPB = Border(top=Side(style='medium', color=AZ))
NUM = '#,##0'; BRL = '"R$" #,##0.00'; BRL0 = '"R$" #,##0'; PCTF = '0.0%'
wb = Workbook()

def banner(ws, ncols, titulo, sub):
    ws.sheet_view.showGridLines = False
    for r in (1, 2, 3):
        ws.row_dimensions[r].height = 16
        for c in range(1, ncols + 1): ws.cell(r, c).fill = fill(AZ)
    ws.row_dimensions[4].height = 4
    for c in range(1, ncols + 1): ws.cell(4, c).fill = fill(ES)
    img = XLImage(LOGO); img.width = 210; img.height = 25; ws.add_image(img, 'B2')
    c = ws.cell(2, ncols, titulo); c.font = F(bold=True, size=13, color='FFFFFF'); c.alignment = Alignment(horizontal='right', vertical='center')
    c = ws.cell(3, ncols, sub); c.font = F(size=9, color='CDE6EE'); c.alignment = Alignment(horizontal='right', vertical='center')
    ws.column_dimensions['A'].width = 2

def title(ws, r, txt, note=None):
    c = ws.cell(r, 2, txt); c.font = F(bold=True, size=12, color=AZ); ws.row_dimensions[r].height = 22
    if note: ws.cell(r + 1, 2, note).font = F(size=9, italic=True, color=CZ)

def head(ws, r, c, hs):
    for j, h in enumerate(hs):
        x = ws.cell(r, c + j, h); x.font = F(bold=True, size=10, color='FFFFFF'); x.fill = fill(AZ)
        x.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
    ws.row_dimensions[r].height = 32

def put(ws, r, c, vals, fmts, zebra=False, bold=False, total=False):
    for j, val in enumerate(vals):
        x = ws.cell(r, c + j, val); x.font = F(size=10, color=AZ if total else TX, bold=bold or total)
        x.border = TOPB if total else BOT
        if zebra: x.fill = fill(CL)
        if total: x.fill = fill('D9EEF3')
        if fmts[j]: x.number_format = fmts[j]
        x.alignment = Alignment(horizontal='left' if j == 0 else 'center', vertical='center')

SUB = 'Ano contratual 1 · 09/11/2026 a 08/11/2027'
TIT = 'Relatório Financeiro de Viagens'

# ---- Premissas (valores editáveis; o resto da planilha usa fórmulas que apontam para cá)
wp = wb.active; wp.title = 'Premissas'; banner(wp, 6, TIT, SUB)
for col, w in zip('BCDEF', [44, 16, 4, 60, 4]): wp.column_dimensions[col].width = w
title(wp, 6, 'Premissas de cálculo', 'Altere as células azuis: todas as abas recalculam.')
prem = [('Preço por partida (PUP)', PUP, BRL, 'Valor informado pela Acquavias'),
        ('Fator de operação (FO) – ano 1', FO, '0.00', 'Anexo 14, Tabela 1 (ano 1 = 0,75)'),
        ('Viagens por partida (divisor)', DIV, '0', 'Regra adotada: viagens ÷ 4'),
        ('Fator das viagens adicionais', PCT, '0%', 'Anexo 14, item 2.1.3 (PV = PUP × 0,6 × PA × FO)')]
head(wp, 9, 2, ['Parâmetro', 'Valor', '', 'Referência'])
for i, (a, b, f, d) in enumerate(prem):
    r = 10 + i; put(wp, r, 2, [a, b, None, d], [None, f, None, None])
    wp.cell(r, 3).font = F(size=10, bold=True, color='1F5FBF'); wp.cell(r, 3).fill = fill('EEF4FF')
put(wp, 15, 2, ['Valor por viagem obrigatória (A) = PUP × FO ÷ 4', '=C10*C11/C12', None, 'Viagem da grade de horários'], [None, BRL, None, None], bold=True)
put(wp, 16, 2, ['Valor por viagem adicional (B) = (A) × 60%', '=C15*C13', None, 'Viagem projetada acima da grade'], [None, BRL, None, None], bold=True)
VA_REF = 'Premissas!$C$15'; VB_REF = 'Premissas!$C$16'

# ---- Diário (base de tudo)
wd = wb.create_sheet('Diário')
cols = ['Data', 'Dia', 'Tipo de dia', 'Região', 'Travessia', 'Grade', 'Projetadas', 'Obrigatórias (A)', 'Adicionais (B)', 'Receita (A)', 'Receita (B)', 'Receita total', 'Mês']
banner(wd, len(cols) + 1, TIT, SUB)
title(wd, 6, 'Projeção diária por travessia', '(A) = grade do dia, limitada à projeção; (B) = projeção acima da grade.')
head(wd, 8, 2, cols)
for col, w in zip(range(2, 15), [11, 6, 16, 17, 32, 9, 11, 13, 13, 15, 15, 16, 9]): wd.column_dimensions[L(col)].width = w
r0 = 9
for i, t in enumerate(P.itertuples(index=False)):
    r = r0 + i
    vals = [t.Data.to_pydatetime(), t.DiaSemana, ('Feriado' if t.Feriado else t.TipoDia), t.Regiao, t.Travessia, t.Grade, t.Projetadas,
            f'=MIN(G{r},H{r})', f'=MAX(H{r}-I{r},0)', f'=I{r}*{VA_REF}', f'=J{r}*{VB_REF}', f'=K{r}+L{r}', f'{MESES[t.Data.month-1]}/{t.Data.year%100:02d}']
    put(wd, r, 2, vals, ['dd/mm/yyyy', None, None, None, None, NUM, NUM, NUM, NUM, BRL, BRL, BRL, None])
rN = r0 + len(P) - 1
wd.freeze_panes = 'C9'; wd.auto_filter.ref = f'B8:{L(14)}{rN}'
DR = lambda c: f"'Diário'!${c}${r0}:${c}${rN}"

# ---- Resumo mensal
ws = wb.create_sheet('Resumo', 0)
banner(ws, 10, TIT, SUB)
for col, w in zip('BCDEFGHIJ', [14, 13, 13, 13, 13, 17, 17, 18, 4]): ws.column_dimensions[col].width = w
title(ws, 6, 'Receita projetada por mês', 'Receita = viagens ÷ 4 × PUP × FO; adicionais a 60%. Valores antes do desconto de desempenho, da receita tarifária e do ônus de fiscalização.')
# cards
cards = [('Viagens projetadas', f'=SUM({DR("H")})', NUM), ('Obrigatórias (A)', f'=SUM({DR("I")})', NUM), ('Adicionais (B)', f'=SUM({DR("J")})', NUM), ('Receita do ano', f'=SUM({DR("M")})', BRL0)]
for j, (lab, f, fm) in enumerate(cards):
    c = 2 + j * 2
    ws.merge_cells(start_row=8, start_column=c, end_row=8, end_column=c + 1); ws.merge_cells(start_row=9, start_column=c, end_row=9, end_column=c + 1)
    a = ws.cell(8, c, lab); a.font = F(size=9, color=CZ); a.alignment = Alignment(horizontal='center')
    b = ws.cell(9, c, f); b.font = F(size=16, bold=True, color=AZ); b.number_format = fm; b.alignment = Alignment(horizontal='center')
    for cc in (c, c + 1):
        ws.cell(8, cc).fill = fill(CL); ws.cell(9, cc).fill = fill(CL)
ws.row_dimensions[9].height = 28
hr = 11
head(ws, hr, 2, ['Mês', 'Projetadas', 'Grade', 'Obrigatórias (A)', 'Adicionais (B)', 'Receita (A)', 'Receita (B)', 'Receita total'])
meses = sorted(P.Mes.unique())
for i, m in enumerate(meses):
    r = hr + 1 + i; lab = f'{MESES[m.month-1]}/{m.year%100:02d}'
    dias = P[P.Mes == m].Data
    lab2 = lab + (f' ({dias.min():%d}–{dias.max():%d})' if dias.dt.day.min() > 1 or dias.max() != (m.to_timestamp(how='end').normalize()) else '')
    crit = f'{DR("N")},"{lab}"'
    put(ws, r, 2, [lab2, f'=SUMIFS({DR("H")},{crit})', f'=SUMIFS({DR("G")},{crit})', f'=SUMIFS({DR("I")},{crit})', f'=SUMIFS({DR("J")},{crit})',
                   f'=SUMIFS({DR("K")},{crit})', f'=SUMIFS({DR("L")},{crit})', f'=SUMIFS({DR("M")},{crit})'],
        [None, NUM, NUM, NUM, NUM, BRL0, BRL0, BRL0], zebra=i % 2)
rt = hr + 1 + len(meses)
put(ws, rt, 2, ['Total'] + [f'=SUM({L(c)}{hr+1}:{L(c)}{rt-1})' for c in range(3, 10)], [None, NUM, NUM, NUM, NUM, BRL0, BRL0, BRL0], total=True)
ws.freeze_panes = 'B12'
notes = ['Grade = viagens previstas nas grades de horários do tipo de dia (cada horário fixo e cada janela conforme demanda conta 1 viagem por margem).',
         'Nos dias em que a grade é maior que a projeção (ex.: travessias ainda fora de operação), (A) fica limitada à projeção.',
         'Travessia sem viagem projetada no dia (João Basso, Taquacetuba e Bororé antes de entrar em operação) não entra, nem na grade.']
for i, n in enumerate(notes): ws.cell(rt + 2 + i, 2, '• ' + n).font = F(size=9, color=CZ)

# ---- Por travessia (ano) + matriz mensal
wt = wb.create_sheet('Por travessia', 1)
trs = P.drop_duplicates('TravessiaID').sort_values('Ordem')
ncol = 2 + len(meses) + 1
banner(wt, max(ncol + 1, 10), TIT, SUB)
title(wt, 6, 'Ano contratual 1 por travessia')
head(wt, 8, 2, ['Travessia', 'Região', 'Projetadas', 'Grade', 'Obrigatórias (A)', 'Adicionais (B)', 'Receita (A)', 'Receita (B)', 'Receita total', '% da receita'])
for col, w in zip(range(2, 12), [32, 17, 12, 12, 13, 13, 15, 15, 16, 11]): wt.column_dimensions[L(col)].width = w
for i, t in enumerate(trs.itertuples(index=False)):
    r = 9 + i; crit = f'{DR("F")},"{t.Travessia}"'
    put(wt, r, 2, [t.Travessia, t.Regiao, f'=SUMIFS({DR("H")},{crit})', f'=SUMIFS({DR("G")},{crit})', f'=SUMIFS({DR("I")},{crit})', f'=SUMIFS({DR("J")},{crit})',
                   f'=SUMIFS({DR("K")},{crit})', f'=SUMIFS({DR("L")},{crit})', f'=SUMIFS({DR("M")},{crit})', f'=J{r}/J${9+len(trs)}'],
        [None, None, NUM, NUM, NUM, NUM, BRL0, BRL0, BRL0, PCTF], zebra=i % 2)
rt2 = 9 + len(trs)
put(wt, rt2, 2, ['Total', None] + [f'=SUM({L(c)}9:{L(c)}{rt2-1})' for c in range(4, 11)] + [f'=J{rt2}/J{rt2}'], [None, None, NUM, NUM, NUM, NUM, BRL0, BRL0, BRL0, PCTF], total=True)
rm = rt2 + 3
title(wt, rm, 'Receita total por mês e travessia (R$)')
head(wt, rm + 2, 2, ['Travessia'] + [f'{MESES[m.month-1]}/{m.year%100:02d}' for m in meses] + ['Total'])
for j in range(len(meses) + 1): wt.column_dimensions[L(3 + j)].width = max(wt.column_dimensions[L(3 + j)].width or 0, 13)
for i, t in enumerate(trs.itertuples(index=False)):
    r = rm + 3 + i
    vals = [t.Travessia] + [f'=SUMIFS({DR("M")},{DR("F")},"{t.Travessia}",{DR("N")},"{MESES[m.month-1]}/{m.year%100:02d}")' for m in meses] + [f'=SUM(C{r}:{L(2+len(meses))}{r})']
    put(wt, r, 2, vals, [None] + [BRL0] * (len(meses) + 1), zebra=i % 2)
rt3 = rm + 3 + len(trs)
put(wt, rt3, 2, ['Total'] + [f'=SUM({L(c)}{rm+3}:{L(c)}{rt3-1})' for c in range(3, 4 + len(meses))], [None] + [BRL0] * (len(meses) + 1), total=True)
wt.freeze_panes = 'C9'

# ---- Realizado × projetado
wr = wb.create_sheet('Realizado × Projetado', 3)
dd = sorted(R.Data.unique())
banner(wr, 13, TIT, f'Realizado de {pd.Timestamp(dd[0]):%d/%m} a {pd.Timestamp(dd[-1]):%d/%m/%Y}')
title(wr, 6, 'Realizado × projetado', 'Mesma regra: (A) = realizadas até o limite da grade; (B) = realizadas acima da grade. Viagens de serviço (INF/LIXO/VAL) e registros duplicados não contam.')
hdr = ['Data', 'Travessia', 'Grade', 'Projetadas', 'Realizadas', '% da projeção', 'Realizadas (A)', 'Realizadas (B)', 'Receita realizada', 'Receita projetada', 'Diferença']
head(wr, 8, 2, hdr)
for col, w in zip(range(2, 13), [11, 32, 9, 11, 11, 11, 12, 12, 16, 16, 15]): wr.column_dimensions[L(col)].width = w
r = 9; tot_rows = []
for d in dd:
    sub_ = R[R.Data == d].sort_values('Ordem'); r1 = r
    for i, t in enumerate(sub_.itertuples(index=False)):
        put(wr, r, 2, [t.Data.to_pydatetime(), t.Travessia, t.Grade, t.Projetadas, t.Realizadas, f'=IF(E{r}=0,"",F{r}/E{r})',
                       f'=MIN(D{r},F{r})', f'=F{r}-H{r}', f'=H{r}*{VA_REF}+I{r}*{VB_REF}', f'=MIN(D{r},E{r})*{VA_REF}+MAX(E{r}-D{r},0)*{VB_REF}', f'=J{r}-K{r}'],
            ['dd/mm/yyyy', None, NUM, NUM, NUM, PCTF, NUM, NUM, BRL, BRL, BRL], zebra=i % 2)
        r += 1
    put(wr, r, 2, [pd.Timestamp(d).to_pydatetime(), 'Total do dia'] + [f'=SUM({L(c)}{r1}:{L(c)}{r-1})' for c in (4, 5, 6)] + [f'=F{r}/E{r}'] +
        [f'=SUM({L(c)}{r1}:{L(c)}{r-1})' for c in (8, 9, 10, 11, 12)], ['dd/mm/yyyy', None, NUM, NUM, NUM, PCTF, NUM, NUM, BRL, BRL, BRL], total=True)
    tot_rows.append(r); r += 2
put(wr, r, 2, [None, 'Total do período'] + [ '=' + '+'.join(f'{L(c)}{x}' for x in tot_rows) for c in (4, 5, 6)] + [f'=F{r}/E{r}'] +
    ['=' + '+'.join(f'{L(c)}{x}' for x in tot_rows) for c in (8, 9, 10, 11, 12)], [None, None, NUM, NUM, NUM, PCTF, NUM, NUM, BRL, BRL, BRL], total=True)
wr.freeze_panes = 'D9'

# ---- Critérios
wc = wb.create_sheet('Critérios')
banner(wc, 3, TIT, SUB); wc.column_dimensions['B'].width = 130
title(wc, 6, 'Critérios')
crit = [
 'Receita por viagem: viagens ÷ 4 × PUP × FO. Com PUP R$ 2.314,05 e FO 0,75, cada viagem obrigatória vale R$ 433,88 e cada adicional R$ 260,33 (60%).',
 'Obrigatórias (A): viagens da grade de horários do dia (dia útil, sábado, domingo ou feriado), limitadas às viagens projetadas.',
 'Adicionais (B): viagens projetadas acima da grade do dia.',
 'Grade: cada horário fixo conta 1 viagem por margem; cada faixa conforme demanda conta 1 viagem por janela do intervalo máximo, por margem.',
 'Mês: mês do calendário (nov/26 = 09 a 30/11; nov/27 = 01 a 08/11). FO 0,75 vale para todo o ano contratual 1.',
 'Não estão descontados: desconto por desempenho (IQS), receita tarifária e ônus de fiscalização (Anexo 14, itens 2.1.1 e 2.2.1).',
 'Pelo Anexo 14, a parcela fixa é paga sobre as partidas base da Tabela 1 e a variável só sobre as partidas acima delas. Este relatório segue a regra por viagem adotada pela Acquavias, não o cálculo literal do anexo.',
 'Realizado: viagens com início de travessia no dia. Viagens de serviço (INF, LIXO, VAL) e registros repetidos da mesma embarcação e sentido em menos de 3 min não contam.',
 'São Sebastião ⇄ Ilhabela: lanchas (LS) vão para a travessia de pedestres; as demais embarcações, para a balsa.',
]
for i, c in enumerate(crit):
    x = wc.cell(8 + i, 2, f'{i+1}. {c}'); x.font = F(size=10, color=TX); x.alignment = Alignment(wrap_text=True, vertical='top'); wc.row_dimensions[8 + i].height = 30

for w_ in wb.worksheets:
    w_.sheet_properties.pageSetUpPr.fitToPage = True; w_.page_setup.orientation = 'landscape'; w_.page_setup.fitToWidth = 1; w_.page_setup.fitToHeight = 0
from openpyxl.workbook.properties import CalcProperties
wb.calculation = CalcProperties(fullCalcOnLoad=True)
wb.save(OUT)

# conferência em Python (mesma regra)
import pickle
pickle.dump(dict(P=P, R=R, VA=VA, VB=VB, semid=semid, desc=desc), open('res.pkl', 'wb'))
print('VA', round(VA, 4), 'VB', round(VB, 4))
print(P.groupby('Mes')[['Projetadas', 'Grade', 'A', 'B', 'RA', 'RB', 'RT']].sum().round(0).to_string())
print(P[['Projetadas', 'Grade', 'A', 'B', 'RA', 'RB', 'RT']].sum().round(0))
print(R.groupby('Data')[['Grade', 'Projetadas', 'Realizadas', 'rA', 'rB', 'rRT']].sum().round(0))
print('sem travessia', semid, 'desconsideradas', desc.to_dict())
