"""Relatório de viagens da Operação, 09 a 11/11/2026, no modelo do relatório por travessia.
Base: full/dia09-11.pkl (calc.py do relatório diário sobre o export completo, 4.506 viagens), grades (grades.py) e quantitativo (BD_QT).
Rodar da pasta gerador/: python3 operacao/gen_op.py"""
import pickle, sys, pandas as pd
sys.path.insert(0, '/mnt/project-files/relatorios-viagens/relatorio-diario/gerador')
from grades import ORDER
DIAS = sys.argv[1].split(',') if len(sys.argv) > 1 else ['09', '10', '11']
UM = len(DIAS) == 1
DSL = ['Segunda-feira', 'Terça-feira', 'Quarta-feira', 'Quinta-feira', 'Sexta-feira', 'Sábado', 'Domingo']
PER = f'{DIAS[0]}/11/2026' if UM else f'{DIAS[0]} a {DIAS[-1]}/11/2026'
PL = 'no dia' if UM else f'{len(DIAS)} dias'
DCOL = [] if UM else DIAS
Y = {d: pickle.load(open(f'full16/dia{d}.pkl', 'rb')) for d in DIAS}
R3 = pickle.load(open('projecao/proj16.pkl', 'rb'))['R3']
DS = ['seg', 'ter', 'qua', 'qui', 'sex', 'sáb', 'dom']
n0 = lambda x: f'{x:,.0f}'.replace(',', '.')
pct = lambda a, b: '–' if not b else f'{100 * a / b:.1f}%'.replace('.', ',')
hm = lambda t: '' if t is None or pd.isna(t) else pd.Timestamp(t).strftime('%H:%M')
z = lambda v: n0(v) if v else '–'

def cat(key):
    return pd.concat([Y[d][key].assign(dia=Y[d]['D']) for d in DIAS], ignore_index=True)
DF, FX, BD, GP = cat('df'), cat('FX'), cat('BD'), cat('GP')
QT = {d: Y[d]['QT'] for d in DIAS}
_T = {0:'dia útil',1:'dia útil',2:'dia útil',3:'dia útil',4:'dia útil',5:'sábado',6:'domingo'}
TIPOG = ' / '.join(dict.fromkeys(_T[Y[d]['D'].weekday()] for d in DIAS))
AB = R3.set_index(['Data', 'Travessia'])

# ---------- ocorrências (export do sistema) ----------
from datetime import timedelta
OC = pd.read_excel('entradas/Ocorrencias_NOV_26_09a16.xlsx')
OC.columns = ['trav', 'ref', 'tipo', 'com', 'para', 'ini', 'fim', 'emb', 'margem', 'user']
OC['fim'] = OC.fim.fillna(OC.ini)
OC['com'] = OC.com.fillna('').astype(str).str.replace(r'\s+', ' ', regex=True).str.strip()
def categ(r):
    c = r.com.lower()
    if r.tipo == 'Maré' or 'maré' in c: return 'Maré'
    if 'navio' in c or 'draga' in c: return 'Passagem de navio/draga'
    if 'especial' in c or 'ambulância' in c or 'emergência' in c: return 'Viagem especial / emergência'
    if 'vazia' in c or 'demanda' in c: return 'Viagem vazia / demanda unilateral'
    if 'troca' in c or 'antes' in c or 'antecip' in c: return 'Troca de embarcação / saída antecipada'
    if isinstance(r.tipo, str): return r.tipo
    return 'Sem descrição' if not c else 'Outras'
OC['cat'] = OC.apply(categ, axis=1)
MODOS = {t: [mm for _, it in ORDER for tt, mm, *_ in it if tt == t] for _, it in ORDER for t, *_ in it}
def oc_modos(r):
    ms = MODOS.get(r.trav, [])
    if len(ms) > 1 and isinstance(r.emb, str): ms = ['Lancha'] if r.emb.startswith('LS') else ['Ferry boat']
    return ms
OC['modos'] = OC.apply(oc_modos, axis=1)
DD = [Y[d]['D'] for d in DIAS]
OCDIAS = sorted(set(OC.ini.dt.normalize())); OCCOB = [D for D in DD if D in OCDIAS]
OC = OC[OC.ini.dt.normalize().isin(DD)].reset_index(drop=True)
OCNOTA = ('Ocorrências: cruzamento feito só para ' + ', '.join(f'{D:%d/%m}' for D in OCCOB) + '; os registros dos demais dias ainda não foram recebidos.') if OCCOB and len(OCCOB) < len(DD) else ('Ocorrências: registros deste período ainda não recebidos; cruzamento não feito.' if not OCCOB else '')
def oc_de(t, m): return OC[[(r.trav == t and m in r.modos) for r in OC.itertuples()]]
def casa(o, a, b, pre=10, pos=20):
    """ocorrências que se sobrepõem a [a, b] (com tolerância antes/depois)"""
    if not len(o): return o
    return o[(o.ini <= b + timedelta(minutes=pos)) & (o.fim >= a - timedelta(minutes=pre))]
def rot(o): return '; '.join(f'{x.cat} {x.ini:%H:%M}' for x in o.itertuples())
FX['oc'] = ''; GP['oc'] = ''
for i, x in FX[FX.status.isin(['Atrasada', 'Adiantada', 'Não realizada'])].iterrows():
    o = casa(oc_de(x.trav, x.modo), x.prog, x.prog if pd.isna(x.real) else max(x.prog, x.real))
    FX.loc[i, 'oc'] = rot(o)
for i, x in GP.iterrows():
    GP.loc[i, 'oc'] = rot(casa(oc_de(x.trav, x.modo), x['de'], x.ate, 5, 5))
FX['jus'] = FX.status.isin(['Atrasada', 'Adiantada', 'Não realizada']) & (FX.oc != ''); GP['jus'] = GP.oc != ''
def impacto(o, t, m):
    f = FX[(FX.trav == t) & (FX.modo == m) & FX.status.isin(['Atrasada', 'Adiantada', 'Não realizada'])]; g = GP[(GP.trav == t) & (GP.modo == m)]
    nf = sum(len(casa(o.to_frame().T, x.prog, x.prog if pd.isna(x.real) else max(x.prog, x.real))) > 0 for x in f.itertuples())
    ng = sum(len(casa(o.to_frame().T, x.de, x.ate, 5, 5)) > 0 for x in g.itertuples())
    return nf, ng

# ---------- por travessia ----------
T = []
for reg, items in ORDER:
    for t, m, lab, q in items:
        g = DF[(DF.trav == t) & (DF.modo == m)]; f = FX[(FX.trav == t) & (FX.modo == m)]; b = BD[(BD.trav == t) & (BD.modo == m)]
        r = dict(reg=reg, t=t, m=m, lab=lab, q=q, V=len(g), Q=sum(QT[d].get(q, 0) for d in DIAS), emb=g.emb.nunique(),
                 ped=g.ped.sum(), bic=g.bic.sum(), veic=g.veic.sum(),
                 fp=len(f), fno=(f.status == 'No horário').sum(), fj=f.jus.sum(), fn=(f.status == 'No horário').sum() + f.jus.sum(), fat=((f.status == 'Atrasada') & ~f.jus).sum(), fad=((f.status == 'Adiantada') & ~f.jus).sum(), fnr=((f.status == 'Não realizada') & ~f.jus).sum(), fnrb=(f.status == 'Não realizada').sum(),
                 bs=b.saidas.sum(), bmin=b.minimo.sum(), bexb=b.excessos.sum(), bj=GP[(GP.trav == t) & (GP.modo == m)].jus.sum(), bex=b.excessos.sum() - GP[(GP.trav == t) & (GP.modo == m)].jus.sum(), bmx=b.maior_int.max() if len(b) else 0,
                 A=sum(AB.loc[(Y[d]['D'], lab), 'A'] for d in DIAS if (Y[d]['D'], lab) in AB.index),
                 B=sum(AB.loc[(Y[d]['D'], lab), 'B'] for d in DIAS if (Y[d]['D'], lab) in AB.index),
                 oc=len(oc_de(t, m)), fxo=(f.oc != '').sum(), fof=f.status.isin(['Atrasada', 'Adiantada', 'Não realizada']).sum(),
                 gxo=(GP[(GP.trav == t) & (GP.modo == m)].oc != '').sum())
        for d in DIAS:
            r['V' + d] = (g.dia == Y[d]['D']).sum(); r['Q' + d] = QT[d].get(q, 0)
            ff = f[f.dia == Y[d]['D']]; r['fp' + d] = len(ff); r['fn' + d] = (ff.status == 'No horário').sum() + ff.jus.sum(); r['fnr' + d] = ((ff.status == 'Não realizada') & ~ff.jus).sum()
            r['bex' + d] = b[b.dia == Y[d]['D']].excessos.sum() - GP[(GP.trav == t) & (GP.modo == m) & (GP.dia == Y[d]['D'])].jus.sum()
        T.append(r)
T = pd.DataFrame(T)
S = T.select_dtypes('number').sum()
S['emb'] = DF.emb.nunique(); S['bmx'] = T.bmx.max()

# =====================================================================
# APRESENTAÇÃO (v2, mais visual): semáforo por travessia, barras e linha do dia
# =====================================================================
OK, AT, CR, NA = '#00A79D', '#E39B2D', '#C8553D', '#B7C6CD'
JUS = '#5BC8C2'
COR = {'Justificada': JUS, 'No horário': OK, 'Atrasada': AT, 'Adiantada': '#7D5BA6', 'Não realizada': CR}
def nivel(v, bom, ruim, maior_melhor=True):
    if v is None: return 'na'
    if maior_melhor: return 'ok' if v >= bom else ('at' if v >= ruim else 'cr')
    return 'ok' if v <= bom else ('at' if v <= ruim else 'cr')
TXT = {'ok': 'OK', 'at': 'Atenção', 'cr': 'Crítico', 'na': '–'}
def ind(r):
    q = nivel(r['V'] / r['Q'] if r['Q'] else None, .98, .95)
    f = nivel(r['fn'] / r['fp'] if r['fp'] else None, .95, .85)
    i = nivel(r['bex'] / r['bmin'] if r['bmin'] else None, .02, .10, False)
    ordem = ['cr', 'at', 'ok']
    geral = next((o for o in ordem if o in (q, f, i)), 'na')
    return q, f, i, geral
def dot(n, lab=''): return f'<span class="dt {n}"></span>{lab}'
def bar(parts, w=24):
    tot = sum(v for v, _ in parts) or 1
    return f'<span class=sb2 style="width:{w}mm">' + ''.join(f'<i style="width:{100 * v / tot:.2f}%;background:{c}"></i>' for v, c in parts if v) + '</span>'
def mini(p, n, w=18):
    c = {'ok': OK, 'at': AT, 'cr': CR}.get(n, NA)
    return f'<span class=sb2 style="width:{w}mm;background:#E8EEF1"><i style="width:{min(p, 1) * 100:.1f}%;background:{c}"></i></span>'

# ---------- página 1 ----------
def linha(r, cls='', lab=None):
    q, f, i, gr = ind(r)
    viag = f'{mini(r["V"] / r["Q"] if r["Q"] else 0, q)} <b>{pct(r["V"], r["Q"])}</b><small>{n0(r["V"])} de {n0(r["Q"])} viagens</small>'
    fixo = ('<span class=na>sem horário fixo</span>' if not r['fp'] else
            f'{bar([(r["fno"], OK), (r["fj"], JUS), (r["fat"], AT), (r["fad"], COR["Adiantada"]), (r["fnr"], CR)])} <b>{pct(r["fn"], r["fp"])}</b><small>{n0(r["fno"])} no horário + {n0(r["fj"])} com ocorrência, de {n0(r["fp"])}'
            + (f' · {n0(r["fnr"])} não real. sem ocorrência' if r['fnr'] else '') + '</small>')
    intv = ('<span class=na>sem faixa sob demanda</span>' if not r['bmin'] else
            f'<span class="pill {i}">{n0(r["bex"])}</span><small>em {n0(r["bmin"])} janelas · {n0(r["bj"])} com ocorrência descontados</small>')
    oc = '<span class=na>–</span>' if not r['oc'] else f'<b>{n0(r["oc"])}</b><small>justificam {n0(r["fj"] + r["bj"])} de {n0(r["fof"] + r["bexb"])} desvios</small>'
    sit = '' if cls == 'tot' else f'<td>{dot(gr)}<span class="sl {gr}">{TXT[gr]}</span></td>'
    return f'<tr class="{cls}"><td class=m>{lab or r["lab"]}</td>{sit if cls != "tot" else "<td></td>"}<td>{viag}</td><td>{fixo}</td><td>{intv}</td><td>{oc}</td></tr>'
pan = ''
for reg, _ in ORDER:
    pan += f'<tr class=rg><td colspan=6>{reg}</td></tr>' + ''.join(linha(r) for _, r in T[T.reg == reg].iterrows())
pan += linha(S, 'tot', 'Total')
panh = ('<tr><th>Travessia</th><th>Situação</th><th>Viagens × quantitativo</th><th>Horários fixos no horário<br><span>considerando as ocorrências</span></th><th>Intervalos acima do máximo<br><span>sem ocorrência registrada</span></th><th>Ocorrências</th></tr>')

# dia a dia (só no relatório de vários dias): células coloridas
def cel(v, n, txt):
    return f'<td class="hc {n}">{txt}</td>'
dd = ''
if not UM:
    for _, r in T.iterrows():
        c1 = ''.join(cel(None, nivel(r['V' + d] / r['Q' + d] if r['Q' + d] else None, .98, .95), pct(r['V' + d], r['Q' + d])) for d in DIAS)
        c2 = ''.join(cel(None, nivel(r['fn' + d] / r['fp' + d] if r['fp' + d] else None, .95, .85), pct(r['fn' + d], r['fp' + d]) if r['fp' + d] else '–') for d in DIAS)
        c3 = ''.join(cel(None, 'ok' if not r['bex' + d] else ('at' if r['bex' + d] <= 5 else 'cr'), z(r['bex' + d]) if r['bmin'] else '–') for d in DIAS)
        dd += f'<tr><td class=m>{r.lab}</td>{c1}<td class=gap></td>{c2}<td class=gap></td>{c3}</tr>'
    dh = ''.join(f'<th class=c>{DS[Y[d]["D"].weekday()]} {d}</th>' for d in DIAS)
    tot1 = ''.join(f'<td class=c>{pct(sum(QT and [Y[d]["df"].shape[0]]), sum(QT[d].values()))}</td>' for d in DIAS)
    dd = (f'<h2><span class=n>2</span>Dia a dia</h2><table class="t hm hd2"><tr><th rowspan=2>Travessia</th><th colspan=3 class="c g">Viagens × quantitativo</th><th class=gap></th>'
          f'<th colspan=3 class="c g">Fixos no horário</th><th class=gap></th><th colspan=3 class="c g">Intervalos acima do máx.</th></tr><tr>{dh}<th class=gap></th>{dh}<th class=gap></th>{dh}</tr>{dd}</table>')

def pts():
    out = []
    crit_ = [r for _, r in T.iterrows() if ind(r)[3] == 'cr']
    if crit_: out.append('<b>Críticas:</b> ' + '; '.join(f'{r.lab} (' + ', '.join(x for x in [
        f'{pct(r.V, r.Q)} do quantitativo' if ind(r)[0] == 'cr' else '', f'{pct(r.fn, r.fp)} dos fixos no horário ou com ocorrência' if ind(r)[1] == 'cr' else '',
        f'{n0(r.bex)} intervalos acima do máx.' if ind(r)[2] == 'cr' else ''] if x) + ')' for r in crit_) + '.')
    if not UM: out.append('<b>Evolução do realizado sobre o quantitativo:</b> ' + ' → '.join(f'{pct(Y[d]["df"].shape[0], sum(QT[d].values()))} ({d}/11)' for d in DIAS) + '.')
    nr = T[T.fnr > 0].sort_values('fnr', ascending=False)
    if len(nr): out.append(f'<b>{n0(S.fnr)} horários fixos não realizados sem ocorrência</b> (de {n0(S.fnrb)} não realizados):' + '; '.join(f'{r.lab} {n0(r.fnr)}' for r in nr.itertuples()) + '.')
    if len(OC): out.append(f'<b>Considerando as ocorrências:</b> {n0(S.fj)} de {n0(T.fof.sum())} fixos fora do horário e {n0(S.bj)} de {n0(S.bexb)} intervalos acima do máximo têm ocorrência registrada no mesmo horário e foram descontados dos indicadores. Fixos no horário: {pct(S.fno, S.fp)} sem ocorrências → {pct(S.fn, S.fp)} com ocorrências.')
    elif not OCCOB: out.append('<b>Ocorrências:</b> registros de ocorrências deste período ainda não recebidos; cruzamento não feito.')
    else: out.append('<b>Ocorrências:</b> nenhuma registrada no período.')
    bb = T[T.B > 0].sort_values('B', ascending=False).head(3)
    out.append(f'<b>{n0(S.B)} viagens adicionais</b> no período de horário fixo: ' + '; '.join(f'{r.lab} {n0(r.B)}' for r in bb.itertuples()) + '.')
    return ''.join(f'<li>{x}</li>' for x in out)

leg = (f'<div class=leg2><b>Como ler:</b> {dot("ok", "dentro do esperado")} {dot("at", "atenção")} {dot("cr", "crítico")} '
       '<span class=lsep>|</span> viagens: ok ≥ 98% do quantitativo, crítico &lt; 95% · fixos no horário: ok ≥ 95%, crítico &lt; 85% · intervalos acima do máx.: ok ≤ 2% das janelas, crítico &gt; 10% '
       f'<span class=lsep>|</span> barra dos fixos: <i class=sw style="background:{OK}"></i>no horário <i class=sw style="background:{JUS}"></i>fora do horário com ocorrência <i class=sw style="background:{AT}"></i>atrasado <i class=sw style="background:{COR["Adiantada"]}"></i>adiantado <i class=sw style="background:{CR}"></i>não realizado</div>')
nsec = 3 if not UM else 2
pg1 = f'''<div class=hero><div class=pat></div><div class=eb>Relatório de viagens · operação</div><h1>Viagens por travessia · {PER}</h1>
<div class=per>{DSL[Y[DIAS[0]]['D'].weekday()] if UM else DSL[Y[DIAS[0]]['D'].weekday()] + ' a ' + DSL[Y[DIAS[-1]]['D'].weekday()].lower()}, dia inteiro · grade de {TIPOG} · comparação com o quantitativo de viagens · indicadores considerando as ocorrências</div><div class=w></div></div>
<div class="kp k8"><div>Viagens realizadas<b>{n0(S.V)}</b>{PL}</div><div>Quantitativo<b>{n0(S.Q)}</b>viagens projetadas</div><div>Realizado do quantitativo<b>{pct(S.V, S.Q)}</b>{("+" if S.V > S.Q else "") + n0(S.V - S.Q)} viagens</div>
<div>Fixos no horário c/ ocorrências<b>{pct(S.fn, S.fp)}</b>sem ocorrências {pct(S.fno, S.fp)}</div><div>Fixos não realizados<b>{n0(S.fnr)}</b>sem ocorrência · {n0(S.fnrb)} no total</div>
<div>Intervalos acima do máx.<b>{n0(S.bex)}</b>sem ocorrência · {n0(S.bexb)} no total</div><div>Ocorrências<b>{n0(len(OC))}</b>justificam {n0(S.fj + S.bj)} desvios</div><div>Embarcações<b>{n0(S.emb)}</b>{n0(S.veic)} veículos</div></div>
<h2><span class=n>1</span>Panorama por travessia</h2>{leg}<table class="t hm pn">{panh}{pan}</table>
{dd}
<h2><span class=n>{nsec}</span>O que olhar primeiro</h2><div class=obs><ul>{pts()}</ul></div>'''

# ---------- linha do dia (SVG) ----------
def linha_dia(t, m):
    W, LW, RH, TOP = 760, 112, 15, 14
    PW = W - LW - 6
    X = lambda ts, D: LW + max(0, min(1440, (ts - D).total_seconds() / 60)) / 1440 * PW
    rows = []
    for d in DIAS:
        D = Y[d]['D']
        g = DF[(DF.trav == t) & (DF.modo == m) & (DF.dia == D)]
        mgs = list(dict.fromkeys(list(FX[(FX.trav == t) & (FX.modo == m)].margem) + list(BD[(BD.trav == t) & (BD.modo == m)].margem) + list(g.margem.value_counts().index)))
        for mg in mgs: rows.append((d, D, mg))
        if len(OC) and len(oc_de(t, m)[lambda o: o.ini.dt.normalize() == D]): rows.append((d, D, None))
    H = TOP + RH * len(rows) + 4
    s = [f'<svg class=tl viewBox="0 0 {W} {H}">']
    for h in range(0, 25, 3):
        x = LW + h / 24 * PW
        s.append(f'<line x1={x:.1f} x2={x:.1f} y1={TOP - 3} y2={H - 2} stroke="#E3ECF0" stroke-width=.6 /><text x={x:.1f} y={TOP - 5} text-anchor=middle class=tx>{h:02d}h</text>')
    last = None
    for k, (d, D, mg) in enumerate(rows):
        y = TOP + k * RH
        if d != last and k: s.append(f'<line x1=0 x2={W} y1={y:.1f} y2={y:.1f} stroke="#C9DAE2" stroke-width=.5 />')
        dl = (f'{DS[D.weekday()]} {d} · ' if not UM and d != last else ('' if UM else '')) ; last = d
        if mg is None:
            s.append(f'<text x=2 y={y + 9} class=tl2>{dl}ocorrências</text>')
            for o in oc_de(t, m)[lambda o: o.ini.dt.normalize() == D].itertuples():
                x1 = X(o.ini, D); x2 = max(X(o.fim, D), x1 + 1.5)
                s.append(f'<rect x={x1:.1f} y={y + 4} width={x2 - x1:.1f} height=5 rx=1 fill="#8A9BA5" opacity=.75 />')
            continue
        s.append(f'<text x=2 y={y + 9} class=tl1>{dl}{mg}</text>')
        for b in BD[(BD.trav == t) & (BD.modo == m) & (BD.dia == D) & (BD.margem == mg)].itertuples():
            s.append(f'<rect x={X(b.ini, D):.1f} y={y + 1.5} width={X(b.fim, D) - X(b.ini, D):.1f} height=10 fill="#DDF3F1" />')
        for gp in GP[(GP.trav == t) & (GP.modo == m) & (GP.dia == D) & (GP.margem == mg)].itertuples():
            s.append(f'<rect x={X(gp.de, D):.1f} y={y + 1.5} width={max(X(gp.ate, D) - X(gp.de, D), 1.2):.1f} height=10 fill="{CR}" opacity=.35 />')
        for sd in DF[(DF.trav == t) & (DF.modo == m) & (DF.dia == D) & (DF.margem == mg)].saida:
            x = X(sd, D); s.append(f'<line x1={x:.1f} x2={x:.1f} y1={y + 3} y2={y + 10} stroke="#005B7F" stroke-width=.55 opacity=.6 />')
        for fx in FX[(FX.trav == t) & (FX.modo == m) & (FX.dia == D) & (FX.margem == mg)].itertuples():
            x = X(fx.prog, D); c = COR.get(fx.status, NA)
            s.append(f'<circle cx={x:.1f} cy={y + 6.5} r=2.4 fill="{c}" stroke="#fff" stroke-width=.6 />' if fx.status != 'Não realizada'
                     else f'<circle cx={x:.1f} cy={y + 6.5} r=2.2 fill="#fff" stroke="{CR}" stroke-width=1.3 />')
    s.append('</svg>')
    return ''.join(s)
tleg = (f'<div class=leg2><b>Linha do dia:</b> <i class=tk></i>saída realizada · <i class=sw style="background:#DDF3F1;border:.2mm solid #BFE7E3"></i>faixa conforme demanda · '
        f'<i class=sw style="background:{CR};opacity:.45"></i>intervalo acima do máximo · horário fixo: <i class=cc style="background:{OK}"></i>no horário <i class=cc style="background:{AT}"></i>atrasado '
        f'<i class=cc style="background:{COR["Adiantada"]}"></i>adiantado <i class=cc style="border:1.2px solid {CR};background:#fff"></i>não realizado · <i class=sw style="background:#8A9BA5"></i>ocorrência</div>')

# ---------- detalhe por travessia ----------
def detail(r):
    t, m = r.t, r.m
    q, fI, iI, gr = ind(r)
    g = DF[(DF.trav == t) & (DF.modo == m)]; f = FX[(FX.trav == t) & (FX.modo == m)]; b = BD[(BD.trav == t) & (BD.modo == m)]
    chips = (f'<div class=dk><div class={q}><b>{pct(r.V, r.Q)}</b>do quantitativo · {n0(r.V)} de {n0(r.Q)}</div>'
             + (f'<div class={fI}><b>{pct(r.fn, r.fp)}</b>fixos no horário c/ ocorrências · {n0(r.fno)} + {n0(r.fj)} de {n0(r.fp)}</div>' if r.fp else '')
             + (f'<div class={iI}><b>{n0(r.bex)}</b>intervalos acima do máx. sem ocorrência</div>' if r.bmin else '')
             + (f'<div><b>{n0(r.oc)}</b>ocorrências</div>' if r.oc else '')
             + f'<div><b>{n0(r.emb)}</b>embarcações</div><div><b>{n0(r.ped + r.bic)}</b>pedestres e cicl.</div><div><b>{n0(r.veic)}</b>veículos</div></div>')
    mg = g.groupby('margem').agg(V=('emb', 'size'), ped=('ped', 'sum'), bic=('bic', 'sum'), veic=('veic', 'sum'))
    mrows = ''.join(f'<tr><td class=m>{k}</td><td class=r>{n0(x.V)}</td><td class=r>{n0(x.ped + x.bic)}</td><td class=r>{n0(x.veic)}</td></tr>' for k, x in mg.iterrows())
    emb = g.emb.value_counts(); embt = ', '.join(f'{k} ({v})' for k, v in emb.items())
    h = (f'<div class="blk {gr}"><div class=keep><div class=bh><div><div class=eb2>{r.reg}</div><h3 class=tt>{r.lab}</h3></div><span class="tag2 {gr}">{TXT[gr]}</span></div>{chips}'
         f'{linha_dia(t, m)}</div>'
         f'<div class=two><table class="t hm sm"><tr><th>Saídas de</th><th class=r>Viagens</th><th class=r>Pedestres e cicl.</th><th class=r>Veículos</th></tr>{mrows}</table>'
         f'<div class=em>Embarcações (nº de viagens): {embt}</div></div>')
    off = f[f.status != 'No horário'].assign(k=lambda d: d.oc == '').sort_values(['k', 'dia', 'prog'])
    if len(off):
        lim = 10; more = len(off) - lim
        cl = {'Atrasada': 'at', 'Adiantada': 'ad', 'Não realizada': 'nr', 'Pendente': 'ad'}
        h += ('<h4>Horários fixos fora do horário</h4><table class="t hm sm"><tr><th>Dia</th><th>Margem</th><th>Programado</th><th>Saída</th><th>Embarcação</th><th class=r>Desvio</th><th>Situação</th><th>Ocorrência no horário</th></tr>'
              + ''.join(f'<tr><td>{x.dia:%d/%m}</td><td>{x.margem}</td><td><b>{hm(x.prog)}</b></td><td>{hm(x.real) or "–"}</td><td>{x.emb if isinstance(x.emb, str) else "–"}</td>'
                        f'<td class=r>{"" if pd.isna(x.desvio) else ("+" if x.desvio > 0 else "") + n0(x.desvio) + " min"}</td><td><span class="st {'ju' if x.jus else cl[x.status]}">{x.status}{' · c/ ocorr.' if x.jus else ''}</span></td><td class=oc>{x.oc or "–"}</td></tr>' for x in off.head(lim).itertuples())
              + (f'<tr><td colspan=8 class=more>+ {more} outros (todos aparecem na linha do dia)</td></tr>' if more > 0 else '') + '</table>')
    if len(b) and r.bexb:
        bb = b.groupby(['margem', b.ini.dt.strftime('%H:%M'), b.fim.dt.strftime('%H:%M').replace('00:00', '24:00'), 'imax'], sort=False).agg(s=('saidas', 'sum'), mn=('minimo', 'sum'), mx=('maior_int', 'max'), ex=('excessos', 'sum')).reset_index()
        bb.columns = ['margem', 'ini', 'fim', 'imax', 's', 'mn', 'mx', 'ex']
        bb = bb[bb.ex > 0]
        h += ('<h4>Faixas conforme demanda com intervalo acima do máximo</h4><table class="t hm sm"><tr><th>Margem</th><th>Faixa</th><th class=r>Interv. máx.</th><th class=r>Saídas</th><th class=r>Mínimo p/ cumprir</th><th class=r>Maior intervalo</th><th class=r>Vezes acima do máx.</th></tr>'
              + ''.join(f'<tr><td>{x.margem}</td><td>{x.ini}–{x.fim}</td><td class=r>{x.imax} min</td><td class=r>{n0(x.s)}</td><td class=r>{n0(x.mn)}</td><td class=r>{n0(x.mx)} min</td><td class="r lo"><b>{n0(x.ex)}</b></td></tr>' for x in bb.itertuples()) + '</table>')
    o = oc_de(t, m)
    if len(o):
        imp = [impacto(x, t, m) for _, x in o.iterrows()]
        o = o.assign(nf=[a for a, _ in imp], ng=[b_ for _, b_ in imp]); oi = o[(o.nf + o.ng) > 0]; resto = o[(o.nf + o.ng) == 0]
        oimore = max(0, len(oi) - 10); oi = oi.assign(w=oi.nf + oi.ng).sort_values(['w', 'ini'], ascending=[False, True]).head(10).sort_values('ini')
        if len(oi):
            h += ('<h4>Ocorrências que coincidem com desvios</h4><table class="t hm sm"><tr><th>Dia</th><th>Início–fim</th><th>Tipo</th><th>Emb.</th><th>Comentário</th><th class=r>Fixos</th><th class=r>Interv.</th></tr>'
                  + ''.join(f'<tr><td>{x.ini:%d/%m}</td><td>{x.ini:%H:%M}–{x.fim:%H:%M}</td><td>{x.cat}</td><td>{x.emb if isinstance(x.emb, str) else "–"}</td><td class=oc>{x.com[:100] + ("…" if len(x.com) > 100 else "") or "sem comentário"}</td><td class=r>{z(x.nf)}</td><td class=r>{z(x.ng)}</td></tr>' for x in oi.itertuples()) + (f'<tr><td colspan=7 class=more>+ {oimore} outras ocorrências com desvio (aparecem na linha do dia)</td></tr>' if oimore else '') + '</table>')
        if len(resto):
            vc = resto.cat.value_counts()
            h += f'<div class=em>{"Demais" if len(oi) else "Todas as"} ocorrências sem desvio na grade ({n0(len(resto))}): ' + ', '.join(f'{k} {v}' for k, v in vc.items()) + '.</div>'
    return h + '</div>'
det = ''.join(detail(r) for _, r in T.iterrows())
crit = ['Viagens: todos os registros do sistema com início de travessia no dia (00:00 às 23:59), inclusive os marcados como INF, LIXO ou VAL e os repetidos. Quantitativo: viagens projetadas para cada travessia e dia.',
        'Grade: grades de horários vigentes de cada travessia por tipo de dia (dia útil, sábado, domingo/feriado).'
        ' Sábado e domingo de Bertioga–Guarujá e sábado de Santos–Vicente de Carvalho seguem premissas a validar.'
        ' Horário fixo: conta a saída mais próxima entre 10 min antes e 15 min depois. No horário: de 2 min antes a 5 min depois; atrasado: mais de 5 min depois; adiantado: mais de 2 min antes; não realizado: sem saída na janela.',
        'Faixa conforme demanda: dividida em janelas do intervalo máximo (mínimo para cumprir = nº de janelas). Intervalo acima do máximo: tempo entre saídas seguidas da mesma margem maior que o máximo da faixa.',
        'Ocorrências: registros do sistema, classificados pelo tipo ou, quando vazio, pelo comentário. Explicam um horário fixo fora do horário quando estão na mesma travessia, de 10 min antes a 20 min depois; e um intervalo acima do máximo quando se sobrepõem a ele (±5 min). Em São Sebastião valem para balsa ou lancha conforme a embarcação; sem embarcação, para as duas.' + (' ' + OCNOTA if OCNOTA else ''),
        'Adicionais: viagens realizadas a mais no período de horário fixo, acima das projetadas para ele.']
html = (pg1 + f'<div class=sec><h2><span class=n>{nsec + 1}</span>Detalhe por travessia</h2>{tleg}{det}</div>'
        f'<h3>Critérios</h3><ol class=crit>{"".join(f"<li>{c}</li>" for c in crit)}</ol>')
css = open('base.css').read() + f'''
.k8{{grid-template-columns:repeat(8,1fr)!important;gap:2mm;margin-bottom:3mm}} .k8 div{{font-size:6.2pt;padding:1.5mm 2mm}} .k8 b{{font-size:12pt}}
.hero{{padding:4mm 6mm 3.5mm;margin-bottom:3mm}} .hero h1{{font-size:18pt}}
h2{{font-size:12pt;margin-top:3.5mm}}
.dt{{display:inline-block;width:2.6mm;height:2.6mm;border-radius:50%;margin-right:1.2mm;vertical-align:-.4mm}} .dt.ok{{background:{OK}}} .dt.at{{background:{AT}}} .dt.cr{{background:{CR}}} .dt.na{{background:{NA}}}
.sl{{font-size:6.6pt;font-weight:700}} .sl.ok{{color:#00857E}} .sl.at{{color:#A86A0E}} .sl.cr{{color:{CR}}}
.sb2{{display:inline-flex;height:2.6mm;border-radius:1.3mm;overflow:hidden;vertical-align:-.5mm;background:#E8EEF1;margin-right:1mm}} .sb2 i{{display:block;height:100%}}
.pn td{{font-size:7pt;padding:.75mm 1.2mm;vertical-align:middle}} .pn th span{{text-transform:none;letter-spacing:0;font-weight:400}} .pn small{{display:block;color:#5E7480;font-size:6pt;margin-top:.2mm}} .pn{{table-layout:fixed}} .pn th:nth-child(1){{width:42mm}} .pn th:nth-child(2){{width:15mm}} .pn th:nth-child(3){{width:31mm}} .pn th:nth-child(4){{width:37mm}} .pn th:nth-child(5){{width:31mm}} .pn td{{white-space:nowrap;overflow:hidden}} .pn td small{{display:block!important;margin-left:0!important}} .pn tr.tot small{{color:#CFE3EA}}
.na{{color:#9FB2BB;font-size:6.4pt;font-style:italic}}
.pill{{display:inline-block;min-width:5mm;text-align:center;border-radius:2mm;padding:0 1.5mm;font-weight:900;font-size:7pt;color:#fff}} .pill.ok{{background:{OK}}} .pill.at{{background:{AT}}} .pill.cr{{background:{CR}}}
.leg2{{font-size:6.4pt;color:#5E7480;margin:.5mm 0 1.5mm;line-height:1.6}} .leg2 b{{color:#005B7F}} .lsep{{color:#C9DAE2;margin:0 1.5mm}}
.sw{{display:inline-block;width:3mm;height:2.2mm;border-radius:.4mm;margin:0 .8mm 0 1.5mm;vertical-align:-.3mm}} .cc{{display:inline-block;width:2.2mm;height:2.2mm;border-radius:50%;margin:0 .8mm 0 1.5mm;vertical-align:-.3mm}}
.tk{{display:inline-block;width:.35mm;height:2.6mm;background:#005B7F;margin:0 .8mm 0 0;vertical-align:-.4mm}}
.hd2 th{{font-size:5.8pt;padding:.6mm 1mm}} .hd2 td{{font-size:6.8pt;padding:.4mm 1mm}} .hd2 th.g{{color:#005B7F;border-bottom:.3mm solid #9FB9C4}} .hd2 .gap{{width:2mm;border:none}}
td.hc{{text-align:center;font-weight:700;border-bottom:.4mm solid #fff}} td.hc.ok{{background:#E0F4F2;color:#00756F}} td.hc.at{{background:#FCEFD9;color:#94600F}} td.hc.cr{{background:#F6DDD7;color:#A4402C}} td.hc.na{{color:#9FB2BB}}
.obs{{font-size:7.3pt}} .obs li{{margin:0 0 .8mm}}
.blk{{border:.3mm solid #D3E1E7;border-left:1.6mm solid {NA};border-radius:1.5mm;padding:2.5mm 3.5mm;margin:0 0 3.5mm}} .keep{{break-inside:avoid}} .sm tr{{break-inside:avoid}} .blk.ok{{border-left-color:{OK}}} .blk.at{{border-left-color:{AT}}} .blk.cr{{border-left-color:{CR}}}
.bh{{display:flex;justify-content:space-between;align-items:flex-start}}
.tag2{{font-size:6.6pt;font-weight:900;color:#fff;border-radius:1mm;padding:.6mm 2mm;letter-spacing:.04em;text-transform:uppercase}} .tag2.ok{{background:{OK}}} .tag2.at{{background:{AT}}} .tag2.cr{{background:{CR}}} .tag2.na{{background:{NA}}}
.eb2{{font-size:6.4pt;letter-spacing:.14em;text-transform:uppercase;font-weight:700;color:#008C86}}
h3.tt{{margin:.3mm 0 1.5mm;font-size:12pt}}
.dk{{display:flex;flex-wrap:wrap;gap:1.5mm;margin:0 0 1.5mm}} .dk div{{background:#EEF5F8;border-radius:1mm;padding:.8mm 2.2mm;font-size:6.6pt;color:#5E7480;border-left:1mm solid transparent}} .dk b{{color:#005B7F;font-size:9.5pt;margin-right:1mm}}
.dk div.ok{{border-left-color:{OK}}} .dk div.at{{border-left-color:{AT};background:#FDF5E8}} .dk div.cr{{border-left-color:{CR};background:#FBEDEA}} .dk div.cr b{{color:{CR}}} .dk div.at b{{color:#A86A0E}}
svg.tl{{width:100%;display:block;margin:0 0 1.5mm;font-family:Lato}} .tx{{font-size:6.5px;fill:#5E7480}} .tl1{{font-size:7px;fill:#17303B;font-weight:700}} .tl2{{font-size:6.5px;fill:#5E7480;font-style:italic}}
.two{{display:grid;grid-template-columns:1fr;gap:0}}
.sm{{font-size:7pt;margin-bottom:1.5mm}} .sm td{{padding:.45mm 1.2mm;white-space:nowrap}} .sm td.oc{{white-space:normal}} .sm th{{padding:.8mm 1.2mm;font-size:5.8pt}}
h4{{font-size:8pt;color:#005B7F;margin:2mm 0 .8mm}}
.em{{font-size:6.5pt;color:#5E7480;margin:-.5mm 0 1mm}}
td.lo{{color:#B35C00;font-weight:700}}
.st{{font-weight:700;font-size:6.6pt}} .st.at{{color:#A86A0E}} .st.ad{{color:#7D5BA6}} .st.nr{{color:{CR}}}
td.more{{font-size:6.5pt;color:#5E7480;font-style:italic}}
.crit{{font-size:7pt}} td.oc{{font-size:6.2pt;color:#3A5260;white-space:normal}}'''
css += f'.st.ju{{{{background:#DDF4F2;color:#00796F}}}}'.replace('{{','{').replace('}}','}')
if len(DIAS) > 3: css += '.pn td{padding:.25mm 1.2mm!important}.pn small{font-size:5.6pt!important;margin-top:0!important}.pn .bar,.pn svg{margin:0!important}h2{margin-top:2mm!important}'
open(f'operacao/pagina_{"_".join(DIAS)}.html', 'w').write(f'<!doctype html><html lang=pt-BR><head><meta charset=utf-8><title>Operação</title><base href="file:///mnt/project-files/relatorios-viagens/relatorio-financeiro/gerador/"><style>{css}</style></head><body>{html}</body></html>')
print(S[['V', 'Q', 'fp', 'fn', 'fat', 'fad', 'fnr', 'bs', 'bex', 'A', 'B']].to_dict())
if '--stats' in sys.argv or True:
    F2 = FX[FX.status.isin(['Atrasada', 'Não realizada'])]
    print('STATS', {s: (len(g), int((g.oc != '').sum())) for s, g in F2.groupby('status')}, 'gaps', int(T.bex.sum()), int(T.gxo.sum()), 'oc', len(OC))
    print(F2[F2.oc != ''].groupby(['trav', 'status']).size().to_string())
    import collections; print(collections.Counter(c.split(' ')[0] for x in F2.oc if x for c in x.split('; ')).most_common(10))
