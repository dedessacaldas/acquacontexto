"""Relatório de viagens da Operação, 09 a 11/11/2026, no modelo do relatório por travessia.
Base: full/dia09-11.pkl (calc.py do relatório diário sobre o export completo, 4.506 viagens), grades (grades.py) e quantitativo (BD_QT).
Rodar da pasta gerador/: python3 operacao/gen_op.py"""
import pickle, sys, pandas as pd
sys.path.insert(0, '/mnt/project-files/relatorios-viagens/relatorio-diario/gerador')
from grades import ORDER
DIAS = sys.argv[1].split(',') if len(sys.argv) > 1 else ['09', '10', '11']
UM = len(DIAS) == 1
DSL = ['Segunda-feira', 'Terça-feira', 'Quarta-feira', 'Quinta-feira', 'Sexta-feira', 'Sábado', 'Domingo']
PER = f'{DIAS[0]}/11/2026' if UM else f'{DIAS[0]} a {DIAS[-1]}/11/2026'
PL = 'no dia' if UM else f'{len(DIAS)} dias'
DCOL = [] if UM else DIAS
Y = {d: pickle.load(open(f'full/dia{d}.pkl', 'rb')) for d in DIAS}
R3 = pickle.load(open('projecao/proj.pkl', 'rb'))['R3']
DS = ['seg', 'ter', 'qua', 'qui', 'sex', 'sáb', 'dom']
n0 = lambda x: f'{x:,.0f}'.replace(',', '.')
pct = lambda a, b: '–' if not b else f'{100 * a / b:.1f}%'.replace('.', ',')
hm = lambda t: '' if t is None or pd.isna(t) else pd.Timestamp(t).strftime('%H:%M')
z = lambda v: n0(v) if v else '–'

def cat(key):
    return pd.concat([Y[d][key].assign(dia=Y[d]['D']) for d in DIAS], ignore_index=True)
DF, FX, BD, GP = cat('df'), cat('FX'), cat('BD'), cat('GP')
QT = {d: Y[d]['QT'] for d in DIAS}
AB = R3.set_index(['Data', 'Travessia'])

# ---------- ocorrências (export do sistema) ----------
from datetime import timedelta
OC = pd.read_excel('entradas/ExportOcorrenciasReport.xlsx')
OC.columns = ['trav', 'ref', 'tipo', 'com', 'para', 'ini', 'fim', 'emb', 'margem', 'user']
OC['fim'] = OC.fim.fillna(OC.ini)
OC['com'] = OC.com.fillna('').astype(str).str.replace(r'\s+', ' ', regex=True).str.strip()
def categ(r):
    c = r.com.lower()
    if r.tipo == 'Maré' or 'maré' in c: return 'Maré'
    if 'navio' in c or 'draga' in c: return 'Passagem de navio/draga'
    if 'especial' in c or 'ambulância' in c or 'emergência' in c: return 'Viagem especial / emergência'
    if 'vazia' in c or 'demanda' in c: return 'Viagem vazia / demanda unilateral'
    if 'troca' in c or 'antes' in c or 'antecip' in c: return 'Troca de embarcação / saída antecipada'
    if isinstance(r.tipo, str): return r.tipo
    return 'Sem descrição' if not c else 'Outras'
OC['cat'] = OC.apply(categ, axis=1)
MODOS = {t: [mm for _, it in ORDER for tt, mm, *_ in it if tt == t] for _, it in ORDER for t, *_ in it}
def oc_modos(r):
    ms = MODOS.get(r.trav, [])
    if len(ms) > 1 and isinstance(r.emb, str): ms = ['Lancha'] if r.emb.startswith('LS') else ['Ferry boat']
    return ms
OC['modos'] = OC.apply(oc_modos, axis=1)
DD = [Y[d]['D'] for d in DIAS]
OC = OC[OC.ini.dt.normalize().isin(DD)].reset_index(drop=True)
def oc_de(t, m): return OC[[(r.trav == t and m in r.modos) for r in OC.itertuples()]]
def casa(o, a, b, pre=10, pos=20):
    """ocorrências que se sobrepõem a [a, b] (com tolerância antes/depois)"""
    if not len(o): return o
    return o[(o.ini <= b + timedelta(minutes=pos)) & (o.fim >= a - timedelta(minutes=pre))]
def rot(o): return '; '.join(f'{x.cat} {x.ini:%H:%M}' for x in o.itertuples())
FX['oc'] = ''; GP['oc'] = ''
for i, x in FX[FX.status.isin(['Atrasada', 'Adiantada', 'Não realizada'])].iterrows():
    o = casa(oc_de(x.trav, x.modo), x.prog, x.prog if pd.isna(x.real) else max(x.prog, x.real))
    FX.loc[i, 'oc'] = rot(o)
for i, x in GP.iterrows():
    GP.loc[i, 'oc'] = rot(casa(oc_de(x.trav, x.modo), x['de'], x.ate, 5, 5))
def impacto(o, t, m):
    f = FX[(FX.trav == t) & (FX.modo == m) & FX.status.isin(['Atrasada', 'Adiantada', 'Não realizada'])]; g = GP[(GP.trav == t) & (GP.modo == m)]
    nf = sum(len(casa(o.to_frame().T, x.prog, x.prog if pd.isna(x.real) else max(x.prog, x.real))) > 0 for x in f.itertuples())
    ng = sum(len(casa(o.to_frame().T, x.de, x.ate, 5, 5)) > 0 for x in g.itertuples())
    return nf, ng

# ---------- por travessia ----------
T = []
for reg, items in ORDER:
    for t, m, lab, q in items:
        g = DF[(DF.trav == t) & (DF.modo == m)]; f = FX[(FX.trav == t) & (FX.modo == m)]; b = BD[(BD.trav == t) & (BD.modo == m)]
        r = dict(reg=reg, t=t, m=m, lab=lab, q=q, V=len(g), Q=sum(QT[d].get(q, 0) for d in DIAS), emb=g.emb.nunique(),
                 ped=g.ped.sum(), bic=g.bic.sum(), veic=g.veic.sum(),
                 fp=len(f), fn=(f.status == 'No horário').sum(), fat=(f.status == 'Atrasada').sum(), fad=(f.status == 'Adiantada').sum(), fnr=(f.status == 'Não realizada').sum(),
                 bs=b.saidas.sum(), bmin=b.minimo.sum(), bex=b.excessos.sum(), bmx=b.maior_int.max() if len(b) else 0,
                 A=sum(AB.loc[(Y[d]['D'], lab), 'A'] for d in DIAS if (Y[d]['D'], lab) in AB.index),
                 B=sum(AB.loc[(Y[d]['D'], lab), 'B'] for d in DIAS if (Y[d]['D'], lab) in AB.index),
                 oc=len(oc_de(t, m)), fxo=(f.oc != '').sum(), fof=f.status.isin(['Atrasada', 'Adiantada', 'Não realizada']).sum(),
                 gxo=(GP[(GP.trav == t) & (GP.modo == m)].oc != '').sum())
        for d in DIAS:
            r['V' + d] = (g.dia == Y[d]['D']).sum(); r['Q' + d] = QT[d].get(q, 0)
            ff = f[f.dia == Y[d]['D']]; r['fp' + d] = len(ff); r['fn' + d] = (ff.status == 'No horário').sum(); r['fnr' + d] = (ff.status == 'Não realizada').sum()
            r['bex' + d] = b[b.dia == Y[d]['D']].excessos.sum()
        T.append(r)
T = pd.DataFrame(T)
S = T.select_dtypes('number').sum()
S['emb'] = DF.emb.nunique(); S['bmx'] = T.bmx.max()

# ---------- página 1: resumo ----------
def rowq(r, cls='', lab=None):
    c = ''.join(f'<td class="r sep">{n0(r["V" + d])}</td><td class=r>{n0(r["Q" + d])}</td><td class="r {"lo" if r["Q" + d] and r["V" + d] / r["Q" + d] < .95 else ""}">{pct(r["V" + d], r["Q" + d])}</td>' for d in DCOL)
    return (f'<tr class="{cls}"><td class=m>{lab or r["lab"]}</td>{c}<td class="r sep"><b>{n0(r["V"])}</b></td><td class=r>{n0(r["Q"])}</td>'
            f'<td class="r {"lo" if r["Q"] and r["V"] / r["Q"] < .95 else ""}"><b>{pct(r["V"], r["Q"])}</b></td><td class="r sep">{n0(r["A"])}</td><td class=r>{z(r["B"])}</td></tr>')
def rowg(r, cls='', lab=None):
    return (f'<tr class="{cls}"><td class=m>{lab or r["lab"]}</td><td class=r>{n0(r["emb"])}</td><td class="r sep">{z(r["fp"])}</td><td class=r>{z(r["fn"])}</td><td class=r>{z(r["fat"])}</td>'
            f'<td class=r>{z(r["fad"])}</td><td class="r {"lo" if r["fnr"] else ""}">{z(r["fnr"])}</td><td class=r><b>{pct(r["fn"], r["fp"])}</b></td>'
            f'<td class="r sep">{z(r["bs"])}</td><td class=r>{z(r["bmin"])}</td><td class="r {"lo" if r["bex"] else ""}">{z(r["bex"])}</td><td class=r>{(n0(r["bmx"]) + " min") if r["bs"] else "–"}</td>'
            f'<td class="r sep">{n0(r["ped"] + r["bic"])}</td><td class=r>{n0(r["veic"])}</td></tr>')
def grouped(fn):
    h = ''
    for reg, _ in ORDER:
        h += f'<tr class=rg><td colspan=20>{reg}</td></tr>' + ''.join(fn(r) for _, r in T[T.reg == reg].iterrows())
    return h + fn(S, 'tot', 'Total')
dh = ''.join(f'<th colspan=3 class="c sep">{DS[Y[d]["D"].weekday()]} {d}/11</th>' for d in DCOL)
headq = (f'<tr><th rowspan=2>Travessia</th>{dh}<th colspan=3 class="c sep">{"Dia " + DIAS[0] + "/11" if UM else PL}</th><th colspan=2 class="c sep">Classificação</th></tr><tr>'
         + '<th class="r sep">Realiz.</th><th class=r>Quant.</th><th class=r>%</th>' * (len(DCOL) + 1) + '<th class="r sep">Obrig. (A)</th><th class=r>Adic. (B)</th></tr>')
headg = ('<tr><th rowspan=2>Travessia</th><th rowspan=2 class=r>Embarc.</th><th colspan=6 class="c sep">Horários fixos</th><th colspan=4 class="c sep">Faixas conforme demanda</th><th colspan=2 class="c sep">Volume</th></tr>'
         '<tr><th class="r sep">Prog.</th><th class=r>No horário</th><th class=r>Atras.</th><th class=r>Adiant.</th><th class=r>Não real.</th><th class=r>% no horário</th>'
         '<th class="r sep">Saídas</th><th class=r>Mínimo</th><th class=r>Interv. acima do máx.</th><th class=r>Maior interv.</th><th class="r sep">Pedestres e cicl.</th><th class=r>Veículos</th></tr>')

# pontos de atenção automáticos
def pts():
    out = []
    lo = T[(T.Q > 0) & (T.V / T.Q.where(T.Q > 0) < .95)].copy(); lo['p'] = lo.V / lo.Q
    if len(lo): out.append('<b>Abaixo de 95% do quantitativo:</b> ' + '; '.join(f'{r.lab} ({pct(r.V, r.Q)}, {n0(r.Q - r.V)} viagens a menos)' for r in lo.sort_values('p').itertuples()) + '.')
    tr = [f'{pct(Y[d]["df"].shape[0], sum(QT[d].values()))} em {d}/11' for d in DIAS]
    if not UM: out.append(f'<b>Evolução:</b> realizado sobre o quantitativo foi de ' + ', '.join(tr) + '.')
    nr = T[T.fnr > 0].sort_values('fnr', ascending=False)
    if len(nr): out.append(f'<b>Horários fixos não realizados ({n0(S.fnr)}):</b> ' + '; '.join(f'{r.lab} {n0(r.fnr)} (' + ', '.join(f'{getattr(r, "fnr" + d)} em {d}/11' for d in DIAS if getattr(r, "fnr" + d)) + ')' for r in nr.itertuples()) + '.')
    at = T[(T.fat + T.fad) > 0].sort_values('fat', ascending=False).head(4)
    if len(at): out.append(f'<b>Fora do horário ({n0(S.fat)} atrasadas, {n0(S.fad)} adiantadas):</b> ' + '; '.join(f'{r.lab} {n0(r.fat)} atras. e {n0(r.fad)} adiant.' for r in at.itertuples()) + '.')
    ex = T[T.bex > 0].sort_values('bex', ascending=False)
    if len(ex): out.append(f'<b>Intervalos acima do máximo ({n0(S.bex)}):</b> ' + '; '.join(f'{r.lab} {n0(r.bex)} (maior {n0(r.bmx)} min)' for r in ex.itertuples()) + '.')
    if len(OC): out.append(f'<b>Ocorrências ({n0(len(OC))}):</b> {n0(T.fxo.sum())} dos {n0(T.fof.sum())} horários fixos fora do horário e {n0(T.gxo.sum())} dos {n0(T.bex.sum())} intervalos acima do máximo coincidem com uma ocorrência registrada; os demais não têm ocorrência que os explique.')
    bb = T[T.B > 0].sort_values('B', ascending=False).head(3)
    out.append(f'<b>Adicionais no período de horário fixo ({n0(S.B)}):</b> ' + '; '.join(f'{r.lab} {n0(r.B)}' for r in bb.itertuples()) + '.')
    return ''.join(f'<li>{x}</li>' for x in out)

def octab_():
    cats = OC.cat.value_counts().index.tolist()
    rows = ''
    for _, r in T[T.oc > 0].iterrows():
        o = oc_de(r.t, r.m); vc = o.cat.value_counts()
        rows += (f'<tr><td class=m>{r.lab}</td><td class=r><b>{n0(r.oc)}</b></td>' + ''.join(f'<td class=r>{z(vc.get(c, 0))}</td>' for c in cats)
                 + f'<td class="r sep">{n0(r.fxo)} de {n0(r.fof)}</td><td class=r>{n0(r.gxo)} de {n0(r.bex)}</td></tr>')
    if not rows: return '<p class=lead>Nenhuma ocorrência registrada no período.</p>'
    rows += (f'<tr class=tot><td class=m>Total</td><td class=r>{n0(len(OC))}</td>' + ''.join(f'<td class=r>{n0((OC.cat == c).sum())}</td>' for c in cats)
             + f'<td class="r sep">{n0(T.fxo.sum())} de {n0(T.fof.sum())}</td><td class=r>{n0(T.gxo.sum())} de {n0(T.bex.sum())}</td></tr>')
    return ('<table class="t hm v"><tr><th rowspan=2>Travessia</th><th rowspan=2 class=r>Ocorrências</th><th colspan=' + str(len(cats)) + ' class="c sep">Por tipo (pelo tipo ou comentário)</th>'
            '<th colspan=2 class="c sep">Explicados por ocorrência</th></tr><tr>' + ''.join(f'<th class=r>{c}</th>' for c in cats)
            + '<th class="r sep">Fixos fora do horário</th><th class=r>Interv. acima do máx.</th></tr>' + rows + '</table>')
octab = octab_()
pg1 = f'''<div class=hero><div class=pat></div><div class=eb>Relatório de viagens · operação</div><h1>Viagens por travessia · {PER}</h1>
<div class=per>{DSL[Y[DIAS[0]]['D'].weekday()] if UM else DSL[Y[DIAS[0]]['D'].weekday()] + ' a ' + DSL[Y[DIAS[-1]]['D'].weekday()].lower()}, dia inteiro · grade de dia útil · comparação com o quantitativo de viagens</div><div class=w></div></div>
<div class="kp k8"><div>Viagens realizadas<b>{n0(S.V)}</b>{PL}</div><div>Quantitativo<b>{n0(S.Q)}</b>viagens projetadas</div><div>Realizado do quantitativo<b>{pct(S.V, S.Q)}</b>{n0(S.V - S.Q)} viagens</div>
<div>Horários fixos no horário<b>{pct(S.fn, S.fp)}</b>{n0(S.fn)} de {n0(S.fp)}</div><div>Fixos não realizados<b>{n0(S.fnr)}</b>{n0(S.fat)} atrasados · {n0(S.fad)} adiantados</div>
<div>Intervalos acima do máx.<b>{n0(S.bex)}</b>faixas conforme demanda</div><div>Embarcações<b>{n0(S.emb)}</b>em operação</div><div>Veículos<b>{n0(S.veic)}</b>{n0(S.ped + S.bic)} pedestres e ciclistas</div></div>
<h2><span class=n>1</span>Viagens realizadas × quantitativo</h2><table class="t hm v">{headq}{grouped(rowq)}</table>
<h2><span class=n>2</span>Cumprimento da grade</h2><table class="t hm v">{headg}{grouped(rowg)}</table>
<h2><span class=n>3</span>Ocorrências × cumprimento</h2>{octab}
<h3>Pontos de atenção</h3><div class=obs><ul>{pts()}</ul></div>'''

# ---------- detalhe por travessia ----------
def detail(r):
    t, m = r.t, r.m
    g = DF[(DF.trav == t) & (DF.modo == m)]; f = FX[(FX.trav == t) & (FX.modo == m)]; b = BD[(BD.trav == t) & (BD.modo == m)]
    cards = (f'<div class=dk><div><b>{n0(r.V)}</b>viagens</div><div><b>{pct(r.V, r.Q)}</b>do quantitativo ({n0(r.Q)})</div><div><b>{n0(r.emb)}</b>embarcações</div>'
             + (f'<div><b>{n0(r.fn)}/{n0(r.fp)}</b>horários fixos no horário</div>' if r.fp else '')
             + (f'<div><b>{n0(r.bex)}</b>intervalos acima do máximo</div>' if r.bs else '')
             + f'<div><b>{n0(r.ped + r.bic)}</b>pedestres e ciclistas</div><div><b>{n0(r.veic)}</b>veículos</div></div>')
    # por dia
    rows = ''
    for d in DIAS:
        D = Y[d]['D']
        rows += (f'<tr><td class=m>{DS[D.weekday()]} {d}/11</td><td class=r>{n0(r["V" + d])}</td><td class=r>{n0(r["Q" + d])}</td><td class="r {"lo" if r["Q" + d] and r["V" + d] / r["Q" + d] < .95 else ""}">{pct(r["V" + d], r["Q" + d])}</td>'
                 + (f'<td class=r>{n0(r["fn" + d])}/{n0(r["fp" + d])}</td><td class="r {"lo" if r["fnr" + d] else ""}">{z(r["fnr" + d])}</td>' if r.fp else '')
                 + (f'<td class=r>{z(r["bex" + d])}</td>' if r.bs else '') + '</tr>')
    hd = ('<tr><th>Dia</th><th class=r>Viagens</th><th class=r>Quantitativo</th><th class=r>%</th>' + ('<th class=r>Fixos no horário</th><th class=r>Fixos não realizados</th>' if r.fp else '')
          + ('<th class=r>Interv. acima do máx.</th>' if r.bs else '') + '</tr>')
    # por margem
    mg = g.groupby('margem').agg(V=('emb', 'size'), p=('saida', 'min'), u=('saida', 'max'), ped=('ped', 'sum'), bic=('bic', 'sum'), veic=('veic', 'sum'))
    mrows = ''.join(f'<tr><td class=m>{k}</td><td class=r>{n0(x.V)}</td>{'' if UM else f'<td class=r>{n0(x.V / len(DIAS))}</td>'}<td class=r>{n0(x.ped)}</td><td class=r>{n0(x.bic)}</td><td class=r>{n0(x.veic)}</td></tr>' for k, x in mg.iterrows())
    emb = g.emb.value_counts(); embt = ', '.join(f'{k} ({v})' for k, v in emb.items())
    h = (f'<div class=blk><div class=eb2>{r.reg}</div><h3 class=tt>{r.lab}</h3>{cards}<table class="t hm sm">{hd}{rows}</table>'
         f'<table class="t hm sm"><tr><th>Saídas de</th><th class=r>Viagens</th>' + ('' if UM else '<th class=r>Média/dia</th>') + f'<th class=r>Pedestres</th><th class=r>Bicicletas</th><th class=r>Veículos</th></tr>{mrows}</table>'
         f'<div class=em>Embarcações (viagens): {embt}</div>')
    off = f[f.status != 'No horário'].assign(k=lambda d: d.oc == '').sort_values(['k', 'dia', 'prog'])
    if len(off):
        lim = 12; more = len(off) - lim
        cl = {'Atrasada': 'at', 'Adiantada': 'ad', 'Não realizada': 'nr'}
        h += ('<h4>Horários fixos fora do horário</h4><table class="t hm sm"><tr><th>Dia</th><th>Margem</th><th>Programado</th><th>Saída</th><th>Embarcação</th><th class=r>Desvio</th><th>Situação</th><th>Ocorrência</th></tr>'
              + ''.join(f'<tr><td>{x.dia:%d/%m}</td><td>{x.margem}</td><td>{hm(x.prog)}</td><td>{hm(x.real) or "–"}</td><td>{x.emb if isinstance(x.emb, str) else "–"}</td>'
                        f'<td class=r>{"" if pd.isna(x.desvio) else ("+" if x.desvio > 0 else "") + n0(x.desvio) + " min"}</td><td><span class="st {cl[x.status]}">{x.status}</span></td><td class=oc>{x.oc or "–"}</td></tr>' for x in off.head(lim).itertuples())
              + (f'<tr><td colspan=8 class=more>+ {more} horários fora do horário {PL}</td></tr>' if more > 0 else '') + '</table>')
    if len(b):
        bb = b.groupby(['margem', b.ini.dt.strftime('%H:%M'), b.fim.dt.strftime('%H:%M').replace('00:00', '24:00'), 'imax'], sort=False).agg(s=('saidas', 'sum'), mn=('minimo', 'sum'), mx=('maior_int', 'max'), ex=('excessos', 'sum')).reset_index()
        bb.columns = ['margem', 'ini', 'fim', 'imax', 's', 'mn', 'mx', 'ex']
        h += ('<h4>Faixas conforme demanda' + ('' if UM else f' ({PL})') + '</h4><table class="t hm sm"><tr><th>Margem</th><th>Faixa</th><th class=r>Interv. máx.</th><th class=r>Saídas</th><th class=r>Mínimo p/ cumprir</th><th class=r>Maior intervalo</th><th class=r>Acima do máx.</th></tr>'
              + ''.join(f'<tr><td>{x.margem}</td><td>{x.ini}–{x.fim}</td><td class=r>{x.imax} min</td><td class=r>{n0(x.s)}</td><td class=r>{n0(x.mn)}</td><td class=r>{n0(x.mx)} min</td><td class="r {"lo" if x.ex else ""}"><b>{z(x.ex)}</b></td></tr>' for x in bb.itertuples()) + '</table>')
    o = oc_de(t, m)
    if len(o):
        imp = [impacto(x, t, m) for _, x in o.iterrows()]
        o = o.assign(nf=[a for a, _ in imp], ng=[b for _, b in imp]); oi = o[(o.nf + o.ng) > 0]; resto = o[(o.nf + o.ng) == 0]
        h += f'<h4>Ocorrências ({n0(len(o))})</h4>'
        if len(oi):
            h += ('<table class="t hm sm"><tr><th>Dia</th><th>Início–fim</th><th>Tipo</th><th>Emb.</th><th>Comentário</th><th class=r>Fixos afetados</th><th class=r>Interv. afetados</th></tr>'
                  + ''.join(f'<tr><td>{x.ini:%d/%m}</td><td>{x.ini:%H:%M}–{x.fim:%H:%M}</td><td>{x.cat}</td><td>{x.emb if isinstance(x.emb, str) else "–"}</td><td class=oc>{x.com[:110] + ("…" if len(x.com) > 110 else "")}</td><td class=r>{z(x.nf)}</td><td class=r>{z(x.ng)}</td></tr>' for x in oi.itertuples()) + '</table>')
        if len(resto):
            vc = resto.cat.value_counts()
            h += f'<div class=em>{"Outras" if len(oi) else "Sem"} ocorrências sem impacto na grade ({n0(len(resto))}): ' + ', '.join(f'{k} {v}' for k, v in vc.items()) + '.</div>'
    return h + '</div>'
det = ''.join(detail(r) for _, r in T.iterrows())
crit = ['Ocorrências: registros do sistema no período, classificados pelo tipo ou, quando vazio, pelo comentário. Um horário fixo fora do horário é explicado por ocorrência quando ela, na mesma travessia, vai de 10 min antes a 20 min depois do horário (ou da saída); um intervalo acima do máximo, quando a ocorrência se sobrepõe ao intervalo (±5 min). Ocorrências de São Sebastião valem para a balsa ou a lancha conforme a embarcação; sem embarcação, para as duas.',
        'Viagens: todos os registros do sistema com início de travessia no dia (00:00 às 23:59), inclusive os marcados como INF, LIXO ou VAL e os repetidos.',
        'Quantitativo: viagens projetadas para cada travessia e dia. Realizado do quantitativo = viagens ÷ quantitativo.',
        'Horário fixo: conta a saída mais próxima entre 10 min antes e 15 min depois do horário. No horário: de 2 min antes a 5 min depois; atrasada: mais de 5 min depois; adiantada: mais de 2 min antes; não realizada: sem saída na janela.',
        'Faixa conforme demanda: a faixa é dividida em janelas do intervalo máximo (mínimo para cumprir = nº de janelas). Intervalo acima do máximo: tempo entre saídas seguidas da mesma margem maior que o máximo da faixa.',
        'Obrigatórias (A) e adicionais (B): adicionais são as viagens realizadas a mais no período de horário fixo, acima das projetadas para ele; as saídas sob demanda e as demais contam como obrigatórias.']
html = (pg1 + f'<div class=sec><h2><span class=n>4</span>Detalhe por travessia</h2>{det}</div>'
        f'<h3>Critérios</h3><ol class=crit>{"".join(f"<li>{c}</li>" for c in crit)}</ol>')
css = open('base.css').read() + '''
.k8{grid-template-columns:repeat(8,1fr)!important;gap:2mm;margin-bottom:3mm} .k8 div{font-size:6.2pt;padding:1.5mm 2mm} .k8 b{font-size:12pt}
.hero{padding:4mm 6mm 3.5mm;margin-bottom:3mm} .hero h1{font-size:18pt}
h2{font-size:12pt;margin-top:3mm}
.v th{font-size:5.6pt;padding:.6mm .9mm} .v td{font-size:6.8pt;padding:.4mm .9mm} .v th.c{text-align:center} .v .sep{border-left:.3mm solid #C9DAE2}
td.lo{color:#B35C00;font-weight:700} tr.tot td.lo{color:#FFE2B8}
.obs{font-size:7.2pt} .obs li{margin:0 0 .7mm}
.blk{border:.3mm solid #D3E1E7;border-radius:1.5mm;padding:2.5mm 3.5mm;margin:0 0 3.5mm;break-inside:avoid}
.eb2{font-size:6.4pt;letter-spacing:.14em;text-transform:uppercase;font-weight:700;color:#008C86}
h3.tt{margin:.3mm 0 1.5mm;font-size:12pt}
.dk{display:flex;flex-wrap:wrap;gap:1.5mm;margin:0 0 2mm} .dk div{background:#EEF5F8;border-radius:1mm;padding:.8mm 2.2mm;font-size:6.8pt;color:#5E7480} .dk b{color:#005B7F;font-size:9.5pt;margin-right:1mm}
.sm{font-size:7pt;margin-bottom:1.5mm} .sm td{padding:.5mm 1.2mm} .sm th{padding:.8mm 1.2mm;font-size:5.8pt}
h4{font-size:8pt;color:#005B7F;margin:2mm 0 .8mm}
.em{font-size:6.6pt;color:#5E7480;margin:-.5mm 0 1mm}
.st{font-weight:700;font-size:6.6pt} .st.at{color:#B35C00} .st.ad{color:#6C3483} .st.nr{color:#A93226}
td.more{font-size:6.6pt;color:#5E7480;font-style:italic}
.crit{font-size:7pt} td.oc{font-size:6.2pt;color:#3A5260;white-space:normal}'''
open(f'operacao/pagina_{"_".join(DIAS)}.html', 'w').write(f'<!doctype html><html lang=pt-BR><head><meta charset=utf-8><title>Operação</title><base href="file:///mnt/project-files/relatorios-viagens/relatorio-financeiro/gerador/"><style>{css}</style></head><body>{html}</body></html>')
print(S[['V', 'Q', 'fp', 'fn', 'fat', 'fad', 'fnr', 'bs', 'bex', 'A', 'B']].to_dict())
