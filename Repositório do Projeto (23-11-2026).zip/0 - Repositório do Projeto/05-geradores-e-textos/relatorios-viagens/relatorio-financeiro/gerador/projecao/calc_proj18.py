"""Base 3 dias (09–11/11) pela regra nova e projeções de novembro (09–30/11) com o quantitativo REV10.
Realizado: viagens no período de horário fixo vs FIX projetado; B = realizadas a mais no período fixo (acima do FIX projetado);
viagens nas faixas conforme demanda e as demais do período fixo = A."""
import pickle, pandas as pd, sys, math
sys.path.insert(0, '/mnt/project-files/relatorios-viagens/relatorio-diario/gerador')
from grades import ORDER, grade
LAB = {(t, m): (reg, l, q) for reg, it in ORDER for t, m, l, q in it}
X = pickle.load(open('projecao/rev10.pkl', 'rb')); P = X['P']
pj = P.pivot_table(index=['Data', 'Nome'], columns='Tipo', values='V', aggfunc='sum').fillna(0)
rows = []
DIAS = ['09', '10', '11', '12', '13', '14', '15', '16', '17', '18']
for d in DIAS:
    Y = pickle.load(open(f'full18/dia{d}.pkl', 'rb')); df, D = Y['df'], Y['D']
    _, S = grade(D)
    def band(r):
        bands = S.get((r.trav, r.modo, r.sent), ([], [], ''))[1]
        return any(a <= r.saida < b for a, b, i in bands)
    df = df.copy(); df['dem'] = [band(r) for r in df.itertuples()]
    for (t, m), g in df.groupby(['trav', 'modo']):
        reg, l, q = LAB[(t, m)]
        fixp = pj.loc[(D, q), 'FIX'] if (D, q) in pj.index else 0
        demp = pj.loc[(D, q), 'DEM'] if (D, q) in pj.index and 'DEM' in pj.columns else 0
        rf = int((~g.dem).sum()); rd = int(g.dem.sum())
        B = max(0, rf - int(fixp))
        rows.append(dict(Data=D, Regiao=reg, Travessia=l, Nome=q, ProjFIX=fixp, ProjDEM=demp, RealFIX=rf, RealDEM=rd, Real=rf + rd, A=rf + rd - B, B=B))
R3 = pd.DataFrame(rows)
# ---- projeção de novembro (09–30)
nov = P[(P.Data >= '2026-11-09') & (P.Data <= '2026-11-30')].pivot_table(index=['Data', 'Nome'], columns='Tipo', values='V', aggfunc='sum').fillna(0).reset_index()
nov['Proj'] = nov.FIX + nov.DEM
# cenário 2: quantitativo puro (tudo projetado é A; B só nasce de viagem a mais no realizado)
nov['A2'] = nov.Proj; nov['B2'] = 0
# cenário 1: tendência dos 3 dias por travessia (realizado ÷ projetado), realizado real em 09–11
k = R3.groupby('Nome')[['A', 'B', 'ProjFIX', 'ProjDEM']].sum()
k['rA'] = k.A / (k.ProjFIX + k.ProjDEM); k['rB'] = k.B / (k.ProjFIX + k.ProjDEM)
nov['A1'] = nov.apply(lambda r: r.Proj * k.rA.get(r.Nome, 1), axis=1)
nov['B1'] = nov.apply(lambda r: r.Proj * k.rB.get(r.Nome, 0), axis=1)
real = R3.set_index(['Data', 'Nome'])
for i, r in nov.iterrows():
    if (r.Data, r.Nome) in real.index:
        nov.loc[i, 'A1'] = real.loc[(r.Data, r.Nome), 'A']; nov.loc[i, 'B1'] = real.loc[(r.Data, r.Nome), 'B']
nov = nov.merge(R3[['Nome', 'Regiao', 'Travessia']].drop_duplicates(), on='Nome', how='left')
nov = nov[nov.Proj > 0]
pickle.dump(dict(R3=R3, nov=nov, k=k), open('projecao/proj18.pkl', 'wb'))
print(R3.groupby('Data')[['ProjFIX', 'ProjDEM', 'RealFIX', 'RealDEM', 'Real', 'A', 'B']].sum())
print(R3.groupby('Travessia')[['ProjFIX', 'RealFIX', 'ProjDEM', 'RealDEM', 'A', 'B']].sum())
print(nov[['Proj', 'A1', 'B1', 'A2', 'B2']].sum())
