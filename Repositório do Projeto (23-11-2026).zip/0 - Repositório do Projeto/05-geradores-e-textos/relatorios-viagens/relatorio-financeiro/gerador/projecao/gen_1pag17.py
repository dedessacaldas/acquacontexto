"""Página única: realizado 09–11/11 + projeção de novembro (obrigatórias = quantitativo; adicionais = taxa de B do período fixo nos 3 dias).
Rodar da pasta gerador/: python3 projecao/gen_1pag.py"""
import pickle, pandas as pd, re
Z = pickle.load(open('projecao/proj17.pkl', 'rb')); R3, nov, k = Z['R3'], Z['nov'].copy(), Z['k']
VA = 2314.05 * 0.75 / 4; VB = VA * 0.6
ORD = ['Santos ⇄ Guarujá', 'Santos ⇄ Vicente de Carvalho', 'Bertioga ⇄ Guarujá', 'São Sebastião ⇄ Ilhabela · balsa', 'São Sebastião ⇄ Ilhabela · lancha',
       'Cananéia ⇄ Continente', 'Cananéia ⇄ Ilha Comprida', 'Iguape ⇄ Juréia', 'Cananéia ⇄ Marujá ⇄ Ariri', 'Natividade', 'Paraitinga', 'Varginha']
DS = ['seg', 'ter', 'qua', 'qui', 'sex', 'sáb', 'dom']
n0 = lambda x: f'{x:,.0f}'.replace(',', '.')
def brl(x, d=0): return ('−' if round(x, d) < 0 else '') + 'R$ ' + f'{abs(x):,.{d}f}'.replace(',', '#').replace('.', ',').replace('#', '.')
def mi(x): return 'R$ ' + f'{x/1e6:,.2f}'.replace('.', ',') + ' mi'
pct = lambda x: f'{x*100:.1f}%'.replace('.', ',')

k['rB'] = (k.B / k.ProjFIX).fillna(0)                 # adicionais por viagem fixa projetada (3 dias)
real = R3.set_index(['Data', 'Nome'])
nov['Real'] = nov.Data <= '2026-11-17'
k['rA3'] = k.A / (k.ProjFIX + k.ProjDEM)                # obrigatórias realizadas ÷ projetadas nos 3 dias
nov['A'] = nov.Proj.astype(float);   # sem perdas: 100% do quantitativo
nov['B'] = nov.apply(lambda r: r.FIX * k.rB.get(r.Nome, 0), axis=1)
for i, r in nov[nov.Real].iterrows():
    if (r.Data, r.Nome) in real.index: nov.loc[i, 'A'] = real.loc[(r.Data, r.Nome), 'A']; nov.loc[i, 'B'] = real.loc[(r.Data, r.Nome), 'B']
    else: nov.loc[i, ['A', 'B']] = 0
nov['RA'] = nov.A * VA; nov['RB'] = nov.B * VB; nov['RT'] = nov.RA + nov.RB
nov['PA'] = nov.Proj * VA                               # meta das obrigatórias do quantitativo
re_ = nov[nov.Real]; fu = nov[~nov.Real]
tot = nov[['Proj', 'A', 'B', 'RA', 'RB', 'RT', 'PA']].sum(); rs = re_[['Proj', 'A', 'B', 'RA', 'RB', 'RT', 'PA']].sum(); fs = fu[['Proj', 'A', 'B', 'RA', 'RB', 'RT']].sum()
ating = rs.RT / tot.RT                                  # quanto da receita do mês já foi realizado
ritmo = rs.RT / (re_.Proj.sum() * VA + (re_.FIX * re_.Nome.map(k.rB).fillna(0)).sum() * VB)   # realizado ÷ esperado para os mesmos dias
dias_real = re_.Data.nunique(); dias_tot = nov.Data.nunique()

# gráfico diário (barras empilhadas A/B; realizado escuro, projeção clara) + linha acumulada
Dd = nov.groupby('Data')[['RA', 'RB', 'RT', 'Real']].agg({'RA': 'sum', 'RB': 'sum', 'RT': 'sum', 'Real': 'max'})
Dd['acc'] = Dd.RT.cumsum()
W, H, pl, pr, pb, pt = 760, 58, 40, 46, 22, 10
mx = Dd.RT.max() * 1.15; amx = Dd.acc.max() * 1.05; bw = (W - pl - pr) / len(Dd); ch = H - pb - pt
g = [f'<svg class=chart viewBox="0 0 {W} {H}">']
for v in range(0, int(mx / 1e5) + 1, 8):
    y = H - pb - v * 1e5 / mx * ch
    g.append(f'<line class=grid x1={pl} x2={W-pr} y1={y:.1f} y2={y:.1f} /><text class=ax x={pl-4} y={y+2.5:.1f} text-anchor=end>{v*100} mil</text>')
for v in range(0, int(amx / 1e7) + 1):
    y = H - pb - v * 1e7 / amx * ch
    g.append(f'<text class=ax x={W-pr+4} y={y+2.5:.1f} style="fill:#003A52">{v*10} mi</text>')
pts = []
for i, (d, r) in enumerate(Dd.iterrows()):
    x = pl + i * bw + bw * .15; w = bw * .7; y0 = H - pb
    ha = r.RA / mx * ch; hb = r.RB / mx * ch
    ca, cb = ('#005B7F', '#00B5AD') if r.Real else ('#9CC3D3', '#A8E3DF')
    g.append(f'<rect x={x:.1f} y={y0-ha:.1f} width={w:.1f} height={ha:.1f} fill="{ca}" rx=1 /><rect x={x:.1f} y={y0-ha-hb:.1f} width={w:.1f} height={hb:.1f} fill="{cb}" rx=1 />')
    g.append(f'<text class=ax x={x+w/2:.1f} y={H-14} text-anchor=middle>{d:%d}</text><text class=ax x={x+w/2:.1f} y={H-5} text-anchor=middle style="font-size:6px">{DS[d.weekday()]}</text>')
    pts.append((x + w / 2, H - pb - r.acc / amx * ch))
xh = pl + dias_real * bw
g.append(f'<rect x={pl} y={pt-6} width={xh-pl:.1f} height={ch+6} fill="#005B7F" opacity=".05" /><text x={pl+3} y={pt+1} style="font-size:7px;font-weight:700;fill:#005B7F">REALIZADO</text><text x={xh+3:.1f} y={pt+1} style="font-size:7px;font-weight:700;fill:#5E7480">PROJEÇÃO</text>')
g.append('<polyline fill=none stroke="#003A52" stroke-width=1.4 points="' + ' '.join(f'{x:.1f},{y:.1f}' for x, y in pts) + '" />')
for j, (x, y) in enumerate(pts):
    if j == len(pts) - 1:
        g.append(f'<circle cx={x:.1f} cy={y:.1f} r=2.2 fill="#003A52" /><text x={x-3:.1f} y={y-4:.1f} text-anchor=end style="font-size:7px;font-weight:700;fill:#003A52">{mi(Dd.acc.iloc[j])}</text>')
g.append('</svg>')

# ---------- PARTE 1: viagens por travessia ----------
dias = sorted(re_.Data.unique())
P = nov.groupby('Travessia')[['Proj', 'A', 'B']].sum()
for i, d in enumerate(dias):
    P = P.join(re_[re_.Data == d].groupby('Travessia')[['A', 'B']].sum().add_suffix(str(i)))
P = P.join(re_.groupby('Travessia')[['A', 'B', 'Proj']].sum().add_suffix('r')).fillna(0)
P = P.loc[[t for t in ORD if t in P.index]]
P['Tr'] = P.Ar + P.Br; P['Tm'] = P.A + P.B; P['pq'] = P.Tr / P.Proj
SP = P.sum(); SP['pq'] = SP.Tr / SP.Proj
d_ = lambda v: n0(v) if round(v) else '–'
def lv(lab, r, cls=''):
    c = ''.join(f'<td class="r sep">{n0(r[f"A{i}"])}</td><td class=r>{d_(r[f"B{i}"])}</td>' for i in range(len(dias)))
    return (f'<tr class="{cls}"><td class=m>{lab}</td>{c}<td class="r sep ac">{n0(r.Ar)}</td><td class="r ac">{d_(r.Br)}</td><td class="r ac"><b>{n0(r.Tr)}</b></td>'
            f'<td class="r sep pj">{n0(r.A)}</td><td class="r pj">{d_(r.B)}</td><td class="r pj"><b>{n0(r.Tm)}</b></td><td class="r sep">{n0(r.Proj)}</td>'
            f'<td class=r style="white-space:nowrap"><span class=mb><i style="width:{min(r.pq * 4, 1) * 100:.0f}%"></i></span>{pct(r.pq)}</td></tr>')
vrows = ''.join(lv(t, r) for t, r in P.iterrows()) + lv('Total', SP, 'tot')
dh = ''.join(f'<th colspan=2 class="c sep">{DS[d.weekday()]} {d:%d/%m}</th>' for d in dias)
vhead = (f'<tr><th rowspan=2>Travessia</th>{dh}<th colspan=3 class="c sep">Acumulado 9 dias</th><th colspan=3 class="c sep">Projeção fim do mês (09–30/11)</th>'
         f'<th rowspan=2 class="r sep">Quantit.<br>do mês</th><th rowspan=2 class=r>% realizado<br>do quantit.</th></tr><tr>'
         + '<th class="r sep">A</th><th class=r>B</th>' * len(dias) + '<th class="r sep">A</th><th class=r>B</th><th class=r>Total</th><th class="r sep">A</th><th class=r>B</th><th class=r>Total</th></tr>')

# ---------- PARTE 2: receita por travessia ----------
Q = nov.groupby('Travessia')[['RA', 'RB', 'RT']].sum().join(re_.groupby('Travessia')[['RA', 'RB', 'RT']].sum().add_suffix('r')).fillna(0)
Q = Q.sort_values('RT', ascending=False); Q['RTf'] = Q.RT - Q.RTr
mxT = Q.RT.max(); TOTRT = Q.RT.sum()
for c in ('RA', 'RB', 'RT'): Q[c + 'f'] = Q[c] - Q[c + 'r']
z_ = lambda v: brl(v) if round(v) else '–'
def lr(lab, r, cls='', bar=True):
    w1 = r.RTr / mxT * 12; w2 = r.RTf / mxT * 12
    b = (f'<span style="display:inline-block;height:2.4mm;width:{w1:.1f}mm;background:#005B7F;border-radius:.5mm 0 0 .5mm;vertical-align:-.5mm"></span>'
         f'<span style="display:inline-block;height:2.4mm;width:{w2:.1f}mm;background:#9CC3D3;border-radius:0 .5mm .5mm 0;vertical-align:-.5mm"></span> ') if bar else ''
    return (f'<tr class="{cls}"><td class=m>{lab}</td><td class="r sep ac">{brl(r.RAr)}</td><td class="r ac">{z_(r.RBr)}</td><td class="r ac"><b>{brl(r.RTr)}</b></td>'
            f'<td class="r sep">{brl(r.RAf)}</td><td class=r>{z_(r.RBf)}</td><td class=r><b>{brl(r.RTf)}</b></td>'
            f'<td class="r sep pj">{brl(r.RA)}</td><td class="r pj">{z_(r.RB)}</td><td class="r pj"><b>{brl(r.RT)}</b></td>'
            f'<td class="r sep pw"><b>{pct2(r.RT / TOTRT)}</b></td><td style="white-space:nowrap" class=sep>{b}{pct(r.RTr / r.RT)}</td></tr>')
SQ = Q.sum()
pct2 = lambda x: f'{x*100:.2f}%'.replace('.', ',')
rrows = ''.join(lr(t, r, bar=False) for t, r in Q.iterrows()) + lr('Total', SQ, 'tot', False)
rhead = ('<tr><th rowspan=2>Travessia</th><th colspan=3 class="c sep">Realizado 09–17/11</th><th colspan=3 class="c sep">Projetado 18–30/11</th>'
         '<th colspan=3 class="c sep">Realizado + Projetado (09–30/11)</th><th rowspan=2 class="r sep pw">% peso no<br>total do mês</th><th rowspan=2 class=sep>Realizado<br>do mês</th></tr>'
         '<tr>' + '<th class="r sep">A</th><th class=r>B</th><th class=r>Total</th>' * 3 + '</tr>')
# orçamento aprovado pelo conselho (receita bruta de novembro), informado pela Dedessa
import os
_f = 'projecao/orcamento_conselho.txt'
ORC = tot.PA   # orçamento = quantitativo do mês ÷ 4 × PUP × FO
# referência: obrigatórias de 12–30/11 no ritmo dos 3 dias (com as perdas de 09–11/11)
RIT = rs.RT + (fu.Proj * fu.Nome.map(k.rA3).fillna(1) * VA).sum() + fs.RB
sg = lambda x: ('+' if round(x) > 0 else '')
def lo(nome, desc, v):
    dv = v - ORC
    return (f'<tr><td class=m>{nome}<small>{desc}</small></td><td class=r>{brl(ORC)}</td><td class=r><b>{brl(v)}</b></td>'
            f'<td class=r><b>{sg(dv) + brl(dv)}</b></td><td class=r><b>{sg(dv) + pct(dv / ORC)}</b></td></tr>')
# comparativo com o orçamento em cartões (orçamento | cenário 1 | cenário 2)
_mx = max(ORC, tot.RT, RIT) * 1.04
def cen(num, nome, desc, v, cls):
    dv = v - ORC; up = dv >= 0
    wr = rs.RT / _mx * 100; wp = (v - rs.RT) / _mx * 100; mk = ORC / _mx * 100
    return (f'<div class="oc {cls}"><div class=och><span class=ocn>{num}</span>{nome}</div><div class=ocd>{desc}</div>'
            f'<div class=ocvr><div class=ocv>{brl(v)}</div><div class="ocx {"up" if up else "dn"}">{"▲" if up else "▼"} {sg(dv) + brl(dv)} ({sg(dv) + pct(dv / ORC)})<small>{"acima" if up else "abaixo"} do orçamento</small></div></div>'
            f'<div class=ocb><i style="width:{wr:.2f}%" class=r1></i><i style="width:{wp:.2f}%" class=r2></i><em style="left:{mk:.2f}%"></em></div>'
            f'<div class=ocl><span>realizado {mi(rs.RT)}</span><span>+ projetado {mi(v - rs.RT)}</span></div>'
            '</div>')
orcbox = (f'<div class=orc2><div class=oct>Comparativo com o orçamento · novembro (receita bruta)</div><div class=ocg>'
          f'<div class="oc ob"><div class=och>Orçamento previsto do mês</div><div class=ocd>meta considerando quantitativo de viagens base</div><div class=ocvr><div class=ocv>{brl(ORC)}</div></div>'
          f'<div class=ocb><i style="width:{ORC/_mx*100:.2f}%" class=r0></i><em style="left:{ORC/_mx*100:.2f}%"></em></div><div class=ocl><span>a linha escura nas barras marca o orçamento</span></div></div>'
          + cen(1, 'Sem perdas', 'de viagens obrigatórias + projeção de adicionais', tot.RT, 'c1')
          + cen(2, 'Ritmo atual', 'considerando perda das viagens obrigatórias', RIT, 'c2')
          + f'</div><div class=ocf>Os dois cenários partem dos mesmos <b>{brl(rs.RT)}</b> já realizados de 09 a 17/11 e só mudam nos dias que faltam. '
          f'A diferença entre eles, <b>{brl(tot.RT - RIT)}</b>, é a receita que se perde se as falhas continuarem no ritmo atual.</div></div>')
P['p3'] = P.Tr / P.Projr
low = P[P.p3 < .95].sort_values('p3'); bb = P.sort_values('B', ascending=False).head(2)
pv = (rs.A + rs.B) / tot.Proj
lowtxt = '; '.join(f'{t} ({pct(r.p3)})' for t, r in low.iterrows())
bbtxt = ', '.join(f'{t} {n0(r.B)}' for t, r in bb.iterrows())

prog = f'''<div style="margin:0 0 2.5mm;border:.3mm solid #D3E1E7;border-radius:1.5mm;padding:2mm 3mm">
<div style="display:flex;justify-content:space-between;font-size:7.4pt;margin-bottom:1mm"><b style="color:#005B7F">Receita de novembro: {pct(ating)} já realizada</b><span style="color:#5E7480">{dias_real} de {dias_tot} dias · {brl(rs.RT)} de {brl(tot.RT)}</span></div>
<div style="height:4.2mm;background:#E3ECF0;border-radius:2mm;overflow:hidden;display:flex"><div style="width:{ating*100:.2f}%;background:#005B7F"></div><div style="width:{(1-ating)*100:.2f}%;background:repeating-linear-gradient(45deg,#9CC3D3 0 2mm,#B5D4E0 2mm 4mm)"></div></div>
<div style="display:flex;justify-content:space-between;font-size:6.6pt;color:#5E7480;margin-top:.8mm"><span>Ritmo dos 9 dias: <b style="color:#00B5AD">{pct(ritmo)}</b> da receita esperada para esses dias</span><span>Viagens: {n0(rs.A + rs.B)} realizadas de {n0(tot.Proj)} do quantitativo do mês ({pct(pv)})</span></div></div>'''

html = f'''<div class=hero><div class=pat></div><div class=eb>Relatório financeiro de viagens</div><h1>Novembro de 2026 · realizado e projeção</h1>
<div class=per>Realizado de 09 a 17/11 · projeção até 30/11 sem perdas (100% do quantitativo) · comparativo com o orçamento</div><div class=w></div></div>
<div class=kc><div class=kch>Cálculo da receita</div>
<div class=kcs><span>Preço por partida</span><b>R$ 2.314,05</b></div><i>÷</i>
<div class=kcs><span>Viagens por partida</span><b>4</b></div><i>×</i>
<div class=kcs><span>Fator de operação (ano 1)</span><b>0,75</b></div><i>=</i>
<div class="kcs ka"><span>Obrigatória (A) · por viagem</span><b>{brl(VA,2)}</b></div>
<div class="kcs kb"><span>Adicional (B) · 60% da A</span><b>{brl(VB,2)}</b></div>
<div class="kcs kt"><span>Receita realizada 09–17/11</span><b>{n0(rs.A)} × {brl(VA,2)} + {n0(rs.B)} × {brl(VB,2)} = {brl(rs.RT)}</b></div></div>
<div class=kp><div>Viagens realizadas<b>{n0(rs.A + rs.B)}</b>{pct(pv)} do quantitativo do mês</div><div>Obrigatórias (A)<b>{n0(rs.A)}</b>realizadas · {n0(tot.A)} no mês</div><div>Adicionais (B)<b>{n0(rs.B)}</b>realizadas · {n0(tot.B)} no mês</div>
<div>Receita realizada<b>{brl(rs.RT)}</b>09 a 17/11 · {pct(ating)} do mês</div><div class=hl>Receita projetada no mês<b>{mi(tot.RT)}</b>09 a 30/11 · realizado + projetado</div><div>Orçamento do mês<b>{mi(ORC)}</b>projeção {sg(tot.RT - ORC)}{pct((tot.RT - ORC) / ORC)}</div><div>A realizar<b>{mi(fs.RT)}</b>{n0(fs.A + fs.B)} viagens em {dias_tot - dias_real} dias</div></div>
{prog}
<h2><span class=n>1</span>Viagens: realizadas e projeção</h2>
<table class="t hm v">{vhead}{vrows}</table>
<div class=obs><ul><li><b>9 dias:</b> {n0(SP.Tr)} viagens ({n0(SP.Ar)} obrigatórias e {n0(SP.Br)} adicionais), {pct(SP.Tr/SP.Projr)} das {n0(SP.Projr)} projetadas para esses dias e {pct(pv)} do quantitativo de novembro ({n0(tot.Proj)}). Abaixo de 95% do projetado nos 9 dias: {lowtxt}.</li>
<li><b>Fim do mês:</b> {n0(SP.Tm)} viagens, {n0(SP.A)} obrigatórias (realizadas + 100% do quantitativo de 18 a 30/11) e {n0(SP.B)} adicionais no período fixo; as maiores são {bbtxt}.</li></ul></div>
<h2><span class=n>2</span>Receita: realizada e projeção</h2>
<div class=cbox><div class=lg><i style="background:#005B7F;margin-left:0"></i>Obrigatórias (A)<i style="background:#00B5AD"></i>Adicionais (B)<i style="background:#9CC3D3"></i>Projeção (A)<i style="background:#A8E3DF"></i>Projeção (B)<i style="background:#003A52;height:.6mm;vertical-align:.6mm"></i>Receita acumulada (eixo da direita)</div>{''.join(g)}</div>
<table class="t hm v rc">{rhead}{rrows}</table>{orcbox}
<div class=crit style="margin-top:.8mm">A = viagens da grade (inclusive atrasadas e faixas conforme demanda); B = viagens a mais no período de horário fixo, projetadas pela taxa de cada travessia em 09–17/11.</div>'''
css = open('base.css').read()
open('projecao/pagina17.html', 'w').write(f'<!doctype html><html lang=pt-BR><head><meta charset=utf-8><title>Novembro</title><base href="file:///mnt/project-files/relatorios-viagens/relatorio-financeiro/gerador/"><style>{css}\n.kp{{grid-template-columns:repeat(7,1fr)!important;margin-bottom:3mm}} .kc{{display:flex;align-items:center;gap:2mm;border:.3mm solid #D3E1E7;border-left:1.2mm solid #005B7F;border-radius:1.5mm;padding:1.4mm 3mm;margin-bottom:2mm}} .kch{{font-size:6.6pt;font-weight:900;color:#005B7F;text-transform:uppercase;letter-spacing:.4pt;width:16mm;line-height:1.15}} .kcs span{{display:block;font-size:5.6pt;color:#5E7480;text-transform:uppercase;letter-spacing:.2pt}} .kcs b{{font-size:10pt;color:#17303B;white-space:nowrap}} .kc i{{font-style:normal;font-weight:900;color:#00B5AD;font-size:12pt}} .kcs.ka,.kcs.kb,.kcs.kt{{background:#EEF5F8;border-radius:1.2mm;padding:.8mm 2.2mm}} .kcs.ka b{{color:#005B7F}} .kcs.kb b{{color:#008C86}} .kcs.kt{{margin-left:auto;background:#005B7F}} .kcs.kt span{{color:#BFE9E6}} .kcs.kt b{{color:#fff;font-size:9pt}} .kp div{{font-size:5.8pt}} .kp b{{font-size:10.5pt;white-space:nowrap}} .kp>div{{padding:1.2mm 2.2mm!important}} .hm th{{font-size:5.6pt}} .hm td{{font-size:7pt;padding:.6mm 1.1mm}} .hero{{padding:3mm 6mm 2.8mm;margin-bottom:2.5mm}} .hero h1{{font-size:15pt}} .obs{{font-size:6.8pt;padding:1mm 3mm}} .obs li{{margin:0 0 .6mm}} .crit{{font-size:6pt;line-height:1.3;padding-left:4mm;margin:0;color:#5E7480}} h2{{font-size:11pt;margin:1.5mm 0 1mm}} .obs{{margin:1.2mm 0}} .cbox{{padding:1.2mm 2.5mm;margin:1mm 0 1.5mm}} .v th{{font-size:5.4pt;padding:.5mm .8mm}} .v td{{font-size:6.3pt;padding:.15mm .8mm;line-height:1.18}} .v tr.tot td{{font-weight:700}} .v .sep{{border-left:.3mm solid #C9DAE2}} .v th.c{{text-align:center}} .v tr:not(.tot) td.ac{{background:#EEF5F8}} .v tr:not(.tot) td.pj{{background:#E8F7F6}} .mb{{display:inline-block;width:8mm;height:2mm;background:#E3ECF0;border-radius:1mm;overflow:hidden;vertical-align:-.3mm;margin-right:1mm}} .mb i{{display:block;height:100%;background:#00B5AD}} .orct{{margin-top:1.5mm}} .orc2{{margin-top:1.6mm;border:.3mm solid #D3E1E7;border-radius:1.5mm;padding:1.4mm 2.5mm 1.6mm}} .oct{{font-size:6.6pt;font-weight:900;color:#005B7F;text-transform:uppercase;letter-spacing:.4pt;margin-bottom:1.2mm}} .ocg{{display:grid;grid-template-columns:1fr 1.15fr 1.15fr;gap:2.5mm}} .oc{{border-radius:1.3mm;padding:1.3mm 2.4mm;background:#F5F9FB;border-top:1mm solid #9CC3D3}} .oc.c1{{background:#E8F7F6;border-top-color:#00B5AD}} .oc.c2{{border-top-color:#005B7F}} .och{{font-size:7.6pt;font-weight:900;color:#17303B}} .ocn{{display:inline-block;width:3.6mm;height:3.6mm;border-radius:50%;background:#005B7F;color:#fff;font-size:6pt;text-align:center;line-height:3.6mm;margin-right:1.2mm}} .c1 .ocn{{background:#00B5AD}} .ocd{{font-size:7pt;font-weight:700;color:#005B7F;min-height:3.4mm;line-height:1.2;margin-top:.3mm}} .c1 .ocd{{color:#008C86}} .ocv{{font-size:13pt;font-weight:900;color:#005B7F;margin:.4mm 0 .8mm}} .c1 .ocv{{color:#008C86}} .ocb{{position:relative;height:3mm;background:#E3ECF0;border-radius:1mm;display:flex}} .ocb i{{display:block;height:100%}} .ocb .r0{{background:#9CC3D3;border-radius:1mm}} .ocb .r1{{background:#005B7F;border-radius:1mm 0 0 1mm}} .ocb .r2{{background:#9CC3D3}} .c1 .ocb .r2{{background:#5FD0C9}} .ocb em{{position:absolute;top:-.8mm;bottom:-.8mm;width:.5mm;background:#17303B}} .ocl{{display:flex;justify-content:space-between;font-size:5.6pt;color:#5E7480;margin-top:.5mm}} .ocvr{{display:flex;align-items:center;justify-content:space-between;gap:1.5mm;margin:.3mm 0 .7mm}} .ocvr .ocv{{margin:0}} .ocx{{font-size:6.8pt;font-weight:900;border-radius:1mm;padding:.4mm 1.4mm;text-align:right;line-height:1.15}} .ocx small{{display:block;font-size:5.4pt;font-weight:400}} .ocx.up{{background:#00B5AD;color:#fff}} .ocx.dn{{background:#F3E3C3;color:#8A5A00}} .ocf{{font-size:6.3pt;color:#17303B;margin-top:1.2mm;line-height:1.35}} .kp>div.hl{{background:#005B7F!important;color:#BFE9E6!important;border-color:#005B7F!important;box-shadow:0 0 0 .6mm #00B5AD}} .kp>div.hl b{{color:#fff!important;font-size:12pt}} .v td.pw,.v th.pw{{background:#E8F7F6;color:#005B7F}} .cen{{font-size:6.4pt;line-height:1.35;color:#17303B;background:#EEF5F8;border-left:1mm solid #00B5AD;border-radius:1mm;padding:1mm 2.5mm;margin-top:1.2mm}} .orct small{{display:block;font-size:5.8pt;color:#5E7480;font-weight:400}} .orct td{{font-size:7.2pt;padding:.4mm 1.5mm}} .orct td b{{color:#005B7F}} .orct th:first-child{{color:#005B7F}} .v.rc td{{font-size:6.1pt;padding:.1mm .7mm;line-height:1.15}} .orc{{margin-top:1.5mm;display:grid;grid-template-columns:2fr 1.3fr 1.1fr .8fr;border:.3mm solid #D3E1E7;border-radius:1.5mm;overflow:hidden}} .orc div{{padding:1mm 3mm;border-left:.3mm solid #D3E1E7}} .orc div:first-child{{border-left:none;background:#EEF5F8}} .orc span{{display:block;font-size:6.2pt;color:#5E7480;text-transform:uppercase;letter-spacing:.3pt}} .orc b{{font-size:10.5pt;color:#005B7F}}</style></head><body>{html}</body></html>')
print(tot.round(0).to_dict(), rs.round(0).to_dict(), round(ating, 4), round(ritmo, 4))
