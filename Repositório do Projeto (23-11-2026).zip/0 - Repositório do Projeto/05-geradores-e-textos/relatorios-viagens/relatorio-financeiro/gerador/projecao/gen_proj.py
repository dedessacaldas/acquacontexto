"""PDF: base 3 dias + projeção de novembro (2 cenários). Rodar da pasta gerador/: python3 projecao/gen_proj.py"""
import pickle, pandas as pd
Z = pickle.load(open('projecao/proj.pkl', 'rb')); R3, nov, k = Z['R3'], Z['nov'], Z['k']
VA = 2314.05 * 0.75 / 4; VB = VA * 0.6
ORD = ['Santos ⇄ Guarujá', 'Santos ⇄ Vicente de Carvalho', 'Bertioga ⇄ Guarujá', 'São Sebastião ⇄ Ilhabela · balsa', 'São Sebastião ⇄ Ilhabela · lancha',
       'Cananéia ⇄ Continente', 'Cananéia ⇄ Ilha Comprida', 'Iguape ⇄ Juréia', 'Cananéia ⇄ Marujá ⇄ Ariri', 'Natividade', 'Paraitinga', 'Varginha']
REG = ['Baixada Santista', 'Litoral Norte', 'Litoral Sul', 'Paraibuna e Natividade da Serra']
DS = ['Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado', 'Domingo']
n0 = lambda x: f'{x:,.0f}'.replace(',', '.')
def brl(x, d=0): return ('−' if round(x, d) < 0 else '') + 'R$ ' + f'{abs(x):,.{d}f}'.replace(',', '#').replace('.', ',').replace('#', '.')
pct = lambda x: f'{x*100:.1f}%'.replace('.', ',')
def z(v, cls=''): return f'<td class="r{" z" if round(v) == 0 else (" " + cls if cls else "")}">{n0(v) if round(v) else "–"}</td>'

# ---------- página 1: base 3 dias
R3['Proj'] = R3.ProjFIX + R3.ProjDEM; R3['RA'] = R3.A * VA; R3['RB'] = R3.B * VB; R3['RT'] = R3.RA + R3.RB
C = ['ProjFIX', 'RealFIX', 'ProjDEM', 'RealDEM', 'Proj', 'Real', 'A', 'B', 'RA', 'RB', 'RT']
HD = ('<th class=r>Projeção<br>período fixo</th><th class=r>Realizadas<br>período fixo</th><th class=r>Projeção<br>sob demanda</th><th class=r>Realizadas<br>sob demanda</th>'
      '<th class=r>Projeção<br>total</th><th class=r>Realizadas<br>total</th><th class=r>% da<br>projeção</th><th class=r>Obrigat.<br>(A)</th><th class=r>Adicionais<br>(B)</th>'
      '<th class=r>Receita (A)</th><th class=r>Receita (B)</th><th class=r>Receita total</th>')
def lin(lab, r, cls=''):
    return (f'<tr class="{cls}"><td class=m>{lab}</td>{z(r.ProjFIX)}{z(r.RealFIX)}{z(r.ProjDEM)}{z(r.RealDEM)}<td class=r>{n0(r.Proj)}</td><td class=r><b>{n0(r.Real)}</b></td>'
            f'<td class="r{" red" if r.Real < .9 * r.Proj else ""}">{pct(r.Real / r.Proj) if r.Proj else "–"}</td><td class=r>{n0(r.A)}</td><td class=r><b>{n0(r.B) if r.B else "–"}</b></td>'
            f'<td class=r>{brl(r.RA)}</td><td class=r>{brl(r.RB)}</td><td class=r><b>{brl(r.RT)}</b></td></tr>')
s3 = R3[C].sum(); D3 = R3.groupby('Data')[C].sum()
dias = ''.join(lin(f'{DS[d.weekday()]} {d:%d/%m}', r) for d, r in D3.iterrows()) + lin('3 dias', s3, 'tot')
T3 = R3.groupby(['Regiao', 'Travessia'])[C].sum().reset_index(); T3['o'] = T3.Travessia.map(ORD.index); T3 = T3.sort_values('o')
trs = ''.join(f'<tr class=rg><td colspan=13>{g}</td></tr>' + ''.join(lin(r.Travessia, r) for r in T3[T3.Regiao == g].itertuples()) for g in REG) + lin('Total', s3, 'tot')
bb = T3[T3.B > 0].sort_values('B', ascending=False)
p1 = f'''<div class=hero><div class=pat></div><div class=eb>Relatório financeiro de viagens · base e projeção</div><h1>Novembro de 2026</h1>
<div class=per>Realizado de 09 a 11/11 e projeção do mês (09 a 30/11) pelo quantitativo de viagens</div><div class=w></div></div>
<div class=kp><div>Realizadas 09–11/11<b>{n0(s3.Real)}</b>{pct(s3.Real/s3.Proj)} da projeção</div><div>Obrigatórias (A)<b>{n0(s3.A)}</b></div><div>Adicionais (B)<b>{n0(s3.B)}</b>a mais no período fixo</div>
<div>Receita (A)<b>{brl(s3.RA)}</b></div><div>Receita (B) a 60%<b>{brl(s3.RB)}</b></div><div>Receita 3 dias<b>{brl(s3.RT)}</b>média de {brl(s3.RT/3)}/dia</div></div>
<h2><span class=n>1</span>Base: realizado de 09 a 11/11</h2>
<p class=lead>Período fixo = horários fixos da grade; sob demanda = faixas conforme demanda (Anexo 3A). Adicionais (B) = viagens realizadas a mais no período fixo, acima das viagens projetadas para ele. Todas as demais realizadas, inclusive as atrasadas e as das faixas sob demanda, são obrigatórias (A).</p>
<table class="t hm"><tr><th>Dia</th>{HD}</tr>{dias}</table>
<h3>Por travessia, 3 dias somados</h3><table class="t hm"><tr><th>Travessia</th>{HD}</tr>{trs}</table>
<div class=obs><ul><li><b>Adicionais (B): {n0(s3.B)} viagens</b>: ''' + '; '.join(f'{r.Travessia} {n0(r.B)}' for r in bb.itertuples()) + f'''.</li>
<li><b>Abaixo da projeção:</b> ''' + '; '.join(f'{r.Travessia} {pct(r.Real/r.Proj)}' for r in T3[T3.Real < .95 * T3.Proj].sort_values('o').itertuples()) + '.</li></ul></div>'

# ---------- página 2: projeção de novembro
nov['RA1'] = nov.A1 * VA; nov['RB1'] = nov.B1 * VB; nov['RT1'] = nov.RA1 + nov.RB1; nov['RT2'] = nov.A2 * VA
nov['real'] = nov.Data <= '2026-11-11'
s = nov[['Proj', 'FIX', 'DEM', 'A1', 'B1', 'RA1', 'RB1', 'RT1', 'A2', 'RT2']].sum()
T = nov.groupby(['Regiao', 'Travessia'])[['Proj', 'FIX', 'DEM', 'A1', 'B1', 'RT1', 'A2', 'RT2']].sum().reset_index(); T['o'] = T.Travessia.map(ORD.index); T = T.sort_values('o')
T = T.merge(k[['rA', 'rB']].rename_axis('Nome').reset_index().merge(R3[['Nome', 'Travessia']].drop_duplicates(), on='Nome')[['Travessia', 'rA', 'rB']], on='Travessia', how='left')
def l2(lab, r, cls=''):
    ra = f'{pct(r.rA)}' if hasattr(r, 'rA') and pd.notna(getattr(r, 'rA', None)) else ''
    return (f'<tr class="{cls}"><td class=m>{lab}</td><td class=r>{n0(r.FIX)}</td>{z(r.DEM)}<td class=r><b>{n0(r.Proj)}</b></td>'
            f'<td class=r>{ra}</td><td class=r>{n0(r.A1)}</td><td class=r><b>{n0(r.B1) if round(r.B1) else "–"}</b></td><td class=r><b>{brl(r.RT1)}</b></td>'
            f'<td class=r>{n0(r.A2)}</td><td class=r><b>{brl(r.RT2)}</b></td><td class="r{" red" if r.RT1 < r.RT2 else ""}">{brl(r.RT1 - r.RT2)}</td></tr>')
H2 = ('<th>Travessia</th><th class=r>Projeção<br>período fixo</th><th class=r>Projeção<br>sob demanda</th><th class=r>Projeção<br>total</th>'
      '<th class=r>Realizado ÷<br>projetado (A)</th><th class=r>Cen. 1<br>obrigat. (A)</th><th class=r>Cen. 1<br>adicion. (B)</th><th class=r>Cen. 1<br>receita</th>'
      '<th class=r>Cen. 2<br>obrigat. (A)</th><th class=r>Cen. 2<br>receita</th><th class=r>Diferença<br>1 − 2</th>')
t2 = ''.join(f'<tr class=rg><td colspan=11>{g}</td></tr>' + ''.join(l2(r.Travessia, r) for r in T[T.Regiao == g].itertuples()) for g in REG)
tot = pd.Series(dict(FIX=s.FIX, DEM=s.DEM, Proj=s.Proj, A1=s.A1, B1=s.B1, RT1=s.RT1, A2=s.A2, RT2=s.RT2))
t2 += l2('Total', tot, 'tot')
# semanas
nov['Sem'] = pd.cut(nov.Data.dt.day, [8, 11, 15, 22, 29, 30], labels=['09–11 (realizado)', '12–15', '16–22', '23–29', '30'])
W = nov.groupby('Sem', observed=True)[['Proj', 'A1', 'B1', 'RT1', 'A2', 'RT2']].sum()
tw = ''.join(f'<tr><td class=m>{w}</td><td class=r>{n0(r.Proj)}</td><td class=r>{n0(r.A1)}</td><td class=r>{n0(r.B1)}</td><td class=r><b>{brl(r.RT1)}</b></td><td class=r>{n0(r.A2)}</td><td class=r><b>{brl(r.RT2)}</b></td></tr>' for w, r in W.iterrows())
tw += f'<tr class=tot><td class=m>Novembro</td><td class=r>{n0(s.Proj)}</td><td class=r>{n0(s.A1)}</td><td class=r>{n0(s.B1)}</td><td class=r>{brl(s.RT1)}</td><td class=r>{n0(s.A2)}</td><td class=r>{brl(s.RT2)}</td></tr>'
low = T[T.rA < .95].sort_values('rA')
p2 = f'''<div class=sec><h2><span class=n>2</span>Projeção de novembro (09 a 30/11)</h2>
<p class=lead><b>Cenário 1 · tendência dos 3 dias:</b> 09 a 11/11 pelo realizado; de 12 a 30/11, a projeção de cada dia × o desempenho de cada travessia em 09–11/11 (obrigatórias ÷ projetadas e adicionais ÷ projetadas).
<b>Cenário 2 · quantitativo de viagens:</b> todas as viagens projetadas (período fixo e sob demanda) entram como obrigatórias, conforme a grade; não há adicionais, porque adicional é só viagem realizada a mais do que o projetado no período fixo.</p>
<div class=kp><div>Viagens projetadas<b>{n0(s.Proj)}</b>{n0(s.FIX)} fixo · {n0(s.DEM)} demanda</div><div>Cen. 1 · obrigatórias<b>{n0(s.A1)}</b>{n0(s.B1)} adicionais</div><div>Cen. 1 · receita<b>{brl(s.RT1)}</b>A {brl(s.RA1)} · B {brl(s.RB1)}</div>
<div>Cen. 2 · obrigatórias<b>{n0(s.A2)}</b>sem adicionais</div><div>Cen. 2 · receita<b>{brl(s.RT2)}</b></div><div>Diferença 1 − 2<b>{brl(s.RT1 - s.RT2)}</b>{pct(s.RT1/s.RT2 - 1)}</div></div>
<table class="t hm"><tr>{H2}</tr>{t2}</table>
<h3>Por semana</h3><table class="t hm"><tr><th>Período</th><th class=r>Projetadas</th><th class=r>Cen. 1 · (A)</th><th class=r>Cen. 1 · (B)</th><th class=r>Cen. 1 · receita</th><th class=r>Cen. 2 · (A)</th><th class=r>Cen. 2 · receita</th></tr>{tw}</table>
<div class=obs><ul><li><b>Cenário 1: {brl(s.RT1)}</b>, se o mês seguir o ritmo de 09–11/11. Fica {brl(s.RT2 - s.RT1)} abaixo do quantitativo, principalmente por ''' + '; '.join(f'{r.Travessia} ({pct(r.rA)} das projetadas realizadas)' for r in low.itertuples()) + f'''.</li>
<li><b>Cenário 2: {brl(s.RT2)}</b>, se todas as {n0(s.Proj)} viagens do quantitativo forem realizadas. É o teto das obrigatórias; só as adicionais (viagens a mais no período fixo) somariam acima disso.</li>
<li>Adicionais no cenário 1 ({n0(s.B1)} viagens, {brl(s.RB1)}) vêm sobretudo da lancha de São Sebastião, que fez quase o dobro das viagens projetadas.</li></ul></div>
<h3>Critérios</h3><ol class=crit><li>Receita = viagens ÷ 4 × R$ 2.314,05 × 0,75 (Anexo 14, item 2.1.3): obrigatória {brl(VA,2)}; adicional a 60%, {brl(VB,2)}.</li>
<li>Obrigatórias (A): viagens realizadas segundo a grade (Anexo 3A), inclusive as atrasadas e todas as saídas dentro das faixas conforme demanda.</li>
<li>Adicionais (B): viagens realizadas a mais no período de horário fixo, acima das viagens projetadas para esse período no dia, conforme o regime de cada travessia.</li>
<li>Mês = 09 a 30/11/2026. Não contam viagens de serviço nem registros repetidos (mesma embarcação e sentido, menos de 3 min).</li></ol></div>'''
css = open('base.css').read()
open('projecao/projecao.html', 'w').write(f'<!doctype html><html lang=pt-BR><head><meta charset=utf-8><title>Projeção de Novembro</title><base href="file:///mnt/project-files/relatorios-viagens/relatorio-financeiro/gerador/"><style>{css}\n.kp{{grid-template-columns:repeat(6,1fr)!important;margin-bottom:3mm}} .kp div{{font-size:6.1pt}} .kp b{{font-size:11.5pt;white-space:nowrap}} .hm th{{font-size:5.5pt}} .hm td{{font-size:6.9pt;padding:.6mm 1.1mm}} .hero{{padding:4mm 6mm 3.5mm;margin-bottom:3mm}} .hero h1{{font-size:18pt}} .obs{{font-size:7.1pt;padding:1.5mm 3mm}} .obs li{{margin:0 0 .6mm}} h3{{margin:2.5mm 0 1mm}} .crit{{font-size:6.6pt;padding-left:4mm;margin:0}} .lead{{font-size:7.4pt}}</style></head><body>{p1}{p2}</body></html>')
print(s.round(0).to_dict()); print(s3.round(0).to_dict())
