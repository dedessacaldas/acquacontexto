# Relatório geral de viagens – todas as travessias – 09/11/2026 (dia inteiro)
import pickle, base64, pandas as pd
from datetime import timedelta
R=pickle.load(open('res.pkl','rb')); df=R['df']; FX=R['FX'].copy(); BD=R['BD'].copy(); GP=R['GP'].copy()
NAT='Natividade da Serra/B. Natividade da Serra'
excl=lambda X:X[~((X.trav==NAT)&(X.margem=='B. Natividade da Serra'))]
FX,BD,GP=excl(FX),excl(BD),excl(GP)
ORDER=[('Baixada Santista',[('Santos/Guarujá','Ferry boat','Santos ⇄ Guarujá','SG'),('Santos/Vicente de Carvalho','Lancha','Santos ⇄ Vicente de Carvalho','VC'),('Bertioga/Guarujá','Ferry boat','Bertioga ⇄ Guarujá','BG')]),
 ('Litoral Norte',[('São Sebastião/Ilhabela','Ferry boat','São Sebastião ⇄ Ilhabela · balsa','SS'),('São Sebastião/Ilhabela','Lancha','São Sebastião ⇄ Ilhabela · lancha','SL')]),
 ('Litoral Sul',[('Cananéia/Continente','Ferry boat','Cananéia ⇄ Continente','CC'),('Cananéia/Ilha Comprida','Ferry boat','Cananéia ⇄ Ilha Comprida','CI'),('Iguape/Juréia','Ferry boat','Iguape ⇄ Juréia','IJ'),('Cananéia/Ariri','Lancha','Cananéia ⇄ Marujá ⇄ Ariri','CA')]),
 ('Paraibuna e Natividade da Serra',[(NAT,'Ferry boat','Natividade','NT'),('Ribeirão Branco/Capim DAngola','Ferry boat','Paraitinga','PA'),('Comércio/Varginha','Ferry boat','Varginha','VA')])]
TR=[(reg,t,m,l,c) for reg,it in ORDER for t,m,l,c in it]
def n(x): return f'{int(round(x)):,}'.replace(',','.')
def pc(a,b,d=0): return '–' if not b else f'{100*a/b:.{d}f}%'.replace('.',',')
def hm(t): return '' if pd.isna(t) else pd.Timestamp(t).strftime('%H:%M')
def sel(X,t,m): return X[(X.trav==t)&(X.modo==m)]
df['h']=df.saida.dt.hour
VE=['moto','aut','micro','onib','c2','c3','c4']
CL=[('ped','Pedestres'),('bic','Bicicletas'),('moto','Motos'),('aut','Automóveis'),('micro','Micro-ônibus e vans'),('onib','Ônibus'),('c2','Cam. 2 eixos'),('c3','Cam. 3 eixos'),('c4','Cam. 4+ eixos')]
TOT=dict(v=len(df),e=df.emb.nunique(),ped=int(df.ped.sum()),bic=int(df.bic.sum()),veic=int(df.veic.sum()))
FXo=FX; okT=(FXo.status=='No horário').sum()
BDok=int((BD.saidas>=0).sum())

# ---------- 1. resumo ----------
def gapstats(t,m):
    b=sel(BD,t,m)
    if not len(b): return None
    # intervalos avaliados = saídas na faixa (cada saída fecha um intervalo) + fechamento
    nint=int(b.saidas.sum()+len(b)); ex=int(b.excessos.sum())
    return nint-ex,nint,ex
rs=''; cur=None
for reg,t,m,l,c in TR:
    if reg!=cur: rs+=f'<tr class=rg><td colspan=11>{reg}</td></tr>'; cur=reg
    g=sel(df,t,m); f=sel(FX,t,m); ok=(f.status=='No horário').sum(); gs=gapstats(t,m)
    rs+=f'''<tr><td class=m>{l}</td><td class=r><b>{len(g)}</b></td><td class=r>{g.emb.nunique()}</td><td class=r>{len(f) or '–'}</td><td class=r>{ok if len(f) else '–'}</td><td class=r><b>{pc(ok,len(f))}</b></td>
<td class=r>{'–' if gs is None else gs[1]}</td><td class=r>{'–' if gs is None else (f'<b class=red>{gs[2]}</b>' if gs[2] else '0')}</td><td class=r><b>{'–' if gs is None else pc(gs[0],gs[1])}</b></td><td class=r>{n(g.ped.sum()+g.bic.sum())}</td><td class=r>{n(g.veic.sum())}</td></tr>'''
nint=int(BD.saidas.sum()+len(BD)); nex=int(BD.excessos.sum())
rs+=f'<tr class=tot><td class=m>Total</td><td class=r>{n(TOT["v"])}</td><td class=r>{TOT["e"]}</td><td class=r>{len(FX)}</td><td class=r>{okT}</td><td class=r>{pc(okT,len(FX))}</td><td class=r>{nint}</td><td class=r>{nex}</td><td class=r>{pc(nint-nex,nint)}</td><td class=r>{n(TOT["ped"]+TOT["bic"])}</td><td class=r>{n(TOT["veic"])}</td></tr>'

# ---------- 2. volume por classificação ----------
vr=''; cur=None
for reg,t,m,l,c in TR:
    if reg!=cur: vr+=f'<tr class=rg><td colspan=12>{reg}</td></tr>'; cur=reg
    g=sel(df,t,m)
    vr+=f'<tr><td class=m>{l}</td><td class=r>{len(g)}</td>'+''.join(f'<td class=r>{n(g[k].sum()) if g[k].sum() else "<span class=z>0</span>"}</td>' for k,_ in CL)+f'<td class=r><b>{n(g.veic.sum())}</b></td></tr>'
vr+='<tr class=tot><td class=m>Total</td><td class=r>'+n(len(df))+'</td>'+''.join(f'<td class=r>{n(df[k].sum())}</td>' for k,_ in CL)+f'<td class=r>{n(df.veic.sum())}</td></tr>'
# participação (barras)
def share_bars():
    rows=[(l,int(sel(df,t,m).veic.sum()),int(sel(df,t,m).ped.sum()+sel(df,t,m).bic.sum())) for _,t,m,l,_ in TR]
    mv=max(r[1] for r in rows); mp=max(r[2] for r in rows)
    o='<div class=sb><div class=sbh><span></span><span>Veículos</span><span>Pedestres e ciclistas</span></div>'
    for l,v,p in rows:
        o+=f'<div class=sbr><span class=sbl>{l}</span><span class=sbc><i style="width:{max(.4,78*v/mv):.1f}%;background:#005B7F"></i><em>{n(v)}</em></span><span class=sbc><i style="width:{max(.4,78*p/mp):.1f}%;background:#00B5AD"></i><em>{n(p)}</em></span></div>'
    return o+'</div>'

# ---------- 3. volume por faixa horária ----------
PER=[('00h–05h',0,5),('05h–07h',5,7),('07h–09h',7,9),('09h–12h',9,12),('12h–16h',12,16),('16h–19h',16,19),('19h–24h',19,24)]
def per_table(field,lab):
    o=f'<table class="t hm"><thead><tr><th>{lab}</th>'+''.join(f'<th class=r>{p}</th>' for p,_,_ in PER)+'<th class=r>Dia</th></tr></thead><tbody>'
    for _,t,m,l,_ in TR:
        g=sel(df,t,m); vals=[g[(g.h>=a)&(g.h<b)][field].sum() for _,a,b in PER]; tot=sum(vals) or 1
        o+=f'<tr><td class=m>{l}</td>'+''.join(f'<td class=r style="background:{heat(v/tot*len(PER)/3)}">{n(v) if v else "<span class=z>0</span>"}<small>{pc(v,tot)}</small></td>' for v in vals)+f'<td class=r><b>{n(sum(vals))}</b></td></tr>'
    vals=[df[(df.h>=a)&(df.h<b)][field].sum() for _,a,b in PER]
    o+='<tr class=tot><td class=m>Total</td>'+''.join(f'<td class=r>{n(v)}<small>{pc(v,sum(vals))}</small></td>' for v in vals)+f'<td class=r>{n(sum(vals))}</td></tr></tbody></table>'
    return o
def heat(x):
    x=max(0,min(1,x)); # 0 branco → esmeralda claro → azul claro
    r=int(255-(255-176)*x); g=int(255-(255-222)*x); b=int(255-(255-230)*x); return f'rgb({r},{g},{b})'
def hour_heat(fn,lab,fmt=lambda v:str(int(v))):
    o=f'<table class="t hh"><thead><tr><th>{lab}</th>'+''.join(f'<th>{h:02d}</th>' for h in range(24))+'<th class=r>Dia</th></tr></thead><tbody>'
    for _,t,m,l,c in TR:
        g=sel(df,t,m); vals=[fn(g[g.h==h]) for h in range(24)]; mx=max(vals) or 1
        o+=f'<tr><td class=m>{l}</td>'+''.join(f'<td style="background:{heat(v/mx)}">{fmt(v) if v else "<span class=z>·</span>"}</td>' for v in vals)+f'<td class=r><b>{fmt(sum(vals)) if lab!="Frota" else g.emb.nunique()}</b></td></tr>'
    vals=[fn(df[df.h==h]) for h in range(24)]
    o+='<tr class=tot><td class=m>Total</td>'+''.join(f'<td>{fmt(v)}</td>' for v in vals)+f'<td class=r>{fmt(sum(vals)) if lab!="Frota" else df.emb.nunique()}</td></tr></tbody></table>'
    return o
def k(v): return f'{v/1000:.1f}k'.replace('.',',') if v>=1000 else str(int(v))
hv=hour_heat(lambda g:g.veic.sum(),'Veículos',k)
hp=hour_heat(lambda g:g.ped.sum()+g.bic.sum(),'Ped. + bic.',k)
hvi=hour_heat(lambda g:len(g),'Viagens')
hf=hour_heat(lambda g:g.emb.nunique(),'Frota')
# sistema por hora (gráfico)
def sys_chart():
    W,H,L,B=520,95,30,14; v=[int(df[df.h==h].veic.sum()) for h in range(24)]; p=[int(df[df.h==h].ped.sum()+df[df.h==h].bic.sum()) for h in range(24)]
    mx=max(max(v),max(p))*1.1; bw=(W-L-6)/24
    o=[f'<svg viewBox="0 0 {W} {H}" class=chart>']
    for y in range(0,int(mx),1000):
        yy=H-B-(H-B-6)*y/mx; o.append(f'<line x1={L} x2={W-4} y1={yy:.1f} y2={yy:.1f} class=grid /><text x={L-4} y={yy+3:.1f} class=ax text-anchor=end>{k(y)}</text>')
    for h in range(24):
        x=L+bw*h
        for j,(arr,col) in enumerate([(v,'#005B7F'),(p,'#00B5AD')]):
            hh=(H-B-6)*arr[h]/mx; o.append(f'<rect x={x+1+j*bw*0.42:.1f} y={H-B-hh:.1f} width={bw*0.4:.1f} height={hh:.1f} rx=1 fill="{col}" />')
        o.append(f'<text x={x+bw/2:.1f} y={H-4} class=ax text-anchor=middle>{h:02d}</text>')
    o.append('</svg>'); return ''.join(o)

# ---------- 4. frota (gantt) ----------
def gantt():
    o='<table class="t gt"><thead><tr><th>Travessia</th><th>Embarcação</th>'+''.join(f'<th>{h:02d}</th>' for h in range(24))+'<th class=r>Viagens</th><th class=r>1ª – última</th></tr></thead><tbody>'
    for _,t,m,l,c in TR:
        g=sel(df,t,m); es=sorted(g.emb.unique())
        for i,e in enumerate(es):
            ge=g[g.emb==e]; cnt=ge.groupby('h').size()
            o+=f'<tr class="{"fst" if i==0 else ""}"><td class=m>{l if i==0 else ""}</td><td><b>{e}</b></td>'+''.join(f'<td class=gc>{"<i style=opacity:"+str(round(.35+.65*min(1,cnt[h]/max(cnt.max(),1)),2))+">"+str(cnt[h])+"</i>" if h in cnt.index else ""}</td>' for h in range(24))+f'<td class=r>{len(ge)}</td><td class=r>{hm(ge.te.min())}–{hm(ge.te.max())}</td></tr>'
    return o+'</tbody></table>'

# ---------- 5. horários fixos ----------
fr=''; cur=None; nlist=[]
for reg,t,m,l,c in TR:
    f=sel(FX,t,m)
    if not len(f): continue
    if reg!=cur: fr+=f'<tr class=rg><td colspan=8>{reg}</td></tr>'; cur=reg
    for mg,s in f.groupby('margem',sort=False):
        st=s.status.value_counts()
        fr+=f'<tr><td class=m>{l}</td><td>Saídas de {mg}</td><td class=r>{len(s)}</td><td class=r>{st.get("No horário",0)}</td><td class=r>{st.get("Atrasada",0) or ""}</td><td class=r>{st.get("Adiantada",0) or ""}</td><td class=r>{"<b class=red>"+str(st.get("Não realizada",0))+"</b>" if st.get("Não realizada",0) else ""}</td><td class=r><b>{pc(st.get("No horário",0),len(s))}</b></td></tr>'
        for r in s[s.status!='No horário'].itertuples(): nlist.append((l,mg,r))
fr+=f'<tr class=tot><td class=m colspan=2>Total</td><td class=r>{len(FX)}</td><td class=r>{okT}</td><td class=r>{(FX.status=="Atrasada").sum()}</td><td class=r>{(FX.status=="Adiantada").sum()}</td><td class=r>{(FX.status=="Não realizada").sum()}</td><td class=r>{pc(okT,len(FX))}</td></tr>'
CLS={'Atrasada':'at','Adiantada':'ad','Não realizada':'nr'}
def chips(items):
    out='';cur=None
    for l,mg,r in items:
        key=(l,mg)
        if key!=cur:
            if cur: out+='</div></div>'
            out+=f'<div class=chl><div class=chh>{l} <span>· saídas de {mg}</span></div><div class=chs>'; cur=key
        lab=f'{hm(r.prog)}'+(f' → {hm(r.real)} ({r.desvio:+.0f})' if r.status!='Não realizada' else ' · não realizada')
        out+=f'<span class="ch {CLS[r.status]}">{lab}{(" · "+r.emb) if isinstance(r.emb,str) else ""}</span>'
    return out+'</div></div>'

# ---------- 6. intervalos ----------
br=''; cur=None
for reg,t,m,l,c in TR:
    b=sel(BD,t,m)
    if not len(b): continue
    if reg!=cur: br+=f'<tr class=rg><td colspan=8>{reg}</td></tr>'; cur=reg
    for r in b.itertuples():
        fim='24:00' if r.fim.day!=r.ini.day else hm(r.fim)
        br+=f'<tr><td class=m>{l}</td><td>{r.margem}</td><td>{hm(r.ini)}–{fim}</td><td class=r>{r.imax} min</td><td class=r>{r.saidas}</td><td class=r>{r.minimo}</td><td class=r>{r.maior_int:.0f} min</td><td class=r>{"<b class=red>"+str(r.excessos)+"</b>" if r.excessos else "0"}</td></tr>'
gl=''
for _,t,m,l,c in TR:
    g=sel(GP,t,m)
    for mg,s in g.groupby('margem',sort=False):
        gl+=f'<div class=chl><div class=chh>{l} <span>· saídas de {mg} · máx. {s.imax.iloc[0]} min</span></div><div class=chs>'+''.join(f'<span class="ch nr">{hm(r.de)} → {hm(r.ate)} · {r.gap:.0f} min</span>' for r in s.itertuples())+'</div></div>'

logo=base64.b64encode(open('horiz_c_white.png','rb').read()).decode()
fx_ok=pc(okT,len(FX),1); int_ok=pc(nint-nex,nint,1)
html=open('template.html').read()
for kk,vv in dict(RS=rs,VR=vr,SHARE=share_bars(),PV=per_table('veic','Veículos'),PP=None,HV=hv,HP=hp,HVI=hvi,HF=hf,SYS=sys_chart(),GANTT=gantt(),FR=fr,FXL=chips(nlist),BR=br,GL=gl,
    V=n(TOT['v']),E=str(TOT['e']),PB=n(TOT['ped']+TOT['bic']),VEI=n(TOT['veic']),FXOK=fx_ok,FXN=f'{okT} de {len(FX)}',INTOK=int_ok,INTN=f'{nint-nex} de {nint}').items():
    if kk=='PP':
        df['pb']=df.ped+df.bic; vv=per_table('pb','Pedestres e ciclistas')
    html=html.replace('{{'+kk+'}}',vv)
open('relatorio.html','w').write(html)
open('header.html','w').write(f'''<div style="width:100%;height:16mm;margin-top:-4mm;background:#005B7F;border-bottom:1.2mm solid #00B5AD;display:flex;align-items:center;justify-content:space-between;padding:0 12mm;box-sizing:border-box;-webkit-print-color-adjust:exact"><img src="data:image/png;base64,{logo}" style="height:6mm"><span style="color:#fff;font-family:Lato,Arial;font-size:7pt;letter-spacing:.14em;font-weight:700">RELATÓRIO GERAL DE VIAGENS · 09/11/2026</span></div>''')
