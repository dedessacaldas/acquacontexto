import pandas as pd, pickle, sys, math
from datetime import datetime, timedelta
df=pd.read_excel(sys.argv[1])
df.columns=['trav','abert','emb','bsm','dir','ie','te','ped','bic','moto','aut','micro','onib','c2','c3','c4','tipo','tt','td']
for c in ['ie','te','tt','td']: df[c]=pd.to_datetime(df[c],dayfirst=True)
df=df.sort_values('te').reset_index(drop=True)
D=datetime(2026,11,9)
CUT=df.te.max().floor('min')
df['saida']=df.te.dt.floor('min')
df['sent']=df.dir.str[0]
df['modo']=df.emb.str.startswith('LS').map({True:'Lancha',False:'Ferry boat'})
df['veic']=df[['moto','aut','micro','onib','c2','c3','c4']].sum(axis=1)
df['cam']=df[['c2','c3','c4']].sum(axis=1)
df['dur']=(df.tt-df.te).dt.total_seconds()/60
def T(s):
    h,m=map(int,s.split(':')); return D+timedelta(hours=h,minutes=m)
def L(s): return [T(x) for x in s.split()]
def hourly(a,b): return [D+timedelta(hours=h) for h in range(a,b+1)]
def step(a,b,st):
    out=[];t=T(a)
    while t<=T(b): out.append(t); t+=timedelta(minutes=st)
    return out
def band(a,b,i): return (T(a),D+timedelta(hours=24) if b=='24:00' else T(b),i)
VC_S=L('00:00 00:40 01:20 02:00 03:00 04:00 04:40')+step('05:18','08:42',12)+step('09:00','15:40',20)+step('16:06','19:18',12)+L('19:42')+step('20:00','22:40',20)+L('22:54 23:25')
VC_V=L('00:20 01:00 01:40 02:30 03:30 04:20')+step('05:00','08:24',12)+step('08:40','15:40',20)+step('16:00','19:24',12)+step('19:40','22:40',20)+L('23:10 23:40')
SG_F=step('00:00','04:30',30)+[T('05:00')]
SG_B=[band('05:00','06:30',20),band('06:30','20:00',12),band('20:00','24:00',20)]
H05=hourly(0,5)
S={ # (trav, modo, sent): (fixed, bands, nome margem)
('Santos/Guarujá','Ferry boat','1'):(SG_F,SG_B,'Santos'),('Santos/Guarujá','Ferry boat','2'):(SG_F,SG_B,'Guarujá'),
('Santos/Vicente de Carvalho','Lancha','1'):(VC_S,[],'Santos'),('Santos/Vicente de Carvalho','Lancha','2'):(VC_V,[],'Vicente de Carvalho'),
('Bertioga/Guarujá','Ferry boat','1'):(L('00:20 01:00 01:40 02:20 03:00 03:40 04:20 05:00 05:40 06:20 06:40')+step('07:00','12:40',20)+L('13:00 13:20 14:00 14:40 15:20 16:00 16:40 17:00 17:20 17:40 18:00 18:20 19:00 19:40 20:20 21:00 21:40 22:20 23:00 23:40'),[],'Bertioga'),
('Bertioga/Guarujá','Ferry boat','2'):(L('00:00 00:40 01:20 02:00 02:40 03:20 04:00 04:40 05:20 06:00 06:40')+step('07:00','12:40',20)+L('13:00 13:40 14:20 15:00 15:40 16:20 16:40 17:00 17:20 17:40 18:00 18:20 18:40 19:20 20:00 20:40 21:20 22:00 22:40 23:20'),[],'Guarujá'),
('São Sebastião/Ilhabela','Ferry boat','1'):(H05,[band('05:30','24:00',30)],'São Sebastião'),
('São Sebastião/Ilhabela','Ferry boat','2'):(L('00:00 00:30 01:30 02:30 03:30 04:30 05:30'),[band('06:00','24:00',30)],'Ilhabela'),
('São Sebastião/Ilhabela','Lancha','1'):(step('06:30','19:30',60),[],'São Sebastião'),
('São Sebastião/Ilhabela','Lancha','2'):(step('07:00','20:00',60),[],'Ilhabela'),
('Cananéia/Continente','Ferry boat','1'):(L('00:00 00:30 02:30 04:00 05:00 06:15')+step('07:00','11:00',60)+[T('12:05')]+step('13:00','23:00',60),[],'Cananéia'),
('Cananéia/Continente','Ferry boat','2'):(L('00:15 01:00 03:00')+step('04:30','22:30',60),[],'Continente'),
('Cananéia/Ilha Comprida','Ferry boat','1'):(L('00:00 00:30 02:30 04:00 05:00 06:00 06:30 07:00 07:30 08:00 08:30 09:00 10:00 11:00 11:30 12:00 12:30 13:00 13:30 14:00 15:00 16:00 17:00 17:30 18:00 18:30 19:00 19:30 20:00 21:00 22:00 23:00'),[],'Cananéia'),
('Cananéia/Ilha Comprida','Ferry boat','2'):(L('00:15 01:00 03:00 04:30 05:45 06:15 06:45 07:15 07:45 08:15 08:45 09:30 10:30 11:15 11:45 12:15 12:45 13:15 13:45 14:30 15:30 16:30 17:15 17:45 18:15 18:45 19:15 19:45 20:30 21:30 22:30 23:30'),[],'Ilha Comprida'),
('Iguape/Juréia','Ferry boat','1'):(step('00:00','02:30',30)+L('03:30 04:30 05:30 06:30')+step('07:00','20:30',30)+L('21:30 22:30 23:30'),[],'Iguape'),
('Iguape/Juréia','Ferry boat','2'):(step('00:15','01:45',30)+L('02:15 03:15 04:15 05:15')+step('06:15','19:45',30)+L('20:15 21:15 22:25 23:15 23:45'),[],'Juréia'),
('Natividade da Serra/B. Natividade da Serra','Ferry boat','1'):(H05,[band('06:00','08:00',40),band('08:00','20:00',20),band('20:00','24:00',40)],'Natividade da Serra'),
('Natividade da Serra/B. Natividade da Serra','Ferry boat','2'):(H05,[band('06:00','08:00',40),band('08:00','20:00',20),band('20:00','24:00',40)],'B. Natividade da Serra'),
('Ribeirão Branco/Capim DAngola','Ferry boat','1'):(H05,[band('06:00','24:00',40)],'Ribeirão Branco'),
('Ribeirão Branco/Capim DAngola','Ferry boat','2'):(H05,[band('06:00','24:00',40)],"Capim D'Angola"),
('Comércio/Varginha','Ferry boat','1'):(H05,[band('06:00','24:00',45)],'Comércio'),
('Comércio/Varginha','Ferry boat','2'):(H05,[band('06:00','24:00',45)],'Varginha'),
('Cananéia/Ariri','Lancha','1'):([T('13:00')],[],'Cananéia'),
}
fx=[];bd=[];gaps=[]
for (tr,mo,se),(fixed,bands,mg) in S.items():
    g=df[(df.trav==tr)&(df.modo==mo)&(df.sent==se)].reset_index(drop=True)
    slots=[s for s in fixed if s<=CUT]
    pairs=sorted([(abs((t-s).total_seconds()),si,gi) for si,s in enumerate(slots) for gi,t in enumerate(g.saida) if -10<=(t-s).total_seconds()/60<=15])
    us,ug={},set()
    for _,si,gi in pairs:
        if si in us or gi in ug: continue
        us[si]=gi; ug.add(gi)
    for si,s in enumerate(slots):
        if si in us:
            gi=us[si]; d=(g.saida[gi]-s).total_seconds()/60
            st='No horário' if -2<=d<=5 else ('Atrasada' if d>5 else 'Adiantada')
            fx.append([tr,mo,mg,s,g.te[gi],g.emb[gi],d,st])
        else:
            st='Pendente' if (CUT-s).total_seconds()/60<15 else 'Não realizada'
            fx.append([tr,mo,mg,s,None,None,None,st])
    # bands
    allt=list(g.saida)
    for a,b,I in bands:
        if a>CUT: continue
        e=min(b,CUT)
        ins=[t for t in allt if a<=t<b and t<=CUT]
        prev=[t for t in allt if t<a]
        anchor=prev[-1] if prev and (a-prev[-1]).total_seconds()/60<=I else a
        seq=[anchor]+ins+([e] if e<b else [b])
        mx=0;exc=0
        for k in range(1,len(seq)):
            gp=(seq[k]-seq[k-1]).total_seconds()/60
            last=(k==len(seq)-1)
            if gp>I:
                exc+=1; gaps.append([tr,mo,mg,f'{a:%H:%M}–{(b-timedelta(minutes=1) if b.day!=D.day else b):%H:%M}'.replace('23:59','24:00'),I,seq[k-1],seq[k],gp,last and e<b])
            mx=max(mx,gp)
        prev_n=math.ceil((e-a).total_seconds()/60/I)
        bd.append([tr,mo,mg,a,b,I,e,len(ins),prev_n,mx,exc])
FX=pd.DataFrame(fx,columns=['trav','modo','margem','prog','real','emb','desvio','status'])
BD=pd.DataFrame(bd,columns=['trav','modo','margem','ini','fim','imax','ate','saidas','minimo','maior_int','excessos'])
GP=pd.DataFrame(gaps,columns=['trav','modo','margem','faixa','imax','de','ate','gap','aberto'])
# extras: departures not matched to fixed and not in bands
pickle.dump(dict(df=df,FX=FX,BD=BD,GP=GP,CUT=CUT),open(sys.argv[2],'wb'))
print(CUT)
print(FX.groupby(['trav','modo','margem','status']).size().unstack(fill_value=0).to_string())
print(BD.to_string())
print(GP.to_string())
