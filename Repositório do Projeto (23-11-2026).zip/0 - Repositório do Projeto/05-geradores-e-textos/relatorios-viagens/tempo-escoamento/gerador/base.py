import pandas as pd, numpy as np, pickle
F=lambda s: pd.to_datetime(s,format='%d/%m/%Y %H:%M:%S',errors='coerce')
V=pd.read_excel('entradas/Viagens_NOV26.xlsx')
V['ie']=F(V['Início Embarque']);V['te']=F(V['Término Embarque\nInício Travessia']);V['tt']=F(V['Término Travessia\nInício Desembarque']);V['td']=F(V['Término Desembarque'])
V=V[V.te.notna()].copy()
V['veic']=V[['Moto','Aut.','Micro-ônibus e vans','Onibus','Caminhões 2 Eixos','Caminhões 3 Eixos','Caminhões 4 ou mais Eixos']].sum(axis=1)
V['veq']=V['Aut.']+0.33*V.Moto+1.5*V['Micro-ônibus e vans']+2.5*(V.Onibus+V['Caminhões 2 Eixos']+V['Caminhões 3 Eixos']+V['Caminhões 4 ou mais Eixos'])
V['pax']=V['Ped.']+V['Bic.']
V['lancha']=V.Embarcação.str.startswith('LS')
V['marg']=V['De/Para'].str.split('-',n=1).str[1].str.split('/').str[0]
V['emb']=(V.te-V.ie).dt.total_seconds()/60
CAP={'FB-10':39,'FB-19':50,'FB-20':40,'FB-25':71,'FB-28':60,'FB-29':40,'FB-30':50,'FB-VA':41,'FB-CL':60,'FB-11':39,'FB-14':24,'FB-15':24,'FB-17':40,'FB-18':40,'FB-21':28,'FB-26':32,'FB-27':48,
     'FB-05':28,'FB-12':28,'FB-CA':9,'FB-RI':11,'FB-13':17,'FB-16':15,'FB-MF09':24,'FB-MF25':32}
CAPP={'LS-02':370,'LS-03':370,'LS-04':370,'LS-05':450}
V['cap']=V.Embarcação.map(CAP); V['capp']=V.Embarcação.map(CAPP)
pickle.dump(V,open('V.pkl','wb'))
pd.set_option('display.width',250)
V['oc']=V.veq/V.cap
print(V[~V.lancha].groupby(['Travessia','Embarcação']).agg(n=('veq','size'),veq=('veq','mean'),p95=('veq',lambda x:x.quantile(.95)),mx=('veq','max'),cap=('cap','first'),oc=('oc','mean'),cheia=('oc',lambda x:(x>=.9).mean())).round(2).to_string())
print(V[V.lancha].groupby(['Travessia','Embarcação']).agg(n=('pax','size'),pax=('pax','mean'),p95=('pax',lambda x:x.quantile(.95)),mx=('pax','max')).round(1))
