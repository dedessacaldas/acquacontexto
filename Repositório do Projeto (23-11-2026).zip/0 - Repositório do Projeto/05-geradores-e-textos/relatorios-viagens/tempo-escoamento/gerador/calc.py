import pandas as pd, numpy as np, pickle
V=pickle.load(open('./V.pkl','rb'))
CIC={'FB-14','FB-16','FB-21'}
def serv(r):
    if r.lancha: return 'Lancha'
    if r.Travessia=='Santos/Guarujá' and r.Embarcação in CIC: return 'Ciclistas'
    return 'Balsa'
V['serv']=V.apply(serv,axis=1)
V['un']=np.where(V.serv=='Balsa',V.veq,V.pax)
CAPX={'FB-GREGA II':55,'FB-BA':11,'FB-SA':8,'FB-SJ':9,'FB-BV':8,'FB-IV':6,'LS-IT':185,'LS-PA':728,'LS-CA':190}
c=V.cap.where(V.serv=='Balsa',V.capp).fillna(V.Embarcação.map(CAPX))
c=np.where(V.serv=='Ciclistas',V.Embarcação.map({'FB-14':96,'FB-16':60,'FB-21':158}),c)
V['capu']=c
V=V.sort_values('te'); V['d']=V.te.dt.normalize(); V['h']=V.te.dt.hour
V['int_m']=V.groupby(['Travessia','serv','De/Para']).te.diff().dt.total_seconds()/60   # intervalo desde a saída anterior na margem (qualquer embarcação)
V['ciclo']=V.groupby(['Embarcação','De/Para']).te.diff().dt.total_seconds()/60
med=V.groupby(['Embarcação','De/Para']).ciclo.transform('median')
V.loc[(V.ciclo>2.5*med)|(V.ciclo<0.4*med),'ciclo']=np.nan
V['cic_ref']=V.groupby(['Embarcação','De/Para']).ciclo.transform('median')
V['oc']=V.un/V.capu
pickle.dump(V,open('./V2.pkl','wb'))
pd.set_option('display.width',250)
print(V.groupby(['Travessia','serv']).agg(n=('un','size'),un=('un','mean'),cap=('capu','mean'),oc=('oc','mean'),ciclo=('ciclo','median'),intm=('int_m','median'),emb=('emb','median'),nan=('capu',lambda x:x.isna().mean())).round(2).to_string())
