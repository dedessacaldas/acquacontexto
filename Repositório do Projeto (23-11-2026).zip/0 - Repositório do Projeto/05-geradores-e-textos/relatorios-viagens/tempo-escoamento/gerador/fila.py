import pandas as pd, numpy as np, pickle
H=pickle.load(open('./H.pkl','rb')); V=pickle.load(open('./V2.pkl','rb'))
T=pd.read_excel('entradas/TempoEmbarque_NOV26.xlsx'); T['dt']=pd.to_datetime(T['Data Hora'],dayfirst=True)+pd.Timedelta(hours=3)
T=T[(T.dt<='2026-11-17 23:45')&T.Travessia.isin(['Santos/Guarujá','São Sebastião/Ilhabela'])].copy()
m=T.dt.dt.hour*60+T.dt.dt.minute; wd=T.dt.dt.weekday
sg=T.Travessia=='Santos/Guarujá'
ini=np.where(wd<5,390,540); fim=np.where(wd<5,1200,np.where(wd==5,1230,1260))
dem_sg=(m>=ini)&(m<fim)
dem_ss=(m>=np.where(T.Margem=='Ilhabela',360,330))&(m<1410)
T['dem']=np.where(sg,dem_sg,dem_ss)
T=T[T.dem].copy()
# tempo de escoamento da frota na hora seguinte ao registro (balsas, mesma margem)
B=V[(V.serv=='Balsa')&V.Travessia.isin(['Santos/Guarujá','São Sebastião/Ilhabela'])]
out=[]
for (tr,mg),g in T.groupby(['Travessia','Margem']):
    v=B[(B.Travessia==tr)&(B.marg==mg)].sort_values('te'); tv=v.te.values
    cu=np.r_[0,v.un.cumsum().values]; cc=np.r_[0,v.capu.cumsum().values]
    a=np.searchsorted(tv,g.dt.values); b=np.searchsorted(tv,(g.dt+pd.Timedelta(minutes=60)).values)
    emb=[v.Embarcação.values[i:j] for i,j in zip(a,b)]
    cic=[np.nanmean(v.cic_ref.values[i:j]) if j>i else np.nan for i,j in zip(a,b)]
    g=g.assign(dem60=cu[b]-cu[a],cap60=cc[b]-cc[a],viag=b-a,emb=[len(set(e)) for e in emb],ciclo=cic)
    out.append(g)
T=pd.concat(out); T['oc']=T.dem60/T.cap60
T['capm']=T.cap60/T.viag; T['tf']=T.dem60/T.capm*T.ciclo/T.emb
pickle.dump(T,open('./T.pkl','wb'))
pd.set_option('display.width',250)
for tr,g in T.groupby('Travessia'):
    lim=60 if tr.startswith('São') else 30
    g=g.assign(alta=g.Tempo>=lim, zero=g.Tempo==0, faixa=pd.cut(g.tf,[0,30,40,45,50,55,60,999]))
    print(tr, 'corr', round(g.Tempo.corr(g.tf),2), round(g.Tempo.corr(g.oc),2))
    print(g.groupby('faixa',observed=True).agg(n=('Tempo','size'),fila=('Tempo','mean'),med=('Tempo','median'),alta=('alta','mean'),zero=('zero','mean'),dem=('dem60','mean'),emb=('emb','mean'),oc=('oc','mean')).round(2).to_string())
    print(g.groupby(g.dt.dt.date).agg(fila=('Tempo','mean'),alta=('alta','mean'),tf=('tf','mean'),emb=('emb','mean'),dem=('dem60','mean')).round(2).to_string())
