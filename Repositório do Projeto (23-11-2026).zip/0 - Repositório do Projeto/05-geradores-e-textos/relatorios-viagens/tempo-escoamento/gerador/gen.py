# Relatório PDF: tempo de escoamento da demanda por travessia (09–17/11/2026)
import pickle, pandas as pd, numpy as np
R = pickle.load(open('res.pkl', 'rb'))
S, prof, dia, profs, EMB, val, H = R['R'], R['prof'], R['dia'], R['profs'], R['emb'], R['val'], R['H']
n0 = lambda x: f'{x:,.0f}'.replace(',', '.')
f1 = lambda x: f'{x:,.1f}'.replace(',', '#').replace('.', ',').replace('#', '.')
pct = lambda x: f'{x*100:.0f}%'
DS = {9: 'seg', 10: 'ter', 11: 'qua', 12: 'qui', 13: 'sex', 14: 'sáb', 15: 'dom/fer', 16: 'seg', 17: 'ter'}
NOME = {'Santos/Guarujá': 'Santos ⇄ Guarujá', 'São Sebastião/Ilhabela': 'São Sebastião ⇄ Ilhabela', 'Santos/Vicente de Carvalho': 'Santos ⇄ Vicente de Carvalho',
        'Bertioga/Guarujá': 'Bertioga ⇄ Guarujá', 'Cananéia/Continente': 'Cananéia ⇄ Continente', 'Cananéia/Ilha Comprida': 'Cananéia ⇄ Ilha Comprida',
        'Iguape/Juréia': 'Iguape ⇄ Juréia', 'Natividade da Serra/B. Natividade da Serra': 'Natividade da Serra', 'Ribeirão Branco/Capim DAngola': "Paraitinga (Ribeirão Branco ⇄ Capim D'Angola)",
        'Comércio/Varginha': 'Comércio ⇄ Varginha'}
ORD = list(NOME)
SV = {'Balsa': 'balsas (veículos)', 'Ciclistas': 'ciclistas e pedestres', 'Lancha': 'lanchas (passageiros)'}
UN = {'Balsa': 'veq', 'Ciclistas': 'pass.', 'Lancha': 'pass.'}
def cor(v):
    if v != v: return '#F4F7F8', '#B7C6CD'
    if v > 60: return '#C8553D', '#fff'
    if v > 45: return '#F2B65A', '#4A2E00'
    if v > 30: return '#7FD0CA', '#063F3B'
    return '#DDF3F1', '#2E5E5A'
def cls(v): return 'cr' if v > 60 else 'at' if v > 45 else 'ok'

sg = S[(S.Travessia == 'Santos/Guarujá') & (S.serv == 'Balsa')].set_index('marg')
ss = S[(S.Travessia == 'São Sebastião/Ilhabela') & (S.serv == 'Balsa')].set_index('marg')
pdu = prof[prof.du].pivot(index='h', columns='marg', values='tf'); pfd = prof[~prof.du].pivot(index='h', columns='marg', values='tf')
edu = prof[prof.du].groupby('h').emb.mean(); ddu = prof[prof.du].pivot(index='h', columns='marg', values='dem')
Hsg = H[(H.Travessia == 'Santos/Guarujá') & (H.serv == 'Balsa')]
tf_sg = Hsg.tf.mean(); t1_sg = Hsg.t1.mean(); p60_sg = (Hsg.tf > 60).mean(); p45_sg = (Hsg.tf > 45).mean()
cap_sg = Hsg.cap.mean(); cic_sg = Hsg.ciclo.mean(); rit_sg = cap_sg * 60 / cic_sg; dem_sg = Hsg.dem.mean(); emb_sg = Hsg.emb.mean()
Hss = H[(H.Travessia == 'São Sebastião/Ilhabela') & (H.serv == 'Balsa')]
# picos dia útil
gpk = pdu['Guarujá'].loc[6:21].idxmax(); spk = pdu['Santos'].loc[6:21].idxmax()
vsg = val[val.Travessia == 'Santos/Guarujá'].set_index('faixa'); vss = val[val.Travessia == 'São Sebastião/Ilhabela'].set_index('faixa')

def prof_chart(series, cols, emb, mxy=70, mxe=6, W=600, Hh=170):
    pl, pr, pt, pb = 34, 34, 10, 22; bw = (W - pl - pr) / 24
    Y = lambda v: pt + (mxy - min(v, mxy)) / mxy * (Hh - pt - pb); Ye = lambda v: Hh - pb - v / mxe * (Hh - pt - pb) * .55
    g = [f'<svg viewBox="0 0 {W} {Hh}" class=chart>']
    g.append(f'<rect x={pl} y={Y(mxy):.1f} width={W-pl-pr} height={Y(60)-Y(mxy):.1f} fill="#C8553D" opacity=".10"/>')
    g.append(f'<rect x={pl} y={Y(60):.1f} width={W-pl-pr} height={Y(45)-Y(60):.1f} fill="#F2B65A" opacity=".16"/>')
    for v in range(0, mxy + 1, 15):
        g.append(f'<line x1={pl} x2={W-pr} y1={Y(v):.1f} y2={Y(v):.1f} stroke="#E3ECF0" stroke-width=".5"/><text x={pl-4} y={Y(v)+3:.1f} text-anchor=end class=ax>{v}</text>')
    g.append(f'<line x1={pl} x2={W-pr} y1={Y(60):.1f} y2={Y(60):.1f} stroke="#C8553D" stroke-width=".9" stroke-dasharray="3 2"/><text x={W-pr-2} y={Y(60)-3:.1f} text-anchor=end style="font-size:8.5px;fill:#A23E28;font-weight:700">60 min = toda a capacidade da hora</text>')
    for v in (0, 2, 4, 6):
        if v <= mxe: g.append(f'<text x={W-pr+4} y={Ye(v)+3:.1f} class=ax style="fill:#008C86">{v}</text>')
    for h in range(24):
        x = pl + h * bw; e = emb.get(h, 0)
        g.append(f'<rect x={x+bw*.22:.1f} y={Ye(e):.1f} width={bw*.56:.1f} height={Ye(0)-Ye(e):.1f} fill="#CDEFEC" rx="1.5"/>')
        if h % 2 == 0: g.append(f'<text x={x+bw/2:.1f} y={Hh-pb+12} text-anchor=middle class=ax>{h:02d}h</text>')
    for s_, col in zip(series, cols):
        pts = [(pl + h * bw + bw / 2, Y(s_[h])) for h in range(24) if h in s_.index and s_[h] == s_[h]]
        g.append('<polyline fill=none stroke="%s" stroke-width="2.2" points="%s"/>' % (col, ' '.join(f'{a:.1f},{b:.1f}' for a, b in pts)))
        g += [f'<circle cx={a:.1f} cy={b:.1f} r="2.2" fill="{col}"/>' for a, b in pts]
    g.append('</svg>'); return ''.join(g)

def bar_val(v, lim):
    W, Hh = 300, 112; rows = [('até 45 min', v.loc['até 45 min']), ('45 a 60 min', v.loc['45 a 60 min']), ('acima de 60 min', v.loc['acima de 60 min'])]
    cols = ['#7FD0CA', '#F2B65A', '#C8553D']; mx = .45
    g = [f'<svg viewBox="0 0 {W} {Hh}" class=chart>']
    for i, ((lab, r), c) in enumerate(zip(rows, cols)):
        y = 6 + i * 35; w = r.alta / mx * (W - 150)
        g.append(f'<text x=0 y={y+16} style="font-size:10.5px;fill:#17303B;font-weight:700">{lab}</text><text x=0 y={y+28} style="font-size:8.5px;fill:#5E7480">{n0(r.n)} registros</text>')
        g.append(f'<rect x=92 y={y+5} width={w:.1f} height=20 rx="3" fill="{c}"/><text x={98+w:.1f} y={y+20} style="font-size:13px;font-weight:900;fill:#17303B">{pct(r.alta)}</text>')
    g.append('</svg>'); return ''.join(g)

# ---------------- página 1 ----------------
kp = f'''<div class=kp4>
<div class={cls(tf_sg)}><span>Tempo de escoamento · média</span><b>{f1(tf_sg)} min</b><small>de cada hora a frota em operação usa para embarcar a demanda da hora (Santos {f1(sg.loc["Santos","tf"])} · Guarujá {f1(sg.loc["Guarujá","tf"])})</small></div>
<div class=at><span>Pico em dia útil</span><b>{f1(pdu["Guarujá"][gpk])} min</b><small>Guarujá às {gpk:02d}h · Santos {f1(pdu["Santos"][spk])} min às {spk:02d}h</small></div>
<div><span>Uma balsa sozinha</span><b>{n0(t1_sg)} min</b><small>para escoar uma hora média de demanda ({n0(dem_sg)} veq): leva {f1(cap_sg)} veq a cada {f1(cic_sg)} min</small></div>
<div class={"cr" if p60_sg > .1 else "ok"}><span>Horas acima de 60 min</span><b>{pct(p60_sg)}</b><small>demanda acima da capacidade da frota na hora; {pct(p45_sg - p60_sg)} das horas entre 45 e 60 min (no limite)</small></div>
</div>'''
defin = f'''<div class=defbox><div class=dt>Definição adotada · tempo de escoamento</div>
<div class=deq><span>Tempo de escoamento <small>(min)</small></span><i>=</i><span>Demanda da hora na margem <small>(veq embarcados)</small></span><i>÷</i><span>Capacidade de escoamento <small>(lotação ÷ ciclo × embarcações)</small></span></div>
<p><b>Demanda da hora</b> = volume transportado a partir da margem naquela hora, em veículos equivalentes (veq, fatores do Anexo 8, item 9.4.6: auto 1, moto 0,33, van 1,5, ônibus e caminhão 2,5). <b>Capacidade de escoamento de uma embarcação</b> = lotação de veículos da ficha técnica (Apêndice 02) dividida pelo ciclo, que é o tempo entre duas saídas seguidas da mesma embarcação na mesma margem. O resultado diz <b>quantos minutos de cada hora as embarcações em operação precisam para embarcar a demanda que chegou</b>. Até 45 min há folga; de 45 a 60 min a operação está no limite; acima de 60 min a demanda passa da capacidade e acumula na fila. Dividindo só pela capacidade de uma embarcação, tem-se o tempo que <b>uma embarcação sozinha</b> levaria para escoar a mesma demanda.</p></div>'''
conc = f'''<div class=conc>
<div><i>1</i><p>Em Santos ⇄ Guarujá a frota usa, em média, <b>{f1(tf_sg)} min de cada hora</b> para escoar a demanda, com cerca de {f1(emb_sg)} balsas por margem. Há folga na maior parte do dia.</p></div>
<div><i>2</i><p>Nos dias úteis, os picos ficam no limite: <b>Guarujá {gpk:02d}h ({f1(pdu["Guarujá"][gpk])} min)</b> e Santos entre 10h e 18h ({f1(pdu["Santos"].loc[10:18].min())} a {f1(pdu["Santos"].loc[10:18].max())} min). Às 05h, Guarujá chega a {f1(pdu["Guarujá"][5])} min com só {f1(prof[prof.du & (prof.h==5) & (prof.marg=="Guarujá")].emb.iloc[0])} balsas, porque a demanda sobe antes do reforço das 06h.</p></div>
<div><i>3</i><p>Cada balsa escoa cerca de <b>{n0(rit_sg)} veq por hora</b> ({f1(cap_sg)} veq a cada {f1(cic_sg)} min). Sozinha, levaria <b>{n0(t1_sg)} min</b> para escoar uma hora média de demanda; no pico de Guarujá seriam {n0(prof[prof.du & (prof.h==gpk) & (prof.marg=="Guarujá")].t1.iloc[0])} min.</p></div>
<div><i>4</i><p>O cálculo confere com a fila registrada: nas horas acima de 60 min, a fila alta (30 min ou mais) aparece em <b>{pct(vsg.loc["acima de 60 min","alta"])}</b> dos registros, contra {pct(vsg.loc["até 45 min","alta"])} quando há folga. Em São Sebastião ⇄ Ilhabela vai de {pct(vss.loc["até 45 min","alta"])} a {pct(vss.loc["acima de 60 min","alta"])} (fila de 60 min ou mais).</p></div>
<div class=wide><i>5</i><p><b>Nas demais travessias</b>, a travessia mais apertada é <b>São Sebastião ⇄ Ilhabela</b>: as balsas usam {f1(Hss.tf.mean())} min por hora em média e passam de 60 min em <b>{pct((Hss.tf>60).mean())}</b> das horas, sobretudo entre 12h e 18h. As outras têm folga: Cananéia ⇄ Continente {f1(S[S.Travessia=="Cananéia/Continente"].tf.mean())} min, Bertioga ⇄ Guarujá {f1(S[S.Travessia=="Bertioga/Guarujá"].tf.mean())} min e as demais abaixo de 20 min.</p></div>
</div>'''
ex = prof[prof.du & (prof.h == gpk) & (prof.marg == 'Guarujá')].iloc[0]
Hx = Hsg[(Hsg.d.dt.weekday < 5) & (Hsg.h == gpk) & (Hsg.marg == 'Guarujá')]
exb = f'''<div class=exb><div class=dt>Exemplo · Guarujá, {gpk:02d}h, dia útil</div><div class=exr>
<div><b>{n0(ex.dem)} veq</b><span>demanda da hora</span></div><i>÷</i><div><b>{f1(Hx.cap.mean())} veq</b><span>lotação média por viagem</span></div><i>=</i><div><b>{f1(ex.dem/Hx.cap.mean())}</b><span>viagens cheias necessárias</span></div>
<i>×</i><div><b>{f1(Hx.ciclo.mean())} min</b><span>ciclo de cada balsa</span></div><i>=</i><div><b>{n0(ex.t1)} min</b><span>para 1 balsa sozinha</span></div><i>÷</i><div><b>{f1(ex.emb)}</b><span>balsas operando</span></div><i>≈</i><div class=res><b>{f1(ex.tf)} min</b><span>tempo de escoamento</span></div></div></div>'''
def pano():
    P = H.groupby(['Travessia', 'serv']).agg(tf=('tf', 'mean'), p60=('tf', lambda x: (x > 60).mean()), pk=('tf', 'max')).reset_index()
    P['o'] = P.Travessia.map(ORD.index); P = P.sort_values('tf', ascending=False)
    W, rh = 600, 17; Hh = 16 + rh * len(P); x0 = 230; mx = 60
    g = [f'<svg viewBox="0 0 {W} {Hh}" class=chart>']
    for v in (0, 15, 30, 45, 60):
        x = x0 + v / mx * (W - x0 - 70); g.append(f'<line x1={x:.1f} x2={x:.1f} y1=10 y2={Hh-4} stroke="{"#C8553D" if v==60 else "#E3ECF0"}" stroke-width=".6" {"stroke-dasharray=\"3 2\"" if v in (45,60) else ""}/><text x={x:.1f} y=8 text-anchor=middle class=ax>{v} min</text>')
    g.append(f'<text x={W-2} y=8 text-anchor=end class=ax>horas &gt; 60</text>')
    for i, r in enumerate(P.itertuples()):
        y = 14 + i * rh; w = r.tf / mx * (W - x0 - 70); bg, _ = cor(r.tf)
        g.append(f'<text x={x0-6} y={y+11} text-anchor=end style="font-size:9.5px;fill:#17303B;font-weight:700">{NOME[r.Travessia].split(" (")[0]}<tspan style="font-weight:400;fill:#5E7480"> · {r.serv.lower()}</tspan></text>')
        g.append(f'<rect x={x0} y={y+2} width={w:.1f} height=12 rx=2 fill="{bg}"/><text x={x0+w+4:.1f} y={y+11.5} style="font-size:9.5px;font-weight:900;fill:#17303B">{f1(r.tf)}</text>')
        g.append(f'<text x={W-2} y={y+11.5} text-anchor=end style="font-size:9.5px;font-weight:900;fill:{"#C8553D" if r.p60>=.05 else "#5E7480"}">{pct(r.p60)}</text>')
    g.append('</svg>'); return ''.join(g)
p1 = f'''<div class=hero><div class=pat></div><div class=eb>Relatório · operação</div><h1>Tempo de escoamento da demanda</h1>
<div class=per>09 a 17/11/2026 · volume transportado (BSM) × capacidade das embarcações · Santos ⇄ Guarujá e todas as travessias</div><div class=w></div></div>
{defin}{exb}
<div class=part>Santos ⇄ Guarujá · balsas</div>{kp}{conc}<div class=cbox style="margin-top:3mm"><div class=ct>Panorama · tempo médio de escoamento por travessia (min de cada hora, ambas as margens)</div>{pano()}</div>'''

# ---------------- página 2: SG detalhe ----------------
chart_du = prof_chart([pdu['Santos'], pdu['Guarujá']], ['#005B7F', '#E39B2D'], edu.to_dict())
efd = prof[~prof.du].groupby('h').emb.mean()
chart_fd = prof_chart([pfd['Santos'], pfd['Guarujá']], ['#005B7F', '#E39B2D'], efd.to_dict(), Hh=150)
lg = '<div class=lg><i style="background:#005B7F"></i>saindo de Santos<i style="background:#E39B2D"></i>saindo de Guarujá<i style="background:#CDEFEC"></i>balsas em operação na hora (escala à direita)<i style="background:#F2B65A;opacity:.5"></i>no limite (45–60)<i style="background:#C8553D;opacity:.35"></i>acima da capacidade</div>'
# tabela por dia
rows = ''
for d in dia.index:
    r = dia.loc[d]
    tds = ''.join(f'<td class=r>{n0(r[("dem", m)])}</td><td class=r><span class="pill {cls(r[("tf", m)])}">{f1(r[("tf", m)])}</span></td>' for m in ('Santos', 'Guarujá'))
    rows += f'<tr><td class=m>{DS[d]} {d:02d}/11</td>{tds}<td class=r>{f1((r[("emb","Santos")]+r[("emb","Guarujá")])/2)}</td></tr>'
tdia = f'<table class="t big"><tr><th>Dia</th><th class=r>Santos · veq</th><th class=r>Santos · min</th><th class=r>Guarujá · veq</th><th class=r>Guarujá · min</th><th class=r>Balsas/h</th></tr>{rows}</table>'
er = ''
for r in EMB[EMB.Travessia == 'Santos/Guarujá'].itertuples():
    er += f'<tr><td class=m>{r.Embarcação}</td><td class=r>{n0(r.viag)}</td><td class=r>{n0(r.cap)}</td><td class=r>{f1(r.porviag)}</td><td class=r>{pct(r.oc)}</td><td class=r>{f1(r.ciclo)}</td><td class=r><b>{n0(r.rit)}</b></td></tr>'
temb = f'<table class="t big"><tr><th>Balsa</th><th class=r>Viagens</th><th class=r>Lotação (veq)</th><th class=r>veq/viagem</th><th class=r>Ocupação</th><th class=r>Ciclo (min)</th><th class=r>Escoa veq/h</th></tr>{er}</table>'
p2 = f'''<div class=sec></div><h2><span class=n>1</span>Santos ⇄ Guarujá · tempo de escoamento hora a hora</h2>
<p class=lead>Minutos de cada hora que as balsas em operação precisam para embarcar a demanda da hora, por margem de saída. Média das horas de 09 a 17/11.</p>
<div class=cbox><div class=ct>Dias úteis (09–13, 16 e 17/11)</div>{chart_du}{lg}</div>
<div class=cbox><div class=ct>Sábado 14/11 e domingo/feriado 15/11</div>{chart_fd}</div>
<div class=g2b><div class=cbox><div class=ct>Por dia · demanda e tempo médio de escoamento</div>{tdia}</div>
<div class=cbox><div class=ct>Por balsa · quanto cada uma escoa</div>{temb}<div class=lg style="margin-left:-3mm">Escoa veq/h = lotação × 60 ÷ ciclo. Ocupação = veq levados ÷ lotação (pode passar de 100% em viagens com muitas motos).</div></div></div>'''

# ---------------- página 3: todas as travessias ----------------
R2 = S.copy(); R2['o'] = R2.Travessia.map(ORD.index); R2 = R2.sort_values(['o', 'serv', 'marg'])
tr = ''; last = None
for r in R2.itertuples():
    if r.Travessia != last: tr += f'<tr class=rg><td colspan=9>{NOME[r.Travessia]}</td></tr>'; last = r.Travessia
    tr += (f'<tr><td class=m>{r.marg}<span class=sm> · {SV[r.serv]}</span></td><td class=r>{n0(r.dem)} {UN[r.serv]}</td><td class=r>{f1(r.emb)}</td><td class=r>{n0(r.cap)}</td><td class=r>{f1(r.ciclo)}</td>'
           f'<td class=r>{n0(r.t1)}</td><td class=r><span class="pill {cls(r.tf)}">{f1(r.tf)}</span></td><td class=r>{f1(r.tfp)} <span class=sm>às {int(r.hp):02d}h</span></td><td class=r>{pct(r.p60)}</td></tr>')
tall = f'''<table class="t big"><tr><th>Margem de saída</th><th class=r>Demanda/h</th><th class=r>Embarc./h</th><th class=r>Lotação</th><th class=r>Ciclo (min)</th><th class=r>1 embarcação (min)</th><th class=r>Escoamento (min)</th><th class=r>Hora mais carregada</th><th class=r>Horas &gt; 60 min</th></tr>{tr}</table>'''
hm = '<table class=hmx><tr><th></th>' + ''.join(f'<th>{h:02d}</th>' for h in range(24)) + '</tr>'
HH = H.groupby(['Travessia', 'serv', 'marg', 'h']).tf.mean()
last = None
for r in R2.itertuples():
    if r.Travessia != last: hm += f'<tr><td class=hn colspan=25>{NOME[r.Travessia]}</td></tr>'; last = r.Travessia
    hm += f'<tr><td class=hl>{r.marg}<span class=sm> · {r.serv.lower()}</span></td>'
    for h in range(24):
        v = HH.get((r.Travessia, r.serv, r.marg, h), np.nan); bg, fg = cor(v)
        hm += f'<td style="background:{bg};color:{fg}">{"" if v != v else n0(v)}</td>'
    hm += '</tr>'
hm += '</table>'
hlg = '<div class=lg><i style="background:#DDF3F1"></i>até 30 min<i style="background:#7FD0CA"></i>30–45<i style="background:#F2B65A"></i>45–60 (no limite)<i style="background:#C8553D"></i>acima de 60 (demanda acumula)<i style="background:#F4F7F8"></i>sem viagem</div>'
p3 = f'''<div class=sec></div><h2><span class=n>2</span>Todas as travessias · resumo</h2>
<p class=lead>Médias por hora com operação, 09 a 17/11. Balsas em veículos equivalentes (veq); lanchas e o serviço de ciclistas de Santos ⇄ Guarujá em passageiros (pedestres + bicicletas). "1 embarcação" = tempo que uma só levaria para escoar a demanda média da hora. Cananéia ⇄ Ariri fica de fora (8 viagens no período).</p>
{tall}'''
p4 = f'''<div class=sec></div><h2><span class=n>3</span>Mapa do tempo de escoamento por hora</h2>
<p class=lead>Minutos de cada hora necessários para escoar a demanda, média de 09 a 17/11 (todos os dias), por travessia, margem de saída e serviço.</p>
<div class=cbox>{hm}{hlg}</div>
<h2 style="margin-top:5mm"><span class=n>4</span>Conferência com a fila registrada</h2>
<p class=lead>Registros de tempo de fila (a cada 15 min, só nos horários sob demanda) comparados ao tempo de escoamento da hora seguinte na mesma margem. Quanto mais perto de 60 min, mais registros de fila alta.</p>
<div class=g2><div class=cbox><div class=ct>Santos ⇄ Guarujá · registros com fila de 30 min ou mais</div>{bar_val(vsg, 30)}</div>
<div class=cbox><div class=ct>São Sebastião ⇄ Ilhabela · registros com fila de 60 min ou mais</div>{bar_val(vss, 60)}</div></div>
<div class=note>Em Santos ⇄ Guarujá a fila alta também aparece em horas com folga ({pct(vsg.loc['até 45 min','alta'])} dos registros), quase toda em 09 a 12/11; nesses casos a fila não vem da falta de capacidade das balsas. Em São Sebastião ⇄ Ilhabela a relação é mais direta: a fila alta acompanha as horas em que a demanda passa da capacidade das balsas.</div>'''
crit = '''<h2 style="margin-top:5mm"><span class=n>5</span>Critérios</h2><ul class=crit>
<li><b>Bases:</b> Viagens_NOV_26 (BSM, 13.748 viagens de 09/11 00h00 a 17/11 23h58) e TempodeEmbarque_NOV26 (fila a cada 15 min, com o ajuste de +3 h já usado no relatório de fila). Movimentações, Ocorrências, Paralisação e Passagens de Navio não entram no cálculo.</li>
<li><b>Margem e hora:</b> margem de saída pelo De/Para; hora pelo "Término Embarque/Início Travessia".</li>
<li><b>Veículos equivalentes:</b> Anexo 8, item 9.4.6 (auto 1; moto 0,33; micro-ônibus e van 1,5; ônibus e caminhões 2,5). Lanchas e serviço de ciclistas: pedestres + bicicletas.</li>
<li><b>Lotação:</b> capacidade de veículos (ou passageiros) da ficha técnica do Apêndice 02; Bertioga FB-MF09 24 e FB-MF25 32 (informados); sem ficha, a maior carga observada (FB-GREGA II 55, FB-BA 11, FB-SA 8, FB-SJ 9, FB-BV 8, FB-IV 6 veq; LS-IT 185 e LS-PA 728 pass.). Serviço de ciclistas de Santos ⇄ Guarujá = FB-14, FB-16 e FB-21.</li>
<li><b>Ciclo:</b> mediana do tempo entre duas saídas seguidas da mesma embarcação na mesma margem; intervalos acima de 2,5× ou abaixo de 0,4× a mediana (paradas, trocas) ficam de fora.</li>
<li><b>Tempo de escoamento da hora</b> = demanda da hora ÷ lotação média × ciclo médio ÷ embarcações que saíram da margem na hora. Tempo de "1 embarcação" = mesmo cálculo sem dividir pelas embarcações.</li>
<li><b>Fila alta:</b> 30 min ou mais em Santos ⇄ Guarujá e 60 min ou mais em São Sebastião ⇄ Ilhabela; só horários sob demanda (SG: dias úteis 06h30–20h, sáb. 09h–20h30, dom. 09h–21h; SSI: São Sebastião 05h30 e Ilhabela 06h00 até 23h30).</li></ul>'''

css = open('../../relatorio-financeiro/gerador/base.css').read() + '''
body{font-size:9pt} .hero h1{font-size:20pt} .hero .per{font-size:9.5pt}
.part{font-size:8pt;font-weight:900;letter-spacing:.14em;text-transform:uppercase;color:#00B5AD;margin:3mm 0 0}
.kp4{display:grid;grid-template-columns:repeat(4,1fr);gap:3mm;margin:2mm 0 3mm}
.kp4>div{border:.3mm solid #D3E1E7;border-top:1.4mm solid #005B7F;border-radius:1.8mm;padding:2.2mm 3.2mm}
.kp4 .ok{border-top-color:#00B5AD} .kp4 .at{border-top-color:#E39B2D} .kp4 .cr{border-top-color:#C8553D}
.kp4 span{display:block;font-size:7.3pt;color:#5E7480;text-transform:uppercase;letter-spacing:.3pt;font-weight:700}
.kp4 b{display:block;font-size:20pt;color:#005B7F;line-height:1.15;margin:.8mm 0} .kp4 .ok b{color:#008C86} .kp4 .at b{color:#B5731A} .kp4 .cr b{color:#C8553D}
.kp4 small{font-size:7.8pt;color:#17303B;line-height:1.3;display:block}
h2{font-size:13pt;margin:0 0 2mm}
.defbox{border:.4mm solid #00B5AD;background:#F2FAF9;border-radius:2mm;padding:3mm 4mm;margin:0 0 2mm}
.defbox .dt{font-size:8pt;font-weight:900;letter-spacing:.12em;text-transform:uppercase;color:#008C86;margin-bottom:1.5mm}
.deq{display:flex;align-items:center;gap:2.5mm;margin:0 0 2mm} .deq span{background:#005B7F;color:#fff;font-weight:900;font-size:9.5pt;border-radius:1.5mm;padding:1.6mm 3mm;line-height:1.2}
.deq span:first-child{background:#00B5AD} .deq small{display:block;font-weight:400;font-size:7pt;opacity:.9} .deq i{font-style:normal;font-size:15pt;font-weight:900;color:#005B7F}
.defbox p{margin:0;font-size:8.6pt;line-height:1.4} .defbox b{color:#005B7F}
.conc{display:grid;grid-template-columns:1fr 1fr;gap:2.5mm 4mm}
.conc>div{display:flex;gap:3mm;align-items:flex-start;background:#EEF5F8;border-radius:1.8mm;padding:2.5mm 3.5mm}
.conc i{font-style:normal;flex:0 0 7mm;height:7mm;border-radius:50%;background:#005B7F;color:#fff;font-weight:900;font-size:11pt;display:flex;align-items:center;justify-content:center}
.conc p{margin:0;font-size:9pt;line-height:1.38} .conc b{color:#005B7F} .conc .wide{grid-column:1/-1}
.g2{display:grid;grid-template-columns:1fr 1fr;gap:4mm} .g2b{display:grid;grid-template-columns:1fr;gap:0}
.cbox{border:.3mm solid #D3E1E7;border-radius:1.8mm;padding:2.5mm 3.5mm;break-inside:avoid;margin:0 0 3mm}
.ct{font-size:8.3pt;font-weight:900;color:#005B7F;text-transform:uppercase;letter-spacing:.3pt;margin-bottom:1.5mm}
svg.chart{width:100%;height:auto;display:block} svg .ax{font-size:9px;fill:#5E7480}
.lg{font-size:7.6pt;color:#5E7480;margin-top:1mm} .lg i{display:inline-block;width:4mm;height:2.5mm;border-radius:.5mm;margin:0 1.2mm 0 3mm;vertical-align:-.3mm}
.t.big td,.t.big th{font-size:8.2pt;padding:1mm 1.6mm} .t th.r{text-align:right}
.pill{display:inline-block;min-width:10mm;text-align:center;border-radius:1mm;padding:.2mm 1.4mm;font-weight:900}
.pill.ok{background:#DDF3F1;color:#00655F} .pill.at{background:#FCE3B8;color:#7A4A00} .pill.cr{background:#C8553D;color:#fff}
.sm{font-size:7pt;color:#5E7480;font-weight:400}
.hmx{border-collapse:collapse;width:100%;table-layout:fixed;font-size:6.8pt} .hmx th{font-size:6.4pt;color:#5E7480;font-weight:700;padding:.6mm 0;text-align:center}
.hmx th:first-child{width:40mm} .hmx td{text-align:center;padding:1mm 0;border:.25mm solid #fff;font-weight:700}
.hmx td.hl{text-align:left;font-weight:700;color:#005B7F;background:#fff;font-size:7pt;padding-left:1mm;white-space:nowrap;overflow:hidden}
.hmx td.hn{text-align:left;background:#E0F5F3;color:#008C86;font-size:6.4pt;letter-spacing:.08em;text-transform:uppercase;padding:.7mm 1mm}
.exb{border:.3mm solid #D3E1E7;border-radius:2mm;padding:2.5mm 4mm;margin:0 0 2mm}.exb .dt{font-size:8pt;font-weight:900;letter-spacing:.12em;text-transform:uppercase;color:#005B7F;margin-bottom:1.5mm}.exr{display:flex;align-items:center;justify-content:space-between}.exr div{text-align:center;line-height:1.15}.exr b{display:block;font-size:12pt;font-weight:900;color:#005B7F}.exr span{font-size:6.8pt;color:#5E7480}.exr i{font-style:normal;font-weight:900;color:#00B5AD;font-size:12pt}.exr .res{background:#005B7F;border-radius:1.5mm;padding:1.2mm 2.5mm}.exr .res b,.exr .res span{color:#fff}
.note{background:#FFF6E8;border-left:1.2mm solid #E39B2D;border-radius:1.5mm;padding:2.5mm 3.5mm;font-size:9pt;line-height:1.4}
.crit{font-size:8pt} .crit li{margin-bottom:1.2mm}
'''
html = p1 + p2 + p3 + p4 + crit
open('pagina.html', 'w').write(f'<!doctype html><html lang=pt-BR><head><meta charset=utf-8><title>Tempo de escoamento</title><base href="file:///mnt/project-files/relatorios-viagens/relatorio-financeiro/gerador/"><style>{css}</style></head><body>{html}</body></html>')
print('ok')
