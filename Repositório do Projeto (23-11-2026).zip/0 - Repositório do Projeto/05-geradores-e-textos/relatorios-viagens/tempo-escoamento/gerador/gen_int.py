# Relatório PDF: intervalo de atendimento da demanda (simples e considerando o volume), 09–17/11/2026
import pickle, pandas as pd, numpy as np
I = pickle.load(open('I.pkl', 'rb'))
src = open('gen.py').read(); exec(src[src.index('css = '):src.index('html = p1')])
n0 = lambda x: f'{x:,.0f}'.replace(',', '.')
f1 = lambda x: f'{x:,.1f}'.replace(',', '#').replace('.', ',').replace('#', '.')
pct = lambda x: f'{x*100:.0f}%'
NOME = {'Santos/Guarujá': 'Santos ⇄ Guarujá', 'São Sebastião/Ilhabela': 'São Sebastião ⇄ Ilhabela', 'Santos/Vicente de Carvalho': 'Santos ⇄ Vicente de Carvalho',
        'Bertioga/Guarujá': 'Bertioga ⇄ Guarujá', 'Cananéia/Continente': 'Cananéia ⇄ Continente', 'Cananéia/Ilha Comprida': 'Cananéia ⇄ Ilha Comprida',
        'Iguape/Juréia': 'Iguape ⇄ Juréia', 'Natividade da Serra/B. Natividade da Serra': 'Natividade da Serra', 'Ribeirão Branco/Capim DAngola': 'Paraitinga',
        'Comércio/Varginha': 'Comércio ⇄ Varginha'}
ORD = list(NOME); SV = {'Balsa': 'balsas', 'Ciclistas': 'ciclistas e pedestres', 'Lancha': 'lanchas'}; UN = {'Balsa': 'veq', 'Ciclistas': 'pass.', 'Lancha': 'pass.'}

def agg(g):
    u = g.un.sum()
    return pd.Series(dict(n=len(g), im=g.int.mean(), imed=g.int.median(), iv=(g.iw.sum() / u) if u > 0 else np.nan, acu=g.un.mean(),
                          taxa=u / g.int.sum() * 60 if g.int.sum() else np.nan, vazia=(g.un == 0).mean(), imax=g.int.quantile(.9)))
S = I.groupby(['Travessia', 'serv', 'marg']).apply(agg).reset_index()
S['o'] = S.Travessia.map(ORD.index); S = S.sort_values(['o', 'serv', 'marg'])
SGI = I[(I.Travessia == 'Santos/Guarujá') & (I.serv == 'Balsa')]
du = SGI[SGI.du].groupby(['marg', 'h']).apply(agg); fd = SGI[~SGI.du].groupby(['marg', 'h']).apply(agg)
sgt = SGI.groupby('marg').apply(agg); sga = agg(SGI)
d6 = SGI[SGI.du & (SGI.h >= 6) & (SGI.h < 22)]; d6a = agg(d6)
mad = SGI[(SGI.h < 5)]; mada = agg(mad)
pkd = du.loc[(slice(None), slice(6, 21)), 'acu'].idxmax()
SSI = I[(I.Travessia == 'São Sebastião/Ilhabela') & (I.serv == 'Balsa')]; ssa = agg(SSI)

def ccol(v):
    if v != v: return '#F4F7F8', '#B7C6CD'
    for lim, bg, fg in ((5, '#E6F4F8', '#1E4F63'), (10, '#BFE2EC', '#11475C'), (20, '#7FC4D8', '#08384B'), (30, '#3E9FBE', '#fff'), (45, '#1F7CA0', '#fff'), (60, '#005B7F', '#fff')):
        if v <= lim: return bg, fg
    return '#00384F', '#fff'

def hchart(tab, mxy, Hh=175, W=600, mxa=None):
    pl, pr, pt, pb = 34, 38, 10, 22; bw = (W - pl - pr) / 24
    mxa = mxa or max(tab.acu.max() * 1.15, 1)
    Y = lambda v: pt + (mxy - min(v, mxy)) / mxy * (Hh - pt - pb); Ya = lambda v: Hh - pb - v / mxa * (Hh - pt - pb) * .6
    g = [f'<svg viewBox="0 0 {W} {Hh}" class=chart>']
    step = 5 if mxy <= 30 else 10
    for v in range(0, mxy + 1, step):
        g.append(f'<line x1={pl} x2={W-pr} y1={Y(v):.1f} y2={Y(v):.1f} stroke="#E3ECF0" stroke-width=".5"/><text x={pl-4} y={Y(v)+3:.1f} text-anchor=end class=ax>{v} min</text>')
    for v in (0, mxa / 2, mxa): g.append(f'<text x={W-pr+4} y={Ya(v)+3:.1f} class=ax style="fill:#008C86">{n0(v)}</text>')
    acu = tab.groupby(level='h').acu.mean()
    for h in range(24):
        x = pl + h * bw; a = acu.get(h, 0)
        g.append(f'<rect x={x+bw*.2:.1f} y={Ya(a):.1f} width={bw*.6:.1f} height={Ya(0)-Ya(a):.1f} fill="#CDEFEC" rx="1.5"/>')
        if h % 2 == 0: g.append(f'<text x={x+bw/2:.1f} y={Hh-pb+12} text-anchor=middle class=ax>{h:02d}h</text>')
    for m, col in (('Santos', '#005B7F'), ('Guarujá', '#E39B2D')):
        for k, dash in (('im', ''), ('iv', 'stroke-dasharray="4 2.5"')):
            s_ = tab.loc[m][k]
            pts = [(pl + h * bw + bw / 2, Y(s_[h])) for h in range(24) if h in s_.index and s_[h] == s_[h]]
            g.append(f'<polyline fill=none stroke="{col}" stroke-width="{2.2 if k=="im" else 1.6}" {dash} points="%s"/>' % ' '.join(f'{a:.1f},{b:.1f}' for a, b in pts))
            if k == 'im': g += [f'<circle cx={a:.1f} cy={b:.1f} r="2.1" fill="{col}"/>' for a, b in pts]
    g.append('</svg>'); return ''.join(g)

def pano():
    P = I.groupby(['Travessia', 'serv']).apply(agg).reset_index().sort_values('im')
    W, rh = 600, 17; Hh = 18 + rh * len(P); x0 = 220; mx = 60
    X = lambda v: x0 + min(v, mx) / mx * (W - x0 - 20)
    g = [f'<svg viewBox="0 0 {W} {Hh}" class=chart>']
    for v in (0, 15, 30, 45, 60): g.append(f'<line x1={X(v):.1f} x2={X(v):.1f} y1=11 y2={Hh-3} stroke="#E3ECF0" stroke-width=".6"/><text x={X(v):.1f} y=8 text-anchor=middle class=ax>{v} min</text>')
    for i, r in enumerate(P.itertuples()):
        y = 15 + i * rh
        g.append(f'<text x={x0-6} y={y+11} text-anchor=end style="font-size:9.5px;fill:#17303B;font-weight:700">{NOME[r.Travessia]}<tspan style="font-weight:400;fill:#5E7480"> · {SV[r.serv]}</tspan></text>')
        g.append(f'<rect x={x0} y={y+2} width={X(r.im)-x0:.1f} height=12 rx=2 fill="#7FC4D8"/>')
        g.append(f'<line x1={X(r.iv):.1f} x2={X(r.iv):.1f} y1={y} y2={y+16} stroke="#E39B2D" stroke-width="2.6"/>')
        g.append(f'<text x={max(X(r.im),X(r.iv))+5:.1f} y={y+11.5} style="font-size:9.5px;font-weight:900;fill:#005B7F">{f1(r.im)}<tspan style="fill:#B5731A"> · {f1(r.iv)}</tspan></text>')
    g.append('</svg>'); return ''.join(g)

# ---------- página 1 ----------
defs = f'''<div class=g2d>
<div class=defbox><div class=dt>Análise 1 · intervalo de atendimento</div>
<div class=deq><span>Intervalo <small>(min)</small></span><i>=</i><span>Saída <small>da margem</small></span><i>−</i><span>Saída anterior <small>da mesma margem</small></span></div>
<p>Tempo entre duas saídas seguidas <b>da mesma margem</b>, com qualquer embarcação. Mostra de quanto em quanto tempo a demanda da margem é atendida, sem olhar quantas embarcações estão escaladas. O <b>intervalo médio</b> é a média simples dos intervalos, por margem e por hora.</p></div>
<div class=defbox><div class=dt>Análise 2 · intervalo considerando o volume</div>
<div class=deq><span>Intervalo c/ volume</span><i>=</i><span>Σ (intervalo × demanda acumulada) <small>÷ Σ demanda acumulada</small></span></div>
<p>A <b>demanda acumulada</b> de cada intervalo é o que se juntou na margem entre as duas saídas, isto é, o que a saída levou (veq nas balsas; passageiros nas lanchas e ciclistas). Cada intervalo pesa pelo volume. O resultado é o <b>intervalo que a demanda de fato enfrentou</b>: intervalos com muita gente pesam mais e saídas vazias não pesam.</p></div></div>'''
lim = lambda m: f'Santos {f1(sgt.loc["Santos", "im"])} · Guarujá {f1(sgt.loc["Guarujá", "im"])}'
kp = f'''<div class=kp4>
<div><span>Intervalo médio</span><b>{f1(sga.im)} min</b><small>dia inteiro, todos os dias · {lim(0)} min</small></div>
<div class=ok><span>Intervalo c/ volume</span><b>{f1(sga.iv)} min</b><small>Santos {f1(sgt.loc["Santos","iv"])} · Guarujá {f1(sgt.loc["Guarujá","iv"])} min</small></div>
<div class=ok><span>Dia útil, 06h às 22h</span><b>{f1(d6a.im)} min</b><small>com volume {f1(d6a.iv)} min · {n0(d6a.n)} intervalos</small></div>
<div class=at><span>Demanda acumulada</span><b>{f1(sga.acu)} veq</b><small>por intervalo, em média ({n0(sga.taxa)} veq por hora chegando em cada margem)</small></div></div>'''
pk_m, pk_h = pkd
conc = f'''<div class=conc>
<div><i>1</i><p>Em Santos ⇄ Guarujá sai uma balsa de cada margem a cada <b>{f1(sga.im)} min</b> em média. Nos dias úteis, das 06h às 22h, o intervalo cai para <b>{f1(d6a.im)} min</b> e fica entre {f1(du.loc[(slice(None), slice(7, 19)), "im"].min())} e {f1(du.loc[(slice(None), slice(7, 19)), "im"].max())} min das 07h às 19h.</p></div>
<div><i>2</i><p>Considerando o volume, o intervalo é de <b>{f1(sga.iv)} min</b>, quase igual ao simples: os intervalos longos (madrugada, {f1(mada.im)} min de 00h a 05h) carregam pouca demanda ({f1(mada.acu)} veq por intervalo contra {f1(d6a.acu)} no dia).</p></div>
<div><i>3</i><p>A cada intervalo se acumulam em média <b>{f1(sga.acu)} veq</b> por margem. Nos dias úteis, o maior acúmulo é em <b>{pk_m} às {pk_h:02d}h ({f1(du.loc[pkd, "acu"])} veq)</b>, com intervalo de {f1(du.loc[pkd, "im"])} min.</p></div>
<div><i>4</i><p>As duas margens têm o mesmo ritmo. A diferença está no acúmulo: Guarujá concentra mais demanda de manhã (06h–08h) e Santos à noite (20h–23h), com o mesmo intervalo.</p></div>
<div class=wide><i>5</i><p><b>Nas demais travessias</b>, São Sebastião ⇄ Ilhabela tem balsa a cada <b>{f1(ssa.im)} min</b> ({f1(ssa.iv)} com volume) e {f1(ssa.acu)} veq por intervalo. Nas travessias de horário fixo, o intervalo segue a grade (30 a 60 min). Onde o intervalo com volume fica bem abaixo do simples, como Cananéia ⇄ Ilha Comprida ({f1(S[S.Travessia=="Cananéia/Ilha Comprida"].im.mean())} contra {f1(S[S.Travessia=="Cananéia/Ilha Comprida"].iv.mean())} min), os intervalos longos são os de pouca demanda.</p></div></div>'''
p1 = f'''<div class=hero><div class=pat></div><div class=eb>Relatório · operação</div><h1>Intervalo de atendimento da demanda</h1>
<div class=per>09 a 17/11/2026 · intervalo entre saídas por margem e hora, simples e considerando o volume · Santos ⇄ Guarujá e todas as travessias</div><div class=w></div></div>
{defs}<div class=part>Santos ⇄ Guarujá · balsas</div>{kp}{conc}
<div class=cbox style="margin-top:3mm"><div class=ct>Panorama · intervalo médio por travessia (ambas as margens, dia inteiro)</div>{pano()}
<div class=lg><i style="background:#7FC4D8"></i>intervalo médio<i style="background:#E39B2D;width:1.2mm"></i>intervalo considerando o volume</div></div>'''

# ---------- página 2: SG hora a hora ----------
lg = '<div class=lg><i style="background:#005B7F"></i>Santos<i style="background:#E39B2D"></i>Guarujá · linha cheia = intervalo médio · tracejada = intervalo c/ volume<i style="background:#CDEFEC"></i>demanda acumulada por intervalo, veq (escala à direita)</div>'
rows = ''
for h in range(24):
    tds = ''
    for m in ('Santos', 'Guarujá'):
        r = du.loc[(m, h)] if (m, h) in du.index else None
        bg, fg = ccol(r.im)
        tds += f'<td class=r><span class=pill style="background:{bg};color:{fg}">{f1(r.im)}</span></td><td class=r>{f1(r.iv)}</td><td class=r>{f1(r.acu)}</td><td class=r>{n0(r.n)}</td>'
    rows += f'<tr><td class=m>{h:02d}h</td>{tds}</tr>'
thr = f'''<table class="t big hr"><tr><th rowspan=2>Hora</th><th colspan=4 class=c>Saindo de Santos</th><th colspan=4 class=c>Saindo de Guarujá</th></tr>
<tr><th class=r>Intervalo</th><th class=r>c/ volume</th><th class=r>Acumulado (veq)</th><th class=r>Nº interv.</th><th class=r>Intervalo</th><th class=r>c/ volume</th><th class=r>Acumulado (veq)</th><th class=r>Nº interv.</th></tr>{rows}</table>'''
p2 = f'''<div class=sec></div><h2><span class=n>1</span>Santos ⇄ Guarujá · intervalo hora a hora</h2>
<p class=lead>Intervalo entre saídas de balsa da mesma margem, atribuído à hora da saída que fecha o intervalo. Média de 09 a 17/11.</p>
<div class=cbox><div class=ct>Dias úteis (09–13, 16 e 17/11)</div>{hchart(du, 30)}{lg}</div>
<div class=cbox><div class=ct>Dias úteis · tabela por hora (intervalos em min)</div>{thr}</div>'''
p2b = f'''<div class=cbox><div class=ct>Sábado 14/11 e domingo/feriado 15/11</div>{hchart(fd, 35, Hh=150)}{lg}</div>'''

# ---------- página 3: todas ----------
tr = ''; last = None
for r in S.itertuples():
    if r.Travessia != last: tr += f'<tr class=rg><td colspan=9>{NOME[r.Travessia]}</td></tr>'; last = r.Travessia
    tr += (f'<tr><td class=m>{r.marg}<span class=sm> · {SV[r.serv]}</span></td><td class=r>{n0(r.n)}</td><td class=r><b>{f1(r.im)}</b></td><td class=r>{f1(r.imax)}</td>'
           f'<td class=r><b style="color:#B5731A">{f1(r.iv)}</b></td><td class=r>{f1(r.acu)} {UN[r.serv]}</td><td class=r>{n0(r.taxa)}</td><td class=r>{pct(r.vazia)}</td></tr>')
tall = f'''<table class="t big tall"><tr><th>Margem de saída</th><th class=r>Intervalos</th><th class=r>Intervalo médio</th><th class=r>9 em 10 até</th><th class=r>Intervalo c/ volume</th><th class=r>Acumulado por intervalo</th><th class=r>Chegada por hora</th><th class=r>Saídas vazias</th></tr>{tr}</table>'''
p3 = f'''{p2b}<div class=sec></div><h2><span class=n>2</span>Todas as travessias · resumo</h2>
<p class=lead>Minutos entre saídas da mesma margem, 09 a 17/11, dia inteiro. "9 em 10 até" = 90% dos intervalos ficam abaixo desse valor. "Chegada por hora" = demanda acumulada ÷ tempo dos intervalos (veq ou passageiros por hora). Cananéia ⇄ Ariri fica de fora (8 viagens no período).</p>{tall}
<div class=note>Natividade da Serra tem três pontas e o BSM junta Pouso Alto e Bairro Alto num sentido só, por isso a margem B. Natividade da Serra mostra intervalos curtos (saídas para pontas diferentes).</div>'''

# ---------- página 4: mapas ----------
def heat(k):
    T = I.groupby(['Travessia', 'serv', 'marg', 'h']).apply(agg)[k]
    hm = '<table class=hmx><tr><th></th>' + ''.join(f'<th>{h:02d}</th>' for h in range(24)) + '</tr>'; last = None
    for r in S.itertuples():
        if r.Travessia != last: hm += f'<tr><td class=hn colspan=25>{NOME[r.Travessia]}</td></tr>'; last = r.Travessia
        hm += f'<tr><td class=hl>{r.marg}<span class=sm> · {r.serv.lower()}</span></td>'
        for h in range(24):
            v = T.get((r.Travessia, r.serv, r.marg, h), np.nan); bg, fg = ccol(v)
            hm += f'<td style="background:{bg};color:{fg}">{"" if v != v else n0(v)}</td>'
        hm += '</tr>'
    return hm + '</table>'
hlg = '<div class=lg>min:<i style="background:#E6F4F8"></i>até 5<i style="background:#BFE2EC"></i>5–10<i style="background:#7FC4D8"></i>10–20<i style="background:#3E9FBE"></i>20–30<i style="background:#1F7CA0"></i>30–45<i style="background:#005B7F"></i>45–60<i style="background:#00384F"></i>acima de 60<i style="background:#F4F7F8"></i>sem saída</div>'
p4 = f'''<div class=sec></div><h2><span class=n>3</span>Mapa · intervalo médio por hora</h2>
<p class=lead>Análise 1. Minutos entre saídas da mesma margem, média de 09 a 17/11 (todos os dias), pela hora da saída.</p><div class=cbox>{heat("im")}{hlg}</div>
<div class=sec></div><h2><span class=n>4</span>Mapa · intervalo considerando o volume por hora</h2>
<p class=lead>Análise 2. Cada intervalo pesa pela demanda acumulada nele; horas só com saídas vazias ficam em branco.</p><div class=cbox>{heat("iv")}{hlg}</div>'''
crit = '''<h2 style="margin-top:4mm"><span class=n>5</span>Critérios</h2><ul class=crit>
<li><b>Base:</b> Viagens_NOV_26 (BSM, 13.748 viagens de 09/11 00h00 a 17/11 23h58). Saída = "Término Embarque/Início Travessia"; margem = De/Para.</li>
<li><b>Intervalo:</b> tempo entre a saída e a saída anterior da mesma margem, no mesmo serviço (balsa, lancha ou ciclistas), com qualquer embarcação. Fica na hora da saída que fecha o intervalo. Intervalos acima de 3 h (operação parada, noite sem serviço) ficam de fora.</li>
<li><b>Demanda acumulada do intervalo:</b> o que a saída que fecha o intervalo levou. Balsas em veículos equivalentes (Anexo 8, 9.4.6: auto 1; moto 0,33; van 1,5; ônibus e caminhões 2,5); lanchas e ciclistas (FB-14, FB-16, FB-21 em Santos ⇄ Guarujá) em pedestres + bicicletas.</li>
<li><b>Intervalo considerando o volume:</b> média dos intervalos ponderada pela demanda acumulada de cada um.</li>
<li><b>Dias úteis:</b> 09 a 13, 16 e 17/11. Sábado 14/11; domingo e feriado 15/11.</li></ul>'''
css += '''.g2d{display:grid;grid-template-columns:1fr 1fr;gap:3mm;margin-bottom:1mm} .g2d .defbox{margin:0} .g2d .deq span{font-size:8.5pt;padding:1.3mm 2.2mm} .g2d .defbox p{font-size:8.2pt}
.t.tall td,.t.tall th{font-size:7.6pt;padding:.8mm 1.3mm} .t.hr td,.t.hr th{font-size:7.6pt;padding:.55mm 1.4mm} .t th.c{text-align:center;border-bottom:.2mm solid #D3E1E7}'''
open('pagina_int.html', 'w').write(f'<!doctype html><html lang=pt-BR><head><meta charset=utf-8><title>Intervalo de atendimento</title><base href="file:///mnt/project-files/relatorios-viagens/relatorio-financeiro/gerador/"><style>{css}</style></head><body>{p1}{p2}{p3}{p4}{crit}</body></html>')
print(sga.round(1).to_dict(), d6a.round(1).to_dict(), pkd)
