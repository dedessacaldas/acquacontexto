import pandas as pd, numpy as np, pickle
V=pickle.load(open('./V2.pkl','rb'))
H=V.groupby(['Travessia','serv','marg','d','h']).agg(dem=('un','sum'),viag=('un','size'),emb=('Embarcação','nunique'),cap=('capu','mean'),capof=('capu','sum'),
   ciclo=('cic_ref','mean'),porviag=('un','mean'),tem=('emb','mean'),cheia=('oc',lambda x:(x>=.9).mean())).reset_index()
H['t1']=H.dem/H.cap*H.ciclo            # min que UMA embarcação leva para escoar a demanda da hora
H['tf']=H.t1/H.emb                       # min com as embarcações que operaram na hora
H['oc']=H.dem/H.capof
pickle.dump(H,open('./H.pkl','wb'))
pd.set_option('display.width',250)
print(H.groupby(['Travessia','serv','marg']).agg(horas=('dem','size'),dem=('dem','mean'),porviag=('porviag','mean'),cap=('cap','mean'),ciclo=('ciclo','mean'),emb=('emb','mean'),t1=('t1','mean'),tf=('tf','mean'),oc=('oc','mean'),tem=('tem','mean')).round(1).to_string())
s=H[(H.Travessia=='Santos/Guarujá')&(H.serv=='Balsa')]
print(s.groupby(['marg','h'])[['dem','emb','t1','tf','oc']].mean().round(1).unstack(0).to_string())
