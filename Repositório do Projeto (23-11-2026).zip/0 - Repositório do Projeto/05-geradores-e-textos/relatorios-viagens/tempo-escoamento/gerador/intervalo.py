# Intervalo de atendimento: tempo entre saídas seguidas da mesma margem (qualquer embarcação), simples e ponderado pela demanda acumulada no intervalo
import pandas as pd, numpy as np, pickle
V=pickle.load(open('V2.pkl','rb')); V=V[V.Travessia!='Cananéia/Ariri'].copy()
V=V.sort_values('te')
V['prev']=V.groupby(['Travessia','serv','De/Para']).te.shift()
V['int']=(V.te-V.prev).dt.total_seconds()/60
V['du']=V.d.dt.weekday<5
I=V[V.int.notna()&(V.int<=180)].copy()      # intervalos > 3 h = operação parada (fora do período/noite), ficam de fora
I['iw']=I.int*I.un
pickle.dump(I,open('I.pkl','wb'))
def agg(g):
    return pd.Series(dict(n=len(g),im=g.int.mean(),imed=g.int.median(),iv=g.iw.sum()/g.un.sum() if g.un.sum()>0 else np.nan,acu=g.un.mean(),
        taxa=g.un.sum()/g.int.sum(),vazia=(g.un==0).mean(),p_long=(g.int>2*g.int.median()).mean()))
pd.set_option('display.width',250)
R=I.groupby(['Travessia','serv','marg']).apply(agg); print(R.round(1).to_string())
s=I[(I.Travessia=='Santos/Guarujá')&(I.serv=='Balsa')&I.du].groupby(['marg','h']).apply(agg)
print(s[['im','iv','acu','n']].round(1).unstack(0).to_string())
print(I.int.describe())
