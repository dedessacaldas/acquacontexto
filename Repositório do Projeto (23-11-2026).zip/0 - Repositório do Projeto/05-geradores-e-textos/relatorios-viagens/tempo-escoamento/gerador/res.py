import pandas as pd, numpy as np, pickle
H=pickle.load(open('H.pkl','rb')); V=pickle.load(open('V2.pkl','rb')); T=pickle.load(open('T.pkl','rb'))
H=H[H.Travessia!='Cananéia/Ariri']
H['du']=H.d.dt.weekday<5
H['rit']=H.cap*60/H.ciclo        # unidades/h que uma embarcação escoa saindo cheia
def resumo(g):
    hh=g.groupby('h').tf.mean()
    return pd.Series(dict(horas=len(g),dem=g.dem.mean(),viag=g.viag.mean(),emb=g.emb.mean(),porviag=g.porviag.mean(),cap=g.cap.mean(),ciclo=g.ciclo.mean(),
        rit=g.rit.mean(),t1=g.t1.mean(),tf=g.tf.mean(),tfp=hh.max(),hp=int(hh.idxmax()),p60=(g.tf>60).mean(),p45=((g.tf>45)&(g.tf<=60)).mean(),oc=g.oc.mean(),
        demp=g.groupby('h').dem.mean().max()))
R=H.groupby(['Travessia','serv','marg']).apply(resumo).reset_index()
SGH=H[(H.Travessia=='Santos/Guarujá')&(H.serv=='Balsa')]
prof=SGH.groupby(['du','marg','h']).agg(tf=('tf','mean'),t1=('t1','mean'),dem=('dem','mean'),emb=('emb','mean'),p60=('tf',lambda x:(x>60).mean())).reset_index()
dia=SGH.groupby([SGH.d.dt.day,'marg']).apply(lambda g:pd.Series(dict(dem=g.dem.sum(),tf=g.tf.mean(),t1=g.t1.mean(),p60=(g.tf>60).mean(),emb=g.emb.mean()))).unstack()
SSH=H[(H.Travessia=='São Sebastião/Ilhabela')&(H.serv=='Balsa')]
profs=SSH.groupby(['marg','h']).agg(tf=('tf','mean'),dem=('dem','mean'),emb=('emb','mean')).reset_index()
B=V[(V.serv=='Balsa')&V.Travessia.isin(['Santos/Guarujá','São Sebastião/Ilhabela'])]
emb=B.groupby(['Travessia','Embarcação']).agg(viag=('un','size'),porviag=('un','mean'),cap=('capu','first'),oc=('oc','mean'),cheia=('oc',lambda x:(x>=.9).mean()),ciclo=('ciclo','median')).reset_index()
emb['rit']=emb.cap*60/emb.ciclo
# validação com a fila registrada (horários sob demanda)
T['faixa']=pd.cut(T.tf,[0,45,60,999],labels=['até 45 min','45 a 60 min','acima de 60 min'])
T['lim']=np.where(T.Travessia.str.startswith('São'),60,30); T['alta']=T.Tempo>=T.lim
val=T.groupby(['Travessia','faixa'],observed=True).agg(n=('Tempo','size'),alta=('alta','mean'),zero=('Tempo',lambda x:(x==0).mean()),comum=('Tempo',lambda x:x.mode().iloc[0]),dem=('dem60','mean'),emb=('emb','mean')).reset_index()
pickle.dump(dict(R=R,prof=prof,dia=dia,profs=profs,emb=emb,val=val,H=H,nV=len(V),dmin=V.te.min(),dmax=V.te.max()),open('res.pkl','wb'))
pd.set_option('display.width',250)
print(R.round(2).to_string()); print(emb.round(2)); print(val.round(2)); print(dia.round(1).to_string())
