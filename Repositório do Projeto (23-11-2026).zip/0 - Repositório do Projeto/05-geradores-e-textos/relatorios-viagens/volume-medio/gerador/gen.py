"""Média de volume transportado por hora e por embarcação, todas as travessias. python3 gen.py"""
import pandas as pd, sys
sys.path.insert(0, '/mnt/project-files/relatorios-viagens/relatorio-diario/gerador')
from grades import ORDER
G = '/mnt/project-files/relatorios-viagens/relatorio-financeiro/gerador/'
d = pd.read_excel('export.xlsx')
d.columns = ['trav', 'abert', 'emb', 'bsm', 'dir', 'ie', 'te', 'ped', 'bic', 'moto', 'aut', 'micro', 'onib', 'c2', 'c3', 'c4', 'tipo', 'tt', 'td']
d['te'] = pd.to_datetime(d.te, dayfirst=True)
d['modo'] = d.emb.astype(str).str.startswith('LS').map({True: 'Lancha', False: 'Ferry boat'})
d['veic'] = d[['moto', 'aut', 'micro', 'onib', 'c2', 'c3', 'c4']].sum(axis=1); d['pas'] = d.ped + d.bic
d['dia'] = d.te.dt.normalize(); d['h'] = d.te.dt.hour
CUT = d.te.max(); D0 = d.dia.min()
LAST = CUT.normalize(); LH = CUT.hour          # hora LH do último dia está incompleta: fica fora das médias
d = d[~((d.dia == LAST) & (d.h >= LH))]
FULLD = d[d.dia < LAST].dia.nunique()
ndias = lambda h: FULLD + (1 if h < LH else 0)  # dias que cobrem a hora h
LAB = {(t, m): (reg, l) for reg, it in ORDER for t, m, l, q in it}
d['lab'] = [LAB.get((t, m), (None, t))[1] for t, m in zip(d.trav, d.modo)]
d['reg'] = [LAB.get((t, m), (None, None))[0] for t, m in zip(d.trav, d.modo)]
ORDL = [l for _, it in ORDER for t, m, l, q in it]
n0 = lambda x: f'{x:,.0f}'.replace(',', '.')
n1 = lambda x: f'{x:,.1f}'.replace(',', '#').replace('.', ',').replace('#', '.')
z0 = lambda x: n0(x) if round(x) else '–'
HRS = list(range(24))

# ---------- resumo por travessia ----------
R = []
for l in ORDL:
    g = d[d.lab == l]
    if not len(g): continue
    nh = sum(ndias(h) for h in HRS)            # horas-calendário cobertas
    hv = pd.Series({h: g[g.h == h].veic.sum() / ndias(h) for h in HRS}); hp = pd.Series({h: g[g.h == h].pas.sum() / ndias(h) for h in HRS})
    hvg = pd.Series({h: len(g[g.h == h]) / ndias(h) for h in HRS})
    R.append(dict(lab=l, reg=g.reg.iloc[0], via=len(g), emb=g.emb.nunique(), vd=len(g) / (nh / 24), vh=g.veic.sum() / nh * 1, ph=g.pas.sum() / nh,
                  vv=g.veic.sum() / len(g), pv=g.pas.sum() / len(g), pkv=hv.idxmax(), pkvv=hv.max(), pkp=hp.idxmax(), pkpv=hp.max(), hv=hv, hp=hp, hvg=hvg))
R = pd.DataFrame(R)
lanc = lambda l: 'lancha' in l or 'Vicente' in l or 'Ariri' in l
rows = ''
for reg, _ in ORDER:
    rr = R[R.reg == reg]
    if not len(rr): continue
    rows += f'<tr class=rg><td colspan=11>{reg}</td></tr>'
    for r in rr.itertuples():
        rows += (f'<tr><td class=m>{r.lab}</td><td class=r>{n0(r.emb)}</td><td class=r>{n1(r.vd)}</td><td class="r sep"><b>{z0(r.vh) if r.vh >= .5 else "–"}</b></td><td class=r><b>{n0(r.ph)}</b></td>'
                 f'<td class="r sep">{n1(r.vv) if r.vv >= .05 else "–"}</td><td class=r>{n1(r.pv)}</td><td class="r sep">{f"{r.pkv:02d}h · {n0(r.pkvv)}" if r.pkvv >= .5 else "–"}</td><td class=r>{r.pkp:02d}h · {n0(r.pkpv)}</td></tr>')
head = ('<tr><th rowspan=2>Travessia</th><th rowspan=2 class=r>Embarc.</th><th rowspan=2 class=r>Viagens<br>por dia</th><th colspan=2 class="c sep">Média por hora</th>'
        '<th colspan=2 class="c sep">Média por viagem</th><th colspan=2 class="c sep">Hora de maior volume (média)</th></tr>'
        '<tr><th class="r sep">Veículos</th><th class=r>Pedestres e cicl.</th><th class="r sep">Veículos</th><th class=r>Pedestres e cicl.</th><th class="r sep">Veículos</th><th class=r>Pedestres e cicl.</th></tr>')

# ---------- mapas de calor por hora ----------
def heat(col, titulo, unid):
    mx = max(r[col].max() for _, r in R.iterrows()) or 1
    h = f'<h3>{titulo}</h3><table class="t hh2"><tr><th>Travessia</th>' + ''.join(f'<th>{x:02d}</th>' for x in HRS) + '<th class=r>Dia</th></tr>'
    for r in R.itertuples():
        s = getattr(r, col)
        if s.sum() < 1: continue
        loc = s.max() or 1
        cells = ''
        for x in HRS:
            v = s[x]; a = v / loc
            bg = f'rgba(0,91,127,{.08 + .85 * a:.2f})' if v >= .5 else '#fff'
            cells += f'<td style="background:{bg};color:{"#fff" if a > .55 else "#17303B"}{";font-size:4.6pt;letter-spacing:-.15pt" if v >= 999.5 else ""}">{n0(v) if v >= .5 else ""}</td>'
        h += f'<tr><td class=m>{r.lab}</td>{cells}<td class=r><b>{n0(s.sum())}</b></td></tr>'
    return h + f'</table><div class=em>{unid} Cor relativa ao pico de cada travessia (mais escuro = hora mais cheia da travessia).</div>'

# ---------- por embarcação ----------
E = []
for (l, e), g in d.groupby(['lab', 'emb']):
    ho = g.groupby(['dia', 'h']).ngroups        # horas em que a embarcação saiu
    E.append(dict(lab=l, emb=e, via=len(g), dias=g.dia.nunique(), ho=ho, vv=g.veic.sum() / len(g), pv=g.pas.sum() / len(g),
                  vh=g.veic.sum() / ho, ph=g.pas.sum() / ho, vxh=len(g) / ho, mxv=g.veic.max(), mxp=g.pas.max()))
E = pd.DataFrame(E); E['o'] = E.lab.map({l: i for i, l in enumerate(ORDL)}); E = E.sort_values(['o', 'via'], ascending=[True, False])
er = ''
for l in ORDL:
    ee = E[E.lab == l]
    if not len(ee): continue
    veic = ee.vv.max() >= .05
    er += f'<tr class=rg><td colspan=10>{l}</td></tr>'
    for r in ee.itertuples():
        er += (f'<tr><td class=m>{r.emb}</td><td class=r>{n0(r.via)}</td><td class=r>{r.dias}</td><td class=r>{n0(r.ho)}</td><td class=r>{n1(r.vxh)}</td>'
               f'<td class="r sep"><b>{n1(r.vv) if veic else "–"}</b></td><td class=r><b>{n1(r.pv)}</b></td><td class="r sep">{n0(r.vh) if veic else "–"}</td><td class=r>{n0(r.ph)}</td>'
               f'<td class="r sep">{(n0(r.mxv) + " veíc. · ") if veic else ""}{n0(r.mxp)} pas.</td></tr>')
eh = ('<tr><th rowspan=2>Embarcação</th><th rowspan=2 class=r>Viagens</th><th rowspan=2 class=r>Dias</th><th rowspan=2 class=r>Horas em<br>operação</th><th rowspan=2 class=r>Viagens<br>por hora</th>'
      '<th colspan=2 class="c sep">Média por viagem</th><th colspan=2 class="c sep">Média por hora em operação</th><th rowspan=2 class="r sep">Maior carga<br>numa viagem</th></tr>'
      '<tr><th class="r sep">Veículos</th><th class=r>Pedestres e cicl.</th><th class="r sep">Veículos</th><th class=r>Pedestres e cicl.</th></tr>')

ss = R[R.lab.str.startswith('São Sebastião')]
sg = R[R.lab == 'Santos ⇄ Guarujá'].iloc[0]
tv = d.veic.sum(); tp = d.pas.sum(); nh = sum(ndias(h) for h in HRS)
obs = [f'<b>Santos ⇄ Guarujá:</b> {n0(sg.vh)} veículos e {n0(sg.ph)} pedestres e ciclistas por hora, em média; {n1(sg.vv)} veículos por viagem; hora mais cheia de veículos {sg.pkv:02d}h ({n0(sg.pkvv)}).']
for r in ss.itertuples():
    obs.append(f'<b>{r.lab}:</b> ' + (f'{n0(r.vh)} veículos e ' if r.vh >= .5 else '') + f'{n0(r.ph)} pedestres e ciclistas por hora; ' + (f'{n1(r.vv)} veículos e ' if r.vv >= .05 else '') + f'{n1(r.pv)} pedestres por viagem; pico às {(r.pkv if r.vh >= .5 else r.pkp):02d}h.')
top = E[E.vv >= .05].sort_values('vv', ascending=False).head(3)
obs.append('<b>Embarcações com maior carga média de veículos por viagem:</b> ' + '; '.join(f'{r.emb} em {r.lab} ({n1(r.vv)})' for r in top.itertuples()) + '.')
html = f'''<div class=hero><div class=pat></div><div class=eb>Relatório de volume transportado</div><h1>Volume médio por hora e por embarcação</h1>
<div class=per>Todas as travessias · {D0:%d/%m} a {CUT:%d/%m/%Y} ({CUT:%H:%M}, último registro) · média por hora do dia e por embarcação</div><div class=w></div></div>
<div class="kp k6"><div>Viagens<b>{n0(len(d))}</b>{FULLD} dias completos + {CUT:%d/%m} até {LH:02d}h</div><div>Veículos por hora<b>{n0(tv / nh)}</b>todas as travessias</div><div>Pedestres e cicl. por hora<b>{n0(tp / nh)}</b>todas as travessias</div>
<div>Veículos por viagem<b>{n1(tv / len(d))}</b>média geral</div><div>Pedestres por viagem<b>{n1(tp / len(d))}</b>média geral</div><div>Embarcações<b>{d.emb.nunique()}</b>em operação</div></div>
<h2><span class=n>1</span>Médias por travessia</h2><table class="t hm v">{head}{rows}</table>
<div class=obs><ul>{"".join(f"<li>{x}</li>" for x in obs)}</ul></div>
<h2><span class=n>2</span>Média por hora do dia</h2>{heat("hv", "Veículos por hora (média)", "Média de veículos embarcados em cada hora do dia, somando as duas margens.")}
{heat("hp", "Pedestres e ciclistas por hora (média)", "Média de pedestres e ciclistas embarcados em cada hora do dia, somando as duas margens.")}
{heat("hvg", "Viagens por hora (média)", "Média de saídas em cada hora do dia, somando as duas margens.")}
<div class=sec><h2><span class=n>3</span>Média por embarcação</h2><table class="t hm v">{eh}{er}</table></div>
<ol class=crit><li>Base: todos os registros do sistema de {D0:%d/%m} a {CUT:%d/%m} {CUT:%H:%M}. Hora = hora do início da travessia (término do embarque). Veículos em unidades (motos, automóveis, micro-ônibus, vans, ônibus e caminhões), sem conversão em veículo equivalente.</li>
<li>Média por hora = volume embarcado na hora ÷ nº de dias com aquela hora completa ({FULLD} dias completos; em {CUT:%d/%m} entram as horas até {LH - 1:02d}h59; a partir de {LH:02d}h, incompleta, fica fora). Média por hora da travessia = volume total ÷ horas do período.</li>
<li>Por embarcação: média por viagem = volume ÷ viagens; média por hora em operação = volume ÷ horas (dia e hora) em que a embarcação fez ao menos uma saída.</li></ol>'''
css = open(G + 'base.css').read() + '''
.k6{grid-template-columns:repeat(6,1fr)!important;margin-bottom:3mm} .k6 div{font-size:6.4pt} .k6 b{font-size:13pt}
.hero{padding:4mm 6mm 3.5mm;margin-bottom:3mm} .hero h1{font-size:19pt}
h2{font-size:12pt;margin-top:3.5mm} h3{margin:2.5mm 0 1mm;font-size:9pt}
.v th{font-size:5.8pt;padding:.7mm 1mm} .v td{font-size:7pt;padding:.5mm 1mm} .v th.c{text-align:center} .v .sep{border-left:.3mm solid #C9DAE2}
.hh2{table-layout:fixed;font-size:5.9pt;margin-bottom:.8mm} .hh2 th{font-size:5.6pt;text-align:center;padding:.5mm 0} .hh2 th:first-child{width:40mm;text-align:left} .hh2 th:last-child{width:10mm}
.hh2 td{text-align:center;padding:.6mm 0;border-bottom:.3mm solid #fff;border-right:.3mm solid #fff} .hh2 td.m{text-align:left;font-size:6.4pt;background:#fff;border-bottom:.2mm solid #D3E1E7;padding-left:1mm}
.em{font-size:6.3pt;color:#5E7480;margin:0 0 1.5mm} .obs{font-size:7.3pt} .crit{font-size:6.8pt;margin-top:3mm}'''
open('pagina.html', 'w').write(f'<!doctype html><html lang=pt-BR><head><meta charset=utf-8><title>Volume médio</title><base href="file://{G}"><style>{css}</style></head><body>{html}</body></html>')
print(len(d), FULLD, LH, CUT); print(R[['lab', 'vd', 'vh', 'ph', 'vv', 'pv', 'pkv', 'pkp']].round(1).to_string())
