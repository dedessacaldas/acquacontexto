"""Volume médio por hora e por embarcação, versão executiva (pág. 1 = hoje 00h até o último registro; pág. 2 = período). python3 gen2.py"""
import pandas as pd, sys
sys.path.insert(0, '/mnt/project-files/relatorios-viagens/relatorio-diario/gerador')
from grades import ORDER
G = '/mnt/project-files/relatorios-viagens/relatorio-financeiro/gerador/'
d = pd.read_excel('export.xlsx')
d.columns = ['trav', 'abert', 'emb', 'bsm', 'dir', 'ie', 'te', 'ped', 'bic', 'moto', 'aut', 'micro', 'onib', 'c2', 'c3', 'c4', 'tipo', 'tt', 'td']
d['te'] = pd.to_datetime(d.te, dayfirst=True)
d['modo'] = d.emb.astype(str).str.startswith('LS').map({True: 'Lancha', False: 'Ferry boat'})
d['veic'] = d[['moto', 'aut', 'micro', 'onib', 'c2', 'c3', 'c4']].sum(axis=1); d['pas'] = d.ped + d.bic
d['dia'] = d.te.dt.normalize(); d['h'] = d.te.dt.hour
CUT = d.te.max(); D0 = d.dia.min(); LAST = CUT.normalize(); LH = CUT.hour
LAB = {(t, m): (reg, l) for reg, it in ORDER for t, m, l, q in it}
d['lab'] = [LAB.get((t, m), (None, t))[1] for t, m in zip(d.trav, d.modo)]
d['reg'] = [LAB.get((t, m), (None, None))[0] for t, m in zip(d.trav, d.modo)]
ORDL = [l for _, it in ORDER for t, m, l, q in it]
n0 = lambda x: f'{x:,.0f}'.replace(',', '.')
n1 = lambda x: f'{x:,.1f}'.replace(',', '#').replace('.', ',').replace('#', '.')
pct = lambda x: (f'+{x:.0%}' if x >= 0 else f'{x:.0%}').replace('.', ',')
HRS = list(range(24))
CURTA = {'Santos ⇄ Guarujá': 'Santos–Guarujá', 'Santos ⇄ Vicente de Carvalho': 'Santos–V. Carvalho', 'Bertioga ⇄ Guarujá': 'Bertioga–Guarujá',
         'São Sebastião ⇄ Ilhabela · balsa': 'SS–Ilhabela balsa', 'São Sebastião ⇄ Ilhabela · lancha': 'SS–Ilhabela lancha'}
cur = lambda l: CURTA.get(l, l.replace(' ⇄ ', '–'))

# ---------- bases ----------
H = d[d.dia == LAST]                                   # hoje, 00h até o último registro
HH = (CUT - LAST).total_seconds() / 3600               # horas decorridas hoje
P = d[~((d.dia == LAST) & (d.h >= LH))]                # período, sem a hora incompleta de hoje
FULLD = P[P.dia < LAST].dia.nunique()
ndias = lambda h: FULLD + (1 if h < LH else 0)
NH = sum(ndias(h) for h in HRS)
REF = d[(d.dia < LAST) & (d.h < LH)]                   # dias anteriores, mesmas horas de hoje (00h a LH-1)
HC = H[H.h < LH]                                       # hoje até LH-1h59, para comparar

def trav(g, horas):
    return dict(via=len(g), emb=g.emb.nunique(), vh=g.veic.sum() / horas, ph=g.pas.sum() / horas, vv=g.veic.sum() / max(len(g), 1), pv=g.pas.sum() / max(len(g), 1),
                tv=g.veic.sum(), tp=g.pas.sum())

def boats(g):
    E = []
    for (l, e), x in g.groupby(['lab', 'emb']):
        ho = x.groupby(['dia', 'h']).ngroups
        E.append(dict(lab=l, emb=e, via=len(x), ho=ho, vv=x.veic.sum() / len(x), pv=x.pas.sum() / len(x), vh=x.veic.sum() / ho, ph=x.pas.sum() / ho,
                      vxh=len(x) / ho, lanc=str(e).startswith('LS')))
    E = pd.DataFrame(E); E['o'] = E.lab.map({l: i for i, l in enumerate(ORDL)})
    return E.sort_values(['o', 'vv', 'pv'], ascending=[True, False, False])

def boat_tables(E, unid_h):
    mv = E[~E.lanc].vv.max() or 1; mp = E[E.lanc].pv.max() or 1
    rows = []                                            # (rótulo do grupo, html) — grupo None = cabeçalho
    for l in ORDL:
        ee = E[E.lab == l]
        if not len(ee): continue
        rows.append((l, None))
        for b in ee.itertuples():
            if b.lanc:
                bar = f'<div class=bw><i class=lp style="width:{b.pv / mp * 17:.1f}mm"></i><span>{n1(b.pv)} pas.</span></div>'
            elif b.vv >= .05:
                bar = f'<div class=bw><i style="width:{b.vv / mv * 17:.1f}mm"></i><span>{n1(b.vv)} veíc.</span></div>'
            else:
                bar = '<div class=bw><span>–</span></div>'
            rows.append((l, f'<tr><td class=m><b>{b.emb}</b></td><td class=r>{n0(b.via)}</td><td class=bc>{bar}</td><td class=r>{n1(b.pv) if not b.lanc else "–"}</td>'
                            f'<td class="r sep">{n0(b.vh) if not b.lanc and b.vv >= .05 else "–"}</td><td class=r>{n0(b.ph)}</td></tr>'))
    half = (len(rows) + 1) // 2
    if rows[half - 1][1] is None: half -= 1              # não deixa cabeçalho órfão no fim da coluna
    L, Rr = rows[:half], rows[half:]
    if Rr and Rr[0][1] is not None: Rr = [(Rr[0][0], 'cont')] + Rr
    gh = lambda l, c: f'<tr class=rg><td colspan=6>{l}{" (cont.)" if c else ""}</td></tr>'
    body = lambda rr: ''.join(gh(l, h == 'cont') if h in (None, 'cont') else h for l, h in rr)
    hd = ('<tr><th rowspan=2>Embarc.</th><th rowspan=2 class=r>Viagens</th><th rowspan=2>Carga média por viagem</th><th rowspan=2 class=r>Pas.<br>/viagem</th>'
          f'<th colspan=2 class="c sep">Média por hora {unid_h}</th></tr><tr><th class="r sep">Veíc.</th><th class=r>Pas.</th></tr>')
    return f'<div class=two><table class="t v bt">{hd}{body(L)}</table><table class="t v bt">{hd}{body(Rr)}</table></div>'

def trav_table(rows, cols_extra=False):
    hd = ('<tr><th>Travessia</th><th class=r>Embarc.</th><th class=r>Viagens</th><th class="r sep">Veíc./hora</th><th class=r>Pas./hora</th>'
          '<th class="r sep">Veíc./viagem</th><th class=r>Pas./viagem</th>' + ('<th class="r sep">Pico veíc.</th><th class=r>Pico pas.</th>' if cols_extra else '') +
          ('<th class="r sep">Hoje × período<br>veíc./hora</th><th class=r>Hoje × período<br>pas./hora</th>' if cols_extra else '') + '</tr>')
    b = ''
    for reg, _ in ORDER:
        rr = [r for r in rows if r['reg'] == reg]
        if not rr: continue
        for r in rr:
            veic = r['vv'] >= .05 and not any(k in r['lab'] for k in ('lancha', 'Vicente', 'Ariri'))
            b += (f'<tr><td class=m>{r["lab"]}</td><td class=r>{r["emb"]}</td><td class=r>{n0(r["via"])}</td><td class="r sep"><b>{n0(r["vh"]) if veic else "–"}</b></td>'
                  f'<td class=r><b>{n0(r["ph"])}</b></td><td class="r sep">{n1(r["vv"]) if veic else "–"}</td><td class=r>{n1(r["pv"])}</td>')
            if cols_extra:
                b += f'<td class="r sep">{r["pkv"]}</td><td class=r>{r["pkp"]}</td>'
                dv, dp = r.get('dv'), r.get('dp')
                f = lambda x: '–' if x is None else f'<span class={"up" if x >= .03 else ("dn" if x <= -.03 else "eq")}>{pct(x)}</span>'
                b += f'<td class="r sep">{f(dv) if veic else "–"}</td><td class=r>{f(dp)}</td>'
            b += '</tr>'
    return f'<table class="t v">{hd}{b}</table>'

# ---------- página 1: hoje ----------
T1 = []
for l in ORDL:
    g = H[H.lab == l]
    if len(g): T1.append(dict(lab=l, reg=g.reg.iloc[0], **trav(g, HH)))
E1 = boats(H)
tv1, tp1 = H.veic.sum(), H.pas.sum()
hv1 = H.groupby('h').veic.sum(); pkh = hv1.idxmax()
fb1 = E1[(~E1.lanc) & (E1.vv >= .05)]; ls1 = E1[E1.lanc]
t1 = fb1.sort_values('vv', ascending=False).head(3); tl1 = ls1.sort_values('pv', ascending=False).head(1)
low1 = fb1[fb1.lab.isin(['Santos ⇄ Guarujá', 'São Sebastião ⇄ Ilhabela · balsa'])].sort_values('vv').head(2)
ob1 = [f'<b>Maior carga média de veículos por viagem:</b> ' + '; '.join(f'{b.emb} ({cur(b.lab)}) {n1(b.vv)}' for b in t1.itertuples()) + '.']
if len(tl1): ob1.append(f'<b>Lancha com maior carga:</b> {tl1.iloc[0].emb} ({cur(tl1.iloc[0].lab)}), {n1(tl1.iloc[0].pv)} pedestres e ciclistas por viagem.')
if len(low1): ob1.append('<b>Menor carga entre as balsas das travessias principais:</b> ' + '; '.join(f'{b.emb} ({cur(b.lab)}) {n1(b.vv)} veículos por viagem' for b in low1.itertuples()) + '.')
ob1.append(f'<b>Hora mais cheia de hoje:</b> {pkh:02d}h, com {n0(hv1.max())} veículos embarcados somando todas as travessias.')

# ---------- página 2: período ----------
T2 = []
for l in ORDL:
    g = P[P.lab == l]
    if not len(g): continue
    hv = pd.Series({h: g[g.h == h].veic.sum() / ndias(h) for h in HRS}); hp = pd.Series({h: g[g.h == h].pas.sum() / ndias(h) for h in HRS})
    r = dict(lab=l, reg=g.reg.iloc[0], **trav(g, NH))
    r['via'] = len(g) / (NH / 24); r['pkv'] = f'{hv.idxmax():02d}h · {n0(hv.max())}' if hv.max() >= .5 else '–'; r['pkp'] = f'{hp.idxmax():02d}h · {n0(hp.max())}'
    ref = REF[REF.lab == l]; hc = HC[HC.lab == l]; nref = REF.dia.nunique()
    rv, rp = ref.veic.sum() / nref, ref.pas.sum() / nref
    r['dv'] = hc.veic.sum() / rv - 1 if rv >= 1 else None; r['dp'] = hc.pas.sum() / rp - 1 if rp >= 1 else None
    T2.append(r)
E2 = boats(P)
tv2, tp2 = P.veic.sum(), P.pas.sum()
R2 = pd.DataFrame(T2)
gv = HC.veic.sum() / (REF.veic.sum() / REF.dia.nunique()) - 1; gp = HC.pas.sum() / (REF.pas.sum() / REF.dia.nunique()) - 1
fb2 = E2[(~E2.lanc) & (E2.vv >= .05) & (E2.via >= 50)]
sg = R2[R2.lab == 'Santos ⇄ Guarujá'].iloc[0]; ssb = R2[R2.lab == 'São Sebastião ⇄ Ilhabela · balsa'].iloc[0]
share = (sg.tv + ssb.tv) / tv2
sgb = fb2[fb2.lab == 'Santos ⇄ Guarujá']; ssbb = fb2[fb2.lab == 'São Sebastião ⇄ Ilhabela · balsa']
dia_v = P[P.dia < LAST].groupby('dia').veic.sum(); dmx = dia_v.idxmax()
ob2 = [f'<b>Concentração:</b> Santos–Guarujá e SS–Ilhabela balsa levam {share:.0%} de todos os veículos do período.'.replace('.', ',', 1) if False else
       f'<b>Concentração:</b> Santos–Guarujá e SS–Ilhabela balsa levam {round(share * 100)}% de todos os veículos do período ({n0(sg.vh)} e {n0(ssb.vh)} veículos por hora).',
       f'<b>Santos–Guarujá:</b> a carga média por viagem varia de {n1(sgb.vv.min())} ({sgb.sort_values("vv").iloc[0].emb}) a {n1(sgb.vv.max())} veículos ({sgb.sort_values("vv").iloc[-1].emb}). '
       f'Os FB-14, FB-21 e FB-16 operam como barcos de pedestres, com {n0(E2[E2.emb.isin(["FB-14", "FB-21", "FB-16"])].pv.mean())} pedestres por viagem em média.',
       f'<b>SS–Ilhabela balsa:</b> a carga média vai de {n1(ssbb.vv.min())} ({ssbb.sort_values("vv").iloc[0].emb}) a {n1(ssbb.vv.max())} veículos por viagem ({ssbb.sort_values("vv").iloc[-1].emb}); '
       f'pico médio às {ssb.pkv[:3]}.',
       f'<b>Hoje × período, de 00h a {LH - 1:02d}h59:</b> veículos {pct(gv)} e pedestres e ciclistas {pct(gp)} em relação à média dos {REF.dia.nunique()} dias anteriores nas mesmas horas.',
       f'<b>Dia de maior movimento:</b> {dmx:%d/%m}, com {n0(dia_v.max())} veículos; média de {n0(dia_v.mean())} veículos por dia completo.']

kp1 = (f'<div class="kp k5"><div>Viagens hoje<b>{n0(len(H))}</b>00h às {CUT:%H:%M}</div><div>Veículos por hora<b>{n0(tv1 / HH)}</b>{n0(tv1)} no dia até agora</div>'
       f'<div>Pedestres e cicl. por hora<b>{n0(tp1 / HH)}</b>{n0(tp1)} no dia até agora</div><div>Veículos por viagem<b>{n1(fb1.vv.mean() if False else H[~H.emb.astype(str).str.startswith("LS")].veic.sum() / max(1, (~H.emb.astype(str).str.startswith("LS")).sum()))}</b>média das balsas</div>'
       f'<div>Embarcações<b>{H.emb.nunique()}</b>operaram hoje</div></div>')
nfb2 = (~P.emb.astype(str).str.startswith('LS')).sum()
kp2 = (f'<div class="kp k5"><div>Viagens<b>{n0(len(P))}</b>{FULLD} dias + hoje até {LH - 1:02d}h59</div><div>Veículos por hora<b>{n0(tv2 / NH)}</b>{n0(dia_v.mean())} por dia completo</div>'
       f'<div>Pedestres e cicl. por hora<b>{n0(tp2 / NH)}</b>todas as travessias</div><div>Veículos por viagem<b>{n1(P[~P.emb.astype(str).str.startswith("LS")].veic.sum() / nfb2)}</b>média das balsas</div>'
       f'<div>Hoje × período<b class={"up" if gv >= 0 else "dn"}>{pct(gv)}</b>veículos, 00h a {LH - 1:02d}h59</div></div>')
lst = lambda ob: '<div class=obs><ul>' + ''.join(f'<li>{x}</li>' for x in ob) + '</ul></div>'

html = f'''<div class=hero><div class=pat></div><div class=eb>Relatório executivo de volume transportado</div><h1>Volume médio por embarcação · hoje</h1>
<div class=per>{CUT:%d/%m/%Y} · de 00h00 até {CUT:%H:%M} (último registro) · todas as travessias</div><div class=w></div></div>
{kp1}
<h2><span class=n>1</span>Média por embarcação hoje</h2>{boat_tables(E1, "em operação")}
<div class=em>Carga média por viagem: veículos nas balsas (azul), pedestres e ciclistas nas lanchas (verde). Média por hora em operação = volume ÷ horas em que a embarcação fez ao menos uma saída.</div>
{lst(ob1)}
<h2><span class=n>2</span>Média por travessia hoje</h2>{trav_table(T1)}
<div class=em>Média por hora = volume de hoje ÷ {n1(HH)} horas (00h00 a {CUT:%H:%M}).</div>
<div class=crit>Média por hora = volume ÷ horas do período; pico = hora do dia com maior média; hoje × período = volume de hoje de 00h a {LH - 1:02d}h59 contra a média dos dias anteriores nas mesmas horas. Base: todos os registros do sistema de {D0:%d/%m} a {CUT:%d/%m} {CUT:%H:%M}; hora = início da travessia. Veículos em unidades, sem conversão em veículo equivalente. No período, cada hora do dia é média só dos dias em que ela está completa; a hora das {LH:02d}h de hoje, incompleta, entra apenas na página de hoje.</div>
<div class=pb></div>
<div class="hero h2x"><div class=pat></div><div class=eb>Análise do período</div><h1>Volume médio · {D0:%d/%m} a {CUT:%d/%m/%Y}</h1>
<div class=per>{FULLD} dias completos + {CUT:%d/%m} até {LH - 1:02d}h59 · todas as travessias</div><div class=w></div></div>
{kp2}
<h2><span class=n>3</span>Principais pontos</h2>{lst(ob2)}
<h2><span class=n>4</span>Média por travessia no período</h2>{trav_table(T2, True)}
<h2><span class=n>5</span>Média por embarcação no período</h2>{boat_tables(E2, "em operação")}
'''
css = open(G + 'base.css').read() + '''
.k5{grid-template-columns:repeat(5,1fr)!important;margin-bottom:2.5mm} .k5 div{font-size:6.4pt;padding:2mm 2.5mm} .k5 b{font-size:13pt}
.hero{padding:3mm 6mm 2.6mm;margin-bottom:2.5mm} .hero h1{font-size:17pt} .h2x{padding:2.4mm 6mm 2mm} .h2x h1{font-size:15pt}
h2{font-size:11pt;margin-top:2.5mm;margin-bottom:1.2mm}
.v th{font-size:5.8pt;padding:.6mm 1mm} .v td{font-size:6.6pt;padding:.2mm 1mm} .v tr.rg td{padding:.35mm 1mm;font-size:6pt} .v th.c{text-align:center} .v .sep{border-left:.3mm solid #C9DAE2}
.two{display:grid;grid-template-columns:1fr 1fr;gap:4mm;align-items:start} .bt td.bc{width:31mm;padding:.1mm 1mm}
.bw{display:flex;align-items:center;gap:1mm;height:3mm} .bw i{display:block;height:2.5mm;background:#005B7F;border-radius:.5mm;flex:none} .bw i.lp{background:#00B5AD}
.bw span{font-size:6.2pt;font-weight:700;color:#17303B;white-space:nowrap}
.em{font-size:6.2pt;color:#5E7480;margin:.8mm 0 1.5mm} .obs{font-size:7.4pt} .obs li{margin-bottom:.6mm} .crit{font-size:6pt;margin-top:1.5mm;color:#5E7480}
.pb{break-after:page} .up{color:#0A8A5A;font-weight:700} .dn{color:#C0392B;font-weight:700} .eq{color:#5E7480}
.kp b.up{color:#0A8A5A} .kp b.dn{color:#C0392B}'''
open('pagina2.html', 'w').write(f'<!doctype html><html lang=pt-BR><head><meta charset=utf-8><title>Volume médio</title><base href="file://{G}"><style>{css}</style></head><body>{html}</body></html>')
print(len(H), HH, len(E1), len(E2), gv, gp); print(pd.DataFrame(T1)[['lab', 'via', 'vh', 'ph', 'vv']].round(1).to_string())
print(R2[['lab', 'vh', 'ph', 'dv', 'dp']].round(2).to_string())
