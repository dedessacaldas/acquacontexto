"""Volume médio por hora em operação, por embarcação (pág. 1 = hoje 00h até o último registro; pág. 2 = período). python3 gen3.py"""
import pandas as pd, sys
sys.path.insert(0, '/mnt/project-files/relatorios-viagens/relatorio-diario/gerador')
from grades import ORDER
G = '/mnt/project-files/relatorios-viagens/relatorio-financeiro/gerador/'
d = pd.read_excel('export.xlsx')
d.columns = ['trav', 'abert', 'emb', 'bsm', 'dir', 'ie', 'te', 'ped', 'bic', 'moto', 'aut', 'micro', 'onib', 'c2', 'c3', 'c4', 'tipo', 'tt', 'td']
d['te'] = pd.to_datetime(d.te, dayfirst=True); d['emb'] = d.emb.astype(str)
d['modo'] = d.emb.str.startswith('LS').map({True: 'Lancha', False: 'Ferry boat'})
d['veic'] = d[['moto', 'aut', 'micro', 'onib', 'c2', 'c3', 'c4']].sum(axis=1); d['pas'] = d.ped + d.bic
d['dia'] = d.te.dt.normalize(); d['h'] = d.te.dt.hour
CUT = d.te.max(); D0 = d.dia.min(); LAST = CUT.normalize(); LH = CUT.hour
LAB = {(t, m): (reg, l) for reg, it in ORDER for t, m, l, q in it}
d['lab'] = [LAB.get((t, m), (None, t))[1] for t, m in zip(d.trav, d.modo)]
ORDL = [l for _, it in ORDER for t, m, l, q in it]
n0 = lambda x: f'{x:,.0f}'.replace(',', '.')
pct = lambda x: f'{"+" if x >= 0 else "−"}{abs(x) * 100:.0f}%'
SOPED = lambda l: any(k in l for k in ('lancha', 'Vicente', 'Ariri'))      # travessias só de pedestres

H = d[d.dia == LAST]                                   # hoje, 00h até o último registro
P = d[~((d.dia == LAST) & (d.h >= LH))]                # período, sem a hora incompleta de hoje
FULLD = P[P.dia < LAST].dia.nunique()
REF = d[(d.dia < LAST) & (d.h < LH)]; HC = H[H.h < LH]; NREF = REF.dia.nunique()

def stats(x):
    ho = x.groupby(['dia', 'h']).ngroups
    return dict(via=len(x), ho=ho, vh=x.veic.sum() / ho, ph=x.pas.sum() / ho, tv=x.veic.sum(), tp=x.pas.sum())

def bar(v, mx, cls, show=True):
    if not show: return '<td class=bc><span class=na>não transporta veículos</span></td>'
    w = 0 if mx == 0 else v / mx * 100
    return f'<td class=bc><div class=bw><div class=tr><i class={cls} style="width:{w:.1f}%"></i></div><span>{n0(v)}</span></div></td>'

def boats(x):
    E = []
    for (l, e), g in x.groupby(['lab', 'emb']):
        E.append(dict(lab=l, emb=e, **stats(g)))
    E = pd.DataFrame(E); E['o'] = E.lab.map({l: i for i, l in enumerate(ORDL)}).fillna(99)
    E['k'] = [p if SOPED(l) else v for l, v, p in zip(E.lab, E.vh, E.ph)]
    return E.sort_values(['o', 'k'], ascending=[True, False])

def boat_tables(E):
    mv = E[~E.lab.map(SOPED)].vh.max(); mp = E.ph.max()
    rows = []
    for l in ORDL:
        ee = E[E.lab == l]
        if not len(ee): continue
        rows.append((l, f'<tr class=rg><td colspan=5>{l}<em>{len(ee)} {"embarcação" if len(ee) == 1 else "embarcações"} · {n0(ee.via.sum())} viagens</em></td></tr>'))
        for b in ee.itertuples():
            rows.append((l, f'<tr><td class=m><b>{b.emb}</b></td><td class=r>{n0(b.via)}</td><td class=r>{n0(b.ho)}</td>{bar(b.vh, mv, "v", not SOPED(l))}{bar(b.ph, mp, "p")}</tr>'))
    half = (len(rows) + 1) // 2
    if rows[half - 1][1].startswith('<tr class=rg'): half -= 1
    L, R = rows[:half], rows[half:]
    if R and not R[0][1].startswith('<tr class=rg'): R = [(R[0][0], f'<tr class=rg><td colspan=5>{R[0][0]} (continuação)</td></tr>')] + R
    hd = ('<tr><th>Embarcação</th><th class=r>Viagens</th><th class=r>Horas em<br>operação</th><th>Veículos por hora<br>em operação</th>'
          '<th>Pedestres e ciclistas<br>por hora em operação</th></tr>')
    t = lambda rr: f'<table class="t v bt">{hd}{"".join(h for _, h in rr)}</table>'
    return f'<div class=two>{t(L)}{t(R)}</div>'

def trav_table(x, comp=False):
    T = []
    for l in ORDL:
        g = x[x.lab == l]
        if not len(g): continue
        s = stats(g); hv = g.groupby(['dia', 'h']).veic.sum().groupby('h').mean(); hp = g.groupby(['dia', 'h']).pas.sum().groupby('h').mean()
        s['pk'] = f'{(hp if SOPED(l) else hv).idxmax():02d}h'
        if comp:
            ref = REF[REF.lab == l]; hc = HC[HC.lab == l]
            a, b = (ref.pas.sum(), hc.pas.sum()) if SOPED(l) else (ref.veic.sum(), hc.veic.sum())
            s['dv'] = b / (a / NREF) - 1 if a / NREF >= 5 else None
        T.append(dict(lab=l, emb=g.emb.nunique(), **s))
    T = pd.DataFrame(T); mv = T[~T.lab.map(SOPED)].vh.max(); mp = T.ph.max()
    hd = ('<tr><th>Travessia</th><th class=r>Embarcações</th><th class=r>Viagens</th><th class=r>Horas em<br>operação</th><th>Veículos por hora em operação</th>'
          '<th>Pedestres e ciclistas por hora em operação</th><th class=r>Hora de maior<br>movimento</th>' + ('<th class=r>Hoje em relação<br>aos dias anteriores</th>' if comp else '') + '</tr>')
    b = ''
    for r in T.itertuples():
        b += f'<tr><td class=m>{r.lab}</td><td class=r>{r.emb}</td><td class=r>{n0(r.via)}</td><td class=r>{n0(r.ho)}</td>{bar(r.vh, mv, "v", not SOPED(r.lab))}{bar(r.ph, mp, "p")}<td class=r>{r.pk}</td>'
        if comp:
            b += '<td class=r>–</td>' if r.dv is None or pd.isna(r.dv) else f'<td class=r><span class={"up" if r.dv >= .03 else ("dn" if r.dv <= -.03 else "eq")}>{pct(r.dv)}</span></td>'
        b += '</tr>'
    return f'<table class="t v tt">{hd}{b}</table>', T

def destaques(E, T, quando):
    fb = E[~E.lab.map(SOPED) & (E.ho >= 3)]; ls = E[E.lab.map(SOPED) & (E.ho >= 3)]
    t = fb.sort_values('vh', ascending=False).head(3); tl = ls.sort_values('ph', ascending=False).head(2)
    o = [f'<b>Mais veículos por hora em operação {quando}:</b> ' + '; '.join(f'{b.emb} ({b.lab}) {n0(b.vh)}' for b in t.itertuples()) + '.',
         f'<b>Mais pedestres e ciclistas por hora em operação:</b> ' + '; '.join(f'{b.emb} ({b.lab}) {n0(b.ph)}' for b in tl.itertuples()) + '.']
    rg = []
    for l in ('Santos ⇄ Guarujá', 'São Sebastião ⇄ Ilhabela · balsa'):
        e = fb[(fb.lab == l) & (fb.vh >= 20)].sort_values('vh')
        if len(e) > 1: rg.append(f'em {l}, de {n0(e.vh.iloc[0])} ({e.emb.iloc[0]}) a {n0(e.vh.iloc[-1])} veículos ({e.emb.iloc[-1]})')
    if rg: o.append('<b>Diferença entre as balsas:</b> ' + '; '.join(rg) + '.')
    return '<div class=obs><ul>' + ''.join(f'<li>{x}</li>' for x in o) + '</ul></div>'

def cards(x, sub):
    hv = x.groupby('h').veic.sum() if x is H else x.groupby(['dia', 'h']).veic.sum().groupby('h').mean()
    return (f'<div class="kp k5"><div>Viagens realizadas<b>{n0(len(x))}</b>{sub}</div><div>Veículos transportados<b>{n0(x.veic.sum())}</b>todas as categorias</div>'
            f'<div>Pedestres e ciclistas transportados<b>{n0(x.pas.sum())}</b>balsas e lanchas</div><div>Embarcações em operação<b>{x.emb.nunique()}</b>em {x.lab.nunique()} travessias</div>'
            f'<div>Hora de maior movimento<b>{hv.idxmax():02d}h</b>{n0(hv.max())} veículos{" " if x is H else " em média "}nessa hora</div></div>')

E1 = boats(H); t1, T1 = trav_table(H); E2 = boats(P); t2, T2 = trav_table(P, True)
gv = HC.veic.sum() / (REF.veic.sum() / NREF) - 1; gp = HC.pas.sum() / (REF.pas.sum() / NREF) - 1
leg = '<div class=lg><span><i class=v></i>Veículos por hora em operação</span><span><i class=p></i>Pedestres e ciclistas por hora em operação</span><span>Hora em operação = cada hora em que a embarcação fez pelo menos uma viagem</span></div>'
html = f'''<div class=hero><div class=pat></div><div class=eb>Relatório de volume transportado</div><h1>Média por hora em operação de cada embarcação · hoje</h1>
<div class=per>{CUT:%d/%m/%Y}, de 00h00 até {CUT:%H:%M} (último registro) · todas as travessias</div><div class=w></div></div>
{cards(H, f"de 00h00 até {CUT:%H:%M}")}
<h2><span class=n>1</span>Média por hora em operação de cada embarcação hoje</h2>{leg}{boat_tables(E1)}
{destaques(E1, T1, "hoje")}
<h2><span class=n>2</span>Média por hora em operação de cada travessia hoje</h2>{t1}
<div class=crit>Base: todos os registros do sistema de {D0:%d/%m} a {CUT:%d/%m} às {CUT:%H:%M}. A hora de cada viagem é a hora de início da travessia. Veículos contados em unidades, sem conversão em veículo equivalente. Média por hora em operação = volume transportado ÷ número de horas em que houve pelo menos uma viagem. No período, a hora das {LH:02d}h de hoje, ainda incompleta, fica de fora.</div>
<div class=pb></div>
<div class="hero h2x"><div class=pat></div><div class=eb>Análise do período</div><h1>Média por hora em operação · {D0:%d/%m} a {CUT:%d/%m/%Y}</h1>
<div class=per>{FULLD} dias completos e {CUT:%d/%m} até {LH - 1:02d}h59 · todas as travessias</div><div class=w></div></div>
{cards(P, f"{FULLD} dias e hoje até {LH - 1:02d}h59")}
<h2><span class=n>3</span>Média por hora em operação de cada travessia no período</h2>{t2}
<div class=em>Hoje em relação aos dias anteriores: volume de hoje de 00h a {LH - 1:02d}h59 comparado à média dos {NREF} dias anteriores nas mesmas horas. No total, hoje teve <b>{pct(gv)} de veículos</b> e <b>{pct(gp)} de pedestres e ciclistas</b>.</div>
<h2><span class=n>4</span>Média por hora em operação de cada embarcação no período</h2>{leg}{boat_tables(E2)}
{destaques(E2, T2, "no período")}
'''
css = open(G + 'base.css').read() + '''
.k5{grid-template-columns:repeat(5,1fr)!important;margin-bottom:2.5mm} .k5 div{font-size:6.2pt;padding:1.4mm 2.5mm} .k5 b{font-size:13pt}
.hero{padding:2.4mm 6mm 2.2mm;margin-bottom:2mm} .hero h1{font-size:15pt} .h2x{padding:2.6mm 6mm 2.2mm}
h2{font-size:10.5pt;margin-top:2mm;margin-bottom:.8mm}
.v th{font-size:5.6pt;padding:.6mm 1mm;letter-spacing:.03em} .v td{font-size:6.6pt;padding:.12mm 1mm} .v tr.rg td{padding:.4mm 1mm;font-size:6pt}
.v tr.rg td em{float:right;font-style:normal;font-weight:400;letter-spacing:0;text-transform:none;color:#4F7F86}
.two{display:grid;grid-template-columns:1fr 1fr;gap:4mm;align-items:start} .bt td.bc{width:26mm} .bt th:nth-child(5){width:28mm} .tt td.bc{width:40mm}
.bw{display:flex;align-items:center;gap:1.2mm} .bw .tr{flex:1;height:2.6mm;background:#EEF4F7;border-radius:.5mm;overflow:hidden} .bw i{display:block;height:100%;border-radius:.5mm}
.bw i.v{background:#005B7F} .bw i.p{background:#00B5AD} .bw span{width:7mm;text-align:right;font-weight:700;font-size:6.5pt;color:#17303B}
.na{font-size:5.8pt;color:#8AA0AA;font-style:italic}
.lg{display:flex;gap:4mm;font-size:6.2pt;color:#5E7480;margin:0 0 1mm} .lg i{display:inline-block;width:3mm;height:2.2mm;border-radius:.4mm;margin-right:1mm;vertical-align:-.2mm} .lg i.v{background:#005B7F} .lg i.p{background:#00B5AD}
.em{font-size:6.3pt;color:#5E7480;margin:.6mm 0 1.2mm} .obs{font-size:7.2pt;padding:1.6mm 3.5mm} .obs li{margin-bottom:.5mm} .crit{font-size:6pt;margin-top:1.5mm;color:#5E7480}
.pb{break-after:page} .up{color:#0A8A5A;font-weight:700} .dn{color:#C0392B;font-weight:700} .eq{color:#5E7480}'''
open('pagina3.html', 'w').write(f'<!doctype html><html lang=pt-BR><head><meta charset=utf-8><title>Volume médio</title><base href="file://{G}"><style>{css}</style></head><body>{html}</body></html>')
print(T1[['lab', 'ho', 'vh', 'ph']].round(0).to_string()); print(gv, gp)
