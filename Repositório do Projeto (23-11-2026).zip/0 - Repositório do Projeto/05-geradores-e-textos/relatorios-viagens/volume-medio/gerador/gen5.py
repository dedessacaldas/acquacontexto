"""Média por hora em operação, versão simples: balsas e lanchas em tabelas separadas, total da travessia no topo. Pág. 1 = hoje; pág. 2 = período. python3 gen4.py"""
import pandas as pd, sys
sys.path.insert(0, '/mnt/project-files/relatorios-viagens/relatorio-diario/gerador')
from grades import ORDER
G = '/mnt/project-files/relatorios-viagens/relatorio-financeiro/gerador/'
d = pd.read_excel('export.xlsx')
d.columns = ['trav', 'abert', 'emb', 'bsm', 'dir', 'ie', 'te', 'ped', 'bic', 'moto', 'aut', 'micro', 'onib', 'c2', 'c3', 'c4', 'tipo', 'tt', 'td']
d['te'] = pd.to_datetime(d.te, dayfirst=True); d['emb'] = d.emb.astype(str)
d['modo'] = d.emb.str.startswith('LS').map({True: 'Lancha', False: 'Ferry boat'})
d['veic'] = d[['moto', 'aut', 'micro', 'onib', 'c2', 'c3', 'c4']].sum(axis=1); d['pas'] = d.ped + d.bic
d['dia'] = d.te.dt.normalize(); d['h'] = d.te.dt.hour
CUT = d.te.max(); D0 = d.dia.min(); LAST = CUT.normalize(); LH = CUT.hour
LAB = {(t, m): l for reg, it in ORDER for t, m, l, q in it}
d['lab'] = [LAB.get((t, m), t) for t, m in zip(d.trav, d.modo)]
ORDL = [l for _, it in ORDER for t, m, l, q in it]
n0 = lambda x: f'{x:,.0f}'.replace(',', '.')
H = d[d.dia == LAST]
P = d[~((d.dia == LAST) & (d.h >= LH))]
FULLD = P[P.dia < LAST].dia.nunique()
HH = (CUT - LAST).total_seconds() / 3600; NHP = FULLD * 24 + LH
n1 = lambda x: f'{x:.1f}'.replace('.', ',')

HORAS = {}                                             # divisor: horas do período (hoje: 00h até o último registro)
def st(x):
    ho = HORAS['h']
    return dict(via=len(x), ho=ho, vh=x.veic.sum() / ho, ph=x.pas.sum() / ho)

def barcell(v, mx, cls):
    return f'<td class=bc><div class=bw><div class=tr><i class={cls} style="width:{v / mx * 100 if mx else 0:.1f}%"></i></div><b>{n0(v)}</b></div></td>'

def tabela(x, lancha):
    x = x[x.modo == ('Lancha' if lancha else 'Ferry boat')]
    key = 'ph' if lancha else 'vh'
    B = pd.DataFrame([dict(lab=l, emb=e, **st(g)) for (l, e), g in x.groupby(['lab', 'emb'])])
    mx = B[key].max()
    hd = ('<tr><th>Embarcação</th><th class=r>Viagens</th>' +
          ('<th>Média de pedestres e ciclistas por hora</th>' if lancha else '<th>Média de veículos por hora</th><th class=r>Média de pedestres<br>e ciclistas por hora</th>') + '</tr>')
    body = ''
    for l in ORDL:
        bb = B[B.lab == l].sort_values(key, ascending=False)
        if not len(bb): continue
        t = st(x[x.lab == l]); ne = len(bb)
        body += (f'<tr class=gt><td>{l}<span>{ne} {"embarcação" if ne == 1 else "embarcações"}</span></td><td class=r>{n0(t["via"])}</td>' +
                 (f'<td class=r><b>{n0(t["ph"])}</b></td>' if lancha else f'<td class=r><b>{n0(t["vh"])}</b></td><td class=r>{n0(t["ph"])}</td>') + '</tr>')
        for b in bb.itertuples():
            body += (f'<tr><td class=e>{b.emb}</td><td class=r>{n0(b.via)}</td>' +
                     (barcell(b.ph, mx, 'p') if lancha else barcell(b.vh, mx, 'v') + f'<td class=r>{n0(b.ph)}</td>') + '</tr>')
    return f'<table class="t s {"ls" if lancha else "fb"}">{hd}{body}</table>'

def pagina(x, titulo, per, sub, horas):
    HORAS['h'] = horas
    return f'''<div class=hero><div class=pat></div><div class=eb>Volume transportado</div><h1>{titulo}</h1><div class=per>{per}</div><div class=w></div></div>
<div class="kp k3"><div>Viagens<b>{n0(len(x))}</b>{sub}</div><div>Veículos transportados<b>{n0(x.veic.sum())}</b>nas balsas</div><div>Pedestres e ciclistas transportados<b>{n0(x.pas.sum())}</b>nas balsas e lanchas</div></div>
<h2><span class=n>1</span>Balsas · média de veículos por hora</h2>{tabela(x, False)}
<h2><span class=n>2</span>Lanchas · média de pedestres e ciclistas por hora</h2>{tabela(x, True)}'''

nota = (f'<div class=crit><b>Como ler:</b> a linha em destaque é o total da travessia; abaixo, cada embarcação, da que mais transporta para a que menos transporta. '
        f'Média por hora = total transportado pela embarcação dividido pelo número de horas do período (hoje: de 00h00 até {CUT:%H:%M}, {n1(HH)} horas), inclusive as horas em que ela não operou; assim, a soma das embarcações dá o total da travessia. '
        f'Veículos contados em unidades (motos incluídas). Base: registros do sistema de {D0:%d/%m} a {CUT:%d/%m} às {CUT:%H:%M}; no período, a hora das {LH:02d}h de hoje, ainda incompleta, fica de fora.</div>')
html = (pagina(H, 'Média por hora de cada embarcação · hoje', f'{CUT:%d/%m/%Y} · média de 00h00 até {CUT:%H:%M} ({n1(HH)} horas)', f'de 00h00 até {CUT:%H:%M}', HH) + nota + '<div class=pb></div>' +
        pagina(P, f'Média por hora de cada embarcação · {D0:%d/%m} a {CUT:%d/%m}', f'média de {D0:%d/%m} 00h00 até {CUT:%d/%m} {LH - 1:02d}h59 ({n0(NHP)} horas)', f'{D0:%d/%m} a {CUT:%d/%m}', NHP))
css = open(G + 'base.css').read() + '''
.hero{padding:2.6mm 6mm 2.4mm;margin-bottom:2.5mm} .hero h1{font-size:17pt} .hero .per{font-size:9pt}
.k3{grid-template-columns:repeat(3,1fr)!important;margin-bottom:2mm} .k3 div{font-size:7pt;padding:1.6mm 3mm} .k3 b{font-size:15pt}
h2{font-size:11pt;margin:2mm 0 .8mm}
.s{font-size:7.2pt;margin-bottom:1mm} .s th{font-size:6pt;padding:.8mm 1.5mm} .s td{padding:.05mm 1.5mm;font-size:6.9pt;line-height:1.25}
.s th:first-child{width:62mm} .s td{white-space:nowrap} .s th:nth-child(2){width:18mm} .fb th:nth-child(4){width:30mm}
.s td.e{padding-left:5mm;color:#17303B;font-weight:700}
.s tr.gt td{background:#EAF3F6;border-top:.4mm solid #005B7F;font-weight:700;color:#005B7F;padding:.35mm 1.5mm;font-size:7.2pt}
.s tr.gt td span{font-weight:400;color:#5E7480;font-size:6.2pt;margin-left:2mm} .s tr.gt td b{font-size:8.4pt}
.bw{display:flex;align-items:center;gap:2mm} .bw .tr{flex:1;height:2.4mm;background:#F0F5F7;border-radius:.6mm;overflow:hidden} .bw i{display:block;height:100%;border-radius:.6mm}
.bw i.v{background:#005B7F} .bw i.p{background:#00B5AD} .bw b{width:9mm;text-align:right;color:#17303B}
.crit{font-size:6.3pt;margin-top:2mm;color:#5E7480;line-height:1.35} .crit b{color:#005B7F} .pb{break-after:page}'''
open('pagina5.html', 'w').write(f'<!doctype html><html lang=pt-BR><head><meta charset=utf-8><title>Volume médio</title><base href="file://{G}"><style>{css}</style></head><body>{html}</body></html>')
