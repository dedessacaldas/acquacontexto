"""Média por hora de cada embarcação — layout em cartões (pág. 1–2 hoje, 3–4 período). python3 gen7.py"""
import pandas as pd, sys
sys.path.insert(0, '/mnt/project-files/relatorios-viagens/relatorio-diario/gerador')
from grades import ORDER
G = '/mnt/project-files/relatorios-viagens/relatorio-financeiro/gerador/'
d = pd.read_excel('export.xlsx')
d.columns = ['trav', 'abert', 'emb', 'bsm', 'dir', 'ie', 'te', 'ped', 'bic', 'moto', 'aut', 'micro', 'onib', 'c2', 'c3', 'c4', 'tipo', 'tt', 'td']
d['te'] = pd.to_datetime(d.te, dayfirst=True); d['emb'] = d.emb.astype(str)
d['modo'] = d.emb.str.startswith('LS').map({True: 'Lancha', False: 'Ferry boat'})
d['veic'] = d[['moto', 'aut', 'micro', 'onib', 'c2', 'c3', 'c4']].sum(axis=1); d['pas'] = d.ped + d.bic
d['dia'] = d.te.dt.normalize(); d['h'] = d.te.dt.hour
CUT = d.te.max(); D0 = d.dia.min(); LAST = CUT.normalize(); LH = CUT.hour
LAB = {(t, m): l for reg, it in ORDER for t, m, l, q in it}
d['lab'] = [LAB.get((t, m), t) for t, m in zip(d.trav, d.modo)]
ORDL = [l for _, it in ORDER for t, m, l, q in it]
n0 = lambda x: f'{x:,.0f}'.replace(',', '.')
H = d[d.dia == LAST]
P = d[~((d.dia == LAST) & (d.h >= LH))]
FULLD = P[P.dia < LAST].dia.nunique()
HH = (CUT - LAST).total_seconds() / 3600; NHP = FULLD * 24 + LH
n1 = lambda x: f'{x:.1f}'.replace('.', ',')

HORAS = {}                                             # divisor: horas do período (hoje: 00h até o último registro)
def st(x):
    ho = HORAS['h']
    return dict(via=len(x), ho=ho, vh=x.veic.sum() / ho, ph=x.pas.sum() / ho, vv=x.veic.sum() / max(len(x), 1), pv=x.pas.sum() / max(len(x), 1))


def bar(v, mx, cls):
    return f'<div class=bw><div class=tr><i class={cls} style="width:{v / mx * 100 if mx else 0:.1f}%"></i></div><b>{n0(v)}</b></div>'

def cartoes(x, lancha):
    x = x[x.modo == ('Lancha' if lancha else 'Ferry boat')]
    key = 'ph' if lancha else 'vh'
    B = pd.DataFrame([dict(lab=l, emb=e, **st(g)) for (l, e), g in x.groupby(['lab', 'emb'])])
    mx = B[key].max(); out = ''
    for l in ORDL:
        bb = B[B.lab == l].sort_values(key, ascending=False)
        if not len(bb): continue
        t = st(x[x.lab == l]); ne = len(bb)
        if lancha:
            chips = f'<span><em>Pedestres e ciclistas por hora</em>{n0(t["ph"])}</span><span><em>Por viagem</em>{n1(t["pv"])}</span><span><em>Viagens</em>{n0(t["via"])}</span>'
            hd = '<tr><th>Embarcação</th><th>Média de pedestres e ciclistas por hora</th><th class=r>Média por viagem</th><th class="r vg">Viagens</th></tr>'
            rows = ''.join(f'<tr><td class=e>{b.emb}</td><td>{bar(b.ph, mx, "p")}</td><td class=r>{n1(b.pv)}</td><td class="r vg">{n0(b.via)}</td></tr>' for b in bb.itertuples())
        else:
            chips = f'<span><em>Veículos por hora</em>{n0(t["vh"])}</span><span><em>Por viagem</em>{n1(t["vv"])}</span><span><em>Pedestres por hora</em>{n0(t["ph"])}</span><span><em>Viagens</em>{n0(t["via"])}</span>'
            hd = '<tr><th>Embarcação</th><th>Média de veículos por hora</th><th class=r>Veículos por viagem</th><th class=r>Pedestres e ciclistas por hora</th><th class="r vg">Viagens</th></tr>'
            rows = ''.join(f'<tr><td class=e>{b.emb}</td><td>{bar(b.vh, mx, "v")}</td><td class=r>{n1(b.vv)}</td><td class="r mu">{n0(b.ph)}</td><td class="r vg">{n0(b.via)}</td></tr>' for b in bb.itertuples())
        out += (f'<div class="cd {"ls" if lancha else "fb"}"><div class=ch><div class=cn>{l}<small>{ne} {"embarcação" if ne == 1 else "embarcações"}</small></div>'
                f'<div class=chips>{chips}</div></div><table class=ct>{hd}{rows}</table></div>')
    return f'<div class="cards{" c3" if lancha else ""}">{out}</div>'

def podio(x):
    B = pd.DataFrame([dict(lab=l, emb=e, **st(g)) for (l, e), g in x.groupby(['lab', 'emb'])])
    fb = B[~B.emb.str.startswith('LS')]; ls = B[B.emb.str.startswith('LS')]
    a = fb.sort_values('vh', ascending=False).head(3); v = fb[fb.via >= 5].sort_values('vv', ascending=False).iloc[0]; p = ls.sort_values('ph', ascending=False).iloc[0]
    card = lambda c, tag, r, val, un: f'<div class="pd {c}"><div class=pt><i>{tag}</i><b>{r.emb}</b></div><strong>{val}</strong><em>{un}</em><small>{r.lab}</small></div>'
    it = ''.join(card('', f'{i}º', r, n0(r.vh), 'veículos por hora') for i, r in enumerate(a.itertuples(), 1))
    it += card('o', 'maior carga', v, n1(v.vv), 'veículos por viagem') + card('l', 'lancha', p, n0(p.ph), 'pedestres e ciclistas por hora')
    return f'<div class=pods>{it}</div>'

def grade(x, lancha, hrs, div):
    x = x[x.modo == ('Lancha' if lancha else 'Ferry boat')]
    col = 'pas' if lancha else 'veic'; rgb = '0,181,173' if lancha else '0,91,127'
    hd = '<tr><th>Embarcação</th>' + ''.join(f'<th>{h:02d}h</th>' for h in hrs) + '<th class=r>Média<br>por hora</th></tr>'
    body = ''
    for l in ORDL:
        g = x[x.lab == l]
        if not len(g): continue
        M = {e: pd.Series({h: gg[gg.h == h][col].sum() / div(h) for h in hrs}) for e, gg in g.groupby('emb')}
        order = sorted(M, key=lambda e: -M[e].sum()); mx = max(m.max() for m in M.values()) or 1
        tot = sum(M.values())
        body += (f'<tr class=gt><td>{l}</td>' + ''.join(f'<td{" class=k" if v >= 999.5 and len(hrs) > 20 else ""}>{n0(v) if v >= .5 else ""}</td>' for v in tot) +
                 f'<td class=r>{n0(g[col].sum() / HORAS["h"])}</td></tr>')
        for e in order:
            cells = ''
            for v in M[e]:
                a = v / mx
                cells += (f'<td><span style="background:rgba({rgb},{.12 + .83 * a:.2f});color:{"#fff" if a > .5 else "#17303B"}">{n0(v)}</span></td>' if v >= .5 else '<td></td>')
            body += f'<tr><td class=e>{e}</td>{cells}<td class=r><b>{n0(g[g.emb == e][col].sum() / HORAS["h"])}</b></td></tr>'
    leg = ''.join(f'<i style="background:rgba({rgb},{.12 + .83 * a:.2f})"></i>' for a in (0, .25, .5, .75, 1))
    return f'<div class=lgd>menos movimento {leg} mais movimento <span>(cor relativa à hora mais cheia de cada travessia)</span></div><table class=gr>{hd}{body}</table>'

def pagina(x, titulo, per, sub, horas, hrs, div, rot):
    HORAS['h'] = horas
    return f'''<div class=hero><div class=pat></div><div class=eb>Volume transportado</div><h1>{titulo}</h1><div class=per>{per}</div><div class=w></div></div>
<div class="kp k3"><div>Viagens<b>{n0(len(x))}</b>{sub}</div><div>Veículos transportados<b>{n0(x.veic.sum())}</b>nas balsas</div><div>Pedestres e ciclistas transportados<b>{n0(x.pas.sum())}</b>nas balsas e lanchas</div></div>
{podio(x)}
<h2><span class=n>1</span>Média por hora de cada embarcação</h2>
<h3 class=hv>Balsas</h3>{cartoes(x, False)}
<h3 class=hp>Lanchas</h3>{cartoes(x, True)}
<div class=keep><h2><span class=n>2</span>Média de hora em hora por embarcação</h2><div class=em>{rot}</div>
<h3 class=hv>Balsas · veículos</h3>{grade(x, False, hrs, div)}</div>
<div class=keep><h3 class=hp>Lanchas · pedestres e ciclistas</h3>{grade(x, True, hrs, div)}</div>'''

nota = (f'<div class=crit><b>Como ler:</b> cada cartão é uma travessia, com os totais no topo e as embarcações da que mais transporta para a que menos transporta. '
        f'Média por hora = total transportado pela embarcação ÷ número de horas do período (hoje: de 00h00 até {CUT:%H:%M}, {n1(HH)} horas), inclusive as horas em que ela não operou; a soma das embarcações dá o total da travessia. '
        f'Veículos contados em unidades (motos incluídas). Base: registros do sistema de {D0:%d/%m} a {CUT:%d/%m} às {CUT:%H:%M}; no período, a hora das {LH:02d}h de hoje, ainda incompleta, fica de fora.</div>')
html = (pagina(H, 'Média por hora de cada embarcação · hoje', f'{CUT:%d/%m/%Y} · de 00h00 até {CUT:%H:%M} ({n1(HH)} horas)', f'de 00h00 até {CUT:%H:%M}', HH, list(range(LH + 1)), lambda h: 1,
               f'Volume transportado em cada hora de hoje; a hora das {LH:02d}h vai até {CUT:%H:%M}. A última coluna é a média por hora da seção 1.') + nota + '<div class=pb></div>' +
        pagina(P, f'Média por hora de cada embarcação · {D0:%d/%m} a {CUT:%d/%m}', f'de {D0:%d/%m} 00h00 até {CUT:%d/%m} {LH - 1:02d}h59 ({n0(NHP)} horas)', f'{D0:%d/%m} a {CUT:%d/%m}', NHP, list(range(24)), lambda h: FULLD + (1 if h < LH else 0),
               'Volume médio transportado em cada hora do dia (total da hora ÷ número de dias em que ela aconteceu). A última coluna é a média por hora da seção 1.'))
css = open(G + 'base.css').read() + '''
.hero{padding:2.6mm 6mm 2.4mm;margin-bottom:2.5mm} .hero h1{font-size:17pt} .hero .per{font-size:9pt}
.k3{grid-template-columns:repeat(3,1fr)!important;margin-bottom:2mm} .k3 div{font-size:7pt;padding:1.6mm 3mm} .k3 b{font-size:15pt}
h2{font-size:11pt;margin:2.4mm 0 1.2mm}
h3{font-size:8.5pt;margin:1.6mm 0 1.2mm;text-transform:uppercase;letter-spacing:.12em;display:flex;align-items:center;gap:2mm}
h3::after{content:"";flex:1;height:.3mm;background:#D3E1E7} h3.hv{color:#005B7F} h3.hp{color:#008C86}
.pods{display:grid;grid-template-columns:repeat(5,1fr);gap:2mm;margin:0 0 1mm}
.pd{background:#F4F8FA;border-radius:1.8mm;padding:1.6mm 2.4mm;border-top:1mm solid #005B7F}
.pd .pt{display:flex;align-items:center;gap:1.4mm} .pd .pt i{font-style:normal;font-weight:900;font-size:5.6pt;color:#fff;background:#005B7F;border-radius:1mm;padding:.3mm 1.2mm;text-transform:uppercase;letter-spacing:.05em}
.pd .pt b{font-size:8.5pt;color:#17303B} .pd strong{display:block;font-size:15pt;font-weight:900;color:#005B7F;line-height:1.1;margin-top:.6mm}
.pd em{display:block;font-style:normal;font-size:5.8pt;color:#5E7480} .pd small{display:block;font-size:5.6pt;color:#8AA0AA;margin-top:.3mm}
.pd.o{border-top-color:#3D8FB0} .pd.o .pt i{background:#3D8FB0} .pd.o strong{color:#3D8FB0} .pd.l{border-top-color:#00B5AD} .pd.l .pt i{background:#00B5AD} .pd.l strong{color:#008C86}
.cards{column-count:2;column-gap:3.5mm} .cards.c3{column-count:3;column-gap:3mm} .c3 .cn small{display:block;margin:0}
.cd{break-inside:avoid;border:.3mm solid #D3E1E7;border-radius:2mm;overflow:hidden;margin:0 0 2.6mm;background:#fff}
.ch{background:#005B7F;color:#fff;padding:1.2mm 2.4mm 1.3mm} .ls .ch{background:#008C86}
.cn{font-weight:900;font-size:8.6pt} .cn small{font-weight:400;font-size:6pt;opacity:.8;margin-left:1.5mm}
.chips{display:flex;gap:3.5mm;margin-top:.4mm} .chips span{font-weight:900;font-size:9.5pt;line-height:1.05} .chips em{display:block;font-style:normal;font-weight:400;font-size:5.3pt;opacity:.8;letter-spacing:.02em}
.ct{width:100%;border-collapse:collapse;font-size:6.8pt;table-layout:fixed} .ct th:first-child{width:15mm} .fb .ct th:nth-child(3){width:14mm} .fb .ct th:nth-child(4){width:20mm} .ct th.vg{width:12mm} .ls .ct th:nth-child(3){width:12mm} .c3 .ct th.vg{width:10mm}
.ct th{font-size:5.6pt;color:#5E7480;font-weight:700;text-align:left;padding:.8mm 1.2mm .4mm;border-bottom:.3mm solid #D3E1E7;text-transform:none;letter-spacing:0;vertical-align:bottom;white-space:normal;line-height:1.15} .ct th.r{text-align:right}
.ct td{padding:.35mm 1.2mm;border-bottom:.15mm solid #EDF2F4} .ct tr:last-child td{border-bottom:0}
.ct td.e{font-weight:700;color:#17303B;white-space:nowrap;overflow:hidden} .ct .r{text-align:right} .ct td.mu{color:#5E7480}
.ct .vg{padding-left:3mm;color:#5E7480} .ct th.vg{color:#5E7480}
.bw{display:flex;align-items:center;gap:1.5mm} .bw .tr{flex:1;height:2.6mm;background:#F0F5F7;border-radius:1.3mm;overflow:hidden}
.bw i{display:block;height:100%;border-radius:1.3mm} .bw i.v{background:linear-gradient(90deg,#3D8FB0,#005B7F)} .bw i.p{background:linear-gradient(90deg,#5FD3CC,#00B5AD)}
.bw b{width:7mm;text-align:right;color:#17303B;font-size:7.4pt}
.em{font-size:6.4pt;color:#5E7480;margin:0 0 1mm}
.lgd{font-size:5.8pt;color:#5E7480;display:flex;align-items:center;gap:.8mm;margin:0 0 1mm} .lgd i{display:inline-block;width:4mm;height:2.4mm;border-radius:.6mm} .lgd span{margin-left:1.5mm}
.gr{width:100%;table-layout:fixed;border-collapse:separate;border-spacing:0 .35mm;font-size:5.9pt;margin-bottom:1.5mm}
.gr th{font-size:5.4pt;color:#5E7480;font-weight:700;text-align:center;padding:.4mm 0;border-bottom:.3mm solid #D3E1E7} .gr th:first-child{width:44mm;text-align:left;padding-left:1.5mm} .gr th:last-child{width:12mm;text-align:right;padding-right:1.5mm}
.gr td{text-align:center;padding:0 .25mm;height:3mm} .gr td span{display:block;border-radius:.7mm;line-height:2.9mm;font-weight:700} .keep{break-inside:avoid}
.gr td.e{text-align:left;padding-left:4.5mm;font-weight:700;color:#17303B;white-space:nowrap}
.gr td.r{text-align:right;padding-right:1.5mm;font-size:6.6pt;color:#17303B}
.gr tr.gt td{background:#EAF3F6;color:#005B7F;font-weight:700;font-size:5.8pt} .gr tr.gt td:first-child{text-align:left;border-radius:1mm 0 0 1mm;padding-left:1.5mm;font-size:6.6pt;white-space:nowrap;overflow:hidden}
.gr tr.gt td:last-child{border-radius:0 1mm 1mm 0;font-size:7pt} .gr td.k{font-size:4.4pt!important;letter-spacing:-.1pt}
.crit{font-size:6.2pt;margin-top:2mm;color:#5E7480;line-height:1.35;border-top:.3mm solid #D3E1E7;padding-top:1.2mm} .crit b{color:#005B7F} .pb{break-after:page}'''
open('pagina7.html', 'w').write(f'<!doctype html><html lang=pt-BR><head><meta charset=utf-8><title>Volume médio</title><base href="file://{G}"><style>{css}</style></head><body>{html}</body></html>')
