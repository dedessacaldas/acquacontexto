"""Volume transportado São Sebastião ⇄ Ilhabela, 19/11/2026 (00:00 até o último registro). python3 gen.py"""
import pandas as pd
G = '/mnt/project-files/relatorios-viagens/relatorio-financeiro/gerador/'
d = pd.read_excel('export_1911.xlsx')
d.columns = ['trav', 'abert', 'emb', 'bsm', 'dir', 'ie', 'te', 'ped', 'bic', 'moto', 'aut', 'micro', 'onib', 'c2', 'c3', 'c4', 'tipo', 'tt', 'td']
for c in ['ie', 'te', 'tt', 'td']: d[c] = pd.to_datetime(d[c], dayfirst=True)
d = d[d.trav.str.contains('Sebasti')].sort_values('te')
d['serv'] = d.emb.str.startswith('LS').map({True: 'Lancha', False: 'Balsa'})
d['margem'] = d.dir.str[0].map({'1': 'São Sebastião', '2': 'Ilhabela'})
d['cam'] = d.c2 + d.c3 + d.c4; d['onm'] = d.micro + d.onib
d['veic'] = d.moto + d.aut + d.onm + d.cam
d['pas'] = d.ped + d.bic
d['h'] = d.te.dt.hour
CUT = d.te.max()
n0 = lambda x: f'{x:,.0f}'.replace(',', '.')
pc = lambda a, b: '–' if not b else f'{100 * a / b:.0f}%'
z = lambda v: n0(v) if v else '–'
V = ['ped', 'bic', 'moto', 'aut', 'onm', 'cam']
VL = {'ped': 'Pedestres', 'bic': 'Bicicletas', 'moto': 'Motos', 'aut': 'Automóveis', 'onm': 'Micro-ônibus, vans e ônibus', 'cam': 'Caminhões'}
S = d[V + ['veic', 'pas']].sum()
B, L = d[d.serv == 'Balsa'], d[d.serv == 'Lancha']

# 1. por serviço e margem
def lin(lab, g, cls=''):
    return (f'<tr class="{cls}"><td class=m>{lab}</td><td class=r><b>{n0(len(g))}</b></td>' + ''.join(f'<td class=r>{z(g[c].sum())}</td>' for c in V)
            + f'<td class="r sep"><b>{z(g.pas.sum())}</b></td><td class=r><b>{z(g.veic.sum())}</b></td><td class=r>{n0(g.veic.sum() / len(g)) if len(g) and g.veic.sum() else "–"}</td></tr>')
t1 = ''
for sv in ['Balsa', 'Lancha']:
    g = d[d.serv == sv]
    t1 += f'<tr class=rg><td colspan=11>{sv}{" · veículos e pedestres" if sv == "Balsa" else " · pedestres e ciclistas"}</td></tr>'
    for mg in ['São Sebastião', 'Ilhabela']: t1 += lin(f'Saídas de {mg}', g[g.margem == mg])
    t1 += lin(f'Total {sv.lower()}', g, 'st')
t1 += lin('Total da travessia', d, 'tot')
h1 = ('<tr><th>Serviço / margem</th><th class=r>Viagens</th>' + ''.join(f'<th class=r>{VL[c]}</th>' for c in V)
      + '<th class="r sep">Pedestres e cicl.</th><th class=r>Veículos</th><th class=r>Veículos por viagem</th></tr>')

# 2. por hora (gráfico + tabela)
hrs = list(range(0, CUT.hour + 1))
P = d.pivot_table(index='h', columns=['serv', 'margem'], values='veic', aggfunc='sum').reindex(hrs).fillna(0)
W, H, pl, pr, pb, pt = 760, 135, 34, 34, 22, 12
hv = d.groupby('h').veic.sum().reindex(hrs).fillna(0); hp = d.groupby('h').pas.sum().reindex(hrs).fillna(0)
mx = max(hv.max(), 1) * 1.15; mp = max(hp.max(), 1) * 1.15
bw = (W - pl - pr) / len(hrs); ch = H - pb - pt
s = [f'<svg class=chart viewBox="0 0 {W} {H}">']
for k in range(5):
    v = mx * k / 4; y = H - pb - v / mx * ch
    s.append(f'<line class=grid x1={pl} x2={W - pr} y1={y:.1f} y2={y:.1f} /><text class=ax x={pl - 4} y={y + 2.5:.1f} text-anchor=end>{n0(v)}</text><text class=ax x={W - pr + 4} y={y + 2.5:.1f} style="fill:#008C86">{n0(mp * k / 4)}</text>')
pts = []
for i, h in enumerate(hrs):
    x = pl + i * bw + bw * .12; w = bw * .76; y0 = H - pb
    a = d[(d.h == h) & (d.serv == 'Balsa') & (d.margem == 'São Sebastião')].veic.sum(); b = d[(d.h == h) & (d.serv == 'Balsa') & (d.margem == 'Ilhabela')].veic.sum()
    ha, hb = a / mx * ch, b / mx * ch
    s.append(f'<rect x={x:.1f} y={y0 - ha:.1f} width={w:.1f} height={ha:.1f} fill="#005B7F" rx=1 /><rect x={x:.1f} y={y0 - ha - hb:.1f} width={w:.1f} height={hb:.1f} fill="#6FA8C2" rx=1 />')
    if a + b: s.append(f'<text x={x + w / 2:.1f} y={y0 - ha - hb - 2:.1f} text-anchor=middle style="font-size:6.5px;font-weight:700;fill:#005B7F">{n0(a + b)}</text>')
    s.append(f'<text class=ax x={x + w / 2:.1f} y={H - 9} text-anchor=middle>{h:02d}h</text>')
    pts.append((x + w / 2, y0 - hp[h] / mp * ch))
s.append('<polyline fill=none stroke="#00B5AD" stroke-width=1.6 points="' + ' '.join(f'{x:.1f},{y:.1f}' for x, y in pts) + '" />')
s += [f'<circle cx={x:.1f} cy={y:.1f} r=1.8 fill="#00B5AD" />' for x, y in pts]
s.append('</svg>')
rows = ''
for h in hrs:
    g = d[d.h == h]
    cells = ''
    for sv, mg in [('Balsa', 'São Sebastião'), ('Balsa', 'Ilhabela'), ('Lancha', 'São Sebastião'), ('Lancha', 'Ilhabela')]:
        x = g[(g.serv == sv) & (g.margem == mg)]
        cells += f'<td class="r sep">{z(len(x))}</td>' + (f'<td class=r>{z(x.veic.sum())}</td><td class=r>{z(x.ped.sum())}</td>' if sv == 'Balsa' else f'<td class=r>{z(x.pas.sum())}</td>')
    hot = g.veic.sum() == hv.max()
    rows += f'<tr class="{"hot" if hot else ""}"><td class=m>{h:02d}h{"*" if h == CUT.hour else ""}</td>{cells}<td class="r sep"><b>{n0(len(g))}</b></td><td class=r><b>{z(g.pas.sum())}</b></td><td class=r><b>{z(g.veic.sum())}</b></td></tr>'
tt = ''
for sv, mg in [('Balsa', 'São Sebastião'), ('Balsa', 'Ilhabela'), ('Lancha', 'São Sebastião'), ('Lancha', 'Ilhabela')]:
    x = d[(d.serv == sv) & (d.margem == mg)]
    tt += f'<td class="r sep">{n0(len(x))}</td>' + (f'<td class=r>{n0(x.veic.sum())}</td><td class=r>{n0(x.ped.sum())}</td>' if sv == 'Balsa' else f'<td class=r>{n0(x.pas.sum())}</td>')
rows += f'<tr class=tot><td class=m>Total</td>{tt}<td class="r sep">{n0(len(d))}</td><td class=r>{n0(S.pas)}</td><td class=r>{n0(S.veic)}</td></tr>'
h2 = ('<tr><th rowspan=2>Hora</th><th colspan=3 class="c sep">Balsa · saídas de São Sebastião</th><th colspan=3 class="c sep">Balsa · saídas de Ilhabela</th>'
      '<th colspan=2 class="c sep">Lancha · S. Sebastião</th><th colspan=2 class="c sep">Lancha · Ilhabela</th><th colspan=3 class="c sep">Total</th></tr><tr>'
      + '<th class="r sep">Viag.</th><th class=r>Veíc.</th><th class=r>Ped.</th>' * 2 + '<th class="r sep">Viag.</th><th class=r>Ped.+bic.</th>' * 2
      + '<th class="r sep">Viag.</th><th class=r>Ped.+bic.</th><th class=r>Veíc.</th></tr>')

# 3. por embarcação
E = d.groupby(['serv', 'emb']).agg(v=('emb', 'size'), p=('te', 'min'), u=('te', 'max'), pas=('pas', 'sum'), veic=('veic', 'sum'), cam=('cam', 'sum')).reset_index().sort_values(['serv', 'v'], ascending=[True, False])
t3 = ''.join(f'<tr><td class=m>{r.emb}</td><td>{r.serv}</td><td class=r>{n0(r.v)}</td><td class=r>{r.p:%H:%M}</td><td class=r>{r.u:%H:%M}</td><td class=r>{z(r.pas)}</td><td class=r>{z(r.veic)}</td><td class=r>{z(r.cam)}</td>'
             f'<td class=r>{n0(r.veic / r.v) if r.veic else "–"}</td></tr>' for r in E.itertuples())
# composição dos veículos (barra)
cmp_ = [(VL[c], S[c], col) for c, col in [('aut', '#005B7F'), ('moto', '#00B5AD'), ('cam', '#E39B2D'), ('onm', '#7D5BA6')]]
bar = '<div class=cb>' + ''.join(f'<i style="width:{100 * v / S.veic:.2f}%;background:{c}"></i>' for _, v, c in cmp_ if v) + '</div><div class=cl>' + ''.join(f'<span><i style="background:{c}"></i>{l} <b>{n0(v)}</b> ({pc(v, S.veic)})</span>' for l, v, c in cmp_) + '</div>'

pk = hv.idxmax(); pkp = hp.idxmax()
bs = B.groupby('margem').veic.sum()
inf = d.tipo.notna().sum()
obs = [f'<b>Até {CUT:%H:%M}:</b> {n0(len(d))} viagens ({n0(len(B))} de balsa e {n0(len(L))} de lancha), {n0(S.veic)} veículos e {n0(S.pas)} pedestres e ciclistas.',
       f'<b>Pico de veículos:</b> {pk:02d}h, com {n0(hv[pk])} veículos; pico de pedestres e ciclistas às {pkp:02d}h ({n0(hp[pkp])}).',
       f'<b>Sentido:</b> nas balsas, {n0(bs.get("São Sebastião", 0))} veículos saíram de São Sebastião e {n0(bs.get("Ilhabela", 0))} de Ilhabela ({pc(bs.get("São Sebastião", 0), bs.sum())} no sentido Ilhabela).',
       f'<b>Lancha:</b> {n0(L.pas.sum())} pedestres e ciclistas em {n0(len(L))} viagens ({n0(L.pas.sum() / len(L)) if len(L) else 0} por viagem); a balsa levou {n0(B.ped.sum())} pedestres e {n0(B.bic.sum())} bicicletas.',
       f'<b>Caminhões:</b> {n0(S.cam)} ({n0(d.c2.sum())} de 2 eixos, {n0(d.c3.sum())} de 3 e {n0(d.c4.sum())} de 4 ou mais).']
if inf: obs.append(f'<b>Registros marcados no sistema:</b> {inf} viagens com tipo "{", ".join(d.tipo.dropna().astype(str).str.upper().unique())}", incluídas nos totais.')
html = f'''<div class=hero><div class=pat></div><div class=eb>Relatório de volume transportado</div><h1>São Sebastião ⇄ Ilhabela</h1>
<div class=per>Quinta-feira, 19/11/2026 · das 00:00 às {CUT:%H:%M} (último registro do sistema) · balsa e lancha</div><div class=w></div></div>
<div class="kp k6"><div>Viagens<b>{n0(len(d))}</b>{n0(len(B))} balsa · {n0(len(L))} lancha</div><div>Veículos<b>{n0(S.veic)}</b>{n0(S.veic / len(B)) if len(B) else 0} por viagem de balsa</div>
<div>Pedestres<b>{n0(S.ped)}</b>{n0(L.ped.sum())} na lancha</div><div>Bicicletas<b>{n0(S.bic)}</b>{n0(L.bic.sum())} na lancha</div>
<div>Caminhões<b>{n0(S.cam)}</b>{pc(S.cam, S.veic)} dos veículos</div><div>Embarcações<b>{d.emb.nunique()}</b>{B.emb.nunique()} balsas · {L.emb.nunique()} lanchas</div></div>
<h2><span class=n>1</span>Por serviço e margem</h2><table class="t hm v">{h1}{t1}</table>
<h3>Composição dos veículos</h3>{bar}
<div class=obs><ul>{"".join(f"<li>{x}</li>" for x in obs)}</ul></div>
<h2><span class=n>2</span>Por hora</h2><div class=cbox><div class=lg><i style="background:#005B7F;margin-left:0"></i>Veículos na balsa · saídas de São Sebastião<i style="background:#6FA8C2"></i>saídas de Ilhabela<i style="background:#00B5AD;height:.6mm;vertical-align:.6mm"></i>Pedestres e ciclistas, balsa + lancha (eixo da direita)</div>{"".join(s)}</div>
<table class="t hm v">{h2}{rows}</table>
<h2><span class=n>3</span>Por embarcação</h2><table class="t hm v"><tr><th>Embarcação</th><th>Serviço</th><th class=r>Viagens</th><th class=r>1ª saída</th><th class=r>Última</th><th class=r>Pedestres e cicl.</th><th class=r>Veículos</th><th class=r>Caminhões</th><th class=r>Veículos por viagem</th></tr>{t3}</table>
<ol class=crit><li>Base: registros do sistema de São Sebastião ⇄ Ilhabela com início de travessia em 19/11/2026, das 00:00 às {CUT:%H:%M}. Hora = hora do início da travessia (término do embarque); * hora incompleta, até {CUT:%H:%M}.</li>
<li>Balsa = embarcações FB (veículos e pedestres); lancha = LS (pedestres e ciclistas). Veículos = motos, automóveis, micro-ônibus, vans, ônibus e caminhões, em unidades (sem conversão em veículo equivalente).</li></ol>'''
css = open(G + 'base.css').read() + '''
.k6{grid-template-columns:repeat(6,1fr)!important;margin-bottom:3mm} .k6 div{font-size:6.6pt} .k6 b{font-size:14pt}
.hero{padding:4mm 6mm 3.5mm;margin-bottom:3mm} .hero h1{font-size:20pt}
h2{font-size:12pt;margin-top:3.5mm} h3{margin:2.5mm 0 1mm;font-size:9pt}
.v th{font-size:5.8pt;padding:.7mm 1mm} .v td{font-size:7pt;padding:.5mm 1mm} .v th.c{text-align:center} .v .sep{border-left:.3mm solid #C9DAE2}
.qt tr.st td,tr.st td{background:#E8F1F5;font-weight:700;color:#005B7F}
tr.hot td{background:#FFF4E0}
.cb{display:flex;height:4mm;border-radius:2mm;overflow:hidden;margin:.5mm 0 1mm} .cb i{display:block;height:100%}
.cl{display:flex;gap:4mm;font-size:7pt;color:#5E7480;margin-bottom:2mm} .cl i{display:inline-block;width:2.6mm;height:2.6mm;border-radius:.5mm;margin-right:1mm;vertical-align:-.3mm} .cl b{color:#17303B}
.obs{font-size:7.4pt} .crit{font-size:6.8pt;margin-top:3mm}'''
open('pagina.html', 'w').write(f'<!doctype html><html lang=pt-BR><head><meta charset=utf-8><title>Volume SSI</title><base href="file://{G}"><style>{css}</style></head><body>{html}</body></html>')
print(len(d), S.to_dict(), CUT, pk, hv[pk])
