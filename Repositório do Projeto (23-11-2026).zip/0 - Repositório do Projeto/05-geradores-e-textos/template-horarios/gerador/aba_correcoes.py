import openpyxl, sys, pickle
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
wb = openpyxl.load_workbook(sys.argv[1]); P = pickle.load(open(sys.argv[1] + '.pkl', 'rb'))
def rng(trav, rota=None, reg=None):
    rs = [R['row'] for R in P if R['v'][1] == trav and (rota is None or R['v'][2] == rota) and (reg is None or R['v'][3] == reg)]
    return f'{min(rs)}–{max(rs)}'
ws = wb.create_sheet('Correções', 0)
ws['A1'] = 'Correções da REV03 para a REV04 (conferidas com as viagens realizadas de 09 a 15/11/2026)'
ws['A1'].font = Font(bold=True, size=13, color='FFFFFF'); ws['A1'].fill = PatternFill('solid', fgColor='0B3B5C')
ws.merge_cells('A1:F1')
H = ['#', 'Travessia', 'O que estava na REV03', 'Como ficou na REV04', 'Aderência ao praticado (horários fixos cumpridos de −10 a +15 min, 09–15/11)', 'Linhas na Unificada']
ws.append([]); ws.append(H)
D = [
 (1, 'Santos ⇄ Vicente de Carvalho',
  'Uma única rota "Santos ↔ Vicente de Carvalho" com os horários da margem de Vicente de Carvalho, aplicados também a Santos (dias úteis, sábados, domingos e feriados).',
  'Separada em "Santos → Vicente de Carvalho" e "Santos ← Vicente de Carvalho", como as demais travessias com horários diferentes por margem. Santos: madrugada 00:00 00:40 01:20 02:00 03:00 04:00 04:40; dias úteis 05:18–08:42 a cada 12, 09:00–15:40 a cada 20, 16:06–19:06 a cada 12, 19:15–20:00 a cada 15, 20:20–22:40 a cada 20, 22:54 e 23:25; sábados 05:18–08:42 a cada 12 (intercalado) e 09:00–22:40 a cada 20; domingos e feriados 05:20–22:40 a cada 20. Vicente de Carvalho manteve os horários da REV03.',
  'Santos: 448 de 511 (87,7%) → 510 de 511 (99,8%). Vicente de Carvalho: 510 de 511 nas duas versões.',
  rng('Santos/Vicente de Carvalho')),
 (2, 'Bertioga ⇄ Guarujá',
  'Grade "Todos os dias" com os mesmos horários nas duas margens (07:00–13:00 a cada 20, 13:20–16:00 a cada 40, 16:30–17:50 a cada 20 e 18:00–06:40 a cada 40).',
  'Continua "Todos os dias", agora com os horários próprios de cada margem (49 saídas por margem), conforme a grade ajustada em 03/11: tarde Bertioga 13:20, 14:00, 14:40, 15:20, 16:00 e Guarujá 13:40, 14:20, 15:00, 15:40, 16:20; madrugada Bertioga 00:20, 01:00… e Guarujá 00:00, 00:40…',
  'Bertioga: 213 de 343 (62,1%) → 329 de 343 (95,9%). Guarujá: 305 de 343 (88,9%) → 328 de 343 (95,6%). Sábado 14/11 e domingo 15/11 seguiram essa mesma grade (46 e 49 de 49). As faltas restantes são quase todas de 09/11, antes do ajuste da tarde.',
  rng('Bertioga/Guarujá')),
 (3, 'Cananéia → Continente',
  'Saída das 04:30 na margem de Cananéia.',
  'Saída das 04:00, que é a praticada todos os dias (04:00 em 7 de 7 dias). A saída das 04:30 é da margem do Continente e continua lá.',
  '154 de 161 (95,7%) → 161 de 161 (100%).',
  [str(R['row']) for R in P if R['v'][1] == 'Cananeia/Continente' and R['m'] == 240][0]),
 (4, 'Taquacetuba ⇄ Bororé',
  'Rota escrita "Taquecetuba ↔ Bororé".',
  'Grafia corrigida para "Taquacetuba ↔ Bororé" (igual à coluna Travessia). Horários sem alteração; travessia sem operação no período.',
  'Sem viagens no período.', rng('Taquacetuba')),
 (5, 'Paraitinga e Taquacetuba',
  'Algumas linhas conforme demanda com "Frequência / Janela" em branco.',
  'Preenchidas com "-", como nas demais linhas conforme demanda. Não muda nenhum horário.', '—', '—'),
 (6, 'Abas "Horário Fixo" e "Conforme Demanda"',
  'Cópias em valores da Unificada (695 fixos e 724 conforme demanda).',
  'Regeradas a partir da Unificada corrigida: 902 linhas de horário fixo e 724 conforme demanda. As tabelas e a formatação condicional foram ajustadas ao novo tamanho.', '—', '—'),
]
for d in D: ws.append(list(d))
ws.append([])
ws.append(['', 'Mantido como está (pontos para decidir)'])
N = [
 ('São Sebastião ⇄ Ilhabela · lancha', 'A grade prevê saídas de hora em hora (São Sebastião 06:30–19:30, Ilhabela 07:00–20:00), mas a lancha sai a cada 30 min todos os dias: São Sebastião também por volta de 05:30, 06:00, 07:00… e Ilhabela 06:00, 06:30, 07:30… Não alterei porque a grade de hora em hora é a do contrato e as saídas extras contam como adicionais.'),
 ('Varginha e Paraitinga · madrugada', 'Os horários fixos das 00h às 05h ficam sem saída em alguns dias (Paraitinga em 09/11; Varginha em 09, 13 e 15/11). A grade segue o Anexo 3A; não alterei.'),
]
for a, b in N: ws.append(['', a, b])
thin = Side(style='thin', color='BFC9D1')
for c in range(1, 7):
    h = ws.cell(3, c); h.font = Font(bold=True, color='FFFFFF'); h.fill = PatternFill('solid', fgColor='1F6F8B')
    h.alignment = Alignment(wrap_text=True, vertical='center')
for r in range(4, ws.max_row+1):
    for c in range(1, 7):
        x = ws.cell(r, c); x.alignment = Alignment(wrap_text=True, vertical='top')
        if r <= 3+len(D): x.border = Border(top=thin, bottom=thin, left=thin, right=thin)
ws.cell(4+len(D)+1, 2).font = Font(bold=True, color='0B3B5C', size=12)
for r in range(4+len(D)+2, ws.max_row+1): ws.merge_cells(start_row=r, start_column=3, end_row=r, end_column=6); ws.cell(r, 2).font = Font(bold=True); ws.row_dimensions[r].height = 48
for col, w in zip('ABCDEF', (4, 26, 48, 70, 42, 14)): ws.column_dimensions[col].width = w
ws.freeze_panes = 'A4'
wb.active = 0
wb.save(sys.argv[2])
