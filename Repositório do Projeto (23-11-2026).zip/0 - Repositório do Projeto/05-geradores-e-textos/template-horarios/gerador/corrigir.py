# Corrige o Template_Horarios_Detalhado (REV03 -> REV04) segundo o praticado (09-15/11/2026) e a grade validada.
import openpyxl, copy, sys, datetime as dt
from openpyxl.worksheet.table import Table
SRC, OUT = sys.argv[1], sys.argv[2]
wb = openpyxl.load_workbook(SRC)
U = wb['Unificada']
NC = 15
def hm(s): h, m = map(int, s.split(':')); return h*60+m
def L(s): return [hm(x) for x in s.split()]
def step(a, b, st): return list(range(hm(a), hm(b)+1, st))
ULT = 'Última partida do intervalo'
CHAIN = '=G{p} + TIME(0, IF(ISNUMBER(H{p}), H{p}, IF(ISNUMBER(I{p}), I{p}, 0)), 0)'
ECOD = '=IF(D{r}="Todos os dias", "TODOS_OS_DIAS", IF(OR(D{r}="Dias Úteis", D{r}="Segunda a Sexta"), "DU", IF(D{r}="Sábados", "SAB", IF(D{r}="Domingos e Feriados", "DOM/FER", IF(D{r}="Sábados, Domingos e Feriados", "SAB_DOM_FER", IF(D{r}="Segunda-feira", "SEG", IF(D{r}="Terça-feira", "TER", IF(D{r}="Quarta-feira", "QUA", IF(D{r}="Quinta-feira", "QUI", IF(D{r}="Sexta-feira", "SEX", "OUTRO"))))))))))'
CODE = {"Todos os dias": "TODOS_OS_DIAS", "Dias Úteis": "DU", "Segunda a Sexta": "DU", "Sábados": "SAB", "Domingos e Feriados": "DOM/FER",
        "Sábados, Domingos e Feriados": "SAB_DOM_FER", "Segunda-feira": "SEG", "Terça-feira": "TER", "Quarta-feira": "QUA", "Quinta-feira": "QUI", "Sexta-feira": "SEX"}

# ---- leitura: cada linha vira um registro (valores fixos + tipo de G)
rows = []
for r in range(2, U.tables['Tb_Unificado'].ref and int(U.tables['Tb_Unificado'].ref.split(':')[1][1:]) + 1):
    v = [U.cell(r, c).value for c in range(1, NC+1)]
    g = v[6]
    rows.append(dict(v=v, lit=not (isinstance(g, str) and g.startswith('=')), src=r))

def enc(times):
    """Lista de minutos -> [(minuto, literal, H, I)] na lógica do Excel: blocos de intervalo constante (>=3 saídas)
    encadeados por fórmula; última do bloco = 'Última partida do intervalo' + intervalo até o próximo bloco; saídas avulsas = N/A."""
    t = sorted(times); n = len(t); blocks = []; i = 0
    while i < n:
        j = i
        if i+1 < n:
            g = t[i+1]-t[i]; j = i+1
            while j+1 < n and t[j+1]-t[j] == g: j += 1
        if j-i+1 >= 3: blocks.append(('run', i, j, g)); i = j+1
        else: blocks.append(('one', i, i, None)); i += 1
    out = []
    for bi, (k, a, b, g) in enumerate(blocks):
        prev = blocks[bi-1] if bi else None
        nxt = blocks[bi+1] if bi+1 < len(blocks) else None
        if k == 'one':
            out.append((t[a], True, 'N/A', 'N/A')); continue
        for x in range(a, b+1):
            lit = (x == a) and not (prev and prev[0] == 'run')
            if x < b: out.append((t[x], lit, g, '-'))
            else: out.append((t[x], lit, ULT, (t[b+1]-t[b]) if nxt and nxt[0] == 'run' else '-'))
    return out

def novo_bloco(base, rota, regime, times, embarque=None):
    out = []
    for m, lit, H, I in enc(times):
        v = list(base['v']); v[2] = rota; v[3] = regime; v[4] = None
        if embarque: v[5] = embarque
        v[6] = dt.time(m//60 % 24, m % 60) if lit else 'CHAIN'; v[7] = H; v[8] = I; v[9] = 'FIX'
        out.append(dict(v=v, lit=lit, src=None, novo=True))
    return out

# ---- grades praticadas
VS0 = L('00:00 00:40 01:20 02:00 03:00 04:00 04:40'); VV0 = L('00:20 01:00 01:40 02:30 03:30 04:20')
SVC = {
 'Dias Úteis': (VS0 + step('05:18','08:42',12) + step('09:00','15:40',20) + step('16:06','19:06',12) + step('19:15','20:00',15) + step('20:20','22:40',20) + L('22:54 23:25'),
                VV0 + step('05:00','08:24',12) + step('08:40','15:40',20) + step('16:00','19:00',12) + step('19:15','20:00',15) + step('20:20','22:40',20) + L('23:10 23:40')),
 'Sábados': (VS0 + step('05:18','08:42',12) + step('09:00','22:40',20) + L('22:54 23:25'),
             VV0 + step('05:00','08:24',12) + step('08:40','22:40',20) + L('23:10 23:40')),
 'Domingos e Feriados': (VS0 + step('05:20','22:40',20) + L('22:54 23:25'),
                         VV0 + step('05:00','22:40',20) + L('23:10 23:40')),
}
BER = {
 'Todos os dias': (L('00:20 01:00 01:40 02:20 03:00 03:40 04:20 05:00 05:40 06:20 06:40') + step('07:00','12:40',20) + L('13:00 13:20 14:00 14:40 15:20 16:00 16:40 17:00 17:20 17:40 18:00 18:20 19:00 19:40 20:20 21:00 21:40 22:20 23:00 23:40'),
                L('00:00 00:40 01:20 02:00 02:40 03:20 04:00 04:40 05:20 06:00 06:40') + step('07:00','12:40',20) + L('13:00 13:40 14:20 15:00 15:40 16:20 16:40 17:00 17:20 17:40 18:00 18:20 18:40 19:20 20:00 20:40 21:20 22:00 22:40 23:20')),
}
# ---- reconstrução
new = []; i = 0; done = set()
while i < len(rows):
    R = rows[i]; v = R['v']; trav = v[1]
    if trav == 'Santos/Vicente de Carvalho' or trav == 'Bertioga/Guarujá':
        blk = [x for x in rows if x['v'][1] == trav]
        if trav not in done:
            base = blk[0]
            if trav == 'Santos/Vicente de Carvalho':
                for reg, (vs, vv) in SVC.items():
                    new += novo_bloco(base, 'Santos → Vicente de Carvalho', reg, vs)
                    new += novo_bloco(base, 'Santos ← Vicente de Carvalho', reg, vv)
            else:
                for reg, (bb, bg) in BER.items():
                    new += novo_bloco(base, 'Bertioga → Guarujá', reg, bb)
                    new += novo_bloco(base, 'Bertioga ← Guarujá', reg, bg)
            done.add(trav)
        i += 1; continue
    R = dict(R, v=list(v))
    if v[2] == 'Taquecetuba ↔ Bororé': R['v'][2] = 'Taquacetuba ↔ Bororé'; R['fix_nome'] = True
    if v[1] == 'Cananeia/Continente' and v[2] == 'Cananéia → Continente' and v[6] == dt.time(4, 30): R['v'][6] = dt.time(4, 0); R['fix_cc'] = True
    if v[7] is None: R['v'][7] = '-'; R['fix_h'] = True
    new.append(R); i += 1

# estilos de referência (linha literal e encadeada da SVC original)
def style_src(kind):
    for x in rows:
        if x['v'][1] == 'Santos/Vicente de Carvalho' and x['lit'] == (kind == 'lit'): return x['src']
SL, SC = style_src('lit'), style_src('chain')
snap = {r: [copy.copy(U.cell(r, c)._style) for c in range(1, NC+1)] for r in range(2, U.max_row+1)}
last_old = rows[-1]['src']
blank_style = snap[last_old+1] if last_old+1 in snap else snap[2]

# limpa área
for r in range(2, U.max_row+1):
    for c in range(1, NC+1): U.cell(r, c).value = None
for k, R in enumerate(new):
    r = k+2; v = R['v']
    src = R['src'] or (SL if R['lit'] else SC)
    for c in range(1, NC+1):
        cell = U.cell(r, c); cell._style = copy.copy(snap[src][c-1])
        val = v[c-1]
        if c == 7 and not R['lit']: val = CHAIN.format(p=r-1)
        if c == 5: val = ECOD.format(r=r)
        cell.value = val
    R['row'] = r
end = len(new)+1
for r in range(end+1, U.max_row+1):
    for c in range(1, NC+1): U.cell(r, c)._style = copy.copy(blank_style[c-1])
U.tables['Tb_Unificado'].ref = f'A1:O{end}'
# formatação condicional acompanha o novo tamanho
from openpyxl.formatting.formatting import ConditionalFormattingList
old = U.conditional_formatting; U.conditional_formatting = ConditionalFormattingList()
for cf in old:
    rng = str(cf.sqref); a, b = rng.split(':'); col = ''.join(ch for ch in b if ch.isalpha())
    for rule in cf.rules: U.conditional_formatting.add(f'{a}:{col}{end}', rule)

# ---- horários calculados (para as abas filtradas e conferência)
def mins(R, prev):
    g = R['v'][6]
    if R['lit']: return g.hour*60+g.minute
    p = prev['v']; inc = p[7] if isinstance(p[7], (int, float)) else (p[8] if isinstance(p[8], (int, float)) else 0)
    return prev['m'] + inc
prev = None
for R in new:
    R['m'] = mins(R, prev); prev = R

def vig(v): a, b = v[12], v[13]; return (b.year-a.year)*12 + b.month-a.month
def kemb(v): return 'Ferry Boat' if v[5] == 'Veículos e Pedestres' else 'Lancha'

for name, tipo in (('Horário Fixo', 'FIX'), ('Conforme Demanda', 'DEM')):
    S = wb[name]; tname = list(S.tables)[0]
    ss = {r: [copy.copy(S.cell(r, c)._style) for c in range(1, NC+1)] for r in range(2, min(S.max_row, 3000)+1)}
    ref_lit = next(r for r in ss if not isinstance(S.cell(r, 7).value, str) and S.cell(r, 7).font.b) if any(S.cell(r,7).font.b for r in ss) else 2
    ref_n = next(r for r in ss if not S.cell(r, 7).font.b)
    for r in range(2, S.max_row+1):
        for c in range(1, NC+1): S.cell(r, c).value = None
    sel = [R for R in new if R['v'][9] == tipo]
    for k, R in enumerate(sel):
        r = k+2; v = list(R['v'])
        v[4] = CODE.get(v[3], 'OUTRO'); v[6] = dt.time(R['m']//60 % 24, R['m'] % 60); v[10] = kemb(v); v[14] = vig(v)
        st = ss[ref_lit if R['lit'] else ref_n]
        for c in range(1, NC+1):
            S.cell(r, c)._style = copy.copy(st[c-1]); S.cell(r, c).value = v[c-1]
    e = len(sel)+1
    S.tables[tname].ref = f'A1:O{e}'
    old = S.conditional_formatting; S.conditional_formatting = ConditionalFormattingList()
    for cf in old:
        a, b = str(cf.sqref).split(':'); col = ''.join(ch for ch in b if ch.isalpha())
        for rule in cf.rules: S.conditional_formatting.add(f'{a}:{col}{e}', rule)
    print(name, len(sel))

import pickle; pickle.dump([dict(v=R['v'][:4]+[R['v'][9]], m=R['m'], row=R['row'], novo=R.get('novo', False)) for R in new], open(OUT + '.pkl', 'wb'))
wb.calculation.fullCalcOnLoad = True
wb._correcoes = None
wb.save(OUT)
print('linhas', len(new), 'fim', end)
