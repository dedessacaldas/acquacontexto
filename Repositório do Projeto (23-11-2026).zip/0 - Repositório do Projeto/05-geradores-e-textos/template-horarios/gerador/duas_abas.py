# Arquivo final só com as abas "Horário Fixo" e "Conforme Demanda" (faixas da Dedessa, 16/11/2026 18h).
import openpyxl, copy, sys, datetime as dt
from openpyxl.worksheet.table import Table, TableStyleInfo
from openpyxl.formatting.formatting import ConditionalFormattingList
SRC, OUT = sys.argv[1], sys.argv[2]
wb = openpyxl.load_workbook(SRC)
T = lambda s: dt.time(*map(int, s.split(':')))
FAIXAS = [  # Região, Rota, Tipo de Embarque, Início, Fim, Intervalo máx., Embarcação (como enviado pela Dedessa)
 ('Litoral Norte', 'São Sebastião ↔ Ilhabela', 'Veículos e Pedestres', '05:30', '23:30', 30),
 ('Litoral Norte', 'São Sebastião ↔ Ilhabela', 'Pedestres e Ciclistas', '06:00', '23:30', 30),
 ('Litoral Centro', 'Santos ↔ Guarujá', 'Dias Úteis (6h30-20h00)', '06:30', '20:00', 12),
 ('Litoral Centro', 'Santos ↔ Guarujá', 'Dias Úteis (demais)', '05:00', '06:30', 20),
 ('Litoral Centro', 'Santos ↔ Guarujá', 'Dias Úteis (demais)', '20:00', '06:30', 20),
 ('Litoral Centro', 'Santos ↔ Guarujá', 'Sábados (9h00-20h30)', '09:00', '20:30', 12),
 ('Litoral Centro', 'Santos ↔ Guarujá', 'Sábados (demais)', '06:30', '09:00', 15),
 ('Litoral Centro', 'Santos ↔ Guarujá', 'Sábados (demais)', '20:30', '06:30', 15),
 ('Litoral Centro', 'Santos ↔ Guarujá', 'Domingos/Feriados (9h00-21h00)', '09:00', '21:00', 12),
 ('Litoral Centro', 'Santos ↔ Guarujá', 'Domingos/Feriados (demais)', '05:00', '09:00', 20),
 ('Litoral Centro', 'Santos ↔ Guarujá', 'Domingos/Feriados (demais)', '21:00', '05:00', 20),
 ('Paraibuna', 'Natividade ↔ Pouso Alto ↔ Bairro Alto', 'Dias Úteis (8h00-20h00)', '08:00', '20:00', 20),
 ('Paraibuna', 'Natividade ↔ Pouso Alto ↔ Bairro Alto', 'Dias Úteis (demais)', '06:00', '08:00', 40),
 ('Paraibuna', 'Natividade ↔ Pouso Alto ↔ Bairro Alto', 'Dias Úteis (demais)', '20:00', '23:20', 40),
 ('Paraibuna', 'Natividade ↔ Pouso Alto ↔ Bairro Alto', 'Sáb., Dom. e Feriados (10h00-12h00 e 16h00-20h00)', '10:00', '12:00', 20),
 ('Paraibuna', 'Natividade ↔ Pouso Alto ↔ Bairro Alto', 'Sáb., Dom. e Feriados (10h00-12h00 e 16h00-20h00)', '16:00', '20:00', 20),
 ('Paraibuna', 'Natividade ↔ Pouso Alto ↔ Bairro Alto', 'Sáb., Dom. e Feriados (demais)', '06:00', '10:00', 40),
 ('Paraibuna', 'Natividade ↔ Pouso Alto ↔ Bairro Alto', 'Sáb., Dom. e Feriados (demais)', '12:00', '16:00', 40),
 ('Paraibuna', 'Natividade ↔ Pouso Alto ↔ Bairro Alto', 'Sáb., Dom. e Feriados (demais)', '20:00', '23:20', 40),
 ('Paraibuna', "Capim D'Angola ↔ Ribeirão Branco", 'Veículos e Pedestres', '06:00', '23:20', 40),
 ('Paraibuna', 'Comércio ↔ Varginha', 'Veículos e Pedestres', '06:00', '23:15', 45),
 ('Metropolitana', 'Taquacetuba ↔ Bororé', 'Dias Úteis (5h00-22h00)', '05:00', '22:00', 40),
 ('Metropolitana', 'Taquacetuba ↔ Bororé', 'Dias Úteis (demais)', '22:00', '05:00', 60),
 ('Metropolitana', 'Taquacetuba ↔ Bororé', 'Sáb., Dom. e Feriados (6h00-01h00)', '06:00', '01:00', 40),
 ('Metropolitana', 'Taquacetuba ↔ Bororé', 'Sáb., Dom. e Feriados (demais)', '01:00', '06:00', 60),
]
for _r, _rota in (('Metropolitana', 'Bororé ↔ Grajaú'), ('Metropolitana', 'João Basso ↔ Riacho Grande')):
    FAIXAS += [(_r, _rota, 'Dias Úteis (7h00-19h00)', '07:00', '19:00', 20),
               (_r, _rota, 'Dias Úteis (demais)', '05:00', '07:00', 40),
               (_r, _rota, 'Dias Úteis (demais)', '19:00', '01:00', 40),
               (_r, _rota, 'Dias Úteis (demais)', '01:00', '05:00', 60),
               (_r, _rota, 'Sáb., Dom. e Feriados (9h00-19h00)', '09:00', '19:00', 20),
               (_r, _rota, 'Sáb., Dom. e Feriados (demais)', '06:00', '09:00', 30),
               (_r, _rota, 'Sáb., Dom. e Feriados (demais)', '19:00', '01:00', 30),
               (_r, _rota, 'Sáb., Dom. e Feriados (demais)', '01:00', '06:00', 60)]
# ---- Horário Fixo: tira o que passou a ser coberto pelas faixas
H = wb['Horário Fixo']; NC = 15
rows = []
for r in range(2, H.max_row+1):
    v = [H.cell(r, c).value for c in range(1, NC+1)]
    if v[1] is None: continue
    rows.append((v, [copy.copy(H.cell(r, c)._style) for c in range(1, NC+1)]))
def coberto(v):
    trav, emb, t = v[1], v[5], v[6]
    if trav == 'Santos/Guarujá': return True                      # faixas cobrem as 24 h nos 3 tipos de dia
    if trav == 'São Sebastião/Ilhabela':
        if emb == 'Pedestres e Ciclistas': return True              # lancha: 06:00–23:30 conforme demanda
        return T('05:30') <= t <= T('23:30')
    return False
fica = [x for x in rows if not coberto(x[0])]
removidos = len(rows) - len(fica)
blank = [copy.copy(H.cell(H.max_row+5, c)._style) for c in range(1, NC+1)]
for r in range(2, H.max_row+1):
    for c in range(1, NC+1): H.cell(r, c).value = None; H.cell(r, c)._style = copy.copy(blank[c-1])
for k, (v, st) in enumerate(fica):
    for c in range(1, NC+1):
        H.cell(k+2, c).value = v[c-1]; H.cell(k+2, c)._style = st[c-1]
eH = len(fica)+1
list(H.tables.values())[0].ref = f'A1:O{eH}'
old = H.conditional_formatting; H.conditional_formatting = ConditionalFormattingList()
for cf in old:
    a, b = str(cf.sqref).split(':'); col = ''.join(ch for ch in b if ch.isalpha())
    for rule in cf.rules: H.conditional_formatting.add(f'{a}:{col}{eH}', rule)
# ---- Conforme Demanda: uma linha por faixa, sem desdobrar horários
old = wb['Conforme Demanda']
hstyle = copy.copy(old.cell(1, 1)._style)
idx = wb.sheetnames.index('Conforme Demanda'); wb.remove(old)
C = wb.create_sheet('Conforme Demanda', idx)
cab = ['Região', 'Rota', 'Tipo de Embarque', 'Hora Início', 'Hora Fim', 'Intervalo Máximo', 'Embarcação']
C.append(cab)
for c in range(1, 8): C.cell(1, c)._style = copy.copy(hstyle)
for f in FAIXAS:
    C.append([f[0], f[1], f[2], T(f[3]), T(f[4]), f[5], 'Ferry Boat / Lancha'])
for r in range(2, C.max_row+1):
    C.cell(r, 4).number_format = C.cell(r, 5).number_format = 'hh:mm'
    C.cell(r, 6).number_format = '0 "minutos"'
tb = Table(displayName='Tb_ConformeDemanda', ref=f'A1:G{C.max_row}')
tb.tableStyleInfo = TableStyleInfo(name='TableStyleLight1', showRowStripes=True)
C.add_table(tb)
for col, w in zip('ABCDEFG', (15, 36, 46, 13, 13, 19, 20)): C.column_dimensions[col].width = w
C.freeze_panes = 'A2'
for n in ('Unificada', 'Correções'):
    if n in wb.sheetnames: wb.remove(wb[n])
wb.active = 0
wb.calculation.fullCalcOnLoad = True
wb.save(OUT)
print('fixos', len(fica), 'removidos', removidos, 'faixas', len(FAIXAS))
